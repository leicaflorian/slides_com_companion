// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function (modules, entry, mainEntry, parcelRequireName, globalName) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        this
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      var res = localRequire.resolve(x);
      return res === false ? {} : newRequire(res);
    }

    function resolve(x) {
      var id = modules[name][1][x];
      return id != null ? id : x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [
      function (require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  Object.defineProperty(newRequire, 'root', {
    get: function () {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function () {
        return mainExports;
      });

      // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }
})({"80kME":[function(require,module,exports) {
var global = arguments[3];
var HMR_HOST = null;
var HMR_PORT = 1234;
var HMR_SECURE = false;
var HMR_ENV_HASH = "d6ea1d42532a7575";
module.bundle.HMR_BUNDLE_ID = "58a71ad23812323c";
"use strict";
/* global HMR_HOST, HMR_PORT, HMR_ENV_HASH, HMR_SECURE, chrome, browser, __parcel__import__, __parcel__importScripts__, ServiceWorkerGlobalScope */ /*::
import type {
  HMRAsset,
  HMRMessage,
} from '@parcel/reporter-dev-server/src/HMRServer.js';
interface ParcelRequire {
  (string): mixed;
  cache: {|[string]: ParcelModule|};
  hotData: {|[string]: mixed|};
  Module: any;
  parent: ?ParcelRequire;
  isParcelRequire: true;
  modules: {|[string]: [Function, {|[string]: string|}]|};
  HMR_BUNDLE_ID: string;
  root: ParcelRequire;
}
interface ParcelModule {
  hot: {|
    data: mixed,
    accept(cb: (Function) => void): void,
    dispose(cb: (mixed) => void): void,
    // accept(deps: Array<string> | string, cb: (Function) => void): void,
    // decline(): void,
    _acceptCallbacks: Array<(Function) => void>,
    _disposeCallbacks: Array<(mixed) => void>,
  |};
}
interface ExtensionContext {
  runtime: {|
    reload(): void,
    getURL(url: string): string;
    getManifest(): {manifest_version: number, ...};
  |};
}
declare var module: {bundle: ParcelRequire, ...};
declare var HMR_HOST: string;
declare var HMR_PORT: string;
declare var HMR_ENV_HASH: string;
declare var HMR_SECURE: boolean;
declare var chrome: ExtensionContext;
declare var browser: ExtensionContext;
declare var __parcel__import__: (string) => Promise<void>;
declare var __parcel__importScripts__: (string) => Promise<void>;
declare var globalThis: typeof self;
declare var ServiceWorkerGlobalScope: Object;
*/ var OVERLAY_ID = "__parcel__error__overlay__";
var OldModule = module.bundle.Module;
function Module(moduleName) {
    OldModule.call(this, moduleName);
    this.hot = {
        data: module.bundle.hotData[moduleName],
        _acceptCallbacks: [],
        _disposeCallbacks: [],
        accept: function(fn) {
            this._acceptCallbacks.push(fn || function() {});
        },
        dispose: function(fn) {
            this._disposeCallbacks.push(fn);
        }
    };
    module.bundle.hotData[moduleName] = undefined;
}
module.bundle.Module = Module;
module.bundle.hotData = {};
var checkedAssets /*: {|[string]: boolean|} */ , assetsToDispose /*: Array<[ParcelRequire, string]> */ , assetsToAccept /*: Array<[ParcelRequire, string]> */ ;
function getHostname() {
    return HMR_HOST || (location.protocol.indexOf("http") === 0 ? location.hostname : "localhost");
}
function getPort() {
    return HMR_PORT || location.port;
}
// eslint-disable-next-line no-redeclare
var parent = module.bundle.parent;
if ((!parent || !parent.isParcelRequire) && typeof WebSocket !== "undefined") {
    var hostname = getHostname();
    var port = getPort();
    var protocol = HMR_SECURE || location.protocol == "https:" && !/localhost|127.0.0.1|0.0.0.0/.test(hostname) ? "wss" : "ws";
    var ws;
    try {
        ws = new WebSocket(protocol + "://" + hostname + (port ? ":" + port : "") + "/");
    } catch (err) {
        if (err.message) console.error(err.message);
        ws = {};
    }
    // Web extension context
    var extCtx = typeof browser === "undefined" ? typeof chrome === "undefined" ? null : chrome : browser;
    // Safari doesn't support sourceURL in error stacks.
    // eval may also be disabled via CSP, so do a quick check.
    var supportsSourceURL = false;
    try {
        (0, eval)('throw new Error("test"); //# sourceURL=test.js');
    } catch (err) {
        supportsSourceURL = err.stack.includes("test.js");
    }
    // $FlowFixMe
    ws.onmessage = async function(event /*: {data: string, ...} */ ) {
        checkedAssets = {} /*: {|[string]: boolean|} */ ;
        assetsToAccept = [];
        assetsToDispose = [];
        var data /*: HMRMessage */  = JSON.parse(event.data);
        if (data.type === "update") {
            // Remove error overlay if there is one
            if (typeof document !== "undefined") removeErrorOverlay();
            let assets = data.assets.filter((asset)=>asset.envHash === HMR_ENV_HASH);
            // Handle HMR Update
            let handled = assets.every((asset)=>{
                return asset.type === "css" || asset.type === "js" && hmrAcceptCheck(module.bundle.root, asset.id, asset.depsByBundle);
            });
            if (handled) {
                console.clear();
                // Dispatch custom event so other runtimes (e.g React Refresh) are aware.
                if (typeof window !== "undefined" && typeof CustomEvent !== "undefined") window.dispatchEvent(new CustomEvent("parcelhmraccept"));
                await hmrApplyUpdates(assets);
                // Dispose all old assets.
                let processedAssets = {} /*: {|[string]: boolean|} */ ;
                for(let i = 0; i < assetsToDispose.length; i++){
                    let id = assetsToDispose[i][1];
                    if (!processedAssets[id]) {
                        hmrDispose(assetsToDispose[i][0], id);
                        processedAssets[id] = true;
                    }
                }
                // Run accept callbacks. This will also re-execute other disposed assets in topological order.
                processedAssets = {};
                for(let i = 0; i < assetsToAccept.length; i++){
                    let id = assetsToAccept[i][1];
                    if (!processedAssets[id]) {
                        hmrAccept(assetsToAccept[i][0], id);
                        processedAssets[id] = true;
                    }
                }
            } else fullReload();
        }
        if (data.type === "error") {
            // Log parcel errors to console
            for (let ansiDiagnostic of data.diagnostics.ansi){
                let stack = ansiDiagnostic.codeframe ? ansiDiagnostic.codeframe : ansiDiagnostic.stack;
                console.error("\uD83D\uDEA8 [parcel]: " + ansiDiagnostic.message + "\n" + stack + "\n\n" + ansiDiagnostic.hints.join("\n"));
            }
            if (typeof document !== "undefined") {
                // Render the fancy html overlay
                removeErrorOverlay();
                var overlay = createErrorOverlay(data.diagnostics.html);
                // $FlowFixMe
                document.body.appendChild(overlay);
            }
        }
    };
    ws.onerror = function(e) {
        if (e.message) console.error(e.message);
    };
    ws.onclose = function() {
        console.warn("[parcel] \uD83D\uDEA8 Connection to the HMR server was lost");
    };
}
function removeErrorOverlay() {
    var overlay = document.getElementById(OVERLAY_ID);
    if (overlay) {
        overlay.remove();
        console.log("[parcel] \u2728 Error resolved");
    }
}
function createErrorOverlay(diagnostics) {
    var overlay = document.createElement("div");
    overlay.id = OVERLAY_ID;
    let errorHTML = '<div style="background: black; opacity: 0.85; font-size: 16px; color: white; position: fixed; height: 100%; width: 100%; top: 0px; left: 0px; padding: 30px; font-family: Menlo, Consolas, monospace; z-index: 9999;">';
    for (let diagnostic of diagnostics){
        let stack = diagnostic.frames.length ? diagnostic.frames.reduce((p, frame)=>{
            return `${p}
<a href="/__parcel_launch_editor?file=${encodeURIComponent(frame.location)}" style="text-decoration: underline; color: #888" onclick="fetch(this.href); return false">${frame.location}</a>
${frame.code}`;
        }, "") : diagnostic.stack;
        errorHTML += `
      <div>
        <div style="font-size: 18px; font-weight: bold; margin-top: 20px;">
          \u{1F6A8} ${diagnostic.message}
        </div>
        <pre>${stack}</pre>
        <div>
          ${diagnostic.hints.map((hint)=>"<div>\uD83D\uDCA1 " + hint + "</div>").join("")}
        </div>
        ${diagnostic.documentation ? `<div>\u{1F4DD} <a style="color: violet" href="${diagnostic.documentation}" target="_blank">Learn more</a></div>` : ""}
      </div>
    `;
    }
    errorHTML += "</div>";
    overlay.innerHTML = errorHTML;
    return overlay;
}
function fullReload() {
    if ("reload" in location) location.reload();
    else if (extCtx && extCtx.runtime && extCtx.runtime.reload) extCtx.runtime.reload();
}
function getParents(bundle, id) /*: Array<[ParcelRequire, string]> */ {
    var modules = bundle.modules;
    if (!modules) return [];
    var parents = [];
    var k, d, dep;
    for(k in modules)for(d in modules[k][1]){
        dep = modules[k][1][d];
        if (dep === id || Array.isArray(dep) && dep[dep.length - 1] === id) parents.push([
            bundle,
            k
        ]);
    }
    if (bundle.parent) parents = parents.concat(getParents(bundle.parent, id));
    return parents;
}
function updateLink(link) {
    var href = link.getAttribute("href");
    if (!href) return;
    var newLink = link.cloneNode();
    newLink.onload = function() {
        if (link.parentNode !== null) // $FlowFixMe
        link.parentNode.removeChild(link);
    };
    newLink.setAttribute("href", // $FlowFixMe
    href.split("?")[0] + "?" + Date.now());
    // $FlowFixMe
    link.parentNode.insertBefore(newLink, link.nextSibling);
}
var cssTimeout = null;
function reloadCSS() {
    if (cssTimeout) return;
    cssTimeout = setTimeout(function() {
        var links = document.querySelectorAll('link[rel="stylesheet"]');
        for(var i = 0; i < links.length; i++){
            // $FlowFixMe[incompatible-type]
            var href /*: string */  = links[i].getAttribute("href");
            var hostname = getHostname();
            var servedFromHMRServer = hostname === "localhost" ? new RegExp("^(https?:\\/\\/(0.0.0.0|127.0.0.1)|localhost):" + getPort()).test(href) : href.indexOf(hostname + ":" + getPort());
            var absolute = /^https?:\/\//i.test(href) && href.indexOf(location.origin) !== 0 && !servedFromHMRServer;
            if (!absolute) updateLink(links[i]);
        }
        cssTimeout = null;
    }, 50);
}
function hmrDownload(asset) {
    if (asset.type === "js") {
        if (typeof document !== "undefined") {
            let script = document.createElement("script");
            script.src = asset.url + "?t=" + Date.now();
            if (asset.outputFormat === "esmodule") script.type = "module";
            return new Promise((resolve, reject)=>{
                var _document$head;
                script.onload = ()=>resolve(script);
                script.onerror = reject;
                (_document$head = document.head) === null || _document$head === void 0 || _document$head.appendChild(script);
            });
        } else if (typeof importScripts === "function") {
            // Worker scripts
            if (asset.outputFormat === "esmodule") return import(asset.url + "?t=" + Date.now());
            else return new Promise((resolve, reject)=>{
                try {
                    importScripts(asset.url + "?t=" + Date.now());
                    resolve();
                } catch (err) {
                    reject(err);
                }
            });
        }
    }
}
async function hmrApplyUpdates(assets) {
    global.parcelHotUpdate = Object.create(null);
    let scriptsToRemove;
    try {
        // If sourceURL comments aren't supported in eval, we need to load
        // the update from the dev server over HTTP so that stack traces
        // are correct in errors/logs. This is much slower than eval, so
        // we only do it if needed (currently just Safari).
        // https://bugs.webkit.org/show_bug.cgi?id=137297
        // This path is also taken if a CSP disallows eval.
        if (!supportsSourceURL) {
            let promises = assets.map((asset)=>{
                var _hmrDownload;
                return (_hmrDownload = hmrDownload(asset)) === null || _hmrDownload === void 0 ? void 0 : _hmrDownload.catch((err)=>{
                    // Web extension fix
                    if (extCtx && extCtx.runtime && extCtx.runtime.getManifest().manifest_version == 3 && typeof ServiceWorkerGlobalScope != "undefined" && global instanceof ServiceWorkerGlobalScope) {
                        extCtx.runtime.reload();
                        return;
                    }
                    throw err;
                });
            });
            scriptsToRemove = await Promise.all(promises);
        }
        assets.forEach(function(asset) {
            hmrApply(module.bundle.root, asset);
        });
    } finally{
        delete global.parcelHotUpdate;
        if (scriptsToRemove) scriptsToRemove.forEach((script)=>{
            if (script) {
                var _document$head2;
                (_document$head2 = document.head) === null || _document$head2 === void 0 || _document$head2.removeChild(script);
            }
        });
    }
}
function hmrApply(bundle /*: ParcelRequire */ , asset /*:  HMRAsset */ ) {
    var modules = bundle.modules;
    if (!modules) return;
    if (asset.type === "css") reloadCSS();
    else if (asset.type === "js") {
        let deps = asset.depsByBundle[bundle.HMR_BUNDLE_ID];
        if (deps) {
            if (modules[asset.id]) {
                // Remove dependencies that are removed and will become orphaned.
                // This is necessary so that if the asset is added back again, the cache is gone, and we prevent a full page reload.
                let oldDeps = modules[asset.id][1];
                for(let dep in oldDeps)if (!deps[dep] || deps[dep] !== oldDeps[dep]) {
                    let id = oldDeps[dep];
                    let parents = getParents(module.bundle.root, id);
                    if (parents.length === 1) hmrDelete(module.bundle.root, id);
                }
            }
            if (supportsSourceURL) // Global eval. We would use `new Function` here but browser
            // support for source maps is better with eval.
            (0, eval)(asset.output);
            // $FlowFixMe
            let fn = global.parcelHotUpdate[asset.id];
            modules[asset.id] = [
                fn,
                deps
            ];
        } else if (bundle.parent) hmrApply(bundle.parent, asset);
    }
}
function hmrDelete(bundle, id) {
    let modules = bundle.modules;
    if (!modules) return;
    if (modules[id]) {
        // Collect dependencies that will become orphaned when this module is deleted.
        let deps = modules[id][1];
        let orphans = [];
        for(let dep in deps){
            let parents = getParents(module.bundle.root, deps[dep]);
            if (parents.length === 1) orphans.push(deps[dep]);
        }
        // Delete the module. This must be done before deleting dependencies in case of circular dependencies.
        delete modules[id];
        delete bundle.cache[id];
        // Now delete the orphans.
        orphans.forEach((id)=>{
            hmrDelete(module.bundle.root, id);
        });
    } else if (bundle.parent) hmrDelete(bundle.parent, id);
}
function hmrAcceptCheck(bundle /*: ParcelRequire */ , id /*: string */ , depsByBundle /*: ?{ [string]: { [string]: string } }*/ ) {
    if (hmrAcceptCheckOne(bundle, id, depsByBundle)) return true;
    // Traverse parents breadth first. All possible ancestries must accept the HMR update, or we'll reload.
    let parents = getParents(module.bundle.root, id);
    let accepted = false;
    while(parents.length > 0){
        let v = parents.shift();
        let a = hmrAcceptCheckOne(v[0], v[1], null);
        if (a) // If this parent accepts, stop traversing upward, but still consider siblings.
        accepted = true;
        else {
            // Otherwise, queue the parents in the next level upward.
            let p = getParents(module.bundle.root, v[1]);
            if (p.length === 0) {
                // If there are no parents, then we've reached an entry without accepting. Reload.
                accepted = false;
                break;
            }
            parents.push(...p);
        }
    }
    return accepted;
}
function hmrAcceptCheckOne(bundle /*: ParcelRequire */ , id /*: string */ , depsByBundle /*: ?{ [string]: { [string]: string } }*/ ) {
    var modules = bundle.modules;
    if (!modules) return;
    if (depsByBundle && !depsByBundle[bundle.HMR_BUNDLE_ID]) {
        // If we reached the root bundle without finding where the asset should go,
        // there's nothing to do. Mark as "accepted" so we don't reload the page.
        if (!bundle.parent) return true;
        return hmrAcceptCheck(bundle.parent, id, depsByBundle);
    }
    if (checkedAssets[id]) return true;
    checkedAssets[id] = true;
    var cached = bundle.cache[id];
    assetsToDispose.push([
        bundle,
        id
    ]);
    if (!cached || cached.hot && cached.hot._acceptCallbacks.length) {
        assetsToAccept.push([
            bundle,
            id
        ]);
        return true;
    }
}
function hmrDispose(bundle /*: ParcelRequire */ , id /*: string */ ) {
    var cached = bundle.cache[id];
    bundle.hotData[id] = {};
    if (cached && cached.hot) cached.hot.data = bundle.hotData[id];
    if (cached && cached.hot && cached.hot._disposeCallbacks.length) cached.hot._disposeCallbacks.forEach(function(cb) {
        cb(bundle.hotData[id]);
    });
    delete bundle.cache[id];
}
function hmrAccept(bundle /*: ParcelRequire */ , id /*: string */ ) {
    // Execute the module.
    bundle(id);
    // Run the accept callbacks in the new version of the module.
    var cached = bundle.cache[id];
    if (cached && cached.hot && cached.hot._acceptCallbacks.length) cached.hot._acceptCallbacks.forEach(function(cb) {
        var assetsToAlsoAccept = cb(function() {
            return getParents(module.bundle.root, id);
        });
        if (assetsToAlsoAccept && assetsToAccept.length) {
            assetsToAlsoAccept.forEach(function(a) {
                hmrDispose(a[0], a[1]);
            });
            // $FlowFixMe[method-unbinding]
            assetsToAccept.push.apply(assetsToAccept, assetsToAlsoAccept);
        }
    });
}

},{}],"1xC6H":[function(require,module,exports) {
var Refresh = require("6d18d6bd340e7473");
var ErrorOverlay = require("74ad5ea14201648c");
Refresh.injectIntoGlobalHook(window);
window.$RefreshReg$ = function() {};
window.$RefreshSig$ = function() {
    return function(type) {
        return type;
    };
};
ErrorOverlay.setEditorHandler(function editorHandler(errorLocation) {
    let file = `${errorLocation.fileName}:${errorLocation.lineNumber || 1}:${errorLocation.colNumber || 1}`;
    fetch(`/__parcel_launch_editor?file=${encodeURIComponent(file)}`);
});
ErrorOverlay.startReportingRuntimeErrors({
    onError: function() {}
});
window.addEventListener("parcelhmraccept", ()=>{
    ErrorOverlay.dismissRuntimeErrors();
});

},{"6d18d6bd340e7473":"786KC","74ad5ea14201648c":"1dldy"}],"786KC":[function(require,module,exports) {
"use strict";
module.exports = require("96622d495519d4e");

},{"96622d495519d4e":"hdge7"}],"hdge7":[function(require,module,exports) {
/** @license React v0.9.0
 * react-refresh-runtime.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ "use strict";
(function() {
    "use strict";
    // ATTENTION
    // When adding new symbols to this file,
    // Please consider also adding to 'react-devtools-shared/src/backend/ReactSymbols'
    // The Symbol used to tag the ReactElement-like types. If there is no native Symbol
    // nor polyfill, then a plain number is used for performance.
    var REACT_ELEMENT_TYPE = 0xeac7;
    var REACT_PORTAL_TYPE = 0xeaca;
    var REACT_FRAGMENT_TYPE = 0xeacb;
    var REACT_STRICT_MODE_TYPE = 0xeacc;
    var REACT_PROFILER_TYPE = 0xead2;
    var REACT_PROVIDER_TYPE = 0xeacd;
    var REACT_CONTEXT_TYPE = 0xeace;
    var REACT_FORWARD_REF_TYPE = 0xead0;
    var REACT_SUSPENSE_TYPE = 0xead1;
    var REACT_SUSPENSE_LIST_TYPE = 0xead8;
    var REACT_MEMO_TYPE = 0xead3;
    var REACT_LAZY_TYPE = 0xead4;
    var REACT_BLOCK_TYPE = 0xead9;
    var REACT_SERVER_BLOCK_TYPE = 0xeada;
    var REACT_FUNDAMENTAL_TYPE = 0xead5;
    var REACT_SCOPE_TYPE = 0xead7;
    var REACT_OPAQUE_ID_TYPE = 0xeae0;
    var REACT_DEBUG_TRACING_MODE_TYPE = 0xeae1;
    var REACT_OFFSCREEN_TYPE = 0xeae2;
    var REACT_LEGACY_HIDDEN_TYPE = 0xeae3;
    if (typeof Symbol === "function" && Symbol.for) {
        var symbolFor = Symbol.for;
        REACT_ELEMENT_TYPE = symbolFor("react.element");
        REACT_PORTAL_TYPE = symbolFor("react.portal");
        REACT_FRAGMENT_TYPE = symbolFor("react.fragment");
        REACT_STRICT_MODE_TYPE = symbolFor("react.strict_mode");
        REACT_PROFILER_TYPE = symbolFor("react.profiler");
        REACT_PROVIDER_TYPE = symbolFor("react.provider");
        REACT_CONTEXT_TYPE = symbolFor("react.context");
        REACT_FORWARD_REF_TYPE = symbolFor("react.forward_ref");
        REACT_SUSPENSE_TYPE = symbolFor("react.suspense");
        REACT_SUSPENSE_LIST_TYPE = symbolFor("react.suspense_list");
        REACT_MEMO_TYPE = symbolFor("react.memo");
        REACT_LAZY_TYPE = symbolFor("react.lazy");
        REACT_BLOCK_TYPE = symbolFor("react.block");
        REACT_SERVER_BLOCK_TYPE = symbolFor("react.server.block");
        REACT_FUNDAMENTAL_TYPE = symbolFor("react.fundamental");
        REACT_SCOPE_TYPE = symbolFor("react.scope");
        REACT_OPAQUE_ID_TYPE = symbolFor("react.opaque.id");
        REACT_DEBUG_TRACING_MODE_TYPE = symbolFor("react.debug_trace_mode");
        REACT_OFFSCREEN_TYPE = symbolFor("react.offscreen");
        REACT_LEGACY_HIDDEN_TYPE = symbolFor("react.legacy_hidden");
    }
    var PossiblyWeakMap = typeof WeakMap === "function" ? WeakMap : Map; // We never remove these associations.
    // It's OK to reference families, but use WeakMap/Set for types.
    var allFamiliesByID = new Map();
    var allFamiliesByType = new PossiblyWeakMap();
    var allSignaturesByType = new PossiblyWeakMap(); // This WeakMap is read by React, so we only put families
    // that have actually been edited here. This keeps checks fast.
    // $FlowIssue
    var updatedFamiliesByType = new PossiblyWeakMap(); // This is cleared on every performReactRefresh() call.
    // It is an array of [Family, NextType] tuples.
    var pendingUpdates = []; // This is injected by the renderer via DevTools global hook.
    var helpersByRendererID = new Map();
    var helpersByRoot = new Map(); // We keep track of mounted roots so we can schedule updates.
    var mountedRoots = new Set(); // If a root captures an error, we remember it so we can retry on edit.
    var failedRoots = new Set(); // In environments that support WeakMap, we also remember the last element for every root.
    // It needs to be weak because we do this even for roots that failed to mount.
    // If there is no WeakMap, we won't attempt to do retrying.
    // $FlowIssue
    var rootElements = typeof WeakMap === "function" ? new WeakMap() : null;
    var isPerformingRefresh = false;
    function computeFullKey(signature) {
        if (signature.fullKey !== null) return signature.fullKey;
        var fullKey = signature.ownKey;
        var hooks;
        try {
            hooks = signature.getCustomHooks();
        } catch (err) {
            // This can happen in an edge case, e.g. if expression like Foo.useSomething
            // depends on Foo which is lazily initialized during rendering.
            // In that case just assume we'll have to remount.
            signature.forceReset = true;
            signature.fullKey = fullKey;
            return fullKey;
        }
        for(var i = 0; i < hooks.length; i++){
            var hook = hooks[i];
            if (typeof hook !== "function") {
                // Something's wrong. Assume we need to remount.
                signature.forceReset = true;
                signature.fullKey = fullKey;
                return fullKey;
            }
            var nestedHookSignature = allSignaturesByType.get(hook);
            if (nestedHookSignature === undefined) continue;
            var nestedHookKey = computeFullKey(nestedHookSignature);
            if (nestedHookSignature.forceReset) signature.forceReset = true;
            fullKey += "\n---\n" + nestedHookKey;
        }
        signature.fullKey = fullKey;
        return fullKey;
    }
    function haveEqualSignatures(prevType, nextType) {
        var prevSignature = allSignaturesByType.get(prevType);
        var nextSignature = allSignaturesByType.get(nextType);
        if (prevSignature === undefined && nextSignature === undefined) return true;
        if (prevSignature === undefined || nextSignature === undefined) return false;
        if (computeFullKey(prevSignature) !== computeFullKey(nextSignature)) return false;
        if (nextSignature.forceReset) return false;
        return true;
    }
    function isReactClass(type) {
        return type.prototype && type.prototype.isReactComponent;
    }
    function canPreserveStateBetween(prevType, nextType) {
        if (isReactClass(prevType) || isReactClass(nextType)) return false;
        if (haveEqualSignatures(prevType, nextType)) return true;
        return false;
    }
    function resolveFamily(type) {
        // Only check updated types to keep lookups fast.
        return updatedFamiliesByType.get(type);
    } // If we didn't care about IE11, we could use new Map/Set(iterable).
    function cloneMap(map) {
        var clone = new Map();
        map.forEach(function(value, key) {
            clone.set(key, value);
        });
        return clone;
    }
    function cloneSet(set) {
        var clone = new Set();
        set.forEach(function(value) {
            clone.add(value);
        });
        return clone;
    }
    function performReactRefresh() {
        if (pendingUpdates.length === 0) return null;
        if (isPerformingRefresh) return null;
        isPerformingRefresh = true;
        try {
            var staleFamilies = new Set();
            var updatedFamilies = new Set();
            var updates = pendingUpdates;
            pendingUpdates = [];
            updates.forEach(function(_ref) {
                var family = _ref[0], nextType = _ref[1];
                // Now that we got a real edit, we can create associations
                // that will be read by the React reconciler.
                var prevType = family.current;
                updatedFamiliesByType.set(prevType, family);
                updatedFamiliesByType.set(nextType, family);
                family.current = nextType; // Determine whether this should be a re-render or a re-mount.
                if (canPreserveStateBetween(prevType, nextType)) updatedFamilies.add(family);
                else staleFamilies.add(family);
            }); // TODO: rename these fields to something more meaningful.
            var update = {
                updatedFamilies: updatedFamilies,
                // Families that will re-render preserving state
                staleFamilies: staleFamilies // Families that will be remounted
            };
            helpersByRendererID.forEach(function(helpers) {
                // Even if there are no roots, set the handler on first update.
                // This ensures that if *new* roots are mounted, they'll use the resolve handler.
                helpers.setRefreshHandler(resolveFamily);
            });
            var didError = false;
            var firstError = null; // We snapshot maps and sets that are mutated during commits.
            // If we don't do this, there is a risk they will be mutated while
            // we iterate over them. For example, trying to recover a failed root
            // may cause another root to be added to the failed list -- an infinite loop.
            var failedRootsSnapshot = cloneSet(failedRoots);
            var mountedRootsSnapshot = cloneSet(mountedRoots);
            var helpersByRootSnapshot = cloneMap(helpersByRoot);
            failedRootsSnapshot.forEach(function(root) {
                var helpers = helpersByRootSnapshot.get(root);
                if (helpers === undefined) throw new Error("Could not find helpers for a root. This is a bug in React Refresh.");
                failedRoots.has(root);
                if (rootElements === null) return;
                if (!rootElements.has(root)) return;
                var element = rootElements.get(root);
                try {
                    helpers.scheduleRoot(root, element);
                } catch (err) {
                    if (!didError) {
                        didError = true;
                        firstError = err;
                    } // Keep trying other roots.
                }
            });
            mountedRootsSnapshot.forEach(function(root) {
                var helpers = helpersByRootSnapshot.get(root);
                if (helpers === undefined) throw new Error("Could not find helpers for a root. This is a bug in React Refresh.");
                mountedRoots.has(root);
                try {
                    helpers.scheduleRefresh(root, update);
                } catch (err) {
                    if (!didError) {
                        didError = true;
                        firstError = err;
                    } // Keep trying other roots.
                }
            });
            if (didError) throw firstError;
            return update;
        } finally{
            isPerformingRefresh = false;
        }
    }
    function register(type, id) {
        if (type === null) return;
        if (typeof type !== "function" && typeof type !== "object") return;
         // This can happen in an edge case, e.g. if we register
        // return value of a HOC but it returns a cached component.
        // Ignore anything but the first registration for each type.
        if (allFamiliesByType.has(type)) return;
         // Create family or remember to update it.
        // None of this bookkeeping affects reconciliation
        // until the first performReactRefresh() call above.
        var family = allFamiliesByID.get(id);
        if (family === undefined) {
            family = {
                current: type
            };
            allFamiliesByID.set(id, family);
        } else pendingUpdates.push([
            family,
            type
        ]);
        allFamiliesByType.set(type, family); // Visit inner types because we might not have registered them.
        if (typeof type === "object" && type !== null) switch(type.$$typeof){
            case REACT_FORWARD_REF_TYPE:
                register(type.render, id + "$render");
                break;
            case REACT_MEMO_TYPE:
                register(type.type, id + "$type");
                break;
        }
    }
    function setSignature(type, key) {
        var forceReset = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
        var getCustomHooks = arguments.length > 3 ? arguments[3] : undefined;
        allSignaturesByType.set(type, {
            forceReset: forceReset,
            ownKey: key,
            fullKey: null,
            getCustomHooks: getCustomHooks || function() {
                return [];
            }
        });
    } // This is lazily called during first render for a type.
    // It captures Hook list at that time so inline requires don't break comparisons.
    function collectCustomHooksForSignature(type) {
        var signature = allSignaturesByType.get(type);
        if (signature !== undefined) computeFullKey(signature);
    }
    function getFamilyByID(id) {
        return allFamiliesByID.get(id);
    }
    function getFamilyByType(type) {
        return allFamiliesByType.get(type);
    }
    function findAffectedHostInstances(families) {
        var affectedInstances = new Set();
        mountedRoots.forEach(function(root) {
            var helpers = helpersByRoot.get(root);
            if (helpers === undefined) throw new Error("Could not find helpers for a root. This is a bug in React Refresh.");
            var instancesForRoot = helpers.findHostInstancesForRefresh(root, families);
            instancesForRoot.forEach(function(inst) {
                affectedInstances.add(inst);
            });
        });
        return affectedInstances;
    }
    function injectIntoGlobalHook(globalObject) {
        // For React Native, the global hook will be set up by require('react-devtools-core').
        // That code will run before us. So we need to monkeypatch functions on existing hook.
        // For React Web, the global hook will be set up by the extension.
        // This will also run before us.
        var hook = globalObject.__REACT_DEVTOOLS_GLOBAL_HOOK__;
        if (hook === undefined) {
            // However, if there is no DevTools extension, we'll need to set up the global hook ourselves.
            // Note that in this case it's important that renderer code runs *after* this method call.
            // Otherwise, the renderer will think that there is no global hook, and won't do the injection.
            var nextID = 0;
            globalObject.__REACT_DEVTOOLS_GLOBAL_HOOK__ = hook = {
                renderers: new Map(),
                supportsFiber: true,
                inject: function(injected) {
                    return nextID++;
                },
                onScheduleFiberRoot: function(id, root, children) {},
                onCommitFiberRoot: function(id, root, maybePriorityLevel, didError) {},
                onCommitFiberUnmount: function() {}
            };
        } // Here, we just want to get a reference to scheduleRefresh.
        var oldInject = hook.inject;
        hook.inject = function(injected) {
            var id = oldInject.apply(this, arguments);
            if (typeof injected.scheduleRefresh === "function" && typeof injected.setRefreshHandler === "function") // This version supports React Refresh.
            helpersByRendererID.set(id, injected);
            return id;
        }; // Do the same for any already injected roots.
        // This is useful if ReactDOM has already been initialized.
        // https://github.com/facebook/react/issues/17626
        hook.renderers.forEach(function(injected, id) {
            if (typeof injected.scheduleRefresh === "function" && typeof injected.setRefreshHandler === "function") // This version supports React Refresh.
            helpersByRendererID.set(id, injected);
        }); // We also want to track currently mounted roots.
        var oldOnCommitFiberRoot = hook.onCommitFiberRoot;
        var oldOnScheduleFiberRoot = hook.onScheduleFiberRoot || function() {};
        hook.onScheduleFiberRoot = function(id, root, children) {
            if (!isPerformingRefresh) {
                // If it was intentionally scheduled, don't attempt to restore.
                // This includes intentionally scheduled unmounts.
                failedRoots.delete(root);
                if (rootElements !== null) rootElements.set(root, children);
            }
            return oldOnScheduleFiberRoot.apply(this, arguments);
        };
        hook.onCommitFiberRoot = function(id, root, maybePriorityLevel, didError) {
            var helpers = helpersByRendererID.get(id);
            if (helpers === undefined) return;
            helpersByRoot.set(root, helpers);
            var current = root.current;
            var alternate = current.alternate; // We need to determine whether this root has just (un)mounted.
            // This logic is copy-pasted from similar logic in the DevTools backend.
            // If this breaks with some refactoring, you'll want to update DevTools too.
            if (alternate !== null) {
                var wasMounted = alternate.memoizedState != null && alternate.memoizedState.element != null;
                var isMounted = current.memoizedState != null && current.memoizedState.element != null;
                if (!wasMounted && isMounted) {
                    // Mount a new root.
                    mountedRoots.add(root);
                    failedRoots.delete(root);
                } else if (wasMounted && isMounted) ;
                else if (wasMounted && !isMounted) {
                    // Unmount an existing root.
                    mountedRoots.delete(root);
                    if (didError) // We'll remount it on future edits.
                    failedRoots.add(root);
                    else helpersByRoot.delete(root);
                } else if (!wasMounted && !isMounted) {
                    if (didError) // We'll remount it on future edits.
                    failedRoots.add(root);
                }
            } else // Mount a new root.
            mountedRoots.add(root);
            return oldOnCommitFiberRoot.apply(this, arguments);
        };
    }
    function hasUnrecoverableErrors() {
        // TODO: delete this after removing dependency in RN.
        return false;
    } // Exposed for testing.
    function _getMountedRootCount() {
        return mountedRoots.size;
    } // This is a wrapper over more primitive functions for setting signature.
    // Signatures let us decide whether the Hook order has changed on refresh.
    //
    // This function is intended to be used as a transform target, e.g.:
    // var _s = createSignatureFunctionForTransform()
    //
    // function Hello() {
    //   const [foo, setFoo] = useState(0);
    //   const value = useCustomHook();
    //   _s(); /* Second call triggers collecting the custom Hook list.
    //          * This doesn't happen during the module evaluation because we
    //          * don't want to change the module order with inline requires.
    //          * Next calls are noops. */
    //   return <h1>Hi</h1>;
    // }
    //
    // /* First call specifies the signature: */
    // _s(
    //   Hello,
    //   'useState{[foo, setFoo]}(0)',
    //   () => [useCustomHook], /* Lazy to avoid triggering inline requires */
    // );
    function createSignatureFunctionForTransform() {
        // We'll fill in the signature in two steps.
        // First, we'll know the signature itself. This happens outside the component.
        // Then, we'll know the references to custom Hooks. This happens inside the component.
        // After that, the returned function will be a fast path no-op.
        var status = "needsSignature";
        var savedType;
        var hasCustomHooks;
        return function(type, key, forceReset, getCustomHooks) {
            switch(status){
                case "needsSignature":
                    if (type !== undefined) {
                        // If we received an argument, this is the initial registration call.
                        savedType = type;
                        hasCustomHooks = typeof getCustomHooks === "function";
                        setSignature(type, key, forceReset, getCustomHooks); // The next call we expect is from inside a function, to fill in the custom Hooks.
                        status = "needsCustomHooks";
                    }
                    break;
                case "needsCustomHooks":
                    if (hasCustomHooks) collectCustomHooksForSignature(savedType);
                    status = "resolved";
                    break;
            }
            return type;
        };
    }
    function isLikelyComponentType(type) {
        switch(typeof type){
            case "function":
                // First, deal with classes.
                if (type.prototype != null) {
                    if (type.prototype.isReactComponent) // React class.
                    return true;
                    var ownNames = Object.getOwnPropertyNames(type.prototype);
                    if (ownNames.length > 1 || ownNames[0] !== "constructor") // This looks like a class.
                    return false;
                     // eslint-disable-next-line no-proto
                    if (type.prototype.__proto__ !== Object.prototype) // It has a superclass.
                    return false;
                     // Pass through.
                // This looks like a regular function with empty prototype.
                } // For plain functions and arrows, use name as a heuristic.
                var name = type.name || type.displayName;
                return typeof name === "string" && /^[A-Z]/.test(name);
            case "object":
                if (type != null) switch(type.$$typeof){
                    case REACT_FORWARD_REF_TYPE:
                    case REACT_MEMO_TYPE:
                        // Definitely React components.
                        return true;
                    default:
                        return false;
                }
                return false;
            default:
                return false;
        }
    }
    exports._getMountedRootCount = _getMountedRootCount;
    exports.collectCustomHooksForSignature = collectCustomHooksForSignature;
    exports.createSignatureFunctionForTransform = createSignatureFunctionForTransform;
    exports.findAffectedHostInstances = findAffectedHostInstances;
    exports.getFamilyByID = getFamilyByID;
    exports.getFamilyByType = getFamilyByType;
    exports.hasUnrecoverableErrors = hasUnrecoverableErrors;
    exports.injectIntoGlobalHook = injectIntoGlobalHook;
    exports.isLikelyComponentType = isLikelyComponentType;
    exports.performReactRefresh = performReactRefresh;
    exports.register = register;
    exports.setSignature = setSignature;
})();

},{}],"1dldy":[function(require,module,exports) {
var process = require("d1546958eb39fdcf");
!function(e, t) {
    module.exports = t();
}(window, function() {
    return function(e) {
        var t = {};
        function r(n) {
            if (t[n]) return t[n].exports;
            var o = t[n] = {
                i: n,
                l: !1,
                exports: {}
            };
            return e[n].call(o.exports, o, o.exports, r), o.l = !0, o.exports;
        }
        return r.m = e, r.c = t, r.d = function(e, t, n) {
            r.o(e, t) || Object.defineProperty(e, t, {
                enumerable: !0,
                get: n
            });
        }, r.r = function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(e, "__esModule", {
                value: !0
            });
        }, r.t = function(e, t) {
            if (1 & t && (e = r(e)), 8 & t) return e;
            if (4 & t && "object" == typeof e && e && e.__esModule) return e;
            var n = Object.create(null);
            if (r.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e) for(var o in e)r.d(n, o, (function(t) {
                return e[t];
            }).bind(null, o));
            return n;
        }, r.n = function(e) {
            var t = e && e.__esModule ? function() {
                return e.default;
            } : function() {
                return e;
            };
            return r.d(t, "a", t), t;
        }, r.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t);
        }, r.p = "", r(r.s = 15);
    }([
        function(e, t, r) {
            e.exports = r(8);
        },
        function(e, t) {
            t.getArg = function(e, t, r) {
                if (t in e) return e[t];
                if (3 === arguments.length) return r;
                throw new Error('"' + t + '" is a required argument.');
            };
            var r = /^(?:([\w+\-.]+):)?\/\/(?:(\w+:\w+)@)?([\w.]*)(?::(\d+))?(\S*)$/, n = /^data:.+\,.+$/;
            function o(e) {
                var t = e.match(r);
                return t ? {
                    scheme: t[1],
                    auth: t[2],
                    host: t[3],
                    port: t[4],
                    path: t[5]
                } : null;
            }
            function a(e) {
                var t = "";
                return e.scheme && (t += e.scheme + ":"), t += "//", e.auth && (t += e.auth + "@"), e.host && (t += e.host), e.port && (t += ":" + e.port), e.path && (t += e.path), t;
            }
            function i(e) {
                var r = e, n = o(e);
                if (n) {
                    if (!n.path) return e;
                    r = n.path;
                }
                for(var i, l = t.isAbsolute(r), u = r.split(/\/+/), c = 0, s = u.length - 1; s >= 0; s--)"." === (i = u[s]) ? u.splice(s, 1) : ".." === i ? c++ : c > 0 && ("" === i ? (u.splice(s + 1, c), c = 0) : (u.splice(s, 2), c--));
                return "" === (r = u.join("/")) && (r = l ? "/" : "."), n ? (n.path = r, a(n)) : r;
            }
            t.urlParse = o, t.urlGenerate = a, t.normalize = i, t.join = function(e, t) {
                "" === e && (e = "."), "" === t && (t = ".");
                var r = o(t), l = o(e);
                if (l && (e = l.path || "/"), r && !r.scheme) return l && (r.scheme = l.scheme), a(r);
                if (r || t.match(n)) return t;
                if (l && !l.host && !l.path) return l.host = t, a(l);
                var u = "/" === t.charAt(0) ? t : i(e.replace(/\/+$/, "") + "/" + t);
                return l ? (l.path = u, a(l)) : u;
            }, t.isAbsolute = function(e) {
                return "/" === e.charAt(0) || !!e.match(r);
            }, t.relative = function(e, t) {
                "" === e && (e = "."), e = e.replace(/\/$/, "");
                for(var r = 0; 0 !== t.indexOf(e + "/");){
                    var n = e.lastIndexOf("/");
                    if (n < 0) return t;
                    if ((e = e.slice(0, n)).match(/^([^\/]+:\/)?\/*$/)) return t;
                    ++r;
                }
                return Array(r + 1).join("../") + t.substr(e.length + 1);
            };
            var l = !("__proto__" in Object.create(null));
            function u(e) {
                return e;
            }
            function c(e) {
                if (!e) return !1;
                var t = e.length;
                if (t < 9) return !1;
                if (95 !== e.charCodeAt(t - 1) || 95 !== e.charCodeAt(t - 2) || 111 !== e.charCodeAt(t - 3) || 116 !== e.charCodeAt(t - 4) || 111 !== e.charCodeAt(t - 5) || 114 !== e.charCodeAt(t - 6) || 112 !== e.charCodeAt(t - 7) || 95 !== e.charCodeAt(t - 8) || 95 !== e.charCodeAt(t - 9)) return !1;
                for(var r = t - 10; r >= 0; r--)if (36 !== e.charCodeAt(r)) return !1;
                return !0;
            }
            function s(e, t) {
                return e === t ? 0 : e > t ? 1 : -1;
            }
            t.toSetString = l ? u : function(e) {
                return c(e) ? "$" + e : e;
            }, t.fromSetString = l ? u : function(e) {
                return c(e) ? e.slice(1) : e;
            }, t.compareByOriginalPositions = function(e, t, r) {
                var n = e.source - t.source;
                return 0 !== n ? n : 0 !== (n = e.originalLine - t.originalLine) ? n : 0 !== (n = e.originalColumn - t.originalColumn) || r ? n : 0 !== (n = e.generatedColumn - t.generatedColumn) ? n : 0 !== (n = e.generatedLine - t.generatedLine) ? n : e.name - t.name;
            }, t.compareByGeneratedPositionsDeflated = function(e, t, r) {
                var n = e.generatedLine - t.generatedLine;
                return 0 !== n ? n : 0 !== (n = e.generatedColumn - t.generatedColumn) || r ? n : 0 !== (n = e.source - t.source) ? n : 0 !== (n = e.originalLine - t.originalLine) ? n : 0 !== (n = e.originalColumn - t.originalColumn) ? n : e.name - t.name;
            }, t.compareByGeneratedPositionsInflated = function(e, t) {
                var r = e.generatedLine - t.generatedLine;
                return 0 !== r ? r : 0 !== (r = e.generatedColumn - t.generatedColumn) ? r : 0 !== (r = s(e.source, t.source)) ? r : 0 !== (r = e.originalLine - t.originalLine) ? r : 0 !== (r = e.originalColumn - t.originalColumn) ? r : s(e.name, t.name);
            };
        },
        function(e, t) {
            function r(e, t) {
                for(var r = 0, n = e.length - 1; n >= 0; n--){
                    var o = e[n];
                    "." === o ? e.splice(n, 1) : ".." === o ? (e.splice(n, 1), r++) : r && (e.splice(n, 1), r--);
                }
                if (t) for(; r--; r)e.unshift("..");
                return e;
            }
            function n(e, t) {
                if (e.filter) return e.filter(t);
                for(var r = [], n = 0; n < e.length; n++)t(e[n], n, e) && r.push(e[n]);
                return r;
            }
            t.resolve = function() {
                for(var e = "", t = !1, o = arguments.length - 1; o >= -1 && !t; o--){
                    var a = o >= 0 ? arguments[o] : process.cwd();
                    if ("string" != typeof a) throw new TypeError("Arguments to path.resolve must be strings");
                    a && (e = a + "/" + e, t = "/" === a.charAt(0));
                }
                return (t ? "/" : "") + (e = r(n(e.split("/"), function(e) {
                    return !!e;
                }), !t).join("/")) || ".";
            }, t.normalize = function(e) {
                var a = t.isAbsolute(e), i = "/" === o(e, -1);
                return (e = r(n(e.split("/"), function(e) {
                    return !!e;
                }), !a).join("/")) || a || (e = "."), e && i && (e += "/"), (a ? "/" : "") + e;
            }, t.isAbsolute = function(e) {
                return "/" === e.charAt(0);
            }, t.join = function() {
                var e = Array.prototype.slice.call(arguments, 0);
                return t.normalize(n(e, function(e, t) {
                    if ("string" != typeof e) throw new TypeError("Arguments to path.join must be strings");
                    return e;
                }).join("/"));
            }, t.relative = function(e, r) {
                function n(e) {
                    for(var t = 0; t < e.length && "" === e[t]; t++);
                    for(var r = e.length - 1; r >= 0 && "" === e[r]; r--);
                    return t > r ? [] : e.slice(t, r - t + 1);
                }
                e = t.resolve(e).substr(1), r = t.resolve(r).substr(1);
                for(var o = n(e.split("/")), a = n(r.split("/")), i = Math.min(o.length, a.length), l = i, u = 0; u < i; u++)if (o[u] !== a[u]) {
                    l = u;
                    break;
                }
                var c = [];
                for(u = l; u < o.length; u++)c.push("..");
                return (c = c.concat(a.slice(l))).join("/");
            }, t.sep = "/", t.delimiter = ":", t.dirname = function(e) {
                if ("string" != typeof e && (e += ""), 0 === e.length) return ".";
                for(var t = e.charCodeAt(0), r = 47 === t, n = -1, o = !0, a = e.length - 1; a >= 1; --a)if (47 === (t = e.charCodeAt(a))) {
                    if (!o) {
                        n = a;
                        break;
                    }
                } else o = !1;
                return -1 === n ? r ? "/" : "." : r && 1 === n ? "/" : e.slice(0, n);
            }, t.basename = function(e, t) {
                var r = function(e) {
                    "string" != typeof e && (e += "");
                    var t, r = 0, n = -1, o = !0;
                    for(t = e.length - 1; t >= 0; --t)if (47 === e.charCodeAt(t)) {
                        if (!o) {
                            r = t + 1;
                            break;
                        }
                    } else -1 === n && (o = !1, n = t + 1);
                    return -1 === n ? "" : e.slice(r, n);
                }(e);
                return t && r.substr(-1 * t.length) === t && (r = r.substr(0, r.length - t.length)), r;
            }, t.extname = function(e) {
                "string" != typeof e && (e += "");
                for(var t = -1, r = 0, n = -1, o = !0, a = 0, i = e.length - 1; i >= 0; --i){
                    var l = e.charCodeAt(i);
                    if (47 !== l) -1 === n && (o = !1, n = i + 1), 46 === l ? -1 === t ? t = i : 1 !== a && (a = 1) : -1 !== t && (a = -1);
                    else if (!o) {
                        r = i + 1;
                        break;
                    }
                }
                return -1 === t || -1 === n || 0 === a || 1 === a && t === n - 1 && t === r + 1 ? "" : e.slice(t, n);
            };
            var o = "b" === "ab".substr(-1) ? function(e, t, r) {
                return e.substr(t, r);
            } : function(e, t, r) {
                return t < 0 && (t = e.length + t), e.substr(t, r);
            };
        },
        function(e, t, r) {
            t.SourceMapGenerator = r(4).SourceMapGenerator, t.SourceMapConsumer = r(11).SourceMapConsumer, t.SourceNode = r(14).SourceNode;
        },
        function(e, t, r) {
            var n = r(5), o = r(1), a = r(6).ArraySet, i = r(10).MappingList;
            function l(e) {
                e || (e = {}), this._file = o.getArg(e, "file", null), this._sourceRoot = o.getArg(e, "sourceRoot", null), this._skipValidation = o.getArg(e, "skipValidation", !1), this._sources = new a, this._names = new a, this._mappings = new i, this._sourcesContents = null;
            }
            l.prototype._version = 3, l.fromSourceMap = function(e) {
                var t = e.sourceRoot, r = new l({
                    file: e.file,
                    sourceRoot: t
                });
                return e.eachMapping(function(e) {
                    var n = {
                        generated: {
                            line: e.generatedLine,
                            column: e.generatedColumn
                        }
                    };
                    null != e.source && (n.source = e.source, null != t && (n.source = o.relative(t, n.source)), n.original = {
                        line: e.originalLine,
                        column: e.originalColumn
                    }, null != e.name && (n.name = e.name)), r.addMapping(n);
                }), e.sources.forEach(function(t) {
                    var n = e.sourceContentFor(t);
                    null != n && r.setSourceContent(t, n);
                }), r;
            }, l.prototype.addMapping = function(e) {
                var t = o.getArg(e, "generated"), r = o.getArg(e, "original", null), n = o.getArg(e, "source", null), a = o.getArg(e, "name", null);
                this._skipValidation || this._validateMapping(t, r, n, a), null != n && (n = String(n), this._sources.has(n) || this._sources.add(n)), null != a && (a = String(a), this._names.has(a) || this._names.add(a)), this._mappings.add({
                    generatedLine: t.line,
                    generatedColumn: t.column,
                    originalLine: null != r && r.line,
                    originalColumn: null != r && r.column,
                    source: n,
                    name: a
                });
            }, l.prototype.setSourceContent = function(e, t) {
                var r = e;
                null != this._sourceRoot && (r = o.relative(this._sourceRoot, r)), null != t ? (this._sourcesContents || (this._sourcesContents = Object.create(null)), this._sourcesContents[o.toSetString(r)] = t) : this._sourcesContents && (delete this._sourcesContents[o.toSetString(r)], 0 === Object.keys(this._sourcesContents).length && (this._sourcesContents = null));
            }, l.prototype.applySourceMap = function(e, t, r) {
                var n = t;
                if (null == t) {
                    if (null == e.file) throw new Error('SourceMapGenerator.prototype.applySourceMap requires either an explicit source file, or the source map\'s "file" property. Both were omitted.');
                    n = e.file;
                }
                var i = this._sourceRoot;
                null != i && (n = o.relative(i, n));
                var l = new a, u = new a;
                this._mappings.unsortedForEach(function(t) {
                    if (t.source === n && null != t.originalLine) {
                        var a = e.originalPositionFor({
                            line: t.originalLine,
                            column: t.originalColumn
                        });
                        null != a.source && (t.source = a.source, null != r && (t.source = o.join(r, t.source)), null != i && (t.source = o.relative(i, t.source)), t.originalLine = a.line, t.originalColumn = a.column, null != a.name && (t.name = a.name));
                    }
                    var c = t.source;
                    null == c || l.has(c) || l.add(c);
                    var s = t.name;
                    null == s || u.has(s) || u.add(s);
                }, this), this._sources = l, this._names = u, e.sources.forEach(function(t) {
                    var n = e.sourceContentFor(t);
                    null != n && (null != r && (t = o.join(r, t)), null != i && (t = o.relative(i, t)), this.setSourceContent(t, n));
                }, this);
            }, l.prototype._validateMapping = function(e, t, r, n) {
                if (t && "number" != typeof t.line && "number" != typeof t.column) throw new Error("original.line and original.column are not numbers -- you probably meant to omit the original mapping entirely and only map the generated position. If so, pass null for the original mapping instead of an object with empty or null values.");
                if ((!(e && "line" in e && "column" in e && e.line > 0 && e.column >= 0) || t || r || n) && !(e && "line" in e && "column" in e && t && "line" in t && "column" in t && e.line > 0 && e.column >= 0 && t.line > 0 && t.column >= 0 && r)) throw new Error("Invalid mapping: " + JSON.stringify({
                    generated: e,
                    source: r,
                    original: t,
                    name: n
                }));
            }, l.prototype._serializeMappings = function() {
                for(var e, t, r, a, i = 0, l = 1, u = 0, c = 0, s = 0, f = 0, d = "", p = this._mappings.toArray(), h = 0, g = p.length; h < g; h++){
                    if (e = "", (t = p[h]).generatedLine !== l) for(i = 0; t.generatedLine !== l;)e += ";", l++;
                    else if (h > 0) {
                        if (!o.compareByGeneratedPositionsInflated(t, p[h - 1])) continue;
                        e += ",";
                    }
                    e += n.encode(t.generatedColumn - i), i = t.generatedColumn, null != t.source && (a = this._sources.indexOf(t.source), e += n.encode(a - f), f = a, e += n.encode(t.originalLine - 1 - c), c = t.originalLine - 1, e += n.encode(t.originalColumn - u), u = t.originalColumn, null != t.name && (r = this._names.indexOf(t.name), e += n.encode(r - s), s = r)), d += e;
                }
                return d;
            }, l.prototype._generateSourcesContent = function(e, t) {
                return e.map(function(e) {
                    if (!this._sourcesContents) return null;
                    null != t && (e = o.relative(t, e));
                    var r = o.toSetString(e);
                    return Object.prototype.hasOwnProperty.call(this._sourcesContents, r) ? this._sourcesContents[r] : null;
                }, this);
            }, l.prototype.toJSON = function() {
                var e = {
                    version: this._version,
                    sources: this._sources.toArray(),
                    names: this._names.toArray(),
                    mappings: this._serializeMappings()
                };
                return null != this._file && (e.file = this._file), null != this._sourceRoot && (e.sourceRoot = this._sourceRoot), this._sourcesContents && (e.sourcesContent = this._generateSourcesContent(e.sources, e.sourceRoot)), e;
            }, l.prototype.toString = function() {
                return JSON.stringify(this.toJSON());
            }, t.SourceMapGenerator = l;
        },
        function(e, t, r) {
            var n = r(9);
            t.encode = function(e) {
                var t, r = "", o = function(e) {
                    return e < 0 ? 1 + (-e << 1) : 0 + (e << 1);
                }(e);
                do t = 31 & o, (o >>>= 5) > 0 && (t |= 32), r += n.encode(t);
                while (o > 0);
                return r;
            }, t.decode = function(e, t, r) {
                var o, a, i, l, u = e.length, c = 0, s = 0;
                do {
                    if (t >= u) throw new Error("Expected more digits in base 64 VLQ value.");
                    if (-1 === (a = n.decode(e.charCodeAt(t++)))) throw new Error("Invalid base64 digit: " + e.charAt(t - 1));
                    o = !!(32 & a), c += (a &= 31) << s, s += 5;
                }while (o);
                r.value = (l = (i = c) >> 1, 1 == (1 & i) ? -l : l), r.rest = t;
            };
        },
        function(e, t, r) {
            var n = r(1), o = Object.prototype.hasOwnProperty, a = "undefined" != typeof Map;
            function i() {
                this._array = [], this._set = a ? new Map : Object.create(null);
            }
            i.fromArray = function(e, t) {
                for(var r = new i, n = 0, o = e.length; n < o; n++)r.add(e[n], t);
                return r;
            }, i.prototype.size = function() {
                return a ? this._set.size : Object.getOwnPropertyNames(this._set).length;
            }, i.prototype.add = function(e, t) {
                var r = a ? e : n.toSetString(e), i = a ? this.has(e) : o.call(this._set, r), l = this._array.length;
                i && !t || this._array.push(e), i || (a ? this._set.set(e, l) : this._set[r] = l);
            }, i.prototype.has = function(e) {
                if (a) return this._set.has(e);
                var t = n.toSetString(e);
                return o.call(this._set, t);
            }, i.prototype.indexOf = function(e) {
                if (a) {
                    var t = this._set.get(e);
                    if (t >= 0) return t;
                } else {
                    var r = n.toSetString(e);
                    if (o.call(this._set, r)) return this._set[r];
                }
                throw new Error('"' + e + '" is not in the set.');
            }, i.prototype.at = function(e) {
                if (e >= 0 && e < this._array.length) return this._array[e];
                throw new Error("No element indexed by " + e);
            }, i.prototype.toArray = function() {
                return this._array.slice();
            }, t.ArraySet = i;
        },
        function(e, t, r) {
            "use strict";
            function n(e) {
                return Array.isArray(e) || (e = [
                    e
                ]), Promise.all(e.map(function(e) {
                    return e.then(function(e) {
                        return {
                            isFulfilled: !0,
                            isRejected: !1,
                            value: e
                        };
                    }).catch(function(e) {
                        return {
                            isFulfilled: !1,
                            isRejected: !0,
                            reason: e
                        };
                    });
                }));
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.settle = n, t.default = n;
        },
        function(e, t, r) {
            var n = function(e) {
                "use strict";
                var t, r = Object.prototype, n = r.hasOwnProperty, o = "function" == typeof Symbol ? Symbol : {}, a = o.iterator || "@@iterator", i = o.asyncIterator || "@@asyncIterator", l = o.toStringTag || "@@toStringTag";
                function u(e, t, r) {
                    return Object.defineProperty(e, t, {
                        value: r,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t];
                }
                try {
                    u({}, "");
                } catch (e) {
                    u = function(e, t, r) {
                        return e[t] = r;
                    };
                }
                function c(e, t, r, n) {
                    var o = t && t.prototype instanceof m ? t : m, a = Object.create(o.prototype), i = new T(n || []);
                    return a._invoke = function(e, t, r) {
                        var n = f;
                        return function(o, a) {
                            if (n === p) throw new Error("Generator is already running");
                            if (n === h) {
                                if ("throw" === o) throw a;
                                return L();
                            }
                            for(r.method = o, r.arg = a;;){
                                var i = r.delegate;
                                if (i) {
                                    var l = _(i, r);
                                    if (l) {
                                        if (l === g) continue;
                                        return l;
                                    }
                                }
                                if ("next" === r.method) r.sent = r._sent = r.arg;
                                else if ("throw" === r.method) {
                                    if (n === f) throw n = h, r.arg;
                                    r.dispatchException(r.arg);
                                } else "return" === r.method && r.abrupt("return", r.arg);
                                n = p;
                                var u = s(e, t, r);
                                if ("normal" === u.type) {
                                    if (n = r.done ? h : d, u.arg === g) continue;
                                    return {
                                        value: u.arg,
                                        done: r.done
                                    };
                                }
                                "throw" === u.type && (n = h, r.method = "throw", r.arg = u.arg);
                            }
                        };
                    }(e, r, i), a;
                }
                function s(e, t, r) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, r)
                        };
                    } catch (e) {
                        return {
                            type: "throw",
                            arg: e
                        };
                    }
                }
                e.wrap = c;
                var f = "suspendedStart", d = "suspendedYield", p = "executing", h = "completed", g = {};
                function m() {}
                function v() {}
                function y() {}
                var b = {};
                b[a] = function() {
                    return this;
                };
                var w = Object.getPrototypeOf, k = w && w(w(P([])));
                k && k !== r && n.call(k, a) && (b = k);
                var E = y.prototype = m.prototype = Object.create(b);
                function S(e) {
                    [
                        "next",
                        "throw",
                        "return"
                    ].forEach(function(t) {
                        u(e, t, function(e) {
                            return this._invoke(t, e);
                        });
                    });
                }
                function x(e, t) {
                    var r;
                    this._invoke = function(o, a) {
                        function i() {
                            return new t(function(r, i) {
                                !function r(o, a, i, l) {
                                    var u = s(e[o], e, a);
                                    if ("throw" !== u.type) {
                                        var c = u.arg, f = c.value;
                                        return f && "object" == typeof f && n.call(f, "__await") ? t.resolve(f.__await).then(function(e) {
                                            r("next", e, i, l);
                                        }, function(e) {
                                            r("throw", e, i, l);
                                        }) : t.resolve(f).then(function(e) {
                                            c.value = e, i(c);
                                        }, function(e) {
                                            return r("throw", e, i, l);
                                        });
                                    }
                                    l(u.arg);
                                }(o, a, r, i);
                            });
                        }
                        return r = r ? r.then(i, i) : i();
                    };
                }
                function _(e, r) {
                    var n = e.iterator[r.method];
                    if (n === t) {
                        if (r.delegate = null, "throw" === r.method) {
                            if (e.iterator.return && (r.method = "return", r.arg = t, _(e, r), "throw" === r.method)) return g;
                            r.method = "throw", r.arg = new TypeError("The iterator does not provide a 'throw' method");
                        }
                        return g;
                    }
                    var o = s(n, e.iterator, r.arg);
                    if ("throw" === o.type) return r.method = "throw", r.arg = o.arg, r.delegate = null, g;
                    var a = o.arg;
                    return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, g) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, g);
                }
                function C(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t);
                }
                function O(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t;
                }
                function T(e) {
                    this.tryEntries = [
                        {
                            tryLoc: "root"
                        }
                    ], e.forEach(C, this), this.reset(!0);
                }
                function P(e) {
                    if (e) {
                        var r = e[a];
                        if (r) return r.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var o = -1, i = function r() {
                                for(; ++o < e.length;)if (n.call(e, o)) return r.value = e[o], r.done = !1, r;
                                return r.value = t, r.done = !0, r;
                            };
                            return i.next = i;
                        }
                    }
                    return {
                        next: L
                    };
                }
                function L() {
                    return {
                        value: t,
                        done: !0
                    };
                }
                return v.prototype = E.constructor = y, y.constructor = v, v.displayName = u(y, l, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === v || "GeneratorFunction" === (t.displayName || t.name));
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, u(e, l, "GeneratorFunction")), e.prototype = Object.create(E), e;
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    };
                }, S(x.prototype), x.prototype[i] = function() {
                    return this;
                }, e.AsyncIterator = x, e.async = function(t, r, n, o, a) {
                    void 0 === a && (a = Promise);
                    var i = new x(c(t, r, n, o), a);
                    return e.isGeneratorFunction(r) ? i : i.next().then(function(e) {
                        return e.done ? e.value : i.next();
                    });
                }, S(E), u(E, l, "Generator"), E[a] = function() {
                    return this;
                }, E.toString = function() {
                    return "[object Generator]";
                }, e.keys = function(e) {
                    var t = [];
                    for(var r in e)t.push(r);
                    return t.reverse(), function r() {
                        for(; t.length;){
                            var n = t.pop();
                            if (n in e) return r.value = n, r.done = !1, r;
                        }
                        return r.done = !0, r;
                    };
                }, e.values = P, T.prototype = {
                    constructor: T,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(O), !e) for(var r in this)"t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t);
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval;
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var r = this;
                        function o(n, o) {
                            return l.type = "throw", l.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o;
                        }
                        for(var a = this.tryEntries.length - 1; a >= 0; --a){
                            var i = this.tryEntries[a], l = i.completion;
                            if ("root" === i.tryLoc) return o("end");
                            if (i.tryLoc <= this.prev) {
                                var u = n.call(i, "catchLoc"), c = n.call(i, "finallyLoc");
                                if (u && c) {
                                    if (this.prev < i.catchLoc) return o(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return o(i.finallyLoc);
                                } else if (u) {
                                    if (this.prev < i.catchLoc) return o(i.catchLoc, !0);
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return o(i.finallyLoc);
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for(var r = this.tryEntries.length - 1; r >= 0; --r){
                            var o = this.tryEntries[r];
                            if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) {
                                var a = o;
                                break;
                            }
                        }
                        a && ("break" === e || "continue" === e) && a.tryLoc <= t && t <= a.finallyLoc && (a = null);
                        var i = a ? a.completion : {};
                        return i.type = e, i.arg = t, a ? (this.method = "next", this.next = a.finallyLoc, g) : this.complete(i);
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), g;
                    },
                    finish: function(e) {
                        for(var t = this.tryEntries.length - 1; t >= 0; --t){
                            var r = this.tryEntries[t];
                            if (r.finallyLoc === e) return this.complete(r.completion, r.afterLoc), O(r), g;
                        }
                    },
                    catch: function(e) {
                        for(var t = this.tryEntries.length - 1; t >= 0; --t){
                            var r = this.tryEntries[t];
                            if (r.tryLoc === e) {
                                var n = r.completion;
                                if ("throw" === n.type) {
                                    var o = n.arg;
                                    O(r);
                                }
                                return o;
                            }
                        }
                        throw new Error("illegal catch attempt");
                    },
                    delegateYield: function(e, r, n) {
                        return this.delegate = {
                            iterator: P(e),
                            resultName: r,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = t), g;
                    }
                }, e;
            }(e.exports);
            try {
                regeneratorRuntime = n;
            } catch (e) {
                Function("r", "regeneratorRuntime = r")(n);
            }
        },
        function(e, t) {
            var r = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("");
            t.encode = function(e) {
                if (0 <= e && e < r.length) return r[e];
                throw new TypeError("Must be between 0 and 63: " + e);
            }, t.decode = function(e) {
                return 65 <= e && e <= 90 ? e - 65 : 97 <= e && e <= 122 ? e - 97 + 26 : 48 <= e && e <= 57 ? e - 48 + 52 : 43 == e ? 62 : 47 == e ? 63 : -1;
            };
        },
        function(e, t, r) {
            var n = r(1);
            function o() {
                this._array = [], this._sorted = !0, this._last = {
                    generatedLine: -1,
                    generatedColumn: 0
                };
            }
            o.prototype.unsortedForEach = function(e, t) {
                this._array.forEach(e, t);
            }, o.prototype.add = function(e) {
                var t, r, o, a, i, l;
                t = this._last, r = e, o = t.generatedLine, a = r.generatedLine, i = t.generatedColumn, l = r.generatedColumn, a > o || a == o && l >= i || n.compareByGeneratedPositionsInflated(t, r) <= 0 ? (this._last = e, this._array.push(e)) : (this._sorted = !1, this._array.push(e));
            }, o.prototype.toArray = function() {
                return this._sorted || (this._array.sort(n.compareByGeneratedPositionsInflated), this._sorted = !0), this._array;
            }, t.MappingList = o;
        },
        function(e, t, r) {
            var n = r(1), o = r(12), a = r(6).ArraySet, i = r(5), l = r(13).quickSort;
            function u(e) {
                var t = e;
                return "string" == typeof e && (t = JSON.parse(e.replace(/^\)\]\}'/, ""))), null != t.sections ? new f(t) : new c(t);
            }
            function c(e) {
                var t = e;
                "string" == typeof e && (t = JSON.parse(e.replace(/^\)\]\}'/, "")));
                var r = n.getArg(t, "version"), o = n.getArg(t, "sources"), i = n.getArg(t, "names", []), l = n.getArg(t, "sourceRoot", null), u = n.getArg(t, "sourcesContent", null), c = n.getArg(t, "mappings"), s = n.getArg(t, "file", null);
                if (r != this._version) throw new Error("Unsupported version: " + r);
                o = o.map(String).map(n.normalize).map(function(e) {
                    return l && n.isAbsolute(l) && n.isAbsolute(e) ? n.relative(l, e) : e;
                }), this._names = a.fromArray(i.map(String), !0), this._sources = a.fromArray(o, !0), this.sourceRoot = l, this.sourcesContent = u, this._mappings = c, this.file = s;
            }
            function s() {
                this.generatedLine = 0, this.generatedColumn = 0, this.source = null, this.originalLine = null, this.originalColumn = null, this.name = null;
            }
            function f(e) {
                var t = e;
                "string" == typeof e && (t = JSON.parse(e.replace(/^\)\]\}'/, "")));
                var r = n.getArg(t, "version"), o = n.getArg(t, "sections");
                if (r != this._version) throw new Error("Unsupported version: " + r);
                this._sources = new a, this._names = new a;
                var i = {
                    line: -1,
                    column: 0
                };
                this._sections = o.map(function(e) {
                    if (e.url) throw new Error("Support for url field in sections not implemented.");
                    var t = n.getArg(e, "offset"), r = n.getArg(t, "line"), o = n.getArg(t, "column");
                    if (r < i.line || r === i.line && o < i.column) throw new Error("Section offsets must be ordered and non-overlapping.");
                    return i = t, {
                        generatedOffset: {
                            generatedLine: r + 1,
                            generatedColumn: o + 1
                        },
                        consumer: new u(n.getArg(e, "map"))
                    };
                });
            }
            u.fromSourceMap = function(e) {
                return c.fromSourceMap(e);
            }, u.prototype._version = 3, u.prototype.__generatedMappings = null, Object.defineProperty(u.prototype, "_generatedMappings", {
                get: function() {
                    return this.__generatedMappings || this._parseMappings(this._mappings, this.sourceRoot), this.__generatedMappings;
                }
            }), u.prototype.__originalMappings = null, Object.defineProperty(u.prototype, "_originalMappings", {
                get: function() {
                    return this.__originalMappings || this._parseMappings(this._mappings, this.sourceRoot), this.__originalMappings;
                }
            }), u.prototype._charIsMappingSeparator = function(e, t) {
                var r = e.charAt(t);
                return ";" === r || "," === r;
            }, u.prototype._parseMappings = function(e, t) {
                throw new Error("Subclasses must implement _parseMappings");
            }, u.GENERATED_ORDER = 1, u.ORIGINAL_ORDER = 2, u.GREATEST_LOWER_BOUND = 1, u.LEAST_UPPER_BOUND = 2, u.prototype.eachMapping = function(e, t, r) {
                var o, a = t || null;
                switch(r || u.GENERATED_ORDER){
                    case u.GENERATED_ORDER:
                        o = this._generatedMappings;
                        break;
                    case u.ORIGINAL_ORDER:
                        o = this._originalMappings;
                        break;
                    default:
                        throw new Error("Unknown order of iteration.");
                }
                var i = this.sourceRoot;
                o.map(function(e) {
                    var t = null === e.source ? null : this._sources.at(e.source);
                    return null != t && null != i && (t = n.join(i, t)), {
                        source: t,
                        generatedLine: e.generatedLine,
                        generatedColumn: e.generatedColumn,
                        originalLine: e.originalLine,
                        originalColumn: e.originalColumn,
                        name: null === e.name ? null : this._names.at(e.name)
                    };
                }, this).forEach(e, a);
            }, u.prototype.allGeneratedPositionsFor = function(e) {
                var t = n.getArg(e, "line"), r = {
                    source: n.getArg(e, "source"),
                    originalLine: t,
                    originalColumn: n.getArg(e, "column", 0)
                };
                if (null != this.sourceRoot && (r.source = n.relative(this.sourceRoot, r.source)), !this._sources.has(r.source)) return [];
                r.source = this._sources.indexOf(r.source);
                var a = [], i = this._findMapping(r, this._originalMappings, "originalLine", "originalColumn", n.compareByOriginalPositions, o.LEAST_UPPER_BOUND);
                if (i >= 0) {
                    var l = this._originalMappings[i];
                    if (void 0 === e.column) for(var u = l.originalLine; l && l.originalLine === u;)a.push({
                        line: n.getArg(l, "generatedLine", null),
                        column: n.getArg(l, "generatedColumn", null),
                        lastColumn: n.getArg(l, "lastGeneratedColumn", null)
                    }), l = this._originalMappings[++i];
                    else for(var c = l.originalColumn; l && l.originalLine === t && l.originalColumn == c;)a.push({
                        line: n.getArg(l, "generatedLine", null),
                        column: n.getArg(l, "generatedColumn", null),
                        lastColumn: n.getArg(l, "lastGeneratedColumn", null)
                    }), l = this._originalMappings[++i];
                }
                return a;
            }, t.SourceMapConsumer = u, c.prototype = Object.create(u.prototype), c.prototype.consumer = u, c.fromSourceMap = function(e) {
                var t = Object.create(c.prototype), r = t._names = a.fromArray(e._names.toArray(), !0), o = t._sources = a.fromArray(e._sources.toArray(), !0);
                t.sourceRoot = e._sourceRoot, t.sourcesContent = e._generateSourcesContent(t._sources.toArray(), t.sourceRoot), t.file = e._file;
                for(var i = e._mappings.toArray().slice(), u = t.__generatedMappings = [], f = t.__originalMappings = [], d = 0, p = i.length; d < p; d++){
                    var h = i[d], g = new s;
                    g.generatedLine = h.generatedLine, g.generatedColumn = h.generatedColumn, h.source && (g.source = o.indexOf(h.source), g.originalLine = h.originalLine, g.originalColumn = h.originalColumn, h.name && (g.name = r.indexOf(h.name)), f.push(g)), u.push(g);
                }
                return l(t.__originalMappings, n.compareByOriginalPositions), t;
            }, c.prototype._version = 3, Object.defineProperty(c.prototype, "sources", {
                get: function() {
                    return this._sources.toArray().map(function(e) {
                        return null != this.sourceRoot ? n.join(this.sourceRoot, e) : e;
                    }, this);
                }
            }), c.prototype._parseMappings = function(e, t) {
                for(var r, o, a, u, c, f = 1, d = 0, p = 0, h = 0, g = 0, m = 0, v = e.length, y = 0, b = {}, w = {}, k = [], E = []; y < v;)if (";" === e.charAt(y)) f++, y++, d = 0;
                else if ("," === e.charAt(y)) y++;
                else {
                    for((r = new s).generatedLine = f, u = y; u < v && !this._charIsMappingSeparator(e, u); u++);
                    if (a = b[o = e.slice(y, u)]) y += o.length;
                    else {
                        for(a = []; y < u;)i.decode(e, y, w), c = w.value, y = w.rest, a.push(c);
                        if (2 === a.length) throw new Error("Found a source, but no line and column");
                        if (3 === a.length) throw new Error("Found a source and line, but no column");
                        b[o] = a;
                    }
                    r.generatedColumn = d + a[0], d = r.generatedColumn, a.length > 1 && (r.source = g + a[1], g += a[1], r.originalLine = p + a[2], p = r.originalLine, r.originalLine += 1, r.originalColumn = h + a[3], h = r.originalColumn, a.length > 4 && (r.name = m + a[4], m += a[4])), E.push(r), "number" == typeof r.originalLine && k.push(r);
                }
                l(E, n.compareByGeneratedPositionsDeflated), this.__generatedMappings = E, l(k, n.compareByOriginalPositions), this.__originalMappings = k;
            }, c.prototype._findMapping = function(e, t, r, n, a, i) {
                if (e[r] <= 0) throw new TypeError("Line must be greater than or equal to 1, got " + e[r]);
                if (e[n] < 0) throw new TypeError("Column must be greater than or equal to 0, got " + e[n]);
                return o.search(e, t, a, i);
            }, c.prototype.computeColumnSpans = function() {
                for(var e = 0; e < this._generatedMappings.length; ++e){
                    var t = this._generatedMappings[e];
                    if (e + 1 < this._generatedMappings.length) {
                        var r = this._generatedMappings[e + 1];
                        if (t.generatedLine === r.generatedLine) {
                            t.lastGeneratedColumn = r.generatedColumn - 1;
                            continue;
                        }
                    }
                    t.lastGeneratedColumn = 1 / 0;
                }
            }, c.prototype.originalPositionFor = function(e) {
                var t = {
                    generatedLine: n.getArg(e, "line"),
                    generatedColumn: n.getArg(e, "column")
                }, r = this._findMapping(t, this._generatedMappings, "generatedLine", "generatedColumn", n.compareByGeneratedPositionsDeflated, n.getArg(e, "bias", u.GREATEST_LOWER_BOUND));
                if (r >= 0) {
                    var o = this._generatedMappings[r];
                    if (o.generatedLine === t.generatedLine) {
                        var a = n.getArg(o, "source", null);
                        null !== a && (a = this._sources.at(a), null != this.sourceRoot && (a = n.join(this.sourceRoot, a)));
                        var i = n.getArg(o, "name", null);
                        return null !== i && (i = this._names.at(i)), {
                            source: a,
                            line: n.getArg(o, "originalLine", null),
                            column: n.getArg(o, "originalColumn", null),
                            name: i
                        };
                    }
                }
                return {
                    source: null,
                    line: null,
                    column: null,
                    name: null
                };
            }, c.prototype.hasContentsOfAllSources = function() {
                return !!this.sourcesContent && this.sourcesContent.length >= this._sources.size() && !this.sourcesContent.some(function(e) {
                    return null == e;
                });
            }, c.prototype.sourceContentFor = function(e, t) {
                if (!this.sourcesContent) return null;
                if (null != this.sourceRoot && (e = n.relative(this.sourceRoot, e)), this._sources.has(e)) return this.sourcesContent[this._sources.indexOf(e)];
                var r;
                if (null != this.sourceRoot && (r = n.urlParse(this.sourceRoot))) {
                    var o = e.replace(/^file:\/\//, "");
                    if ("file" == r.scheme && this._sources.has(o)) return this.sourcesContent[this._sources.indexOf(o)];
                    if ((!r.path || "/" == r.path) && this._sources.has("/" + e)) return this.sourcesContent[this._sources.indexOf("/" + e)];
                }
                if (t) return null;
                throw new Error('"' + e + '" is not in the SourceMap.');
            }, c.prototype.generatedPositionFor = function(e) {
                var t = n.getArg(e, "source");
                if (null != this.sourceRoot && (t = n.relative(this.sourceRoot, t)), !this._sources.has(t)) return {
                    line: null,
                    column: null,
                    lastColumn: null
                };
                var r = {
                    source: t = this._sources.indexOf(t),
                    originalLine: n.getArg(e, "line"),
                    originalColumn: n.getArg(e, "column")
                }, o = this._findMapping(r, this._originalMappings, "originalLine", "originalColumn", n.compareByOriginalPositions, n.getArg(e, "bias", u.GREATEST_LOWER_BOUND));
                if (o >= 0) {
                    var a = this._originalMappings[o];
                    if (a.source === r.source) return {
                        line: n.getArg(a, "generatedLine", null),
                        column: n.getArg(a, "generatedColumn", null),
                        lastColumn: n.getArg(a, "lastGeneratedColumn", null)
                    };
                }
                return {
                    line: null,
                    column: null,
                    lastColumn: null
                };
            }, t.BasicSourceMapConsumer = c, f.prototype = Object.create(u.prototype), f.prototype.constructor = u, f.prototype._version = 3, Object.defineProperty(f.prototype, "sources", {
                get: function() {
                    for(var e = [], t = 0; t < this._sections.length; t++)for(var r = 0; r < this._sections[t].consumer.sources.length; r++)e.push(this._sections[t].consumer.sources[r]);
                    return e;
                }
            }), f.prototype.originalPositionFor = function(e) {
                var t = {
                    generatedLine: n.getArg(e, "line"),
                    generatedColumn: n.getArg(e, "column")
                }, r = o.search(t, this._sections, function(e, t) {
                    var r = e.generatedLine - t.generatedOffset.generatedLine;
                    return r || e.generatedColumn - t.generatedOffset.generatedColumn;
                }), a = this._sections[r];
                return a ? a.consumer.originalPositionFor({
                    line: t.generatedLine - (a.generatedOffset.generatedLine - 1),
                    column: t.generatedColumn - (a.generatedOffset.generatedLine === t.generatedLine ? a.generatedOffset.generatedColumn - 1 : 0),
                    bias: e.bias
                }) : {
                    source: null,
                    line: null,
                    column: null,
                    name: null
                };
            }, f.prototype.hasContentsOfAllSources = function() {
                return this._sections.every(function(e) {
                    return e.consumer.hasContentsOfAllSources();
                });
            }, f.prototype.sourceContentFor = function(e, t) {
                for(var r = 0; r < this._sections.length; r++){
                    var n = this._sections[r].consumer.sourceContentFor(e, !0);
                    if (n) return n;
                }
                if (t) return null;
                throw new Error('"' + e + '" is not in the SourceMap.');
            }, f.prototype.generatedPositionFor = function(e) {
                for(var t = 0; t < this._sections.length; t++){
                    var r = this._sections[t];
                    if (-1 !== r.consumer.sources.indexOf(n.getArg(e, "source"))) {
                        var o = r.consumer.generatedPositionFor(e);
                        if (o) return {
                            line: o.line + (r.generatedOffset.generatedLine - 1),
                            column: o.column + (r.generatedOffset.generatedLine === o.line ? r.generatedOffset.generatedColumn - 1 : 0)
                        };
                    }
                }
                return {
                    line: null,
                    column: null
                };
            }, f.prototype._parseMappings = function(e, t) {
                this.__generatedMappings = [], this.__originalMappings = [];
                for(var r = 0; r < this._sections.length; r++)for(var o = this._sections[r], a = o.consumer._generatedMappings, i = 0; i < a.length; i++){
                    var u = a[i], c = o.consumer._sources.at(u.source);
                    null !== o.consumer.sourceRoot && (c = n.join(o.consumer.sourceRoot, c)), this._sources.add(c), c = this._sources.indexOf(c);
                    var s = o.consumer._names.at(u.name);
                    this._names.add(s), s = this._names.indexOf(s);
                    var f = {
                        source: c,
                        generatedLine: u.generatedLine + (o.generatedOffset.generatedLine - 1),
                        generatedColumn: u.generatedColumn + (o.generatedOffset.generatedLine === u.generatedLine ? o.generatedOffset.generatedColumn - 1 : 0),
                        originalLine: u.originalLine,
                        originalColumn: u.originalColumn,
                        name: s
                    };
                    this.__generatedMappings.push(f), "number" == typeof f.originalLine && this.__originalMappings.push(f);
                }
                l(this.__generatedMappings, n.compareByGeneratedPositionsDeflated), l(this.__originalMappings, n.compareByOriginalPositions);
            }, t.IndexedSourceMapConsumer = f;
        },
        function(e, t) {
            t.GREATEST_LOWER_BOUND = 1, t.LEAST_UPPER_BOUND = 2, t.search = function(e, r, n, o) {
                if (0 === r.length) return -1;
                var a = function e(r, n, o, a, i, l) {
                    var u = Math.floor((n - r) / 2) + r, c = i(o, a[u], !0);
                    return 0 === c ? u : c > 0 ? n - u > 1 ? e(u, n, o, a, i, l) : l == t.LEAST_UPPER_BOUND ? n < a.length ? n : -1 : u : u - r > 1 ? e(r, u, o, a, i, l) : l == t.LEAST_UPPER_BOUND ? u : r < 0 ? -1 : r;
                }(-1, r.length, e, r, n, o || t.GREATEST_LOWER_BOUND);
                if (a < 0) return -1;
                for(; a - 1 >= 0 && 0 === n(r[a], r[a - 1], !0);)--a;
                return a;
            };
        },
        function(e, t) {
            function r(e, t, r) {
                var n = e[t];
                e[t] = e[r], e[r] = n;
            }
            function n(e, t, o, a) {
                if (o < a) {
                    var i = o - 1;
                    r(e, (s = o, f = a, Math.round(s + Math.random() * (f - s))), a);
                    for(var l = e[a], u = o; u < a; u++)t(e[u], l) <= 0 && r(e, i += 1, u);
                    r(e, i + 1, u);
                    var c = i + 1;
                    n(e, t, o, c - 1), n(e, t, c + 1, a);
                }
                var s, f;
            }
            t.quickSort = function(e, t) {
                n(e, t, 0, e.length - 1);
            };
        },
        function(e, t, r) {
            var n = r(4).SourceMapGenerator, o = r(1), a = /(\r?\n)/, i = "$$$isSourceNode$$$";
            function l(e, t, r, n, o) {
                this.children = [], this.sourceContents = {}, this.line = null == e ? null : e, this.column = null == t ? null : t, this.source = null == r ? null : r, this.name = null == o ? null : o, this[i] = !0, null != n && this.add(n);
            }
            l.fromStringWithSourceMap = function(e, t, r) {
                var n = new l, i = e.split(a), u = 0, c = function() {
                    return e() + (e() || "");
                    function e() {
                        return u < i.length ? i[u++] : void 0;
                    }
                }, s = 1, f = 0, d = null;
                return t.eachMapping(function(e) {
                    if (null !== d) {
                        if (!(s < e.generatedLine)) {
                            var t = (r = i[u]).substr(0, e.generatedColumn - f);
                            return i[u] = r.substr(e.generatedColumn - f), f = e.generatedColumn, p(d, t), void (d = e);
                        }
                        p(d, c()), s++, f = 0;
                    }
                    for(; s < e.generatedLine;)n.add(c()), s++;
                    if (f < e.generatedColumn) {
                        var r = i[u];
                        n.add(r.substr(0, e.generatedColumn)), i[u] = r.substr(e.generatedColumn), f = e.generatedColumn;
                    }
                    d = e;
                }, this), u < i.length && (d && p(d, c()), n.add(i.splice(u).join(""))), t.sources.forEach(function(e) {
                    var a = t.sourceContentFor(e);
                    null != a && (null != r && (e = o.join(r, e)), n.setSourceContent(e, a));
                }), n;
                function p(e, t) {
                    if (null === e || void 0 === e.source) n.add(t);
                    else {
                        var a = r ? o.join(r, e.source) : e.source;
                        n.add(new l(e.originalLine, e.originalColumn, a, t, e.name));
                    }
                }
            }, l.prototype.add = function(e) {
                if (Array.isArray(e)) e.forEach(function(e) {
                    this.add(e);
                }, this);
                else {
                    if (!e[i] && "string" != typeof e) throw new TypeError("Expected a SourceNode, string, or an array of SourceNodes and strings. Got " + e);
                    e && this.children.push(e);
                }
                return this;
            }, l.prototype.prepend = function(e) {
                if (Array.isArray(e)) for(var t = e.length - 1; t >= 0; t--)this.prepend(e[t]);
                else {
                    if (!e[i] && "string" != typeof e) throw new TypeError("Expected a SourceNode, string, or an array of SourceNodes and strings. Got " + e);
                    this.children.unshift(e);
                }
                return this;
            }, l.prototype.walk = function(e) {
                for(var t, r = 0, n = this.children.length; r < n; r++)(t = this.children[r])[i] ? t.walk(e) : "" !== t && e(t, {
                    source: this.source,
                    line: this.line,
                    column: this.column,
                    name: this.name
                });
            }, l.prototype.join = function(e) {
                var t, r, n = this.children.length;
                if (n > 0) {
                    for(t = [], r = 0; r < n - 1; r++)t.push(this.children[r]), t.push(e);
                    t.push(this.children[r]), this.children = t;
                }
                return this;
            }, l.prototype.replaceRight = function(e, t) {
                var r = this.children[this.children.length - 1];
                return r[i] ? r.replaceRight(e, t) : "string" == typeof r ? this.children[this.children.length - 1] = r.replace(e, t) : this.children.push("".replace(e, t)), this;
            }, l.prototype.setSourceContent = function(e, t) {
                this.sourceContents[o.toSetString(e)] = t;
            }, l.prototype.walkSourceContents = function(e) {
                for(var t = 0, r = this.children.length; t < r; t++)this.children[t][i] && this.children[t].walkSourceContents(e);
                var n = Object.keys(this.sourceContents);
                for(t = 0, r = n.length; t < r; t++)e(o.fromSetString(n[t]), this.sourceContents[n[t]]);
            }, l.prototype.toString = function() {
                var e = "";
                return this.walk(function(t) {
                    e += t;
                }), e;
            }, l.prototype.toStringWithSourceMap = function(e) {
                var t = {
                    code: "",
                    line: 1,
                    column: 0
                }, r = new n(e), o = !1, a = null, i = null, l = null, u = null;
                return this.walk(function(e, n) {
                    t.code += e, null !== n.source && null !== n.line && null !== n.column ? (a === n.source && i === n.line && l === n.column && u === n.name || r.addMapping({
                        source: n.source,
                        original: {
                            line: n.line,
                            column: n.column
                        },
                        generated: {
                            line: t.line,
                            column: t.column
                        },
                        name: n.name
                    }), a = n.source, i = n.line, l = n.column, u = n.name, o = !0) : o && (r.addMapping({
                        generated: {
                            line: t.line,
                            column: t.column
                        }
                    }), a = null, o = !1);
                    for(var c = 0, s = e.length; c < s; c++)10 === e.charCodeAt(c) ? (t.line++, t.column = 0, c + 1 === s ? (a = null, o = !1) : o && r.addMapping({
                        source: n.source,
                        original: {
                            line: n.line,
                            column: n.column
                        },
                        generated: {
                            line: t.line,
                            column: t.column
                        },
                        name: n.name
                    })) : t.column++;
                }), this.walkSourceContents(function(e, t) {
                    r.setSourceContent(e, t);
                }), {
                    code: t.code,
                    map: r
                };
            }, t.SourceNode = l;
        },
        function(e, t, r) {
            "use strict";
            r.r(t), r.d(t, "setEditorHandler", function() {
                return ue;
            }), r.d(t, "reportBuildError", function() {
                return ce;
            }), r.d(t, "reportRuntimeError", function() {
                return se;
            }), r.d(t, "dismissBuildError", function() {
                return fe;
            }), r.d(t, "startReportingRuntimeErrors", function() {
                return de;
            }), r.d(t, "dismissRuntimeErrors", function() {
                return he;
            }), r.d(t, "stopReportingRuntimeErrors", function() {
                return ge;
            });
            var n = null;
            function o(e, t) {
                if (t.error) {
                    var r = t.error;
                    r instanceof Error ? e(r) : e(new Error(r));
                }
            }
            function a(e, t) {
                null === n && (n = o.bind(void 0, t), e.addEventListener("error", n));
            }
            var i = null;
            function l(e, t) {
                if (null == t || null == t.reason) return e(new Error("Unknown"));
                var r = t.reason;
                return r instanceof Error ? e(r) : e(new Error(r));
            }
            function u(e, t) {
                null === i && (i = l.bind(void 0, t), e.addEventListener("unhandledrejection", i));
            }
            var c = !1, s = 10, f = 50;
            var d = [], p = function() {
                "undefined" != typeof console && (console.reactStack = function(e) {
                    return d.push(e);
                }, console.reactStackEnd = function(e) {
                    return d.pop();
                });
            }, h = function() {
                "undefined" != typeof console && (console.reactStack = void 0, console.reactStackEnd = void 0);
            }, g = function(e, t) {
                if ("undefined" != typeof console) {
                    var r = console[e];
                    "function" == typeof r && (console[e] = function() {
                        try {
                            var e = arguments[0];
                            "string" == typeof e && d.length > 0 && t(e, d[d.length - 1]);
                        } catch (e) {
                            setTimeout(function() {
                                throw e;
                            });
                        }
                        return r.apply(this, arguments);
                    });
                }
            };
            function m(e, t) {
                return (m = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e;
                })(e, t);
            }
            function v(e, t, r) {
                return (v = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], function() {})), !0;
                    } catch (e) {
                        return !1;
                    }
                }() ? Reflect.construct : function(e, t, r) {
                    var n = [
                        null
                    ];
                    n.push.apply(n, t);
                    var o = new (Function.bind.apply(e, n));
                    return r && m(o, r.prototype), o;
                }).apply(null, arguments);
            }
            function y(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for(var r = 0, n = new Array(t); r < t; r++)n[r] = e[r];
                return n;
            }
            function b(e) {
                return function(e) {
                    if (Array.isArray(e)) return y(e);
                }(e) || function(e) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) return Array.from(e);
                }(e) || function(e, t) {
                    if (e) {
                        if ("string" == typeof e) return y(e, t);
                        var r = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? y(e, t) : void 0;
                    }
                }(e) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function w(e, t) {
                for(var r = 0; r < t.length; r++){
                    var n = t[r];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function k(e, t, r) {
                return t && w(e.prototype, t), r && w(e, r), e;
            }
            function E(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            var S = function e(t, r) {
                var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                E(this, e), this.lineNumber = t, this.content = r, this.highlight = n;
            }, x = function() {
                function e() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null, o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null, a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null, i = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null, l = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null, u = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null, c = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : null, s = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : null;
                    E(this, e), t && 0 === t.indexOf("Object.") && (t = t.slice(7)), "friendlySyntaxErrorLabel" !== t && "exports.__esModule" !== t && "<anonymous>" !== t && t || (t = null), this.functionName = t, this.fileName = r, this.lineNumber = n, this.columnNumber = o, this._originalFunctionName = i, this._originalFileName = l, this._originalLineNumber = u, this._originalColumnNumber = c, this._scriptCode = a, this._originalScriptCode = s;
                }
                return k(e, [
                    {
                        key: "getFunctionName",
                        value: function() {
                            return this.functionName || "(anonymous function)";
                        }
                    },
                    {
                        key: "getSource",
                        value: function() {
                            var e = "";
                            return null != this.fileName && (e += this.fileName + ":"), null != this.lineNumber && (e += this.lineNumber + ":"), null != this.columnNumber && (e += this.columnNumber + ":"), e.slice(0, -1);
                        }
                    },
                    {
                        key: "toString",
                        value: function() {
                            var e = this.getFunctionName(), t = this.getSource();
                            return "".concat(e).concat(t ? " (".concat(t, ")") : "");
                        }
                    }
                ]), e;
            }(), _ = /\(?(.+?)(?::(\d+))?(?::(\d+))?\)?$/;
            function C(e) {
                return _.exec(e).slice(1).map(function(e) {
                    var t = Number(e);
                    return isNaN(t) ? e : t;
                });
            }
            var O = /^\s*(at|in)\s.+(:\d+)/, T = /(^|@)\S+:\d+|.+line\s+\d+\s+>\s+(eval|Function).+/;
            function P(e) {
                return e.filter(function(e) {
                    return O.test(e) || T.test(e);
                }).map(function(e) {
                    if (T.test(e)) {
                        var t = !1;
                        / > (eval|Function)/.test(e) && (e = e.replace(/ line (\d+)(?: > eval line \d+)* > (eval|Function):\d+:\d+/g, ":$1"), t = !0);
                        var r = e.split(/[@]/g), n = r.pop();
                        return v(x, [
                            r.join("@") || (t ? "eval" : null)
                        ].concat(b(C(n))));
                    }
                    -1 !== e.indexOf("(eval ") && (e = e.replace(/(\(eval at [^()]*)|(\),.*$)/g, "")), -1 !== e.indexOf("(at ") && (e = e.replace(/\(at /, "("));
                    var o = e.trim().split(/\s+/g).slice(1), a = o.pop();
                    return v(x, [
                        o.join(" ") || null
                    ].concat(b(C(a))));
                });
            }
            function L(e) {
                if (null == e) throw new Error("You cannot pass a null object.");
                if ("string" == typeof e) return P(e.split("\n"));
                if (Array.isArray(e)) return P(e);
                if ("string" == typeof e.stack) return P(e.stack.split("\n"));
                throw new Error("The error you provided does not contain a stack trace.");
            }
            var R = r(0), A = r.n(R);
            function N(e, t, r, n, o, a, i) {
                try {
                    var l = e[a](i), u = l.value;
                } catch (e) {
                    return void r(e);
                }
                l.done ? t(u) : Promise.resolve(u).then(n, o);
            }
            function j(e) {
                return function() {
                    var t = this, r = arguments;
                    return new Promise(function(n, o) {
                        var a = e.apply(t, r);
                        function i(e) {
                            N(a, n, o, i, l, "next", e);
                        }
                        function l(e) {
                            N(a, n, o, i, l, "throw", e);
                        }
                        i(void 0);
                    });
                };
            }
            var M = r(3), I = function() {
                function e(t) {
                    E(this, e), this.__source_map = t;
                }
                return k(e, [
                    {
                        key: "getOriginalPosition",
                        value: function(e, t) {
                            var r = this.__source_map.originalPositionFor({
                                line: e,
                                column: t
                            });
                            return {
                                line: r.line,
                                column: r.column,
                                source: r.source
                            };
                        }
                    },
                    {
                        key: "getGeneratedPosition",
                        value: function(e, t, r) {
                            var n = this.__source_map.generatedPositionFor({
                                source: e,
                                line: t,
                                column: r
                            });
                            return {
                                line: n.line,
                                column: n.column
                            };
                        }
                    },
                    {
                        key: "getSource",
                        value: function(e) {
                            return this.__source_map.sourceContentFor(e);
                        }
                    },
                    {
                        key: "getSources",
                        value: function() {
                            return this.__source_map.sources;
                        }
                    }
                ]), e;
            }();
            function D(e, t) {
                for(var r = /\/\/[#@] ?sourceMappingURL=([^\s'"]+)\s*$/gm, n = null;;){
                    var o = r.exec(t);
                    if (null == o) break;
                    n = o;
                }
                return n && n[1] ? Promise.resolve(n[1].toString()) : Promise.reject("Cannot find a source map directive for ".concat(e, "."));
            }
            function z(e, t) {
                return q.apply(this, arguments);
            }
            function q() {
                return (q = j(A.a.mark(function e(t, r) {
                    var n, o, a, i, l, u;
                    return A.a.wrap(function(e) {
                        for(;;)switch(e.prev = e.next){
                            case 0:
                                return e.next = 2, D(t, r);
                            case 2:
                                if (0 !== (n = e.sent).indexOf("data:")) {
                                    e.next = 14;
                                    break;
                                }
                                if (o = /^data:application\/json;([\w=:"-]+;)*base64,/, a = n.match(o)) {
                                    e.next = 8;
                                    break;
                                }
                                throw new Error("Sorry, non-base64 inline source-map encoding is not supported.");
                            case 8:
                                return n = n.substring(a[0].length), n = window.atob(n), n = JSON.parse(n), e.abrupt("return", new I(new M.SourceMapConsumer(n)));
                            case 14:
                                return i = t.lastIndexOf("/"), l = t.substring(0, i + 1) + n, e.next = 18, fetch(l).then(function(e) {
                                    return e.json();
                                });
                            case 18:
                                return u = e.sent, e.abrupt("return", new I(new M.SourceMapConsumer(u)));
                            case 20:
                            case "end":
                                return e.stop();
                        }
                    }, e);
                }))).apply(this, arguments);
            }
            function F(e, t, r) {
                "string" == typeof r && (r = r.split("\n"));
                for(var n = [], o = Math.max(0, e - 1 - t); o <= Math.min(r.length - 1, e - 1 + t); ++o)n.push(new S(o + 1, r[o], o === e - 1));
                return n;
            }
            var U = r(7);
            function B(e) {
                return H.apply(this, arguments);
            }
            function H() {
                return (H = j(A.a.mark(function e(t) {
                    var r, n, o, a = arguments;
                    return A.a.wrap(function(e) {
                        for(;;)switch(e.prev = e.next){
                            case 0:
                                return r = a.length > 1 && void 0 !== a[1] ? a[1] : 3, n = {}, o = [], t.forEach(function(e) {
                                    var t = e.fileName;
                                    null != t && -1 === o.indexOf(t) && o.push(t);
                                }), e.next = 6, Object(U.settle)(o.map(function() {
                                    var e = j(A.a.mark(function e(t) {
                                        var r, o, a;
                                        return A.a.wrap(function(e) {
                                            for(;;)switch(e.prev = e.next){
                                                case 0:
                                                    return r = 0 === t.indexOf("webpack-internal:") ? "/__get-internal-source?fileName=".concat(encodeURIComponent(t)) : t, e.next = 3, fetch(r).then(function(e) {
                                                        return e.text();
                                                    });
                                                case 3:
                                                    return o = e.sent, e.next = 6, z(t, o);
                                                case 6:
                                                    a = e.sent, n[t] = {
                                                        fileSource: o,
                                                        map: a
                                                    };
                                                case 8:
                                                case "end":
                                                    return e.stop();
                                            }
                                        }, e);
                                    }));
                                    return function(t) {
                                        return e.apply(this, arguments);
                                    };
                                }()));
                            case 6:
                                return e.abrupt("return", t.map(function(e) {
                                    var t = e.functionName, o = e.fileName, a = e.lineNumber, i = e.columnNumber, l = n[o] || {}, u = l.map, c = l.fileSource;
                                    if (null == u || null == a) return e;
                                    var s = u.getOriginalPosition(a, i), f = s.source, d = s.line, p = s.column, h = null == f ? [] : u.getSource(f);
                                    return new x(t, o, a, i, F(a, r, c), t, f, d, p, F(d, r, h));
                                }));
                            case 7:
                            case "end":
                                return e.stop();
                        }
                    }, e);
                }))).apply(this, arguments);
            }
            var $ = r(2), V = r.n($);
            function W(e, t) {
                var r = -1, n = -1;
                do ++r, n = t.indexOf(e, n + 1);
                while (-1 !== n);
                return r;
            }
            function G(e, t) {
                return Q.apply(this, arguments);
            }
            function Q() {
                return (Q = j(A.a.mark(function e(t, r) {
                    var n, o, a, i, l = arguments;
                    return A.a.wrap(function(e) {
                        for(;;)switch(e.prev = e.next){
                            case 0:
                                if (n = l.length > 2 && void 0 !== l[2] ? l[2] : 3, o = "object" == typeof t ? t.contents : null, a = "object" == typeof t ? t.uri : t, null != o) {
                                    e.next = 7;
                                    break;
                                }
                                return e.next = 6, fetch(a).then(function(e) {
                                    return e.text();
                                });
                            case 6:
                                o = e.sent;
                            case 7:
                                return e.next = 9, z(a, o);
                            case 9:
                                return i = e.sent, e.abrupt("return", r.map(function(e) {
                                    var t = e.functionName, r = e.lineNumber, l = e.columnNumber;
                                    if (null != e._originalLineNumber) return e;
                                    var u = e.fileName;
                                    if (u && (u = V.a.normalize(u.replace(/[\\]+/g, "/"))), null == u) return e;
                                    var c = u, s = i.getSources().map(function(e) {
                                        return e.replace(/[\\]+/g, "/");
                                    }).filter(function(e) {
                                        var t = (e = V.a.normalize(e)).lastIndexOf(c);
                                        return -1 !== t && t === e.length - c.length;
                                    }).map(function(e) {
                                        return {
                                            token: e,
                                            seps: W(V.a.sep, V.a.normalize(e)),
                                            penalties: W("node_modules", e) + W("~", e)
                                        };
                                    }).sort(function(e, t) {
                                        var r = Math.sign(e.seps - t.seps);
                                        return 0 !== r ? r : Math.sign(e.penalties - t.penalties);
                                    });
                                    if (s.length < 1 || null == r) return new x(null, null, null, null, null, t, c, r, l, null);
                                    var f = s[0].token, d = i.getGeneratedPosition(f, r, l), p = d.line, h = d.column, g = i.getSource(f);
                                    return new x(t, a, p, h || null, F(p, n, o || []), t, c, r, l, F(r, n, g));
                                }));
                            case 11:
                            case "end":
                                return e.stop();
                        }
                    }, e);
                }))).apply(this, arguments);
            }
            var Y = function(e) {
                arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                var t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 3, r = L(e);
                return (e.__unmap_source ? G(e.__unmap_source, r, t) : B(r, t)).then(function(e) {
                    return 0 === e.map(function(e) {
                        return e._originalFileName;
                    }).filter(function(e) {
                        return null != e && -1 === e.indexOf("node_modules");
                    }).length ? null : e.filter(function(e) {
                        var t = e.functionName;
                        return null == t || -1 === t.indexOf("__stack_frame_overlay_proxy_console__");
                    });
                });
            }, X = function(e) {
                return function(t) {
                    var r = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    Y(t, r, 3).then(function(n) {
                        null != n && e({
                            error: t,
                            unhandledRejection: r,
                            contextSize: 3,
                            stackFrames: n
                        });
                    }).catch(function(e) {
                        console.log("Could not get the stack frames of error:", e);
                    });
                };
            };
            function K(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "/static/js/bundle.js", r = X(e);
                return a(window, function(e) {
                    return r(e, !1);
                }), u(window, function(e) {
                    return r(e, !0);
                }), function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : f;
                    if (!c) try {
                        s = Error.stackTraceLimit, Error.stackTraceLimit = e, c = !0;
                    } catch (e) {}
                }(), p(), g("error", function(e, n) {
                    var o = function(e, t) {
                        for(var r, n, o = function(e) {
                            return e.split("\n").filter(function(e) {
                                return !e.match(/^\s*in/);
                            }).join("\n");
                        }(e), a = "", i = 0; i < t.length; ++i){
                            var l = t[i], u = l.fileName, c = l.lineNumber;
                            if (null != u && null != c && !(u === r && "number" == typeof c && "number" == typeof n && Math.abs(c - n) < 3)) {
                                r = u, n = c;
                                var s = t[i].name;
                                a += "in ".concat(s = s || "(anonymous function)", " (at ").concat(u, ":").concat(c, ")\n");
                            }
                        }
                        return {
                            message: o,
                            stack: a
                        };
                    }(e, n);
                    r({
                        message: o.message,
                        stack: o.stack,
                        __unmap_source: t
                    }, !1);
                }), function() {
                    var e;
                    !function() {
                        if (c) try {
                            Error.stackTraceLimit = s, c = !1;
                        } catch (e) {}
                    }(), e = window, null !== i && (e.removeEventListener("unhandledrejection", i), i = null), function(e) {
                        null !== n && (e.removeEventListener("error", n), n = null);
                    }(window), h();
                };
            }
            var J = {
                position: "fixed",
                top: "0",
                left: "0",
                width: "100%",
                height: "100%",
                border: "none",
                "z-index": 2147483647
            };
            var Z = '/*! For license information please see iframe-bundle.js.LICENSE.txt */\n!function(e){var t={};function r(n){if(t[n])return t[n].exports;var o=t[n]={i:n,l:!1,exports:{}};return e[n].call(o.exports,o,o.exports,r),o.l=!0,o.exports}r.m=e,r.c=t,r.d=function(e,t,n){r.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:n})},r.r=function(e){"undefined"!==typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},r.t=function(e,t){if(1&t&&(e=r(e)),8&t)return e;if(4&t&&"object"===typeof e&&e&&e.__esModule)return e;var n=Object.create(null);if(r.r(n),Object.defineProperty(n,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var o in e)r.d(n,o,function(t){return e[t]}.bind(null,o));return n},r.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return r.d(t,"a",t),t},r.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},r.p="",r(r.s=208)}([function(e,t,r){"use strict";e.exports=r(183)},function(e,t,r){var n=r(8),o=r(35).f,a=r(18),i=r(21),l=r(38),u=r(60),c=r(64);e.exports=function(e,t){var r,s,f,d,p,h=e.target,g=e.global,v=e.stat;if(r=g?n:v?n[h]||l(h,{}):(n[h]||{}).prototype)for(s in t){if(d=t[s],f=e.noTargetGet?(p=o(r,s))&&p.value:r[s],!c(g?s:h+(v?".":"#")+s,e.forced)&&void 0!==f){if(typeof d===typeof f)continue;u(d,f)}(e.sham||f&&f.sham)&&a(d,"sham",!0),i(r,s,d,e)}}},function(e,t,r){var n=r(13);e.exports=function(e){if(!n(e))throw TypeError(String(e)+" is not an object");return e}},function(e,t){e.exports=!1},function(e,t,r){var n=r(2),o=r(66),a=r(26),i=r(7),l=r(45),u=r(69),c=function(e,t){this.stopped=e,this.result=t};e.exports=function(e,t,r){var s,f,d,p,h,g,v,m=r&&r.that,y=!(!r||!r.AS_ENTRIES),b=!(!r||!r.IS_ITERATOR),w=!(!r||!r.INTERRUPTED),k=i(t,m,1+y+w),E=function(e){return s&&u(s),new c(!0,e)},x=function(e){return y?(n(e),w?k(e[0],e[1],E):k(e[0],e[1])):w?k(e,E):k(e)};if(b)s=e;else{if("function"!=typeof(f=l(e)))throw TypeError("Target is not iterable");if(o(f)){for(d=0,p=a(e.length);p>d;d++)if((h=x(e[d]))&&h instanceof c)return h;return new c(!1)}s=f.call(e)}for(g=s.next;!(v=g.call(s)).done;){try{h=x(v.value)}catch(e){throw u(s),e}if("object"==typeof h&&h&&h instanceof c)return h}return new c(!1)}},function(e,t){e.exports=function(e){if("function"!=typeof e)throw TypeError(String(e)+" is not a function");return e}},function(e,t,r){var n=r(8),o=r(40),a=r(11),i=r(31),l=r(44),u=r(67),c=o("wks"),s=n.Symbol,f=u?s:s&&s.withoutSetter||i;e.exports=function(e){return a(c,e)||(l&&a(s,e)?c[e]=s[e]:c[e]=f("Symbol."+e)),c[e]}},function(e,t,r){var n=r(5);e.exports=function(e,t,r){if(n(e),void 0===t)return e;switch(r){case 0:return function(){return e.call(t)};case 1:return function(r){return e.call(t,r)};case 2:return function(r,n){return e.call(t,r,n)};case 3:return function(r,n,o){return e.call(t,r,n,o)}}return function(){return e.apply(t,arguments)}}},function(e,t,r){(function(t){var r=function(e){return e&&e.Math==Math&&e};e.exports=r("object"==typeof globalThis&&globalThis)||r("object"==typeof window&&window)||r("object"==typeof self&&self)||r("object"==typeof t&&t)||function(){return this}()||Function("return this")()}).call(this,r(34))},function(e,t,r){var n=r(61),o=r(11),a=r(82),i=r(14).f;e.exports=function(e){var t=n.Symbol||(n.Symbol={});o(t,e)||i(t,e,{value:a.f(e)})}},function(e,t,r){var n=r(61),o=r(8),a=function(e){return"function"==typeof e?e:void 0};e.exports=function(e,t){return arguments.length<2?a(n[e])||a(o[e]):n[e]&&n[e][t]||o[e]&&o[e][t]}},function(e,t){var r={}.hasOwnProperty;e.exports=function(e,t){return r.call(e,t)}},function(e,t){e.exports=function(e){try{return!!e()}catch(e){return!0}}},function(e,t){e.exports=function(e){return"object"===typeof e?null!==e:"function"===typeof e}},function(e,t,r){var n=r(16),o=r(57),a=r(2),i=r(29),l=Object.defineProperty;t.f=n?l:function(e,t,r){if(a(e),t=i(t,!0),a(r),o)try{return l(e,t,r)}catch(e){}if("get"in r||"set"in r)throw TypeError("Accessors not supported");return"value"in r&&(e[t]=r.value),e}},function(e,t,r){var n=r(3),o=r(48);e.exports=n?o:function(e){return Map.prototype.entries.call(e)}},function(e,t,r){var n=r(12);e.exports=!n((function(){return 7!=Object.defineProperty({},1,{get:function(){return 7}})[1]}))},function(e,t,r){var n=r(2),o=r(5),a=r(6)("species");e.exports=function(e,t){var r,i=n(e).constructor;return void 0===i||void 0==(r=n(i)[a])?t:o(r)}},function(e,t,r){var n=r(16),o=r(14),a=r(23);e.exports=n?function(e,t,r){return o.f(e,t,a(1,r))}:function(e,t,r){return e[t]=r,e}},function(e,t,r){var n=r(3),o=r(48);e.exports=n?o:function(e){return Set.prototype.values.call(e)}},function(e,t,r){var n=r(56),o=r(37);e.exports=function(e){return n(o(e))}},function(e,t,r){var n=r(8),o=r(18),a=r(11),i=r(38),l=r(59),u=r(24),c=u.get,s=u.enforce,f=String(String).split("String");(e.exports=function(e,t,r,l){var u,c=!!l&&!!l.unsafe,d=!!l&&!!l.enumerable,p=!!l&&!!l.noTargetGet;"function"==typeof r&&("string"!=typeof t||a(r,"name")||o(r,"name",t),(u=s(r)).source||(u.source=f.join("string"==typeof t?t:""))),e!==n?(c?!p&&e[t]&&(d=!0):delete e[t],d?e[t]=r:o(e,t,r)):d?e[t]=r:i(t,r)})(Function.prototype,"toString",(function(){return"function"==typeof this&&c(this).source||l(this)}))},function(e,t,r){var n=r(14).f,o=r(11),a=r(6)("toStringTag");e.exports=function(e,t,r){e&&!o(e=r?e:e.prototype,a)&&n(e,a,{configurable:!0,value:t})}},function(e,t){e.exports=function(e,t){return{enumerable:!(1&e),configurable:!(2&e),writable:!(4&e),value:t}}},function(e,t,r){var n,o,a,i=r(92),l=r(8),u=r(13),c=r(18),s=r(11),f=r(39),d=r(30),p=r(25),h=l.WeakMap;if(i){var g=f.state||(f.state=new h),v=g.get,m=g.has,y=g.set;n=function(e,t){return t.facade=e,y.call(g,e,t),t},o=function(e){return v.call(g,e)||{}},a=function(e){return m.call(g,e)}}else{var b=d("state");p[b]=!0,n=function(e,t){return t.facade=e,c(e,b,t),t},o=function(e){return s(e,b)?e[b]:{}},a=function(e){return s(e,b)}}e.exports={set:n,get:o,has:a,enforce:function(e){return a(e)?o(e):n(e,{})},getterFor:function(e){return function(t){var r;if(!u(t)||(r=o(t)).type!==e)throw TypeError("Incompatible receiver, "+e+" required");return r}}}},function(e,t){e.exports={}},function(e,t,r){var n=r(42),o=Math.min;e.exports=function(e){return e>0?o(n(e),9007199254740991):0}},function(e,t){e.exports={}},function(e,t,r){var n=r(37);e.exports=function(e){return Object(n(e))}},function(e,t,r){var n=r(13);e.exports=function(e,t){if(!n(e))return e;var r,o;if(t&&"function"==typeof(r=e.toString)&&!n(o=r.call(e)))return o;if("function"==typeof(r=e.valueOf)&&!n(o=r.call(e)))return o;if(!t&&"function"==typeof(r=e.toString)&&!n(o=r.call(e)))return o;throw TypeError("Can\'t convert object to primitive value")}},function(e,t,r){var n=r(40),o=r(31),a=n("keys");e.exports=function(e){return a[e]||(a[e]=o(e))}},function(e,t){var r=0,n=Math.random();e.exports=function(e){return"Symbol("+String(void 0===e?"":e)+")_"+(++r+n).toString(36)}},function(e,t,r){var n,o=r(2),a=r(99),i=r(43),l=r(25),u=r(100),c=r(58),s=r(30),f=s("IE_PROTO"),d=function(){},p=function(e){return"<script>"+e+"</"+"script>"},h=function(){try{n=document.domain&&new ActiveXObject("htmlfile")}catch(e){}var e,t;h=n?function(e){e.write(p("")),e.close();var t=e.parentWindow.Object;return e=null,t}(n):((t=c("iframe")).style.display="none",u.appendChild(t),t.src=String("javascript:"),(e=t.contentWindow.document).open(),e.write(p("document.F=Object")),e.close(),e.F);for(var r=i.length;r--;)delete h.prototype[i[r]];return h()};l[f]=!0,e.exports=Object.create||function(e,t){var r;return null!==e?(d.prototype=o(e),r=new d,d.prototype=null,r[f]=e):r=h(),void 0===t?r:a(r,t)}},function(e,t,r){"use strict";var n=function(){function e(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(t,r,n){return r&&e(t.prototype,r),n&&e(t,n),t}}();var o=[[{color:"0, 0, 0",class:"ansi-black"},{color:"187, 0, 0",class:"ansi-red"},{color:"0, 187, 0",class:"ansi-green"},{color:"187, 187, 0",class:"ansi-yellow"},{color:"0, 0, 187",class:"ansi-blue"},{color:"187, 0, 187",class:"ansi-magenta"},{color:"0, 187, 187",class:"ansi-cyan"},{color:"255,255,255",class:"ansi-white"}],[{color:"85, 85, 85",class:"ansi-bright-black"},{color:"255, 85, 85",class:"ansi-bright-red"},{color:"0, 255, 0",class:"ansi-bright-green"},{color:"255, 255, 85",class:"ansi-bright-yellow"},{color:"85, 85, 255",class:"ansi-bright-blue"},{color:"255, 85, 255",class:"ansi-bright-magenta"},{color:"85, 255, 255",class:"ansi-bright-cyan"},{color:"255, 255, 255",class:"ansi-bright-white"}]],a=function(){function e(){!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e),this.fg=this.bg=this.fg_truecolor=this.bg_truecolor=null,this.bright=0}return n(e,null,[{key:"escapeForHtml",value:function(t){return(new e).escapeForHtml(t)}},{key:"linkify",value:function(t){return(new e).linkify(t)}},{key:"ansiToHtml",value:function(t,r){return(new e).ansiToHtml(t,r)}},{key:"ansiToJson",value:function(t,r){return(new e).ansiToJson(t,r)}},{key:"ansiToText",value:function(t){return(new e).ansiToText(t)}}]),n(e,[{key:"setupPalette",value:function(){this.PALETTE_COLORS=[];for(var e=0;e<2;++e)for(var t=0;t<8;++t)this.PALETTE_COLORS.push(o[e][t].color);for(var r=[0,95,135,175,215,255],n=function(e,t,n){return r[e]+", "+r[t]+", "+r[n]},a=0;a<6;++a)for(var i=0;i<6;++i)for(var l=0;l<6;++l)this.PALETTE_COLORS.push(n(a,i,l));for(var u=8,c=0;c<24;++c,u+=10)this.PALETTE_COLORS.push(n(u,u,u))}},{key:"escapeForHtml",value:function(e){return e.replace(/[&<>]/gm,(function(e){return"&"==e?"&amp;":"<"==e?"&lt;":">"==e?"&gt;":""}))}},{key:"linkify",value:function(e){return e.replace(/(https?:\\/\\/[^\\s]+)/gm,(function(e){return\'<a href="\'+e+\'">\'+e+"</a>"}))}},{key:"ansiToHtml",value:function(e,t){return this.process(e,t,!0)}},{key:"ansiToJson",value:function(e,t){return(t=t||{}).json=!0,t.clearLine=!1,this.process(e,t,!0)}},{key:"ansiToText",value:function(e){return this.process(e,{},!1)}},{key:"process",value:function(e,t,r){var n=this,o=e.split(/\\033\\[/),a=o.shift();void 0!==t&&null!==t||(t={}),t.clearLine=/\\r/.test(e);var i=o.map((function(e){return n.processChunk(e,t,r)}));if(t&&t.json){var l=this.processChunkJson("");return l.content=a,l.clearLine=t.clearLine,i.unshift(l),t.remove_empty&&(i=i.filter((function(e){return!e.isEmpty()}))),i}return i.unshift(a),i.join("")}},{key:"processChunkJson",value:function(e,t,r){var n=(t="undefined"==typeof t?{}:t).use_classes="undefined"!=typeof t.use_classes&&t.use_classes,a=t.key=n?"class":"color",i={content:e,fg:null,bg:null,fg_truecolor:null,bg_truecolor:null,clearLine:t.clearLine,decoration:null,was_processed:!1,isEmpty:function(){return!i.content}},l=e.match(/^([!\\x3c-\\x3f]*)([\\d;]*)([\\x20-\\x2c]*[\\x40-\\x7e])([\\s\\S]*)/m);if(!l)return i;i.content=l[4];var u=l[2].split(";");if(""!==l[1]||"m"!==l[3])return i;if(!r)return i;var c=this;for(c.decoration=null;u.length>0;){var s=u.shift(),f=parseInt(s);if(isNaN(f)||0===f)c.fg=c.bg=c.decoration=null;else if(1===f)c.decoration="bold";else if(2===f)c.decoration="dim";else if(3==f)c.decoration="italic";else if(4==f)c.decoration="underline";else if(5==f)c.decoration="blink";else if(7===f)c.decoration="reverse";else if(8===f)c.decoration="hidden";else if(9===f)c.decoration="strikethrough";else if(39==f)c.fg=null;else if(49==f)c.bg=null;else if(f>=30&&f<38)c.fg=o[0][f%10][a];else if(f>=90&&f<98)c.fg=o[1][f%10][a];else if(f>=40&&f<48)c.bg=o[0][f%10][a];else if(f>=100&&f<108)c.bg=o[1][f%10][a];else if(38===f||48===f){var d=38===f;if(u.length>=1){var p=u.shift();if("5"===p&&u.length>=1){var h=parseInt(u.shift());if(h>=0&&h<=255)if(n){var g=h>=16?"ansi-palette-"+h:o[h>7?1:0][h%8].class;d?c.fg=g:c.bg=g}else this.PALETTE_COLORS||c.setupPalette(),d?c.fg=this.PALETTE_COLORS[h]:c.bg=this.PALETTE_COLORS[h]}else if("2"===p&&u.length>=3){var v=parseInt(u.shift()),m=parseInt(u.shift()),y=parseInt(u.shift());if(v>=0&&v<=255&&m>=0&&m<=255&&y>=0&&y<=255){var b=v+", "+m+", "+y;n?d?(c.fg="ansi-truecolor",c.fg_truecolor=b):(c.bg="ansi-truecolor",c.bg_truecolor=b):d?c.fg=b:c.bg=b}}}}}if(null===c.fg&&null===c.bg&&null===c.decoration)return i;return i.fg=c.fg,i.bg=c.bg,i.fg_truecolor=c.fg_truecolor,i.bg_truecolor=c.bg_truecolor,i.decoration=c.decoration,i.was_processed=!0,i}},{key:"processChunk",value:function(e,t,r){var n=this;t=t||{};var o=this.processChunkJson(e,t,r);if(t.json)return o;if(o.isEmpty())return"";if(!o.was_processed)return o.content;var a=t.use_classes,i=[],l=[],u={},c=function(e){var t=[],r=void 0;for(r in e)e.hasOwnProperty(r)&&t.push("data-"+r+\'="\'+n.escapeForHtml(e[r])+\'"\');return t.length>0?" "+t.join(" "):""};return o.fg&&(a?(l.push(o.fg+"-fg"),null!==o.fg_truecolor&&(u["ansi-truecolor-fg"]=o.fg_truecolor,o.fg_truecolor=null)):i.push("color:rgb("+o.fg+")")),o.bg&&(a?(l.push(o.bg+"-bg"),null!==o.bg_truecolor&&(u["ansi-truecolor-bg"]=o.bg_truecolor,o.bg_truecolor=null)):i.push("background-color:rgb("+o.bg+")")),o.decoration&&(a?l.push("ansi-"+o.decoration):"bold"===o.decoration?i.push("font-weight:bold"):"dim"===o.decoration?i.push("opacity:0.5"):"italic"===o.decoration?i.push("font-style:italic"):"reverse"===o.decoration?i.push("filter:invert(100%)"):"hidden"===o.decoration?i.push("visibility:hidden"):"strikethrough"===o.decoration?i.push("text-decoration:line-through"):i.push("text-decoration:"+o.decoration)),a?\'<span class="\'+l.join(" ")+\'"\'+c(u)+">"+o.content+"</span>":\'<span style="\'+i.join(";")+\'"\'+c(u)+">"+o.content+"</span>"}}]),e}();e.exports=a},function(e,t){var r;r=function(){return this}();try{r=r||new Function("return this")()}catch(e){"object"===typeof window&&(r=window)}e.exports=r},function(e,t,r){var n=r(16),o=r(55),a=r(23),i=r(20),l=r(29),u=r(11),c=r(57),s=Object.getOwnPropertyDescriptor;t.f=n?s:function(e,t){if(e=i(e),t=l(t,!0),c)try{return s(e,t)}catch(e){}if(u(e,t))return a(!o.f.call(e,t),e[t])}},function(e,t){var r={}.toString;e.exports=function(e){return r.call(e).slice(8,-1)}},function(e,t){e.exports=function(e){if(void 0==e)throw TypeError("Can\'t call method on "+e);return e}},function(e,t,r){var n=r(8),o=r(18);e.exports=function(e,t){try{o(n,e,t)}catch(r){n[e]=t}return t}},function(e,t,r){var n=r(8),o=r(38),a="__core-js_shared__",i=n[a]||o(a,{});e.exports=i},function(e,t,r){var n=r(3),o=r(39);(e.exports=function(e,t){return o[e]||(o[e]=void 0!==t?t:{})})("versions",[]).push({version:"3.8.3",mode:n?"pure":"global",copyright:"\xa9 2021 Denis Pushkarev (zloirock.ru)"})},function(e,t,r){var n=r(62),o=r(43).concat("length","prototype");t.f=Object.getOwnPropertyNames||function(e){return n(e,o)}},function(e,t){var r=Math.ceil,n=Math.floor;e.exports=function(e){return isNaN(e=+e)?0:(e>0?n:r)(e)}},function(e,t){e.exports=["constructor","hasOwnProperty","isPrototypeOf","propertyIsEnumerable","toLocaleString","toString","valueOf"]},function(e,t,r){var n=r(12);e.exports=!!Object.getOwnPropertySymbols&&!n((function(){return!String(Symbol())}))},function(e,t,r){var n=r(68),o=r(27),a=r(6)("iterator");e.exports=function(e){if(void 0!=e)return e[a]||e["@@iterator"]||o[n(e)]}},function(e,t,r){var n={};n[r(6)("toStringTag")]="z",e.exports="[object z]"===String(n)},function(e,t,r){"use strict";var n=r(1),o=r(102),a=r(76),i=r(72),l=r(22),u=r(18),c=r(21),s=r(6),f=r(3),d=r(27),p=r(75),h=p.IteratorPrototype,g=p.BUGGY_SAFARI_ITERATORS,v=s("iterator"),m="keys",y="values",b="entries",w=function(){return this};e.exports=function(e,t,r,s,p,k,E){o(r,t,s);var x,S,_,T=function(e){if(e===p&&N)return N;if(!g&&e in P)return P[e];switch(e){case m:case y:case b:return function(){return new r(this,e)}}return function(){return new r(this)}},C=t+" Iterator",O=!1,P=e.prototype,R=P[v]||P["@@iterator"]||p&&P[p],N=!g&&R||T(p),L="Array"==t&&P.entries||R;if(L&&(x=a(L.call(new e)),h!==Object.prototype&&x.next&&(f||a(x)===h||(i?i(x,h):"function"!=typeof x[v]&&u(x,v,w)),l(x,C,!0,!0),f&&(d[C]=w))),p==y&&R&&R.name!==y&&(O=!0,N=function(){return R.call(this)}),f&&!E||P[v]===N||u(P,v,N),d[t]=N,p)if(S={values:T(y),keys:k?N:T(m),entries:T(b)},E)for(_ in S)(g||O||!(_ in P))&&c(P,_,S[_]);else n({target:t,proto:!0,forced:g||O},S);return S}},function(e,t,r){var n=r(2),o=r(45);e.exports=function(e){var t=o(e);if("function"!=typeof t)throw TypeError(String(e)+" is not iterable");return n(t.call(e))}},function(e,t,r){var n=r(36);e.exports=Array.isArray||function(e){return"Array"==n(e)}},function(e,t,r){"use strict";var n=Object.getOwnPropertySymbols,o=Object.prototype.hasOwnProperty,a=Object.prototype.propertyIsEnumerable;function i(e){if(null===e||void 0===e)throw new TypeError("Object.assign cannot be called with null or undefined");return Object(e)}e.exports=function(){try{if(!Object.assign)return!1;var e=new String("abc");if(e[5]="de","5"===Object.getOwnPropertyNames(e)[0])return!1;for(var t={},r=0;r<10;r++)t["_"+String.fromCharCode(r)]=r;if("0123456789"!==Object.getOwnPropertyNames(t).map((function(e){return t[e]})).join(""))return!1;var n={};return"abcdefghijklmnopqrst".split("").forEach((function(e){n[e]=e})),"abcdefghijklmnopqrst"===Object.keys(Object.assign({},n)).join("")}catch(e){return!1}}()?Object.assign:function(e,t){for(var r,l,u=i(e),c=1;c<arguments.length;c++){for(var s in r=Object(arguments[c]))o.call(r,s)&&(u[s]=r[s]);if(n){l=n(r);for(var f=0;f<l.length;f++)a.call(r,l[f])&&(u[l[f]]=r[l[f]])}}return u}},function(e,t){var r,n,o=e.exports={};function a(){throw new Error("setTimeout has not been defined")}function i(){throw new Error("clearTimeout has not been defined")}function l(e){if(r===setTimeout)return setTimeout(e,0);if((r===a||!r)&&setTimeout)return r=setTimeout,setTimeout(e,0);try{return r(e,0)}catch(t){try{return r.call(null,e,0)}catch(t){return r.call(this,e,0)}}}!function(){try{r="function"===typeof setTimeout?setTimeout:a}catch(e){r=a}try{n="function"===typeof clearTimeout?clearTimeout:i}catch(e){n=i}}();var u,c=[],s=!1,f=-1;function d(){s&&u&&(s=!1,u.length?c=u.concat(c):f=-1,c.length&&p())}function p(){if(!s){var e=l(d);s=!0;for(var t=c.length;t;){for(u=c,c=[];++f<t;)u&&u[f].run();f=-1,t=c.length}u=null,s=!1,function(e){if(n===clearTimeout)return clearTimeout(e);if((n===i||!n)&&clearTimeout)return n=clearTimeout,clearTimeout(e);try{n(e)}catch(t){try{return n.call(null,e)}catch(t){return n.call(this,e)}}}(e)}}function h(e,t){this.fun=e,this.array=t}function g(){}o.nextTick=function(e){var t=new Array(arguments.length-1);if(arguments.length>1)for(var r=1;r<arguments.length;r++)t[r-1]=arguments[r];c.push(new h(e,t)),1!==c.length||s||l(p)},h.prototype.run=function(){this.fun.apply(null,this.array)},o.title="browser",o.browser=!0,o.env={},o.argv=[],o.version="",o.versions={},o.on=g,o.addListener=g,o.once=g,o.off=g,o.removeListener=g,o.removeAllListeners=g,o.emit=g,o.prependListener=g,o.prependOnceListener=g,o.listeners=function(e){return[]},o.binding=function(e){throw new Error("process.binding is not supported")},o.cwd=function(){return"/"},o.chdir=function(e){throw new Error("process.chdir is not supported")},o.umask=function(){return 0}},function(e,t,r){var n=r(191);e.exports=function(e,t){var r;if("undefined"===typeof Symbol||null==e[Symbol.iterator]){if(Array.isArray(e)||(r=n(e))||t&&e&&"number"===typeof e.length){r&&(e=r);var o=0,a=function(){};return{s:a,n:function(){return o>=e.length?{done:!0}:{done:!1,value:e[o++]}},e:function(e){throw e},f:a}}throw new TypeError("Invalid attempt to iterate non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}var i,l=!0,u=!1;return{s:function(){r=e[Symbol.iterator]()},n:function(){var e=r.next();return l=e.done,e},e:function(e){u=!0,i=e},f:function(){try{l||null==r.return||r.return()}finally{if(u)throw i}}}}},function(e,t,r){"use strict";!function e(){if("undefined"!==typeof{}&&"function"===typeof{}.checkDCE)try{({}).checkDCE(e)}catch(e){console.error(e)}}(),e.exports=r(184)},function(e,t,r){"use strict";var n=r(1),o=r(8),a=r(64),i=r(21),l=r(65),u=r(4),c=r(70),s=r(13),f=r(12),d=r(71),p=r(22),h=r(97);e.exports=function(e,t,r){var g=-1!==e.indexOf("Map"),v=-1!==e.indexOf("Weak"),m=g?"set":"add",y=o[e],b=y&&y.prototype,w=y,k={},E=function(e){var t=b[e];i(b,e,"add"==e?function(e){return t.call(this,0===e?0:e),this}:"delete"==e?function(e){return!(v&&!s(e))&&t.call(this,0===e?0:e)}:"get"==e?function(e){return v&&!s(e)?void 0:t.call(this,0===e?0:e)}:"has"==e?function(e){return!(v&&!s(e))&&t.call(this,0===e?0:e)}:function(e,r){return t.call(this,0===e?0:e,r),this})};if(a(e,"function"!=typeof y||!(v||b.forEach&&!f((function(){(new y).entries().next()})))))w=r.getConstructor(t,e,g,m),l.REQUIRED=!0;else if(a(e,!0)){var x=new w,S=x[m](v?{}:-0,1)!=x,_=f((function(){x.has(1)})),T=d((function(e){new y(e)})),C=!v&&f((function(){for(var e=new y,t=5;t--;)e[m](t,t);return!e.has(-0)}));T||((w=t((function(t,r){c(t,w,e);var n=h(new y,t,w);return void 0!=r&&u(r,n[m],{that:n,AS_ENTRIES:g}),n}))).prototype=b,b.constructor=w),(_||C)&&(E("delete"),E("has"),g&&E("get")),(C||S)&&E(m),v&&b.clear&&delete b.clear}return k[e]=w,n({global:!0,forced:w!=y},k),p(w,e),v||r.setStrong(w,e,g),w}},function(e,t,r){"use strict";var n={}.propertyIsEnumerable,o=Object.getOwnPropertyDescriptor,a=o&&!n.call({1:2},1);t.f=a?function(e){var t=o(this,e);return!!t&&t.enumerable}:n},function(e,t,r){var n=r(12),o=r(36),a="".split;e.exports=n((function(){return!Object("z").propertyIsEnumerable(0)}))?function(e){return"String"==o(e)?a.call(e,""):Object(e)}:Object},function(e,t,r){var n=r(16),o=r(12),a=r(58);e.exports=!n&&!o((function(){return 7!=Object.defineProperty(a("div"),"a",{get:function(){return 7}}).a}))},function(e,t,r){var n=r(8),o=r(13),a=n.document,i=o(a)&&o(a.createElement);e.exports=function(e){return i?a.createElement(e):{}}},function(e,t,r){var n=r(39),o=Function.toString;"function"!=typeof n.inspectSource&&(n.inspectSource=function(e){return o.call(e)}),e.exports=n.inspectSource},function(e,t,r){var n=r(11),o=r(93),a=r(35),i=r(14);e.exports=function(e,t){for(var r=o(t),l=i.f,u=a.f,c=0;c<r.length;c++){var s=r[c];n(e,s)||l(e,s,u(t,s))}}},function(e,t,r){var n=r(8);e.exports=n},function(e,t,r){var n=r(11),o=r(20),a=r(94).indexOf,i=r(25);e.exports=function(e,t){var r,l=o(e),u=0,c=[];for(r in l)!n(i,r)&&n(l,r)&&c.push(r);for(;t.length>u;)n(l,r=t[u++])&&(~a(c,r)||c.push(r));return c}},function(e,t){t.f=Object.getOwnPropertySymbols},function(e,t,r){var n=r(12),o=/#|\\.prototype\\./,a=function(e,t){var r=l[i(e)];return r==c||r!=u&&("function"==typeof t?n(t):!!t)},i=a.normalize=function(e){return String(e).replace(o,".").toLowerCase()},l=a.data={},u=a.NATIVE="N",c=a.POLYFILL="P";e.exports=a},function(e,t,r){var n=r(25),o=r(13),a=r(11),i=r(14).f,l=r(31),u=r(96),c=l("meta"),s=0,f=Object.isExtensible||function(){return!0},d=function(e){i(e,c,{value:{objectID:"O"+ ++s,weakData:{}}})},p=e.exports={REQUIRED:!1,fastKey:function(e,t){if(!o(e))return"symbol"==typeof e?e:("string"==typeof e?"S":"P")+e;if(!a(e,c)){if(!f(e))return"F";if(!t)return"E";d(e)}return e[c].objectID},getWeakData:function(e,t){if(!a(e,c)){if(!f(e))return!0;if(!t)return!1;d(e)}return e[c].weakData},onFreeze:function(e){return u&&p.REQUIRED&&f(e)&&!a(e,c)&&d(e),e}};n[c]=!0},function(e,t,r){var n=r(6),o=r(27),a=n("iterator"),i=Array.prototype;e.exports=function(e){return void 0!==e&&(o.Array===e||i[a]===e)}},function(e,t,r){var n=r(44);e.exports=n&&!Symbol.sham&&"symbol"==typeof Symbol.iterator},function(e,t,r){var n=r(46),o=r(36),a=r(6)("toStringTag"),i="Arguments"==o(function(){return arguments}());e.exports=n?o:function(e){var t,r,n;return void 0===e?"Undefined":null===e?"Null":"string"==typeof(r=function(e,t){try{return e[t]}catch(e){}}(t=Object(e),a))?r:i?o(t):"Object"==(n=o(t))&&"function"==typeof t.callee?"Arguments":n}},function(e,t,r){var n=r(2);e.exports=function(e){var t=e.return;if(void 0!==t)return n(t.call(e)).value}},function(e,t){e.exports=function(e,t,r){if(!(e instanceof t))throw TypeError("Incorrect "+(r?r+" ":"")+"invocation");return e}},function(e,t,r){var n=r(6)("iterator"),o=!1;try{var a=0,i={next:function(){return{done:!!a++}},return:function(){o=!0}};i[n]=function(){return this},Array.from(i,(function(){throw 2}))}catch(e){}e.exports=function(e,t){if(!t&&!o)return!1;var r=!1;try{var a={};a[n]=function(){return{next:function(){return{done:r=!0}}}},e(a)}catch(e){}return r}},function(e,t,r){var n=r(2),o=r(98);e.exports=Object.setPrototypeOf||("__proto__"in{}?function(){var e,t=!1,r={};try{(e=Object.getOwnPropertyDescriptor(Object.prototype,"__proto__").set).call(r,[]),t=r instanceof Array}catch(e){}return function(r,a){return n(r),o(a),t?e.call(r,a):r.__proto__=a,r}}():void 0)},function(e,t,r){"use strict";var n=r(14).f,o=r(32),a=r(101),i=r(7),l=r(70),u=r(4),c=r(47),s=r(104),f=r(16),d=r(65).fastKey,p=r(24),h=p.set,g=p.getterFor;e.exports={getConstructor:function(e,t,r,c){var s=e((function(e,n){l(e,s,t),h(e,{type:t,index:o(null),first:void 0,last:void 0,size:0}),f||(e.size=0),void 0!=n&&u(n,e[c],{that:e,AS_ENTRIES:r})})),p=g(t),v=function(e,t,r){var n,o,a=p(e),i=m(e,t);return i?i.value=r:(a.last=i={index:o=d(t,!0),key:t,value:r,previous:n=a.last,next:void 0,removed:!1},a.first||(a.first=i),n&&(n.next=i),f?a.size++:e.size++,"F"!==o&&(a.index[o]=i)),e},m=function(e,t){var r,n=p(e),o=d(t);if("F"!==o)return n.index[o];for(r=n.first;r;r=r.next)if(r.key==t)return r};return a(s.prototype,{clear:function(){for(var e=p(this),t=e.index,r=e.first;r;)r.removed=!0,r.previous&&(r.previous=r.previous.next=void 0),delete t[r.index],r=r.next;e.first=e.last=void 0,f?e.size=0:this.size=0},delete:function(e){var t=this,r=p(t),n=m(t,e);if(n){var o=n.next,a=n.previous;delete r.index[n.index],n.removed=!0,a&&(a.next=o),o&&(o.previous=a),r.first==n&&(r.first=o),r.last==n&&(r.last=a),f?r.size--:t.size--}return!!n},forEach:function(e){for(var t,r=p(this),n=i(e,arguments.length>1?arguments[1]:void 0,3);t=t?t.next:r.first;)for(n(t.value,t.key,this);t&&t.removed;)t=t.previous},has:function(e){return!!m(this,e)}}),a(s.prototype,r?{get:function(e){var t=m(this,e);return t&&t.value},set:function(e,t){return v(this,0===e?0:e,t)}}:{add:function(e){return v(this,e=0===e?0:e,e)}}),f&&n(s.prototype,"size",{get:function(){return p(this).size}}),s},setStrong:function(e,t,r){var n=t+" Iterator",o=g(t),a=g(n);c(e,t,(function(e,t){h(this,{type:n,target:e,state:o(e),kind:t,last:void 0})}),(function(){for(var e=a(this),t=e.kind,r=e.last;r&&r.removed;)r=r.previous;return e.target&&(e.last=r=r?r.next:e.state.first)?"keys"==t?{value:r.key,done:!1}:"values"==t?{value:r.value,done:!1}:{value:[r.key,r.value],done:!1}:(e.target=void 0,{value:void 0,done:!0})}),r?"entries":"values",!r,!0),s(t)}}},function(e,t,r){var n=r(62),o=r(43);e.exports=Object.keys||function(e){return n(e,o)}},function(e,t,r){"use strict";var n,o,a,i=r(12),l=r(76),u=r(18),c=r(11),s=r(6),f=r(3),d=s("iterator"),p=!1;[].keys&&("next"in(a=[].keys())?(o=l(l(a)))!==Object.prototype&&(n=o):p=!0);var h=void 0==n||i((function(){var e={};return n[d].call(e)!==e}));h&&(n={}),f&&!h||c(n,d)||u(n,d,(function(){return this})),e.exports={IteratorPrototype:n,BUGGY_SAFARI_ITERATORS:p}},function(e,t,r){var n=r(11),o=r(28),a=r(30),i=r(103),l=a("IE_PROTO"),u=Object.prototype;e.exports=i?Object.getPrototypeOf:function(e){return e=o(e),n(e,l)?e[l]:"function"==typeof e.constructor&&e instanceof e.constructor?e.constructor.prototype:e instanceof Object?u:null}},function(e,t,r){var n=r(46),o=r(21),a=r(105);n||o(Object.prototype,"toString",a,{unsafe:!0})},function(e,t,r){"use strict";var n=r(107).charAt,o=r(24),a=r(47),i="String Iterator",l=o.set,u=o.getterFor(i);a(String,"String",(function(e){l(this,{type:i,string:String(e),index:0})}),(function(){var e,t=u(this),r=t.string,o=t.index;return o>=r.length?{value:void 0,done:!0}:(e=n(r,o),t.index+=e.length,{value:e,done:!1})}))},function(e,t,r){"use strict";var n=r(2),o=r(5);e.exports=function(){for(var e,t=n(this),r=o(t.delete),a=!0,i=0,l=arguments.length;i<l;i++)e=r.call(t,arguments[i]),a=a&&e;return!!a}},function(e,t,r){"use strict";var n=r(5),o=r(7),a=r(4);e.exports=function(e){var t,r,i,l,u=arguments.length,c=u>1?arguments[1]:void 0;return n(this),(t=void 0!==c)&&n(c),void 0==e?new this:(r=[],t?(i=0,l=o(c,u>2?arguments[2]:void 0,2),a(e,(function(e){r.push(l(e,i++))}))):a(e,r.push,{that:r}),new this(r))}},function(e,t,r){"use strict";e.exports=function(){for(var e=arguments.length,t=new Array(e);e--;)t[e]=arguments[e];return new this(t)}},function(e,t,r){var n=r(6);t.f=n},function(e,t,r){var n=r(13),o=r(49),a=r(6)("species");e.exports=function(e,t){var r;return o(e)&&("function"!=typeof(r=e.constructor)||r!==Array&&!o(r.prototype)?n(r)&&null===(r=r[a])&&(r=void 0):r=void 0),new(void 0===r?Array:r)(0===t?0:t)}},function(e,t,r){"use strict";var n=r(29),o=r(14),a=r(23);e.exports=function(e,t,r){var i=n(t);i in e?o.f(e,i,a(0,r)):e[i]=r}},function(e,t,r){var n,o,a=r(8),i=r(168),l=a.process,u=l&&l.versions,c=u&&u.v8;c?o=(n=c.split("."))[0]+n[1]:i&&(!(n=i.match(/Edge\\/(\\d+)/))||n[1]>=74)&&(n=i.match(/Chrome\\/(\\d+)/))&&(o=n[1]),e.exports=o&&+o},function(e,t,r){"use strict";var n=r(178);function o(){}var a=null,i={};function l(e){if("object"!==typeof this)throw new TypeError("Promises must be constructed via new");if("function"!==typeof e)throw new TypeError("Promise constructor\'s argument is not a function");this._U=0,this._V=0,this._W=null,this._X=null,e!==o&&p(e,this)}function u(e,t){for(;3===e._V;)e=e._W;if(l._Y&&l._Y(e),0===e._V)return 0===e._U?(e._U=1,void(e._X=t)):1===e._U?(e._U=2,void(e._X=[e._X,t])):void e._X.push(t);!function(e,t){n((function(){var r=1===e._V?t.onFulfilled:t.onRejected;if(null!==r){var n=function(e,t){try{return e(t)}catch(e){return a=e,i}}(r,e._W);n===i?s(t.promise,a):c(t.promise,n)}else 1===e._V?c(t.promise,e._W):s(t.promise,e._W)}))}(e,t)}function c(e,t){if(t===e)return s(e,new TypeError("A promise cannot be resolved with itself."));if(t&&("object"===typeof t||"function"===typeof t)){var r=function(e){try{return e.then}catch(e){return a=e,i}}(t);if(r===i)return s(e,a);if(r===e.then&&t instanceof l)return e._V=3,e._W=t,void f(e);if("function"===typeof r)return void p(r.bind(t),e)}e._V=1,e._W=t,f(e)}function s(e,t){e._V=2,e._W=t,l._Z&&l._Z(e,t),f(e)}function f(e){if(1===e._U&&(u(e,e._X),e._X=null),2===e._U){for(var t=0;t<e._X.length;t++)u(e,e._X[t]);e._X=null}}function d(e,t,r){this.onFulfilled="function"===typeof e?e:null,this.onRejected="function"===typeof t?t:null,this.promise=r}function p(e,t){var r=!1,n=function(e,t,r){try{e(t,r)}catch(e){return a=e,i}}(e,(function(e){r||(r=!0,c(t,e))}),(function(e){r||(r=!0,s(t,e))}));r||n!==i||(r=!0,s(t,a))}e.exports=l,l._Y=null,l._Z=null,l._0=o,l.prototype.then=function(e,t){if(this.constructor!==l)return function(e,t,r){return new e.constructor((function(n,a){var i=new l(o);i.then(n,a),u(e,new d(t,r,i))}))}(this,e,t);var r=new l(o);return u(this,new d(e,t,r)),r}},function(e,t,r){var n=r(204),o={};for(var a in n)n.hasOwnProperty(a)&&(o[n[a]]=a);var i=e.exports={rgb:{channels:3,labels:"rgb"},hsl:{channels:3,labels:"hsl"},hsv:{channels:3,labels:"hsv"},hwb:{channels:3,labels:"hwb"},cmyk:{channels:4,labels:"cmyk"},xyz:{channels:3,labels:"xyz"},lab:{channels:3,labels:"lab"},lch:{channels:3,labels:"lch"},hex:{channels:1,labels:["hex"]},keyword:{channels:1,labels:["keyword"]},ansi16:{channels:1,labels:["ansi16"]},ansi256:{channels:1,labels:["ansi256"]},hcg:{channels:3,labels:["h","c","g"]},apple:{channels:3,labels:["r16","g16","b16"]},gray:{channels:1,labels:["gray"]}};for(var l in i)if(i.hasOwnProperty(l)){if(!("channels"in i[l]))throw new Error("missing channels property: "+l);if(!("labels"in i[l]))throw new Error("missing channel labels property: "+l);if(i[l].labels.length!==i[l].channels)throw new Error("channel and label counts mismatch: "+l);var u=i[l].channels,c=i[l].labels;delete i[l].channels,delete i[l].labels,Object.defineProperty(i[l],"channels",{value:u}),Object.defineProperty(i[l],"labels",{value:c})}i.rgb.hsl=function(e){var t,r,n=e[0]/255,o=e[1]/255,a=e[2]/255,i=Math.min(n,o,a),l=Math.max(n,o,a),u=l-i;return l===i?t=0:n===l?t=(o-a)/u:o===l?t=2+(a-n)/u:a===l&&(t=4+(n-o)/u),(t=Math.min(60*t,360))<0&&(t+=360),r=(i+l)/2,[t,100*(l===i?0:r<=.5?u/(l+i):u/(2-l-i)),100*r]},i.rgb.hsv=function(e){var t,r,n,o,a,i=e[0]/255,l=e[1]/255,u=e[2]/255,c=Math.max(i,l,u),s=c-Math.min(i,l,u),f=function(e){return(c-e)/6/s+.5};return 0===s?o=a=0:(a=s/c,t=f(i),r=f(l),n=f(u),i===c?o=n-r:l===c?o=1/3+t-n:u===c&&(o=2/3+r-t),o<0?o+=1:o>1&&(o-=1)),[360*o,100*a,100*c]},i.rgb.hwb=function(e){var t=e[0],r=e[1],n=e[2];return[i.rgb.hsl(e)[0],100*(1/255*Math.min(t,Math.min(r,n))),100*(n=1-1/255*Math.max(t,Math.max(r,n)))]},i.rgb.cmyk=function(e){var t,r=e[0]/255,n=e[1]/255,o=e[2]/255;return[100*((1-r-(t=Math.min(1-r,1-n,1-o)))/(1-t)||0),100*((1-n-t)/(1-t)||0),100*((1-o-t)/(1-t)||0),100*t]},i.rgb.keyword=function(e){var t=o[e];if(t)return t;var r,a,i,l=1/0;for(var u in n)if(n.hasOwnProperty(u)){var c=n[u],s=(a=e,i=c,Math.pow(a[0]-i[0],2)+Math.pow(a[1]-i[1],2)+Math.pow(a[2]-i[2],2));s<l&&(l=s,r=u)}return r},i.keyword.rgb=function(e){return n[e]},i.rgb.xyz=function(e){var t=e[0]/255,r=e[1]/255,n=e[2]/255;return[100*(.4124*(t=t>.04045?Math.pow((t+.055)/1.055,2.4):t/12.92)+.3576*(r=r>.04045?Math.pow((r+.055)/1.055,2.4):r/12.92)+.1805*(n=n>.04045?Math.pow((n+.055)/1.055,2.4):n/12.92)),100*(.2126*t+.7152*r+.0722*n),100*(.0193*t+.1192*r+.9505*n)]},i.rgb.lab=function(e){var t=i.rgb.xyz(e),r=t[0],n=t[1],o=t[2];return n/=100,o/=108.883,r=(r/=95.047)>.008856?Math.pow(r,1/3):7.787*r+16/116,[116*(n=n>.008856?Math.pow(n,1/3):7.787*n+16/116)-16,500*(r-n),200*(n-(o=o>.008856?Math.pow(o,1/3):7.787*o+16/116))]},i.hsl.rgb=function(e){var t,r,n,o,a,i=e[0]/360,l=e[1]/100,u=e[2]/100;if(0===l)return[a=255*u,a,a];t=2*u-(r=u<.5?u*(1+l):u+l-u*l),o=[0,0,0];for(var c=0;c<3;c++)(n=i+1/3*-(c-1))<0&&n++,n>1&&n--,a=6*n<1?t+6*(r-t)*n:2*n<1?r:3*n<2?t+(r-t)*(2/3-n)*6:t,o[c]=255*a;return o},i.hsl.hsv=function(e){var t=e[0],r=e[1]/100,n=e[2]/100,o=r,a=Math.max(n,.01);return r*=(n*=2)<=1?n:2-n,o*=a<=1?a:2-a,[t,100*(0===n?2*o/(a+o):2*r/(n+r)),100*((n+r)/2)]},i.hsv.rgb=function(e){var t=e[0]/60,r=e[1]/100,n=e[2]/100,o=Math.floor(t)%6,a=t-Math.floor(t),i=255*n*(1-r),l=255*n*(1-r*a),u=255*n*(1-r*(1-a));switch(n*=255,o){case 0:return[n,u,i];case 1:return[l,n,i];case 2:return[i,n,u];case 3:return[i,l,n];case 4:return[u,i,n];case 5:return[n,i,l]}},i.hsv.hsl=function(e){var t,r,n,o=e[0],a=e[1]/100,i=e[2]/100,l=Math.max(i,.01);return n=(2-a)*i,r=a*l,[o,100*(r=(r/=(t=(2-a)*l)<=1?t:2-t)||0),100*(n/=2)]},i.hwb.rgb=function(e){var t,r,n,o,a,i,l,u=e[0]/360,c=e[1]/100,s=e[2]/100,f=c+s;switch(f>1&&(c/=f,s/=f),n=6*u-(t=Math.floor(6*u)),0!==(1&t)&&(n=1-n),o=c+n*((r=1-s)-c),t){default:case 6:case 0:a=r,i=o,l=c;break;case 1:a=o,i=r,l=c;break;case 2:a=c,i=r,l=o;break;case 3:a=c,i=o,l=r;break;case 4:a=o,i=c,l=r;break;case 5:a=r,i=c,l=o}return[255*a,255*i,255*l]},i.cmyk.rgb=function(e){var t=e[0]/100,r=e[1]/100,n=e[2]/100,o=e[3]/100;return[255*(1-Math.min(1,t*(1-o)+o)),255*(1-Math.min(1,r*(1-o)+o)),255*(1-Math.min(1,n*(1-o)+o))]},i.xyz.rgb=function(e){var t,r,n,o=e[0]/100,a=e[1]/100,i=e[2]/100;return r=-.9689*o+1.8758*a+.0415*i,n=.0557*o+-.204*a+1.057*i,t=(t=3.2406*o+-1.5372*a+-.4986*i)>.0031308?1.055*Math.pow(t,1/2.4)-.055:12.92*t,r=r>.0031308?1.055*Math.pow(r,1/2.4)-.055:12.92*r,n=n>.0031308?1.055*Math.pow(n,1/2.4)-.055:12.92*n,[255*(t=Math.min(Math.max(0,t),1)),255*(r=Math.min(Math.max(0,r),1)),255*(n=Math.min(Math.max(0,n),1))]},i.xyz.lab=function(e){var t=e[0],r=e[1],n=e[2];return r/=100,n/=108.883,t=(t/=95.047)>.008856?Math.pow(t,1/3):7.787*t+16/116,[116*(r=r>.008856?Math.pow(r,1/3):7.787*r+16/116)-16,500*(t-r),200*(r-(n=n>.008856?Math.pow(n,1/3):7.787*n+16/116))]},i.lab.xyz=function(e){var t,r,n,o=e[0];t=e[1]/500+(r=(o+16)/116),n=r-e[2]/200;var a=Math.pow(r,3),i=Math.pow(t,3),l=Math.pow(n,3);return r=a>.008856?a:(r-16/116)/7.787,t=i>.008856?i:(t-16/116)/7.787,n=l>.008856?l:(n-16/116)/7.787,[t*=95.047,r*=100,n*=108.883]},i.lab.lch=function(e){var t,r=e[0],n=e[1],o=e[2];return(t=360*Math.atan2(o,n)/2/Math.PI)<0&&(t+=360),[r,Math.sqrt(n*n+o*o),t]},i.lch.lab=function(e){var t,r=e[0],n=e[1];return t=e[2]/360*2*Math.PI,[r,n*Math.cos(t),n*Math.sin(t)]},i.rgb.ansi16=function(e){var t=e[0],r=e[1],n=e[2],o=1 in arguments?arguments[1]:i.rgb.hsv(e)[2];if(0===(o=Math.round(o/50)))return 30;var a=30+(Math.round(n/255)<<2|Math.round(r/255)<<1|Math.round(t/255));return 2===o&&(a+=60),a},i.hsv.ansi16=function(e){return i.rgb.ansi16(i.hsv.rgb(e),e[2])},i.rgb.ansi256=function(e){var t=e[0],r=e[1],n=e[2];return t===r&&r===n?t<8?16:t>248?231:Math.round((t-8)/247*24)+232:16+36*Math.round(t/255*5)+6*Math.round(r/255*5)+Math.round(n/255*5)},i.ansi16.rgb=function(e){var t=e%10;if(0===t||7===t)return e>50&&(t+=3.5),[t=t/10.5*255,t,t];var r=.5*(1+~~(e>50));return[(1&t)*r*255,(t>>1&1)*r*255,(t>>2&1)*r*255]},i.ansi256.rgb=function(e){if(e>=232){var t=10*(e-232)+8;return[t,t,t]}var r;return e-=16,[Math.floor(e/36)/5*255,Math.floor((r=e%36)/6)/5*255,r%6/5*255]},i.rgb.hex=function(e){var t=(((255&Math.round(e[0]))<<16)+((255&Math.round(e[1]))<<8)+(255&Math.round(e[2]))).toString(16).toUpperCase();return"000000".substring(t.length)+t},i.hex.rgb=function(e){var t=e.toString(16).match(/[a-f0-9]{6}|[a-f0-9]{3}/i);if(!t)return[0,0,0];var r=t[0];3===t[0].length&&(r=r.split("").map((function(e){return e+e})).join(""));var n=parseInt(r,16);return[n>>16&255,n>>8&255,255&n]},i.rgb.hcg=function(e){var t,r=e[0]/255,n=e[1]/255,o=e[2]/255,a=Math.max(Math.max(r,n),o),i=Math.min(Math.min(r,n),o),l=a-i;return t=l<=0?0:a===r?(n-o)/l%6:a===n?2+(o-r)/l:4+(r-n)/l+4,t/=6,[360*(t%=1),100*l,100*(l<1?i/(1-l):0)]},i.hsl.hcg=function(e){var t=e[1]/100,r=e[2]/100,n=1,o=0;return(n=r<.5?2*t*r:2*t*(1-r))<1&&(o=(r-.5*n)/(1-n)),[e[0],100*n,100*o]},i.hsv.hcg=function(e){var t=e[1]/100,r=e[2]/100,n=t*r,o=0;return n<1&&(o=(r-n)/(1-n)),[e[0],100*n,100*o]},i.hcg.rgb=function(e){var t=e[0]/360,r=e[1]/100,n=e[2]/100;if(0===r)return[255*n,255*n,255*n];var o,a=[0,0,0],i=t%1*6,l=i%1,u=1-l;switch(Math.floor(i)){case 0:a[0]=1,a[1]=l,a[2]=0;break;case 1:a[0]=u,a[1]=1,a[2]=0;break;case 2:a[0]=0,a[1]=1,a[2]=l;break;case 3:a[0]=0,a[1]=u,a[2]=1;break;case 4:a[0]=l,a[1]=0,a[2]=1;break;default:a[0]=1,a[1]=0,a[2]=u}return o=(1-r)*n,[255*(r*a[0]+o),255*(r*a[1]+o),255*(r*a[2]+o)]},i.hcg.hsv=function(e){var t=e[1]/100,r=t+e[2]/100*(1-t),n=0;return r>0&&(n=t/r),[e[0],100*n,100*r]},i.hcg.hsl=function(e){var t=e[1]/100,r=e[2]/100*(1-t)+.5*t,n=0;return r>0&&r<.5?n=t/(2*r):r>=.5&&r<1&&(n=t/(2*(1-r))),[e[0],100*n,100*r]},i.hcg.hwb=function(e){var t=e[1]/100,r=t+e[2]/100*(1-t);return[e[0],100*(r-t),100*(1-r)]},i.hwb.hcg=function(e){var t=e[1]/100,r=1-e[2]/100,n=r-t,o=0;return n<1&&(o=(r-n)/(1-n)),[e[0],100*n,100*o]},i.apple.rgb=function(e){return[e[0]/65535*255,e[1]/65535*255,e[2]/65535*255]},i.rgb.apple=function(e){return[e[0]/255*65535,e[1]/255*65535,e[2]/255*65535]},i.gray.rgb=function(e){return[e[0]/100*255,e[0]/100*255,e[0]/100*255]},i.gray.hsl=i.gray.hsv=function(e){return[0,0,e[0]]},i.gray.hwb=function(e){return[0,100,e[0]]},i.gray.cmyk=function(e){return[0,0,0,e[0]]},i.gray.lab=function(e){return[e[0],0,0]},i.gray.hex=function(e){var t=255&Math.round(e[0]/100*255),r=((t<<16)+(t<<8)+t).toString(16).toUpperCase();return"000000".substring(r.length)+r},i.rgb.gray=function(e){return[(e[0]+e[1]+e[2])/3/255*100]}},function(e,t,r){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var n=r(187);t.XmlEntities=n.XmlEntities;var o=r(188);t.Html4Entities=o.Html4Entities;var a=r(189);t.Html5Entities=a.Html5Entities,t.AllHtmlEntities=a.Html5Entities},function(e,t,r){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.codeFrameColumns=c,t.default=function(t,r,n){var o=arguments.length>3&&void 0!==arguments[3]?arguments[3]:{};if(!a){a=!0;var i="Passing lineNumber and colNumber is deprecated to @babel/code-frame. Please use `codeFrameColumns`.";if(e.emitWarning)e.emitWarning(i,"DeprecationWarning");else{var l=new Error(i);l.name="DeprecationWarning",console.warn(new Error(i))}}var u={start:{column:n=Math.max(n,0),line:r}};return c(t,u,o)};var n=function(e){if(e&&e.__esModule)return e;if(null===e||"object"!==typeof e&&"function"!==typeof e)return{default:e};var t=o();if(t&&t.has(e))return t.get(e);var r={},n=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var a in e)if(Object.prototype.hasOwnProperty.call(e,a)){var i=n?Object.getOwnPropertyDescriptor(e,a):null;i&&(i.get||i.set)?Object.defineProperty(r,a,i):r[a]=e[a]}r.default=e,t&&t.set(e,r);return r}(r(190));function o(){if("function"!==typeof WeakMap)return null;var e=new WeakMap;return o=function(){return e},e}var a=!1;function i(e){return{gutter:e.grey,marker:e.red.bold,message:e.red.bold}}var l=/\\r\\n|[\\n\\r\\u2028\\u2029]/;function u(e,t,r){var n=Object.assign({column:0,line:-1},e.start),o=Object.assign({},n,e.end),a=r||{},i=a.linesAbove,l=void 0===i?2:i,u=a.linesBelow,c=void 0===u?3:u,s=n.line,f=n.column,d=o.line,p=o.column,h=Math.max(s-(l+1),0),g=Math.min(t.length,d+c);-1===s&&(h=0),-1===d&&(g=t.length);var v=d-s,m={};if(v)for(var y=0;y<=v;y++){var b=y+s;if(f)if(0===y){var w=t[b-1].length;m[b]=[f,w-f+1]}else if(y===v)m[b]=[0,p];else{var k=t[b-y].length;m[b]=[0,k]}else m[b]=!0}else m[s]=f===p?!f||[f,0]:[f,p-f];return{start:h,end:g,markerLines:m}}function c(e,t){var r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},o=(r.highlightCode||r.forceColor)&&(0,n.shouldHighlight)(r),a=(0,n.getChalk)(r),c=i(a),s=function(e,t){return o?e(t):t},f=e.split(l),d=u(t,f,r),p=d.start,h=d.end,g=d.markerLines,v=t.start&&"number"===typeof t.start.column,m=String(h).length,y=o?(0,n.default)(e,r):e,b=y.split(l).slice(p,h).map((function(e,t){var n=p+1+t,o=" ".concat(n).slice(-m),a=" ".concat(o," | "),i=g[n],l=!g[n+1];if(i){var u="";if(Array.isArray(i)){var f=e.slice(0,Math.max(i[0]-1,0)).replace(/[^\\t]/g," "),d=i[1]||1;u=["\\n ",s(c.gutter,a.replace(/\\d/g," ")),f,s(c.marker,"^").repeat(d)].join(""),l&&r.message&&(u+=" "+s(c.message,r.message))}return[s(c.marker,">"),s(c.gutter,a),e,u].join("")}return" ".concat(s(c.gutter,a)).concat(e)})).join("\\n");return r.message&&!v&&(b="".concat(" ".repeat(m+1)).concat(r.message,"\\n").concat(b)),o?a.reset(b):b}}).call(this,r(51))},function(e,t,r){"use strict";r(91),r(77),r(106),r(78),r(108),r(109),r(110),r(111),r(112),r(113),r(114),r(115),r(117),r(118),r(119),r(120),r(121),r(122),r(123),r(124),r(125),r(126),r(128),r(129),r(130),r(131),r(132),r(133),r(134),r(135),r(136),r(137),r(138),r(139),r(140),r(141),r(142),r(143),r(144),r(145),r(149),r(181).polyfill()},function(e,t,r){"use strict";var n=r(54),o=r(73);e.exports=n("Map",(function(e){return function(){return e(this,arguments.length?arguments[0]:void 0)}}),o)},function(e,t,r){var n=r(8),o=r(59),a=n.WeakMap;e.exports="function"===typeof a&&/native code/.test(o(a))},function(e,t,r){var n=r(10),o=r(41),a=r(63),i=r(2);e.exports=n("Reflect","ownKeys")||function(e){var t=o.f(i(e)),r=a.f;return r?t.concat(r(e)):t}},function(e,t,r){var n=r(20),o=r(26),a=r(95),i=function(e){return function(t,r,i){var l,u=n(t),c=o(u.length),s=a(i,c);if(e&&r!=r){for(;c>s;)if((l=u[s++])!=l)return!0}else for(;c>s;s++)if((e||s in u)&&u[s]===r)return e||s||0;return!e&&-1}};e.exports={includes:i(!0),indexOf:i(!1)}},function(e,t,r){var n=r(42),o=Math.max,a=Math.min;e.exports=function(e,t){var r=n(e);return r<0?o(r+t,0):a(r,t)}},function(e,t,r){var n=r(12);e.exports=!n((function(){return Object.isExtensible(Object.preventExtensions({}))}))},function(e,t,r){var n=r(13),o=r(72);e.exports=function(e,t,r){var a,i;return o&&"function"==typeof(a=t.constructor)&&a!==r&&n(i=a.prototype)&&i!==r.prototype&&o(e,i),e}},function(e,t,r){var n=r(13);e.exports=function(e){if(!n(e)&&null!==e)throw TypeError("Can\'t set "+String(e)+" as a prototype");return e}},function(e,t,r){var n=r(16),o=r(14),a=r(2),i=r(74);e.exports=n?Object.defineProperties:function(e,t){a(e);for(var r,n=i(t),l=n.length,u=0;l>u;)o.f(e,r=n[u++],t[r]);return e}},function(e,t,r){var n=r(10);e.exports=n("document","documentElement")},function(e,t,r){var n=r(21);e.exports=function(e,t,r){for(var o in t)n(e,o,t[o],r);return e}},function(e,t,r){"use strict";var n=r(75).IteratorPrototype,o=r(32),a=r(23),i=r(22),l=r(27),u=function(){return this};e.exports=function(e,t,r){var c=t+" Iterator";return e.prototype=o(n,{next:a(1,r)}),i(e,c,!1,!0),l[c]=u,e}},function(e,t,r){var n=r(12);e.exports=!n((function(){function e(){}return e.prototype.constructor=null,Object.getPrototypeOf(new e)!==e.prototype}))},function(e,t,r){"use strict";var n=r(10),o=r(14),a=r(6),i=r(16),l=a("species");e.exports=function(e){var t=n(e),r=o.f;i&&t&&!t[l]&&r(t,l,{configurable:!0,get:function(){return this}})}},function(e,t,r){"use strict";var n=r(46),o=r(68);e.exports=n?{}.toString:function(){return"[object "+o(this)+"]"}},function(e,t,r){"use strict";var n=r(54),o=r(73);e.exports=n("Set",(function(e){return function(){return e(this,arguments.length?arguments[0]:void 0)}}),o)},function(e,t,r){var n=r(42),o=r(37),a=function(e){return function(t,r){var a,i,l=String(o(t)),u=n(r),c=l.length;return u<0||u>=c?e?"":void 0:(a=l.charCodeAt(u))<55296||a>56319||u+1===c||(i=l.charCodeAt(u+1))<56320||i>57343?e?l.charAt(u):a:e?l.slice(u,u+2):i-56320+(a-55296<<10)+65536}};e.exports={codeAt:a(!1),charAt:a(!0)}},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(79);n({target:"Map",proto:!0,real:!0,forced:o},{deleteAll:function(){return a.apply(this,arguments)}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(7),l=r(15),u=r(4);n({target:"Map",proto:!0,real:!0,forced:o},{every:function(e){var t=a(this),r=l(t),n=i(e,arguments.length>1?arguments[1]:void 0,3);return!u(r,(function(e,r,o){if(!n(r,e,t))return o()}),{AS_ENTRIES:!0,IS_ITERATOR:!0,INTERRUPTED:!0}).stopped}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(10),i=r(2),l=r(5),u=r(7),c=r(17),s=r(15),f=r(4);n({target:"Map",proto:!0,real:!0,forced:o},{filter:function(e){var t=i(this),r=s(t),n=u(e,arguments.length>1?arguments[1]:void 0,3),o=new(c(t,a("Map"))),d=l(o.set);return f(r,(function(e,r){n(r,e,t)&&d.call(o,e,r)}),{AS_ENTRIES:!0,IS_ITERATOR:!0}),o}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(7),l=r(15),u=r(4);n({target:"Map",proto:!0,real:!0,forced:o},{find:function(e){var t=a(this),r=l(t),n=i(e,arguments.length>1?arguments[1]:void 0,3);return u(r,(function(e,r,o){if(n(r,e,t))return o(r)}),{AS_ENTRIES:!0,IS_ITERATOR:!0,INTERRUPTED:!0}).result}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(7),l=r(15),u=r(4);n({target:"Map",proto:!0,real:!0,forced:o},{findKey:function(e){var t=a(this),r=l(t),n=i(e,arguments.length>1?arguments[1]:void 0,3);return u(r,(function(e,r,o){if(n(r,e,t))return o(e)}),{AS_ENTRIES:!0,IS_ITERATOR:!0,INTERRUPTED:!0}).result}})},function(e,t,r){r(1)({target:"Map",stat:!0},{from:r(80)})},function(e,t,r){"use strict";var n=r(1),o=r(4),a=r(5);n({target:"Map",stat:!0},{groupBy:function(e,t){var r=new this;a(t);var n=a(r.has),i=a(r.get),l=a(r.set);return o(e,(function(e){var o=t(e);n.call(r,o)?i.call(r,o).push(e):l.call(r,o,[e])})),r}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(15),l=r(116),u=r(4);n({target:"Map",proto:!0,real:!0,forced:o},{includes:function(e){return u(i(a(this)),(function(t,r,n){if(l(r,e))return n()}),{AS_ENTRIES:!0,IS_ITERATOR:!0,INTERRUPTED:!0}).stopped}})},function(e,t){e.exports=function(e,t){return e===t||e!=e&&t!=t}},function(e,t,r){"use strict";var n=r(1),o=r(4),a=r(5);n({target:"Map",stat:!0},{keyBy:function(e,t){var r=new this;a(t);var n=a(r.set);return o(e,(function(e){n.call(r,t(e),e)})),r}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(15),l=r(4);n({target:"Map",proto:!0,real:!0,forced:o},{keyOf:function(e){return l(i(a(this)),(function(t,r,n){if(r===e)return n(t)}),{AS_ENTRIES:!0,IS_ITERATOR:!0,INTERRUPTED:!0}).result}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(10),i=r(2),l=r(5),u=r(7),c=r(17),s=r(15),f=r(4);n({target:"Map",proto:!0,real:!0,forced:o},{mapKeys:function(e){var t=i(this),r=s(t),n=u(e,arguments.length>1?arguments[1]:void 0,3),o=new(c(t,a("Map"))),d=l(o.set);return f(r,(function(e,r){d.call(o,n(r,e,t),r)}),{AS_ENTRIES:!0,IS_ITERATOR:!0}),o}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(10),i=r(2),l=r(5),u=r(7),c=r(17),s=r(15),f=r(4);n({target:"Map",proto:!0,real:!0,forced:o},{mapValues:function(e){var t=i(this),r=s(t),n=u(e,arguments.length>1?arguments[1]:void 0,3),o=new(c(t,a("Map"))),d=l(o.set);return f(r,(function(e,r){d.call(o,e,n(r,e,t))}),{AS_ENTRIES:!0,IS_ITERATOR:!0}),o}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(5),l=r(4);n({target:"Map",proto:!0,real:!0,forced:o},{merge:function(e){for(var t=a(this),r=i(t.set),n=0;n<arguments.length;)l(arguments[n++],r,{that:t,AS_ENTRIES:!0});return t}})},function(e,t,r){r(1)({target:"Map",stat:!0},{of:r(81)})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(5),l=r(15),u=r(4);n({target:"Map",proto:!0,real:!0,forced:o},{reduce:function(e){var t=a(this),r=l(t),n=arguments.length<2,o=n?void 0:arguments[1];if(i(e),u(r,(function(r,a){n?(n=!1,o=a):o=e(o,a,r,t)}),{AS_ENTRIES:!0,IS_ITERATOR:!0}),n)throw TypeError("Reduce of empty map with no initial value");return o}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(7),l=r(15),u=r(4);n({target:"Map",proto:!0,real:!0,forced:o},{some:function(e){var t=a(this),r=l(t),n=i(e,arguments.length>1?arguments[1]:void 0,3);return u(r,(function(e,r,o){if(n(r,e,t))return o()}),{AS_ENTRIES:!0,IS_ITERATOR:!0,INTERRUPTED:!0}).stopped}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(5);n({target:"Map",proto:!0,real:!0,forced:o},{update:function(e,t){var r=a(this),n=arguments.length;i(t);var o=r.has(e);if(!o&&n<3)throw TypeError("Updating absent value");var l=o?r.get(e):i(n>2?arguments[2]:void 0)(e,r);return r.set(e,t(l,e,r)),r}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(127);n({target:"Set",proto:!0,real:!0,forced:o},{addAll:function(){return a.apply(this,arguments)}})},function(e,t,r){"use strict";var n=r(2),o=r(5);e.exports=function(){for(var e=n(this),t=o(e.add),r=0,a=arguments.length;r<a;r++)t.call(e,arguments[r]);return e}},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(79);n({target:"Set",proto:!0,real:!0,forced:o},{deleteAll:function(){return a.apply(this,arguments)}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(10),i=r(2),l=r(5),u=r(17),c=r(4);n({target:"Set",proto:!0,real:!0,forced:o},{difference:function(e){var t=i(this),r=new(u(t,a("Set")))(t),n=l(r.delete);return c(e,(function(e){n.call(r,e)})),r}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(7),l=r(19),u=r(4);n({target:"Set",proto:!0,real:!0,forced:o},{every:function(e){var t=a(this),r=l(t),n=i(e,arguments.length>1?arguments[1]:void 0,3);return!u(r,(function(e,r){if(!n(e,e,t))return r()}),{IS_ITERATOR:!0,INTERRUPTED:!0}).stopped}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(10),i=r(2),l=r(5),u=r(7),c=r(17),s=r(19),f=r(4);n({target:"Set",proto:!0,real:!0,forced:o},{filter:function(e){var t=i(this),r=s(t),n=u(e,arguments.length>1?arguments[1]:void 0,3),o=new(c(t,a("Set"))),d=l(o.add);return f(r,(function(e){n(e,e,t)&&d.call(o,e)}),{IS_ITERATOR:!0}),o}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(7),l=r(19),u=r(4);n({target:"Set",proto:!0,real:!0,forced:o},{find:function(e){var t=a(this),r=l(t),n=i(e,arguments.length>1?arguments[1]:void 0,3);return u(r,(function(e,r){if(n(e,e,t))return r(e)}),{IS_ITERATOR:!0,INTERRUPTED:!0}).result}})},function(e,t,r){r(1)({target:"Set",stat:!0},{from:r(80)})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(10),i=r(2),l=r(5),u=r(17),c=r(4);n({target:"Set",proto:!0,real:!0,forced:o},{intersection:function(e){var t=i(this),r=new(u(t,a("Set"))),n=l(t.has),o=l(r.add);return c(e,(function(e){n.call(t,e)&&o.call(r,e)})),r}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(5),l=r(4);n({target:"Set",proto:!0,real:!0,forced:o},{isDisjointFrom:function(e){var t=a(this),r=i(t.has);return!l(e,(function(e,n){if(!0===r.call(t,e))return n()}),{INTERRUPTED:!0}).stopped}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(10),i=r(2),l=r(5),u=r(48),c=r(4);n({target:"Set",proto:!0,real:!0,forced:o},{isSubsetOf:function(e){var t=u(this),r=i(e),n=r.has;return"function"!=typeof n&&(r=new(a("Set"))(e),n=l(r.has)),!c(t,(function(e,t){if(!1===n.call(r,e))return t()}),{IS_ITERATOR:!0,INTERRUPTED:!0}).stopped}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(5),l=r(4);n({target:"Set",proto:!0,real:!0,forced:o},{isSupersetOf:function(e){var t=a(this),r=i(t.has);return!l(e,(function(e,n){if(!1===r.call(t,e))return n()}),{INTERRUPTED:!0}).stopped}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(19),l=r(4);n({target:"Set",proto:!0,real:!0,forced:o},{join:function(e){var t=a(this),r=i(t),n=void 0===e?",":String(e),o=[];return l(r,o.push,{that:o,IS_ITERATOR:!0}),o.join(n)}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(10),i=r(2),l=r(5),u=r(7),c=r(17),s=r(19),f=r(4);n({target:"Set",proto:!0,real:!0,forced:o},{map:function(e){var t=i(this),r=s(t),n=u(e,arguments.length>1?arguments[1]:void 0,3),o=new(c(t,a("Set"))),d=l(o.add);return f(r,(function(e){d.call(o,n(e,e,t))}),{IS_ITERATOR:!0}),o}})},function(e,t,r){r(1)({target:"Set",stat:!0},{of:r(81)})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(5),l=r(19),u=r(4);n({target:"Set",proto:!0,real:!0,forced:o},{reduce:function(e){var t=a(this),r=l(t),n=arguments.length<2,o=n?void 0:arguments[1];if(i(e),u(r,(function(r){n?(n=!1,o=r):o=e(o,r,r,t)}),{IS_ITERATOR:!0}),n)throw TypeError("Reduce of empty set with no initial value");return o}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(2),i=r(7),l=r(19),u=r(4);n({target:"Set",proto:!0,real:!0,forced:o},{some:function(e){var t=a(this),r=l(t),n=i(e,arguments.length>1?arguments[1]:void 0,3);return u(r,(function(e,r){if(n(e,e,t))return r()}),{IS_ITERATOR:!0,INTERRUPTED:!0}).stopped}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(10),i=r(2),l=r(5),u=r(17),c=r(4);n({target:"Set",proto:!0,real:!0,forced:o},{symmetricDifference:function(e){var t=i(this),r=new(u(t,a("Set")))(t),n=l(r.delete),o=l(r.add);return c(e,(function(e){n.call(r,e)||o.call(r,e)})),r}})},function(e,t,r){"use strict";var n=r(1),o=r(3),a=r(10),i=r(2),l=r(5),u=r(17),c=r(4);n({target:"Set",proto:!0,real:!0,forced:o},{union:function(e){var t=i(this),r=new(u(t,a("Set")))(t);return c(e,l(r.add),{that:r}),r}})},function(e,t,r){var n=r(8),o=r(146),a=r(147),i=r(18),l=r(6),u=l("iterator"),c=l("toStringTag"),s=a.values;for(var f in o){var d=n[f],p=d&&d.prototype;if(p){if(p[u]!==s)try{i(p,u,s)}catch(e){p[u]=s}if(p[c]||i(p,c,f),o[f])for(var h in a)if(p[h]!==a[h])try{i(p,h,a[h])}catch(e){p[h]=a[h]}}}},function(e,t){e.exports={CSSRuleList:0,CSSStyleDeclaration:0,CSSValueList:0,ClientRectList:0,DOMRectList:0,DOMStringList:0,DOMTokenList:1,DataTransferItemList:0,FileList:0,HTMLAllCollection:0,HTMLCollection:0,HTMLFormElement:0,HTMLSelectElement:0,MediaList:0,MimeTypeArray:0,NamedNodeMap:0,NodeList:1,PaintRequestList:0,Plugin:0,PluginArray:0,SVGLengthList:0,SVGNumberList:0,SVGPathSegList:0,SVGPointList:0,SVGStringList:0,SVGTransformList:0,SourceBufferList:0,StyleSheetList:0,TextTrackCueList:0,TextTrackList:0,TouchList:0}},function(e,t,r){"use strict";var n=r(20),o=r(148),a=r(27),i=r(24),l=r(47),u="Array Iterator",c=i.set,s=i.getterFor(u);e.exports=l(Array,"Array",(function(e,t){c(this,{type:u,target:n(e),index:0,kind:t})}),(function(){var e=s(this),t=e.target,r=e.kind,n=e.index++;return!t||n>=t.length?(e.target=void 0,{value:void 0,done:!0}):"keys"==r?{value:n,done:!1}:"values"==r?{value:t[n],done:!1}:{value:[n,t[n]],done:!1}}),"values"),a.Arguments=a.Array,o("keys"),o("values"),o("entries")},function(e,t,r){var n=r(6),o=r(32),a=r(14),i=n("unscopables"),l=Array.prototype;void 0==l[i]&&a.f(l,i,{configurable:!0,value:o(null)}),e.exports=function(e){l[i][e]=!0}},function(e,t,r){"use strict";r(150),r(153),r(154),r(155),r(156),r(157),r(158),r(159),r(160),r(161),r(162),r(163),r(164),r(165),r(166),r(169),r(172),r(173),r(77),r(78),r(174),r(175),r(176),"undefined"===typeof Promise&&(r(177).enable(),self.Promise=r(179)),"undefined"!==typeof window&&r(180),Object.assign=r(50)},function(e,t,r){"use strict";var n=r(1),o=r(8),a=r(10),i=r(3),l=r(16),u=r(44),c=r(67),s=r(12),f=r(11),d=r(49),p=r(13),h=r(2),g=r(28),v=r(20),m=r(29),y=r(23),b=r(32),w=r(74),k=r(41),E=r(151),x=r(63),S=r(35),_=r(14),T=r(55),C=r(18),O=r(21),P=r(40),R=r(30),N=r(25),L=r(31),A=r(6),I=r(82),j=r(9),M=r(22),D=r(24),q=r(152).forEach,z=R("hidden"),U="Symbol",F=A("toPrimitive"),B=D.set,V=D.getterFor(U),H=Object.prototype,W=o.Symbol,$=a("JSON","stringify"),G=S.f,Q=_.f,Y=E.f,K=T.f,X=P("symbols"),J=P("op-symbols"),Z=P("string-to-symbol-registry"),ee=P("symbol-to-string-registry"),te=P("wks"),re=o.QObject,ne=!re||!re.prototype||!re.prototype.findChild,oe=l&&s((function(){return 7!=b(Q({},"a",{get:function(){return Q(this,"a",{value:7}).a}})).a}))?function(e,t,r){var n=G(H,t);n&&delete H[t],Q(e,t,r),n&&e!==H&&Q(H,t,n)}:Q,ae=function(e,t){var r=X[e]=b(W.prototype);return B(r,{type:U,tag:e,description:t}),l||(r.description=t),r},ie=c?function(e){return"symbol"==typeof e}:function(e){return Object(e)instanceof W},le=function(e,t,r){e===H&&le(J,t,r),h(e);var n=m(t,!0);return h(r),f(X,n)?(r.enumerable?(f(e,z)&&e[z][n]&&(e[z][n]=!1),r=b(r,{enumerable:y(0,!1)})):(f(e,z)||Q(e,z,y(1,{})),e[z][n]=!0),oe(e,n,r)):Q(e,n,r)},ue=function(e,t){h(e);var r=v(t),n=w(r).concat(de(r));return q(n,(function(t){l&&!ce.call(r,t)||le(e,t,r[t])})),e},ce=function(e){var t=m(e,!0),r=K.call(this,t);return!(this===H&&f(X,t)&&!f(J,t))&&(!(r||!f(this,t)||!f(X,t)||f(this,z)&&this[z][t])||r)},se=function(e,t){var r=v(e),n=m(t,!0);if(r!==H||!f(X,n)||f(J,n)){var o=G(r,n);return!o||!f(X,n)||f(r,z)&&r[z][n]||(o.enumerable=!0),o}},fe=function(e){var t=Y(v(e)),r=[];return q(t,(function(e){f(X,e)||f(N,e)||r.push(e)})),r},de=function(e){var t=e===H,r=Y(t?J:v(e)),n=[];return q(r,(function(e){!f(X,e)||t&&!f(H,e)||n.push(X[e])})),n};(u||(O((W=function(){if(this instanceof W)throw TypeError("Symbol is not a constructor");var e=arguments.length&&void 0!==arguments[0]?String(arguments[0]):void 0,t=L(e),r=function e(r){this===H&&e.call(J,r),f(this,z)&&f(this[z],t)&&(this[z][t]=!1),oe(this,t,y(1,r))};return l&&ne&&oe(H,t,{configurable:!0,set:r}),ae(t,e)}).prototype,"toString",(function(){return V(this).tag})),O(W,"withoutSetter",(function(e){return ae(L(e),e)})),T.f=ce,_.f=le,S.f=se,k.f=E.f=fe,x.f=de,I.f=function(e){return ae(A(e),e)},l&&(Q(W.prototype,"description",{configurable:!0,get:function(){return V(this).description}}),i||O(H,"propertyIsEnumerable",ce,{unsafe:!0}))),n({global:!0,wrap:!0,forced:!u,sham:!u},{Symbol:W}),q(w(te),(function(e){j(e)})),n({target:U,stat:!0,forced:!u},{for:function(e){var t=String(e);if(f(Z,t))return Z[t];var r=W(t);return Z[t]=r,ee[r]=t,r},keyFor:function(e){if(!ie(e))throw TypeError(e+" is not a symbol");if(f(ee,e))return ee[e]},useSetter:function(){ne=!0},useSimple:function(){ne=!1}}),n({target:"Object",stat:!0,forced:!u,sham:!l},{create:function(e,t){return void 0===t?b(e):ue(b(e),t)},defineProperty:le,defineProperties:ue,getOwnPropertyDescriptor:se}),n({target:"Object",stat:!0,forced:!u},{getOwnPropertyNames:fe,getOwnPropertySymbols:de}),n({target:"Object",stat:!0,forced:s((function(){x.f(1)}))},{getOwnPropertySymbols:function(e){return x.f(g(e))}}),$)&&n({target:"JSON",stat:!0,forced:!u||s((function(){var e=W();return"[null]"!=$([e])||"{}"!=$({a:e})||"{}"!=$(Object(e))}))},{stringify:function(e,t,r){for(var n,o=[e],a=1;arguments.length>a;)o.push(arguments[a++]);if(n=t,(p(t)||void 0!==e)&&!ie(e))return d(t)||(t=function(e,t){if("function"==typeof n&&(t=n.call(this,e,t)),!ie(t))return t}),o[1]=t,$.apply(null,o)}});W.prototype[F]||C(W.prototype,F,W.prototype.valueOf),M(W,U),N[z]=!0},function(e,t,r){var n=r(20),o=r(41).f,a={}.toString,i="object"==typeof window&&window&&Object.getOwnPropertyNames?Object.getOwnPropertyNames(window):[];e.exports.f=function(e){return i&&"[object Window]"==a.call(e)?function(e){try{return o(e)}catch(e){return i.slice()}}(e):o(n(e))}},function(e,t,r){var n=r(7),o=r(56),a=r(28),i=r(26),l=r(83),u=[].push,c=function(e){var t=1==e,r=2==e,c=3==e,s=4==e,f=6==e,d=7==e,p=5==e||f;return function(h,g,v,m){for(var y,b,w=a(h),k=o(w),E=n(g,v,3),x=i(k.length),S=0,_=m||l,T=t?_(h,x):r||d?_(h,0):void 0;x>S;S++)if((p||S in k)&&(b=E(y=k[S],S,w),e))if(t)T[S]=b;else if(b)switch(e){case 3:return!0;case 5:return y;case 6:return S;case 2:u.call(T,y)}else switch(e){case 4:return!1;case 7:u.call(T,y)}return f?-1:c||s?s:T}};e.exports={forEach:c(0),map:c(1),filter:c(2),some:c(3),every:c(4),find:c(5),findIndex:c(6),filterOut:c(7)}},function(e,t,r){"use strict";var n=r(1),o=r(16),a=r(8),i=r(11),l=r(13),u=r(14).f,c=r(60),s=a.Symbol;if(o&&"function"==typeof s&&(!("description"in s.prototype)||void 0!==s().description)){var f={},d=function(){var e=arguments.length<1||void 0===arguments[0]?void 0:String(arguments[0]),t=this instanceof d?new s(e):void 0===e?s():s(e);return""===e&&(f[t]=!0),t};c(d,s);var p=d.prototype=s.prototype;p.constructor=d;var h=p.toString,g="Symbol(test)"==String(s("test")),v=/^Symbol\\((.*)\\)[^)]+$/;u(p,"description",{configurable:!0,get:function(){var e=l(this)?this.valueOf():this,t=h.call(e);if(i(f,e))return"";var r=g?t.slice(7,-1):t.replace(v,"$1");return""===r?void 0:r}}),n({global:!0,forced:!0},{Symbol:d})}},function(e,t,r){r(9)("asyncIterator")},function(e,t,r){r(9)("hasInstance")},function(e,t,r){r(9)("isConcatSpreadable")},function(e,t,r){r(9)("iterator")},function(e,t,r){r(9)("match")},function(e,t,r){r(9)("replace")},function(e,t,r){r(9)("search")},function(e,t,r){r(9)("species")},function(e,t,r){r(9)("split")},function(e,t,r){r(9)("toPrimitive")},function(e,t,r){r(9)("toStringTag")},function(e,t,r){r(9)("unscopables")},function(e,t,r){"use strict";var n=r(1),o=r(12),a=r(49),i=r(13),l=r(28),u=r(26),c=r(84),s=r(83),f=r(167),d=r(6),p=r(85),h=d("isConcatSpreadable"),g=9007199254740991,v="Maximum allowed index exceeded",m=p>=51||!o((function(){var e=[];return e[h]=!1,e.concat()[0]!==e})),y=f("concat"),b=function(e){if(!i(e))return!1;var t=e[h];return void 0!==t?!!t:a(e)};n({target:"Array",proto:!0,forced:!m||!y},{concat:function(e){var t,r,n,o,a,i=l(this),f=s(i,0),d=0;for(t=-1,n=arguments.length;t<n;t++)if(b(a=-1===t?i:arguments[t])){if(d+(o=u(a.length))>g)throw TypeError(v);for(r=0;r<o;r++,d++)r in a&&c(f,d,a[r])}else{if(d>=g)throw TypeError(v);c(f,d++,a)}return f.length=d,f}})},function(e,t,r){var n=r(12),o=r(6),a=r(85),i=o("species");e.exports=function(e){return a>=51||!n((function(){var t=[];return(t.constructor={})[i]=function(){return{foo:1}},1!==t[e](Boolean).foo}))}},function(e,t,r){var n=r(10);e.exports=n("navigator","userAgent")||""},function(e,t,r){var n=r(1),o=r(170);n({target:"Array",stat:!0,forced:!r(71)((function(e){Array.from(e)}))},{from:o})},function(e,t,r){"use strict";var n=r(7),o=r(28),a=r(171),i=r(66),l=r(26),u=r(84),c=r(45);e.exports=function(e){var t,r,s,f,d,p,h=o(e),g="function"==typeof this?this:Array,v=arguments.length,m=v>1?arguments[1]:void 0,y=void 0!==m,b=c(h),w=0;if(y&&(m=n(m,v>2?arguments[2]:void 0,2)),void 0==b||g==Array&&i(b))for(r=new g(t=l(h.length));t>w;w++)p=y?m(h[w],w):h[w],u(r,w,p);else for(d=(f=b.call(h)).next,r=new g;!(s=d.call(f)).done;w++)p=y?a(f,m,[s.value,w],!0):s.value,u(r,w,p);return r.length=w,r}},function(e,t,r){var n=r(2),o=r(69);e.exports=function(e,t,r,a){try{return a?t(n(r)[0],r[1]):t(r)}catch(t){throw o(e),t}}},function(e,t,r){var n=r(8);r(22)(n.JSON,"JSON",!0)},function(e,t,r){r(22)(Math,"Math",!0)},function(e,t,r){r(9)("dispose")},function(e,t,r){r(9)("observable")},function(e,t,r){r(9)("patternMatch")},function(e,t,r){"use strict";var n=r(86),o=[ReferenceError,TypeError,RangeError],a=!1;function i(){a=!1,n._Y=null,n._Z=null}function l(e,t){return t.some((function(t){return e instanceof t}))}t.disable=i,t.enable=function(e){e=e||{},a&&i();a=!0;var t=0,r=0,u={};function c(t){(e.allRejections||l(u[t].error,e.whitelist||o))&&(u[t].displayId=r++,e.onUnhandled?(u[t].logged=!0,e.onUnhandled(u[t].displayId,u[t].error)):(u[t].logged=!0,function(e,t){console.warn("Possible Unhandled Promise Rejection (id: "+e+"):"),((t&&(t.stack||t))+"").split("\\n").forEach((function(e){console.warn("  "+e)}))}(u[t].displayId,u[t].error)))}n._Y=function(t){2===t._V&&u[t._1]&&(u[t._1].logged?function(t){u[t].logged&&(e.onHandled?e.onHandled(u[t].displayId,u[t].error):u[t].onUnhandled||(console.warn("Promise Rejection Handled (id: "+u[t].displayId+"):"),console.warn(\'  This means you can ignore any previous messages of the form "Possible Unhandled Promise Rejection" with id \'+u[t].displayId+".")))}(t._1):clearTimeout(u[t._1].timeout),delete u[t._1])},n._Z=function(e,r){0===e._U&&(e._1=t++,u[e._1]={displayId:null,error:r,timeout:setTimeout(c.bind(null,e._1),l(r,o)?100:2e3),logged:!1})}}},function(e,t,r){"use strict";(function(t){function r(e){o.length||(n(),!0),o[o.length]=e}e.exports=r;var n,o=[],a=0;function i(){for(;a<o.length;){var e=a;if(a+=1,o[e].call(),a>1024){for(var t=0,r=o.length-a;t<r;t++)o[t]=o[t+a];o.length-=a,a=0}}o.length=0,a=0,!1}var l,u,c,s="undefined"!==typeof t?t:self,f=s.MutationObserver||s.WebKitMutationObserver;function d(e){return function(){var t=setTimeout(n,0),r=setInterval(n,50);function n(){clearTimeout(t),clearInterval(r),e()}}}"function"===typeof f?(l=1,u=new f(i),c=document.createTextNode(""),u.observe(c,{characterData:!0}),n=function(){l=-l,c.data=l}):n=d(i),r.requestFlush=n,r.makeRequestCallFromTimer=d}).call(this,r(34))},function(e,t,r){"use strict";var n=r(86);e.exports=n;var o=s(!0),a=s(!1),i=s(null),l=s(void 0),u=s(0),c=s("");function s(e){var t=new n(n._0);return t._V=1,t._W=e,t}n.resolve=function(e){if(e instanceof n)return e;if(null===e)return i;if(void 0===e)return l;if(!0===e)return o;if(!1===e)return a;if(0===e)return u;if(""===e)return c;if("object"===typeof e||"function"===typeof e)try{var t=e.then;if("function"===typeof t)return new n(t.bind(e))}catch(e){return new n((function(t,r){r(e)}))}return s(e)};var f=function(e){return"function"===typeof Array.from?(f=Array.from,Array.from(e)):(f=function(e){return Array.prototype.slice.call(e)},Array.prototype.slice.call(e))};n.all=function(e){var t=f(e);return new n((function(e,r){if(0===t.length)return e([]);var o=t.length;function a(i,l){if(l&&("object"===typeof l||"function"===typeof l)){if(l instanceof n&&l.then===n.prototype.then){for(;3===l._V;)l=l._W;return 1===l._V?a(i,l._W):(2===l._V&&r(l._W),void l.then((function(e){a(i,e)}),r))}var u=l.then;if("function"===typeof u)return void new n(u.bind(l)).then((function(e){a(i,e)}),r)}t[i]=l,0===--o&&e(t)}for(var i=0;i<t.length;i++)a(i,t[i])}))},n.reject=function(e){return new n((function(t,r){r(e)}))},n.race=function(e){return new n((function(t,r){f(e).forEach((function(e){n.resolve(e).then(t,r)}))}))},n.prototype.catch=function(e){return this.then(null,e)}},function(e,t,r){"use strict";r.r(t),r.d(t,"Headers",(function(){return h})),r.d(t,"Request",(function(){return k})),r.d(t,"Response",(function(){return x})),r.d(t,"DOMException",(function(){return _})),r.d(t,"fetch",(function(){return T}));var n="undefined"!==typeof globalThis&&globalThis||"undefined"!==typeof self&&self||"undefined"!==typeof n&&n,o="URLSearchParams"in n,a="Symbol"in n&&"iterator"in Symbol,i="FileReader"in n&&"Blob"in n&&function(){try{return new Blob,!0}catch(e){return!1}}(),l="FormData"in n,u="ArrayBuffer"in n;if(u)var c=["[object Int8Array]","[object Uint8Array]","[object Uint8ClampedArray]","[object Int16Array]","[object Uint16Array]","[object Int32Array]","[object Uint32Array]","[object Float32Array]","[object Float64Array]"],s=ArrayBuffer.isView||function(e){return e&&c.indexOf(Object.prototype.toString.call(e))>-1};function f(e){if("string"!==typeof e&&(e=String(e)),/[^a-z0-9\\-#$%&\'*+.^_`|~!]/i.test(e)||""===e)throw new TypeError("Invalid character in header field name");return e.toLowerCase()}function d(e){return"string"!==typeof e&&(e=String(e)),e}function p(e){var t={next:function(){var t=e.shift();return{done:void 0===t,value:t}}};return a&&(t[Symbol.iterator]=function(){return t}),t}function h(e){this.map={},e instanceof h?e.forEach((function(e,t){this.append(t,e)}),this):Array.isArray(e)?e.forEach((function(e){this.append(e[0],e[1])}),this):e&&Object.getOwnPropertyNames(e).forEach((function(t){this.append(t,e[t])}),this)}function g(e){if(e.bodyUsed)return Promise.reject(new TypeError("Already read"));e.bodyUsed=!0}function v(e){return new Promise((function(t,r){e.onload=function(){t(e.result)},e.onerror=function(){r(e.error)}}))}function m(e){var t=new FileReader,r=v(t);return t.readAsArrayBuffer(e),r}function y(e){if(e.slice)return e.slice(0);var t=new Uint8Array(e.byteLength);return t.set(new Uint8Array(e)),t.buffer}function b(){return this.bodyUsed=!1,this._initBody=function(e){var t;this.bodyUsed=this.bodyUsed,this._bodyInit=e,e?"string"===typeof e?this._bodyText=e:i&&Blob.prototype.isPrototypeOf(e)?this._bodyBlob=e:l&&FormData.prototype.isPrototypeOf(e)?this._bodyFormData=e:o&&URLSearchParams.prototype.isPrototypeOf(e)?this._bodyText=e.toString():u&&i&&((t=e)&&DataView.prototype.isPrototypeOf(t))?(this._bodyArrayBuffer=y(e.buffer),this._bodyInit=new Blob([this._bodyArrayBuffer])):u&&(ArrayBuffer.prototype.isPrototypeOf(e)||s(e))?this._bodyArrayBuffer=y(e):this._bodyText=e=Object.prototype.toString.call(e):this._bodyText="",this.headers.get("content-type")||("string"===typeof e?this.headers.set("content-type","text/plain;charset=UTF-8"):this._bodyBlob&&this._bodyBlob.type?this.headers.set("content-type",this._bodyBlob.type):o&&URLSearchParams.prototype.isPrototypeOf(e)&&this.headers.set("content-type","application/x-www-form-urlencoded;charset=UTF-8"))},i&&(this.blob=function(){var e=g(this);if(e)return e;if(this._bodyBlob)return Promise.resolve(this._bodyBlob);if(this._bodyArrayBuffer)return Promise.resolve(new Blob([this._bodyArrayBuffer]));if(this._bodyFormData)throw new Error("could not read FormData body as blob");return Promise.resolve(new Blob([this._bodyText]))},this.arrayBuffer=function(){if(this._bodyArrayBuffer){var e=g(this);return e||(ArrayBuffer.isView(this._bodyArrayBuffer)?Promise.resolve(this._bodyArrayBuffer.buffer.slice(this._bodyArrayBuffer.byteOffset,this._bodyArrayBuffer.byteOffset+this._bodyArrayBuffer.byteLength)):Promise.resolve(this._bodyArrayBuffer))}return this.blob().then(m)}),this.text=function(){var e,t,r,n=g(this);if(n)return n;if(this._bodyBlob)return e=this._bodyBlob,t=new FileReader,r=v(t),t.readAsText(e),r;if(this._bodyArrayBuffer)return Promise.resolve(function(e){for(var t=new Uint8Array(e),r=new Array(t.length),n=0;n<t.length;n++)r[n]=String.fromCharCode(t[n]);return r.join("")}(this._bodyArrayBuffer));if(this._bodyFormData)throw new Error("could not read FormData body as text");return Promise.resolve(this._bodyText)},l&&(this.formData=function(){return this.text().then(E)}),this.json=function(){return this.text().then(JSON.parse)},this}h.prototype.append=function(e,t){e=f(e),t=d(t);var r=this.map[e];this.map[e]=r?r+", "+t:t},h.prototype.delete=function(e){delete this.map[f(e)]},h.prototype.get=function(e){return e=f(e),this.has(e)?this.map[e]:null},h.prototype.has=function(e){return this.map.hasOwnProperty(f(e))},h.prototype.set=function(e,t){this.map[f(e)]=d(t)},h.prototype.forEach=function(e,t){for(var r in this.map)this.map.hasOwnProperty(r)&&e.call(t,this.map[r],r,this)},h.prototype.keys=function(){var e=[];return this.forEach((function(t,r){e.push(r)})),p(e)},h.prototype.values=function(){var e=[];return this.forEach((function(t){e.push(t)})),p(e)},h.prototype.entries=function(){var e=[];return this.forEach((function(t,r){e.push([r,t])})),p(e)},a&&(h.prototype[Symbol.iterator]=h.prototype.entries);var w=["DELETE","GET","HEAD","OPTIONS","POST","PUT"];function k(e,t){if(!(this instanceof k))throw new TypeError(\'Please use the "new" operator, this DOM object constructor cannot be called as a function.\');var r,n,o=(t=t||{}).body;if(e instanceof k){if(e.bodyUsed)throw new TypeError("Already read");this.url=e.url,this.credentials=e.credentials,t.headers||(this.headers=new h(e.headers)),this.method=e.method,this.mode=e.mode,this.signal=e.signal,o||null==e._bodyInit||(o=e._bodyInit,e.bodyUsed=!0)}else this.url=String(e);if(this.credentials=t.credentials||this.credentials||"same-origin",!t.headers&&this.headers||(this.headers=new h(t.headers)),this.method=(r=t.method||this.method||"GET",n=r.toUpperCase(),w.indexOf(n)>-1?n:r),this.mode=t.mode||this.mode||null,this.signal=t.signal||this.signal,this.referrer=null,("GET"===this.method||"HEAD"===this.method)&&o)throw new TypeError("Body not allowed for GET or HEAD requests");if(this._initBody(o),("GET"===this.method||"HEAD"===this.method)&&("no-store"===t.cache||"no-cache"===t.cache)){var a=/([?&])_=[^&]*/;if(a.test(this.url))this.url=this.url.replace(a,"$1_="+(new Date).getTime());else{this.url+=(/\\?/.test(this.url)?"&":"?")+"_="+(new Date).getTime()}}}function E(e){var t=new FormData;return e.trim().split("&").forEach((function(e){if(e){var r=e.split("="),n=r.shift().replace(/\\+/g," "),o=r.join("=").replace(/\\+/g," ");t.append(decodeURIComponent(n),decodeURIComponent(o))}})),t}function x(e,t){if(!(this instanceof x))throw new TypeError(\'Please use the "new" operator, this DOM object constructor cannot be called as a function.\');t||(t={}),this.type="default",this.status=void 0===t.status?200:t.status,this.ok=this.status>=200&&this.status<300,this.statusText="statusText"in t?t.statusText:"",this.headers=new h(t.headers),this.url=t.url||"",this._initBody(e)}k.prototype.clone=function(){return new k(this,{body:this._bodyInit})},b.call(k.prototype),b.call(x.prototype),x.prototype.clone=function(){return new x(this._bodyInit,{status:this.status,statusText:this.statusText,headers:new h(this.headers),url:this.url})},x.error=function(){var e=new x(null,{status:0,statusText:""});return e.type="error",e};var S=[301,302,303,307,308];x.redirect=function(e,t){if(-1===S.indexOf(t))throw new RangeError("Invalid status code");return new x(null,{status:t,headers:{location:e}})};var _=n.DOMException;try{new _}catch(e){(_=function(e,t){this.message=e,this.name=t;var r=Error(e);this.stack=r.stack}).prototype=Object.create(Error.prototype),_.prototype.constructor=_}function T(e,t){return new Promise((function(r,o){var a=new k(e,t);if(a.signal&&a.signal.aborted)return o(new _("Aborted","AbortError"));var l=new XMLHttpRequest;function c(){l.abort()}l.onload=function(){var e,t,n={status:l.status,statusText:l.statusText,headers:(e=l.getAllResponseHeaders()||"",t=new h,e.replace(/\\r?\\n[\\t ]+/g," ").split("\\r").map((function(e){return 0===e.indexOf("\\n")?e.substr(1,e.length):e})).forEach((function(e){var r=e.split(":"),n=r.shift().trim();if(n){var o=r.join(":").trim();t.append(n,o)}})),t)};n.url="responseURL"in l?l.responseURL:n.headers.get("X-Request-URL");var o="response"in l?l.response:l.responseText;setTimeout((function(){r(new x(o,n))}),0)},l.onerror=function(){setTimeout((function(){o(new TypeError("Network request failed"))}),0)},l.ontimeout=function(){setTimeout((function(){o(new TypeError("Network request failed"))}),0)},l.onabort=function(){setTimeout((function(){o(new _("Aborted","AbortError"))}),0)},l.open(a.method,function(e){try{return""===e&&n.location.href?n.location.href:e}catch(t){return e}}(a.url),!0),"include"===a.credentials?l.withCredentials=!0:"omit"===a.credentials&&(l.withCredentials=!1),"responseType"in l&&(i?l.responseType="blob":u&&a.headers.get("Content-Type")&&-1!==a.headers.get("Content-Type").indexOf("application/octet-stream")&&(l.responseType="arraybuffer")),!t||"object"!==typeof t.headers||t.headers instanceof h?a.headers.forEach((function(e,t){l.setRequestHeader(t,e)})):Object.getOwnPropertyNames(t.headers).forEach((function(e){l.setRequestHeader(e,d(t.headers[e]))})),a.signal&&(a.signal.addEventListener("abort",c),l.onreadystatechange=function(){4===l.readyState&&a.signal.removeEventListener("abort",c)}),l.send("undefined"===typeof a._bodyInit?null:a._bodyInit)}))}T.polyfill=!0,n.fetch||(n.fetch=T,n.Headers=h,n.Request=k,n.Response=x)},function(e,t,r){(function(t){for(var n=r(182),o="undefined"===typeof window?t:window,a=["moz","webkit"],i="AnimationFrame",l=o["request"+i],u=o["cancel"+i]||o["cancelRequest"+i],c=0;!l&&c<a.length;c++)l=o[a[c]+"Request"+i],u=o[a[c]+"Cancel"+i]||o[a[c]+"CancelRequest"+i];if(!l||!u){var s=0,f=0,d=[];l=function(e){if(0===d.length){var t=n(),r=Math.max(0,16.666666666666668-(t-s));s=r+t,setTimeout((function(){var e=d.slice(0);d.length=0;for(var t=0;t<e.length;t++)if(!e[t].cancelled)try{e[t].callback(s)}catch(e){setTimeout((function(){throw e}),0)}}),Math.round(r))}return d.push({handle:++f,callback:e,cancelled:!1}),f},u=function(e){for(var t=0;t<d.length;t++)d[t].handle===e&&(d[t].cancelled=!0)}}e.exports=function(e){return l.call(o,e)},e.exports.cancel=function(){u.apply(o,arguments)},e.exports.polyfill=function(e){e||(e=o),e.requestAnimationFrame=l,e.cancelAnimationFrame=u}}).call(this,r(34))},function(e,t,r){(function(t){(function(){var r,n,o,a,i,l;"undefined"!==typeof performance&&null!==performance&&performance.now?e.exports=function(){return performance.now()}:"undefined"!==typeof t&&null!==t&&t.hrtime?(e.exports=function(){return(r()-i)/1e6},n=t.hrtime,a=(r=function(){var e;return 1e9*(e=n())[0]+e[1]})(),l=1e9*t.uptime(),i=a-l):Date.now?(e.exports=function(){return Date.now()-o},o=Date.now()):(e.exports=function(){return(new Date).getTime()-o},o=(new Date).getTime())}).call(this)}).call(this,r(51))},function(e,t,r){"use strict";var n=r(50),o=60103,a=60106;t.Fragment=60107,t.StrictMode=60108,t.Profiler=60114;var i=60109,l=60110,u=60112;t.Suspense=60113;var c=60115,s=60116;if("function"===typeof Symbol&&Symbol.for){var f=Symbol.for;o=f("react.element"),a=f("react.portal"),t.Fragment=f("react.fragment"),t.StrictMode=f("react.strict_mode"),t.Profiler=f("react.profiler"),i=f("react.provider"),l=f("react.context"),u=f("react.forward_ref"),t.Suspense=f("react.suspense"),c=f("react.memo"),s=f("react.lazy")}var d="function"===typeof Symbol&&Symbol.iterator;function p(e){for(var t="https://reactjs.org/docs/error-decoder.html?invariant="+e,r=1;r<arguments.length;r++)t+="&args[]="+encodeURIComponent(arguments[r]);return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var h={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},g={};function v(e,t,r){this.props=e,this.context=t,this.refs=g,this.updater=r||h}function m(){}function y(e,t,r){this.props=e,this.context=t,this.refs=g,this.updater=r||h}v.prototype.isReactComponent={},v.prototype.setState=function(e,t){if("object"!==typeof e&&"function"!==typeof e&&null!=e)throw Error(p(85));this.updater.enqueueSetState(this,e,t,"setState")},v.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")},m.prototype=v.prototype;var b=y.prototype=new m;b.constructor=y,n(b,v.prototype),b.isPureReactComponent=!0;var w={current:null},k=Object.prototype.hasOwnProperty,E={key:!0,ref:!0,__self:!0,__source:!0};function x(e,t,r){var n,a={},i=null,l=null;if(null!=t)for(n in void 0!==t.ref&&(l=t.ref),void 0!==t.key&&(i=""+t.key),t)k.call(t,n)&&!E.hasOwnProperty(n)&&(a[n]=t[n]);var u=arguments.length-2;if(1===u)a.children=r;else if(1<u){for(var c=Array(u),s=0;s<u;s++)c[s]=arguments[s+2];a.children=c}if(e&&e.defaultProps)for(n in u=e.defaultProps)void 0===a[n]&&(a[n]=u[n]);return{$$typeof:o,type:e,key:i,ref:l,props:a,_owner:w.current}}function S(e){return"object"===typeof e&&null!==e&&e.$$typeof===o}var _=/\\/+/g;function T(e,t){return"object"===typeof e&&null!==e&&null!=e.key?function(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,(function(e){return t[e]}))}(""+e.key):t.toString(36)}function C(e,t,r,n,i){var l=typeof e;"undefined"!==l&&"boolean"!==l||(e=null);var u=!1;if(null===e)u=!0;else switch(l){case"string":case"number":u=!0;break;case"object":switch(e.$$typeof){case o:case a:u=!0}}if(u)return i=i(u=e),e=""===n?"."+T(u,0):n,Array.isArray(i)?(r="",null!=e&&(r=e.replace(_,"$&/")+"/"),C(i,t,r,"",(function(e){return e}))):null!=i&&(S(i)&&(i=function(e,t){return{$$typeof:o,type:e.type,key:t,ref:e.ref,props:e.props,_owner:e._owner}}(i,r+(!i.key||u&&u.key===i.key?"":(""+i.key).replace(_,"$&/")+"/")+e)),t.push(i)),1;if(u=0,n=""===n?".":n+":",Array.isArray(e))for(var c=0;c<e.length;c++){var s=n+T(l=e[c],c);u+=C(l,t,r,s,i)}else if("function"===typeof(s=function(e){return null===e||"object"!==typeof e?null:"function"===typeof(e=d&&e[d]||e["@@iterator"])?e:null}(e)))for(e=s.call(e),c=0;!(l=e.next()).done;)u+=C(l=l.value,t,r,s=n+T(l,c++),i);else if("object"===l)throw t=""+e,Error(p(31,"[object Object]"===t?"object with keys {"+Object.keys(e).join(", ")+"}":t));return u}function O(e,t,r){if(null==e)return e;var n=[],o=0;return C(e,n,"","",(function(e){return t.call(r,e,o++)})),n}function P(e){if(-1===e._status){var t=e._result;t=t(),e._status=0,e._result=t,t.then((function(t){0===e._status&&(t=t.default,e._status=1,e._result=t)}),(function(t){0===e._status&&(e._status=2,e._result=t)}))}if(1===e._status)return e._result;throw e._result}var R={current:null};function N(){var e=R.current;if(null===e)throw Error(p(321));return e}var L={ReactCurrentDispatcher:R,ReactCurrentBatchConfig:{transition:0},ReactCurrentOwner:w,IsSomeRendererActing:{current:!1},assign:n};t.Children={map:O,forEach:function(e,t,r){O(e,(function(){t.apply(this,arguments)}),r)},count:function(e){var t=0;return O(e,(function(){t++})),t},toArray:function(e){return O(e,(function(e){return e}))||[]},only:function(e){if(!S(e))throw Error(p(143));return e}},t.Component=v,t.PureComponent=y,t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=L,t.cloneElement=function(e,t,r){if(null===e||void 0===e)throw Error(p(267,e));var a=n({},e.props),i=e.key,l=e.ref,u=e._owner;if(null!=t){if(void 0!==t.ref&&(l=t.ref,u=w.current),void 0!==t.key&&(i=""+t.key),e.type&&e.type.defaultProps)var c=e.type.defaultProps;for(s in t)k.call(t,s)&&!E.hasOwnProperty(s)&&(a[s]=void 0===t[s]&&void 0!==c?c[s]:t[s])}var s=arguments.length-2;if(1===s)a.children=r;else if(1<s){c=Array(s);for(var f=0;f<s;f++)c[f]=arguments[f+2];a.children=c}return{$$typeof:o,type:e.type,key:i,ref:l,props:a,_owner:u}},t.createContext=function(e,t){return void 0===t&&(t=null),(e={$$typeof:l,_calculateChangedBits:t,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null}).Provider={$$typeof:i,_context:e},e.Consumer=e},t.createElement=x,t.createFactory=function(e){var t=x.bind(null,e);return t.type=e,t},t.createRef=function(){return{current:null}},t.forwardRef=function(e){return{$$typeof:u,render:e}},t.isValidElement=S,t.lazy=function(e){return{$$typeof:s,_payload:{_status:-1,_result:e},_init:P}},t.memo=function(e,t){return{$$typeof:c,type:e,compare:void 0===t?null:t}},t.useCallback=function(e,t){return N().useCallback(e,t)},t.useContext=function(e,t){return N().useContext(e,t)},t.useDebugValue=function(){},t.useEffect=function(e,t){return N().useEffect(e,t)},t.useImperativeHandle=function(e,t,r){return N().useImperativeHandle(e,t,r)},t.useLayoutEffect=function(e,t){return N().useLayoutEffect(e,t)},t.useMemo=function(e,t){return N().useMemo(e,t)},t.useReducer=function(e,t,r){return N().useReducer(e,t,r)},t.useRef=function(e){return N().useRef(e)},t.useState=function(e){return N().useState(e)},t.version="17.0.1"},function(e,t,r){"use strict";var n=r(0),o=r(50),a=r(185);function i(e){for(var t="https://reactjs.org/docs/error-decoder.html?invariant="+e,r=1;r<arguments.length;r++)t+="&args[]="+encodeURIComponent(arguments[r]);return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}if(!n)throw Error(i(227));var l=new Set,u={};function c(e,t){s(e,t),s(e+"Capture",t)}function s(e,t){for(u[e]=t,e=0;e<t.length;e++)l.add(t[e])}var f=!("undefined"===typeof window||"undefined"===typeof window.document||"undefined"===typeof window.document.createElement),d=/^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$/,p=Object.prototype.hasOwnProperty,h={},g={};function v(e,t,r,n,o,a,i){this.acceptsBooleans=2===t||3===t||4===t,this.attributeName=n,this.attributeNamespace=o,this.mustUseProperty=r,this.propertyName=e,this.type=t,this.sanitizeURL=a,this.removeEmptyString=i}var m={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach((function(e){m[e]=new v(e,0,!1,e,null,!1,!1)})),[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach((function(e){var t=e[0];m[t]=new v(t,1,!1,e[1],null,!1,!1)})),["contentEditable","draggable","spellCheck","value"].forEach((function(e){m[e]=new v(e,2,!1,e.toLowerCase(),null,!1,!1)})),["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach((function(e){m[e]=new v(e,2,!1,e,null,!1,!1)})),"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach((function(e){m[e]=new v(e,3,!1,e.toLowerCase(),null,!1,!1)})),["checked","multiple","muted","selected"].forEach((function(e){m[e]=new v(e,3,!0,e,null,!1,!1)})),["capture","download"].forEach((function(e){m[e]=new v(e,4,!1,e,null,!1,!1)})),["cols","rows","size","span"].forEach((function(e){m[e]=new v(e,6,!1,e,null,!1,!1)})),["rowSpan","start"].forEach((function(e){m[e]=new v(e,5,!1,e.toLowerCase(),null,!1,!1)}));var y=/[\\-:]([a-z])/g;function b(e){return e[1].toUpperCase()}function w(e,t,r,n){var o=m.hasOwnProperty(t)?m[t]:null;(null!==o?0===o.type:!n&&(2<t.length&&("o"===t[0]||"O"===t[0])&&("n"===t[1]||"N"===t[1])))||(function(e,t,r,n){if(null===t||"undefined"===typeof t||function(e,t,r,n){if(null!==r&&0===r.type)return!1;switch(typeof t){case"function":case"symbol":return!0;case"boolean":return!n&&(null!==r?!r.acceptsBooleans:"data-"!==(e=e.toLowerCase().slice(0,5))&&"aria-"!==e);default:return!1}}(e,t,r,n))return!0;if(n)return!1;if(null!==r)switch(r.type){case 3:return!t;case 4:return!1===t;case 5:return isNaN(t);case 6:return isNaN(t)||1>t}return!1}(t,r,o,n)&&(r=null),n||null===o?function(e){return!!p.call(g,e)||!p.call(h,e)&&(d.test(e)?g[e]=!0:(h[e]=!0,!1))}(t)&&(null===r?e.removeAttribute(t):e.setAttribute(t,""+r)):o.mustUseProperty?e[o.propertyName]=null===r?3!==o.type&&"":r:(t=o.attributeName,n=o.attributeNamespace,null===r?e.removeAttribute(t):(r=3===(o=o.type)||4===o&&!0===r?"":""+r,n?e.setAttributeNS(n,t,r):e.setAttribute(t,r))))}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach((function(e){var t=e.replace(y,b);m[t]=new v(t,1,!1,e,null,!1,!1)})),"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach((function(e){var t=e.replace(y,b);m[t]=new v(t,1,!1,e,"http://www.w3.org/1999/xlink",!1,!1)})),["xml:base","xml:lang","xml:space"].forEach((function(e){var t=e.replace(y,b);m[t]=new v(t,1,!1,e,"http://www.w3.org/XML/1998/namespace",!1,!1)})),["tabIndex","crossOrigin"].forEach((function(e){m[e]=new v(e,1,!1,e.toLowerCase(),null,!1,!1)})),m.xlinkHref=new v("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1),["src","href","action","formAction"].forEach((function(e){m[e]=new v(e,1,!1,e.toLowerCase(),null,!0,!0)}));var k=n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,E=60103,x=60106,S=60107,_=60108,T=60114,C=60109,O=60110,P=60112,R=60113,N=60120,L=60115,A=60116,I=60121,j=60128,M=60129,D=60130,q=60131;if("function"===typeof Symbol&&Symbol.for){var z=Symbol.for;E=z("react.element"),x=z("react.portal"),S=z("react.fragment"),_=z("react.strict_mode"),T=z("react.profiler"),C=z("react.provider"),O=z("react.context"),P=z("react.forward_ref"),R=z("react.suspense"),N=z("react.suspense_list"),L=z("react.memo"),A=z("react.lazy"),I=z("react.block"),z("react.scope"),j=z("react.opaque.id"),M=z("react.debug_trace_mode"),D=z("react.offscreen"),q=z("react.legacy_hidden")}var U,F="function"===typeof Symbol&&Symbol.iterator;function B(e){return null===e||"object"!==typeof e?null:"function"===typeof(e=F&&e[F]||e["@@iterator"])?e:null}function V(e){if(void 0===U)try{throw Error()}catch(e){var t=e.stack.trim().match(/\\n( *(at )?)/);U=t&&t[1]||""}return"\\n"+U+e}var H=!1;function W(e,t){if(!e||H)return"";H=!0;var r=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(t)if(t=function(){throw Error()},Object.defineProperty(t.prototype,"props",{set:function(){throw Error()}}),"object"===typeof Reflect&&Reflect.construct){try{Reflect.construct(t,[])}catch(e){var n=e}Reflect.construct(e,[],t)}else{try{t.call()}catch(e){n=e}e.call(t.prototype)}else{try{throw Error()}catch(e){n=e}e()}}catch(e){if(e&&n&&"string"===typeof e.stack){for(var o=e.stack.split("\\n"),a=n.stack.split("\\n"),i=o.length-1,l=a.length-1;1<=i&&0<=l&&o[i]!==a[l];)l--;for(;1<=i&&0<=l;i--,l--)if(o[i]!==a[l]){if(1!==i||1!==l)do{if(i--,0>--l||o[i]!==a[l])return"\\n"+o[i].replace(" at new "," at ")}while(1<=i&&0<=l);break}}}finally{H=!1,Error.prepareStackTrace=r}return(e=e?e.displayName||e.name:"")?V(e):""}function $(e){switch(e.tag){case 5:return V(e.type);case 16:return V("Lazy");case 13:return V("Suspense");case 19:return V("SuspenseList");case 0:case 2:case 15:return e=W(e.type,!1);case 11:return e=W(e.type.render,!1);case 22:return e=W(e.type._render,!1);case 1:return e=W(e.type,!0);default:return""}}function G(e){if(null==e)return null;if("function"===typeof e)return e.displayName||e.name||null;if("string"===typeof e)return e;switch(e){case S:return"Fragment";case x:return"Portal";case T:return"Profiler";case _:return"StrictMode";case R:return"Suspense";case N:return"SuspenseList"}if("object"===typeof e)switch(e.$$typeof){case O:return(e.displayName||"Context")+".Consumer";case C:return(e._context.displayName||"Context")+".Provider";case P:var t=e.render;return t=t.displayName||t.name||"",e.displayName||(""!==t?"ForwardRef("+t+")":"ForwardRef");case L:return G(e.type);case I:return G(e._render);case A:t=e._payload,e=e._init;try{return G(e(t))}catch(e){}}return null}function Q(e){switch(typeof e){case"boolean":case"number":case"object":case"string":case"undefined":return e;default:return""}}function Y(e){var t=e.type;return(e=e.nodeName)&&"input"===e.toLowerCase()&&("checkbox"===t||"radio"===t)}function K(e){e._valueTracker||(e._valueTracker=function(e){var t=Y(e)?"checked":"value",r=Object.getOwnPropertyDescriptor(e.constructor.prototype,t),n=""+e[t];if(!e.hasOwnProperty(t)&&"undefined"!==typeof r&&"function"===typeof r.get&&"function"===typeof r.set){var o=r.get,a=r.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return o.call(this)},set:function(e){n=""+e,a.call(this,e)}}),Object.defineProperty(e,t,{enumerable:r.enumerable}),{getValue:function(){return n},setValue:function(e){n=""+e},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}(e))}function X(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var r=t.getValue(),n="";return e&&(n=Y(e)?e.checked?"true":"false":e.value),(e=n)!==r&&(t.setValue(e),!0)}function J(e){if("undefined"===typeof(e=e||("undefined"!==typeof document?document:void 0)))return null;try{return e.activeElement||e.body}catch(t){return e.body}}function Z(e,t){var r=t.checked;return o({},t,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:null!=r?r:e._wrapperState.initialChecked})}function ee(e,t){var r=null==t.defaultValue?"":t.defaultValue,n=null!=t.checked?t.checked:t.defaultChecked;r=Q(null!=t.value?t.value:r),e._wrapperState={initialChecked:n,initialValue:r,controlled:"checkbox"===t.type||"radio"===t.type?null!=t.checked:null!=t.value}}function te(e,t){null!=(t=t.checked)&&w(e,"checked",t,!1)}function re(e,t){te(e,t);var r=Q(t.value),n=t.type;if(null!=r)"number"===n?(0===r&&""===e.value||e.value!=r)&&(e.value=""+r):e.value!==""+r&&(e.value=""+r);else if("submit"===n||"reset"===n)return void e.removeAttribute("value");t.hasOwnProperty("value")?oe(e,t.type,r):t.hasOwnProperty("defaultValue")&&oe(e,t.type,Q(t.defaultValue)),null==t.checked&&null!=t.defaultChecked&&(e.defaultChecked=!!t.defaultChecked)}function ne(e,t,r){if(t.hasOwnProperty("value")||t.hasOwnProperty("defaultValue")){var n=t.type;if(!("submit"!==n&&"reset"!==n||void 0!==t.value&&null!==t.value))return;t=""+e._wrapperState.initialValue,r||t===e.value||(e.value=t),e.defaultValue=t}""!==(r=e.name)&&(e.name=""),e.defaultChecked=!!e._wrapperState.initialChecked,""!==r&&(e.name=r)}function oe(e,t,r){"number"===t&&J(e.ownerDocument)===e||(null==r?e.defaultValue=""+e._wrapperState.initialValue:e.defaultValue!==""+r&&(e.defaultValue=""+r))}function ae(e,t){return e=o({children:void 0},t),(t=function(e){var t="";return n.Children.forEach(e,(function(e){null!=e&&(t+=e)})),t}(t.children))&&(e.children=t),e}function ie(e,t,r,n){if(e=e.options,t){t={};for(var o=0;o<r.length;o++)t["$"+r[o]]=!0;for(r=0;r<e.length;r++)o=t.hasOwnProperty("$"+e[r].value),e[r].selected!==o&&(e[r].selected=o),o&&n&&(e[r].defaultSelected=!0)}else{for(r=""+Q(r),t=null,o=0;o<e.length;o++){if(e[o].value===r)return e[o].selected=!0,void(n&&(e[o].defaultSelected=!0));null!==t||e[o].disabled||(t=e[o])}null!==t&&(t.selected=!0)}}function le(e,t){if(null!=t.dangerouslySetInnerHTML)throw Error(i(91));return o({},t,{value:void 0,defaultValue:void 0,children:""+e._wrapperState.initialValue})}function ue(e,t){var r=t.value;if(null==r){if(r=t.children,t=t.defaultValue,null!=r){if(null!=t)throw Error(i(92));if(Array.isArray(r)){if(!(1>=r.length))throw Error(i(93));r=r[0]}t=r}null==t&&(t=""),r=t}e._wrapperState={initialValue:Q(r)}}function ce(e,t){var r=Q(t.value),n=Q(t.defaultValue);null!=r&&((r=""+r)!==e.value&&(e.value=r),null==t.defaultValue&&e.defaultValue!==r&&(e.defaultValue=r)),null!=n&&(e.defaultValue=""+n)}function se(e){var t=e.textContent;t===e._wrapperState.initialValue&&""!==t&&null!==t&&(e.value=t)}var fe="http://www.w3.org/1999/xhtml",de="http://www.w3.org/2000/svg";function pe(e){switch(e){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function he(e,t){return null==e||"http://www.w3.org/1999/xhtml"===e?pe(t):"http://www.w3.org/2000/svg"===e&&"foreignObject"===t?"http://www.w3.org/1999/xhtml":e}var ge,ve,me=(ve=function(e,t){if(e.namespaceURI!==de||"innerHTML"in e)e.innerHTML=t;else{for((ge=ge||document.createElement("div")).innerHTML="<svg>"+t.valueOf().toString()+"</svg>",t=ge.firstChild;e.firstChild;)e.removeChild(e.firstChild);for(;t.firstChild;)e.appendChild(t.firstChild)}},"undefined"!==typeof MSApp&&MSApp.execUnsafeLocalFunction?function(e,t,r,n){MSApp.execUnsafeLocalFunction((function(){return ve(e,t)}))}:ve);function ye(e,t){if(t){var r=e.firstChild;if(r&&r===e.lastChild&&3===r.nodeType)return void(r.nodeValue=t)}e.textContent=t}var be={animationIterationCount:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},we=["Webkit","ms","Moz","O"];function ke(e,t,r){return null==t||"boolean"===typeof t||""===t?"":r||"number"!==typeof t||0===t||be.hasOwnProperty(e)&&be[e]?(""+t).trim():t+"px"}function Ee(e,t){for(var r in e=e.style,t)if(t.hasOwnProperty(r)){var n=0===r.indexOf("--"),o=ke(r,t[r],n);"float"===r&&(r="cssFloat"),n?e.setProperty(r,o):e[r]=o}}Object.keys(be).forEach((function(e){we.forEach((function(t){t=t+e.charAt(0).toUpperCase()+e.substring(1),be[t]=be[e]}))}));var xe=o({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function Se(e,t){if(t){if(xe[e]&&(null!=t.children||null!=t.dangerouslySetInnerHTML))throw Error(i(137,e));if(null!=t.dangerouslySetInnerHTML){if(null!=t.children)throw Error(i(60));if("object"!==typeof t.dangerouslySetInnerHTML||!("__html"in t.dangerouslySetInnerHTML))throw Error(i(61))}if(null!=t.style&&"object"!==typeof t.style)throw Error(i(62))}}function _e(e,t){if(-1===e.indexOf("-"))return"string"===typeof t.is;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}function Te(e){return(e=e.target||e.srcElement||window).correspondingUseElement&&(e=e.correspondingUseElement),3===e.nodeType?e.parentNode:e}var Ce=null,Oe=null,Pe=null;function Re(e){if(e=eo(e)){if("function"!==typeof Ce)throw Error(i(280));var t=e.stateNode;t&&(t=ro(t),Ce(e.stateNode,e.type,t))}}function Ne(e){Oe?Pe?Pe.push(e):Pe=[e]:Oe=e}function Le(){if(Oe){var e=Oe,t=Pe;if(Pe=Oe=null,Re(e),t)for(e=0;e<t.length;e++)Re(t[e])}}function Ae(e,t){return e(t)}function Ie(e,t,r,n,o){return e(t,r,n,o)}function je(){}var Me=Ae,De=!1,qe=!1;function ze(){null===Oe&&null===Pe||(je(),Le())}function Ue(e,t){var r=e.stateNode;if(null===r)return null;var n=ro(r);if(null===n)return null;r=n[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(n=!n.disabled)||(n=!("button"===(e=e.type)||"input"===e||"select"===e||"textarea"===e)),e=!n;break e;default:e=!1}if(e)return null;if(r&&"function"!==typeof r)throw Error(i(231,t,typeof r));return r}var Fe=!1;if(f)try{var Be={};Object.defineProperty(Be,"passive",{get:function(){Fe=!0}}),window.addEventListener("test",Be,Be),window.removeEventListener("test",Be,Be)}catch(ve){Fe=!1}function Ve(e,t,r,n,o,a,i,l,u){var c=Array.prototype.slice.call(arguments,3);try{t.apply(r,c)}catch(e){this.onError(e)}}var He=!1,We=null,$e=!1,Ge=null,Qe={onError:function(e){He=!0,We=e}};function Ye(e,t,r,n,o,a,i,l,u){He=!1,We=null,Ve.apply(Qe,arguments)}function Ke(e){var t=e,r=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do{0!==(1026&(t=e).flags)&&(r=t.return),e=t.return}while(e)}return 3===t.tag?r:null}function Xe(e){if(13===e.tag){var t=e.memoizedState;if(null===t&&(null!==(e=e.alternate)&&(t=e.memoizedState)),null!==t)return t.dehydrated}return null}function Je(e){if(Ke(e)!==e)throw Error(i(188))}function Ze(e){if(!(e=function(e){var t=e.alternate;if(!t){if(null===(t=Ke(e)))throw Error(i(188));return t!==e?null:e}for(var r=e,n=t;;){var o=r.return;if(null===o)break;var a=o.alternate;if(null===a){if(null!==(n=o.return)){r=n;continue}break}if(o.child===a.child){for(a=o.child;a;){if(a===r)return Je(o),e;if(a===n)return Je(o),t;a=a.sibling}throw Error(i(188))}if(r.return!==n.return)r=o,n=a;else{for(var l=!1,u=o.child;u;){if(u===r){l=!0,r=o,n=a;break}if(u===n){l=!0,n=o,r=a;break}u=u.sibling}if(!l){for(u=a.child;u;){if(u===r){l=!0,r=a,n=o;break}if(u===n){l=!0,n=a,r=o;break}u=u.sibling}if(!l)throw Error(i(189))}}if(r.alternate!==n)throw Error(i(190))}if(3!==r.tag)throw Error(i(188));return r.stateNode.current===r?e:t}(e)))return null;for(var t=e;;){if(5===t.tag||6===t.tag)return t;if(t.child)t.child.return=t,t=t.child;else{if(t===e)break;for(;!t.sibling;){if(!t.return||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}}return null}function et(e,t){for(var r=e.alternate;null!==t;){if(t===e||t===r)return!0;t=t.return}return!1}var tt,rt,nt,ot,at=!1,it=[],lt=null,ut=null,ct=null,st=new Map,ft=new Map,dt=[],pt="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function ht(e,t,r,n,o){return{blockedOn:e,domEventName:t,eventSystemFlags:16|r,nativeEvent:o,targetContainers:[n]}}function gt(e,t){switch(e){case"focusin":case"focusout":lt=null;break;case"dragenter":case"dragleave":ut=null;break;case"mouseover":case"mouseout":ct=null;break;case"pointerover":case"pointerout":st.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":ft.delete(t.pointerId)}}function vt(e,t,r,n,o,a){return null===e||e.nativeEvent!==a?(e=ht(t,r,n,o,a),null!==t&&(null!==(t=eo(t))&&rt(t)),e):(e.eventSystemFlags|=n,t=e.targetContainers,null!==o&&-1===t.indexOf(o)&&t.push(o),e)}function mt(e){var t=Zn(e.target);if(null!==t){var r=Ke(t);if(null!==r)if(13===(t=r.tag)){if(null!==(t=Xe(r)))return e.blockedOn=t,void ot(e.lanePriority,(function(){a.unstable_runWithPriority(e.priority,(function(){nt(r)}))}))}else if(3===t&&r.stateNode.hydrate)return void(e.blockedOn=3===r.tag?r.stateNode.containerInfo:null)}e.blockedOn=null}function yt(e){if(null!==e.blockedOn)return!1;for(var t=e.targetContainers;0<t.length;){var r=Zt(e.domEventName,e.eventSystemFlags,t[0],e.nativeEvent);if(null!==r)return null!==(t=eo(r))&&rt(t),e.blockedOn=r,!1;t.shift()}return!0}function bt(e,t,r){yt(e)&&r.delete(t)}function wt(){for(at=!1;0<it.length;){var e=it[0];if(null!==e.blockedOn){null!==(e=eo(e.blockedOn))&&tt(e);break}for(var t=e.targetContainers;0<t.length;){var r=Zt(e.domEventName,e.eventSystemFlags,t[0],e.nativeEvent);if(null!==r){e.blockedOn=r;break}t.shift()}null===e.blockedOn&&it.shift()}null!==lt&&yt(lt)&&(lt=null),null!==ut&&yt(ut)&&(ut=null),null!==ct&&yt(ct)&&(ct=null),st.forEach(bt),ft.forEach(bt)}function kt(e,t){e.blockedOn===t&&(e.blockedOn=null,at||(at=!0,a.unstable_scheduleCallback(a.unstable_NormalPriority,wt)))}function Et(e){function t(t){return kt(t,e)}if(0<it.length){kt(it[0],e);for(var r=1;r<it.length;r++){var n=it[r];n.blockedOn===e&&(n.blockedOn=null)}}for(null!==lt&&kt(lt,e),null!==ut&&kt(ut,e),null!==ct&&kt(ct,e),st.forEach(t),ft.forEach(t),r=0;r<dt.length;r++)(n=dt[r]).blockedOn===e&&(n.blockedOn=null);for(;0<dt.length&&null===(r=dt[0]).blockedOn;)mt(r),null===r.blockedOn&&dt.shift()}function xt(e,t){var r={};return r[e.toLowerCase()]=t.toLowerCase(),r["Webkit"+e]="webkit"+t,r["Moz"+e]="moz"+t,r}var St={animationend:xt("Animation","AnimationEnd"),animationiteration:xt("Animation","AnimationIteration"),animationstart:xt("Animation","AnimationStart"),transitionend:xt("Transition","TransitionEnd")},_t={},Tt={};function Ct(e){if(_t[e])return _t[e];if(!St[e])return e;var t,r=St[e];for(t in r)if(r.hasOwnProperty(t)&&t in Tt)return _t[e]=r[t];return e}f&&(Tt=document.createElement("div").style,"AnimationEvent"in window||(delete St.animationend.animation,delete St.animationiteration.animation,delete St.animationstart.animation),"TransitionEvent"in window||delete St.transitionend.transition);var Ot=Ct("animationend"),Pt=Ct("animationiteration"),Rt=Ct("animationstart"),Nt=Ct("transitionend"),Lt=new Map,At=new Map,It=["abort","abort",Ot,"animationEnd",Pt,"animationIteration",Rt,"animationStart","canplay","canPlay","canplaythrough","canPlayThrough","durationchange","durationChange","emptied","emptied","encrypted","encrypted","ended","ended","error","error","gotpointercapture","gotPointerCapture","load","load","loadeddata","loadedData","loadedmetadata","loadedMetadata","loadstart","loadStart","lostpointercapture","lostPointerCapture","playing","playing","progress","progress","seeking","seeking","stalled","stalled","suspend","suspend","timeupdate","timeUpdate",Nt,"transitionEnd","waiting","waiting"];function jt(e,t){for(var r=0;r<e.length;r+=2){var n=e[r],o=e[r+1];o="on"+(o[0].toUpperCase()+o.slice(1)),At.set(n,t),Lt.set(n,o),c(o,[n])}}(0,a.unstable_now)();var Mt=8;function Dt(e){if(0!==(1&e))return Mt=15,1;if(0!==(2&e))return Mt=14,2;if(0!==(4&e))return Mt=13,4;var t=24&e;return 0!==t?(Mt=12,t):0!==(32&e)?(Mt=11,32):0!==(t=192&e)?(Mt=10,t):0!==(256&e)?(Mt=9,256):0!==(t=3584&e)?(Mt=8,t):0!==(4096&e)?(Mt=7,4096):0!==(t=4186112&e)?(Mt=6,t):0!==(t=62914560&e)?(Mt=5,t):67108864&e?(Mt=4,67108864):0!==(134217728&e)?(Mt=3,134217728):0!==(t=805306368&e)?(Mt=2,t):0!==(1073741824&e)?(Mt=1,1073741824):(Mt=8,e)}function qt(e,t){var r=e.pendingLanes;if(0===r)return Mt=0;var n=0,o=0,a=e.expiredLanes,i=e.suspendedLanes,l=e.pingedLanes;if(0!==a)n=a,o=Mt=15;else if(0!==(a=134217727&r)){var u=a&~i;0!==u?(n=Dt(u),o=Mt):0!==(l&=a)&&(n=Dt(l),o=Mt)}else 0!==(a=r&~i)?(n=Dt(a),o=Mt):0!==l&&(n=Dt(l),o=Mt);if(0===n)return 0;if(n=r&((0>(n=31-Ht(n))?0:1<<n)<<1)-1,0!==t&&t!==n&&0===(t&i)){if(Dt(t),o<=Mt)return t;Mt=o}if(0!==(t=e.entangledLanes))for(e=e.entanglements,t&=n;0<t;)o=1<<(r=31-Ht(t)),n|=e[r],t&=~o;return n}function zt(e){return 0!==(e=-1073741825&e.pendingLanes)?e:1073741824&e?1073741824:0}function Ut(e,t){switch(e){case 15:return 1;case 14:return 2;case 12:return 0===(e=Ft(24&~t))?Ut(10,t):e;case 10:return 0===(e=Ft(192&~t))?Ut(8,t):e;case 8:return 0===(e=Ft(3584&~t))&&(0===(e=Ft(4186112&~t))&&(e=512)),e;case 2:return 0===(t=Ft(805306368&~t))&&(t=268435456),t}throw Error(i(358,e))}function Ft(e){return e&-e}function Bt(e){for(var t=[],r=0;31>r;r++)t.push(e);return t}function Vt(e,t,r){e.pendingLanes|=t;var n=t-1;e.suspendedLanes&=n,e.pingedLanes&=n,(e=e.eventTimes)[t=31-Ht(t)]=r}var Ht=Math.clz32?Math.clz32:function(e){return 0===e?32:31-(Wt(e)/$t|0)|0},Wt=Math.log,$t=Math.LN2;var Gt=a.unstable_UserBlockingPriority,Qt=a.unstable_runWithPriority,Yt=!0;function Kt(e,t,r,n){De||je();var o=Jt,a=De;De=!0;try{Ie(o,e,t,r,n)}finally{(De=a)||ze()}}function Xt(e,t,r,n){Qt(Gt,Jt.bind(null,e,t,r,n))}function Jt(e,t,r,n){var o;if(Yt)if((o=0===(4&t))&&0<it.length&&-1<pt.indexOf(e))e=ht(null,e,t,r,n),it.push(e);else{var a=Zt(e,t,r,n);if(null===a)o&&gt(e,n);else{if(o){if(-1<pt.indexOf(e))return e=ht(a,e,t,r,n),void it.push(e);if(function(e,t,r,n,o){switch(t){case"focusin":return lt=vt(lt,e,t,r,n,o),!0;case"dragenter":return ut=vt(ut,e,t,r,n,o),!0;case"mouseover":return ct=vt(ct,e,t,r,n,o),!0;case"pointerover":var a=o.pointerId;return st.set(a,vt(st.get(a)||null,e,t,r,n,o)),!0;case"gotpointercapture":return a=o.pointerId,ft.set(a,vt(ft.get(a)||null,e,t,r,n,o)),!0}return!1}(a,e,t,r,n))return;gt(e,n)}Ln(e,t,n,null,r)}}}function Zt(e,t,r,n){var o=Te(n);if(null!==(o=Zn(o))){var a=Ke(o);if(null===a)o=null;else{var i=a.tag;if(13===i){if(null!==(o=Xe(a)))return o;o=null}else if(3===i){if(a.stateNode.hydrate)return 3===a.tag?a.stateNode.containerInfo:null;o=null}else a!==o&&(o=null)}}return Ln(e,t,n,o,r),null}var er=null,tr=null,rr=null;function nr(){if(rr)return rr;var e,t,r=tr,n=r.length,o="value"in er?er.value:er.textContent,a=o.length;for(e=0;e<n&&r[e]===o[e];e++);var i=n-e;for(t=1;t<=i&&r[n-t]===o[a-t];t++);return rr=o.slice(e,1<t?1-t:void 0)}function or(e){var t=e.keyCode;return"charCode"in e?0===(e=e.charCode)&&13===t&&(e=13):e=t,10===e&&(e=13),32<=e||13===e?e:0}function ar(){return!0}function ir(){return!1}function lr(e){function t(t,r,n,o,a){for(var i in this._reactName=t,this._targetInst=n,this.type=r,this.nativeEvent=o,this.target=a,this.currentTarget=null,e)e.hasOwnProperty(i)&&(t=e[i],this[i]=t?t(o):o[i]);return this.isDefaultPrevented=(null!=o.defaultPrevented?o.defaultPrevented:!1===o.returnValue)?ar:ir,this.isPropagationStopped=ir,this}return o(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var e=this.nativeEvent;e&&(e.preventDefault?e.preventDefault():"unknown"!==typeof e.returnValue&&(e.returnValue=!1),this.isDefaultPrevented=ar)},stopPropagation:function(){var e=this.nativeEvent;e&&(e.stopPropagation?e.stopPropagation():"unknown"!==typeof e.cancelBubble&&(e.cancelBubble=!0),this.isPropagationStopped=ar)},persist:function(){},isPersistent:ar}),t}var ur,cr,sr,fr={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},dr=lr(fr),pr=o({},fr,{view:0,detail:0}),hr=lr(pr),gr=o({},pr,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Tr,button:0,buttons:0,relatedTarget:function(e){return void 0===e.relatedTarget?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==sr&&(sr&&"mousemove"===e.type?(ur=e.screenX-sr.screenX,cr=e.screenY-sr.screenY):cr=ur=0,sr=e),ur)},movementY:function(e){return"movementY"in e?e.movementY:cr}}),vr=lr(gr),mr=lr(o({},gr,{dataTransfer:0})),yr=lr(o({},pr,{relatedTarget:0})),br=lr(o({},fr,{animationName:0,elapsedTime:0,pseudoElement:0})),wr=lr(o({},fr,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}})),kr=lr(o({},fr,{data:0})),Er={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},xr={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Sr={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function _r(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):!!(e=Sr[e])&&!!t[e]}function Tr(){return _r}var Cr=lr(o({},pr,{key:function(e){if(e.key){var t=Er[e.key]||e.key;if("Unidentified"!==t)return t}return"keypress"===e.type?13===(e=or(e))?"Enter":String.fromCharCode(e):"keydown"===e.type||"keyup"===e.type?xr[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Tr,charCode:function(e){return"keypress"===e.type?or(e):0},keyCode:function(e){return"keydown"===e.type||"keyup"===e.type?e.keyCode:0},which:function(e){return"keypress"===e.type?or(e):"keydown"===e.type||"keyup"===e.type?e.keyCode:0}})),Or=lr(o({},gr,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0})),Pr=lr(o({},pr,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Tr})),Rr=lr(o({},fr,{propertyName:0,elapsedTime:0,pseudoElement:0})),Nr=lr(o({},gr,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0})),Lr=[9,13,27,32],Ar=f&&"CompositionEvent"in window,Ir=null;f&&"documentMode"in document&&(Ir=document.documentMode);var jr=f&&"TextEvent"in window&&!Ir,Mr=f&&(!Ar||Ir&&8<Ir&&11>=Ir),Dr=String.fromCharCode(32),qr=!1;function zr(e,t){switch(e){case"keyup":return-1!==Lr.indexOf(t.keyCode);case"keydown":return 229!==t.keyCode;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Ur(e){return"object"===typeof(e=e.detail)&&"data"in e?e.data:null}var Fr=!1;var Br={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Vr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return"input"===t?!!Br[e.type]:"textarea"===t}function Hr(e,t,r,n){Ne(n),0<(t=In(t,"onChange")).length&&(r=new dr("onChange","change",null,r,n),e.push({event:r,listeners:t}))}var Wr=null,$r=null;function Gr(e){Tn(e,0)}function Qr(e){if(X(to(e)))return e}function Yr(e,t){if("change"===e)return t}var Kr=!1;if(f){var Xr;if(f){var Jr="oninput"in document;if(!Jr){var Zr=document.createElement("div");Zr.setAttribute("oninput","return;"),Jr="function"===typeof Zr.oninput}Xr=Jr}else Xr=!1;Kr=Xr&&(!document.documentMode||9<document.documentMode)}function en(){Wr&&(Wr.detachEvent("onpropertychange",tn),$r=Wr=null)}function tn(e){if("value"===e.propertyName&&Qr($r)){var t=[];if(Hr(t,$r,e,Te(e)),e=Gr,De)e(t);else{De=!0;try{Ae(e,t)}finally{De=!1,ze()}}}}function rn(e,t,r){"focusin"===e?(en(),$r=r,(Wr=t).attachEvent("onpropertychange",tn)):"focusout"===e&&en()}function nn(e){if("selectionchange"===e||"keyup"===e||"keydown"===e)return Qr($r)}function on(e,t){if("click"===e)return Qr(t)}function an(e,t){if("input"===e||"change"===e)return Qr(t)}var ln="function"===typeof Object.is?Object.is:function(e,t){return e===t&&(0!==e||1/e===1/t)||e!==e&&t!==t},un=Object.prototype.hasOwnProperty;function cn(e,t){if(ln(e,t))return!0;if("object"!==typeof e||null===e||"object"!==typeof t||null===t)return!1;var r=Object.keys(e),n=Object.keys(t);if(r.length!==n.length)return!1;for(n=0;n<r.length;n++)if(!un.call(t,r[n])||!ln(e[r[n]],t[r[n]]))return!1;return!0}function sn(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function fn(e,t){var r,n=sn(e);for(e=0;n;){if(3===n.nodeType){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=sn(n)}}function dn(e,t){return!(!e||!t)&&(e===t||(!e||3!==e.nodeType)&&(t&&3===t.nodeType?dn(e,t.parentNode):"contains"in e?e.contains(t):!!e.compareDocumentPosition&&!!(16&e.compareDocumentPosition(t))))}function pn(){for(var e=window,t=J();t instanceof e.HTMLIFrameElement;){try{var r="string"===typeof t.contentWindow.location.href}catch(e){r=!1}if(!r)break;t=J((e=t.contentWindow).document)}return t}function hn(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&("input"===t&&("text"===e.type||"search"===e.type||"tel"===e.type||"url"===e.type||"password"===e.type)||"textarea"===t||"true"===e.contentEditable)}var gn=f&&"documentMode"in document&&11>=document.documentMode,vn=null,mn=null,yn=null,bn=!1;function wn(e,t,r){var n=r.window===r?r.document:9===r.nodeType?r:r.ownerDocument;bn||null==vn||vn!==J(n)||("selectionStart"in(n=vn)&&hn(n)?n={start:n.selectionStart,end:n.selectionEnd}:n={anchorNode:(n=(n.ownerDocument&&n.ownerDocument.defaultView||window).getSelection()).anchorNode,anchorOffset:n.anchorOffset,focusNode:n.focusNode,focusOffset:n.focusOffset},yn&&cn(yn,n)||(yn=n,0<(n=In(mn,"onSelect")).length&&(t=new dr("onSelect","select",null,t,r),e.push({event:t,listeners:n}),t.target=vn)))}jt("cancel cancel click click close close contextmenu contextMenu copy copy cut cut auxclick auxClick dblclick doubleClick dragend dragEnd dragstart dragStart drop drop focusin focus focusout blur input input invalid invalid keydown keyDown keypress keyPress keyup keyUp mousedown mouseDown mouseup mouseUp paste paste pause pause play play pointercancel pointerCancel pointerdown pointerDown pointerup pointerUp ratechange rateChange reset reset seeked seeked submit submit touchcancel touchCancel touchend touchEnd touchstart touchStart volumechange volumeChange".split(" "),0),jt("drag drag dragenter dragEnter dragexit dragExit dragleave dragLeave dragover dragOver mousemove mouseMove mouseout mouseOut mouseover mouseOver pointermove pointerMove pointerout pointerOut pointerover pointerOver scroll scroll toggle toggle touchmove touchMove wheel wheel".split(" "),1),jt(It,2);for(var kn="change selectionchange textInput compositionstart compositionend compositionupdate".split(" "),En=0;En<kn.length;En++)At.set(kn[En],0);s("onMouseEnter",["mouseout","mouseover"]),s("onMouseLeave",["mouseout","mouseover"]),s("onPointerEnter",["pointerout","pointerover"]),s("onPointerLeave",["pointerout","pointerover"]),c("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),c("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),c("onBeforeInput",["compositionend","keypress","textInput","paste"]),c("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),c("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),c("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var xn="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Sn=new Set("cancel close invalid load scroll toggle".split(" ").concat(xn));function _n(e,t,r){var n=e.type||"unknown-event";e.currentTarget=r,function(e,t,r,n,o,a,l,u,c){if(Ye.apply(this,arguments),He){if(!He)throw Error(i(198));var s=We;He=!1,We=null,$e||($e=!0,Ge=s)}}(n,t,void 0,e),e.currentTarget=null}function Tn(e,t){t=0!==(4&t);for(var r=0;r<e.length;r++){var n=e[r],o=n.event;n=n.listeners;e:{var a=void 0;if(t)for(var i=n.length-1;0<=i;i--){var l=n[i],u=l.instance,c=l.currentTarget;if(l=l.listener,u!==a&&o.isPropagationStopped())break e;_n(o,l,c),a=u}else for(i=0;i<n.length;i++){if(u=(l=n[i]).instance,c=l.currentTarget,l=l.listener,u!==a&&o.isPropagationStopped())break e;_n(o,l,c),a=u}}}if($e)throw e=Ge,$e=!1,Ge=null,e}function Cn(e,t){var r=no(t),n=e+"__bubble";r.has(n)||(Nn(t,e,2,!1),r.add(n))}var On="_reactListening"+Math.random().toString(36).slice(2);function Pn(e){e[On]||(e[On]=!0,l.forEach((function(t){Sn.has(t)||Rn(t,!1,e,null),Rn(t,!0,e,null)})))}function Rn(e,t,r,n){var o=4<arguments.length&&void 0!==arguments[4]?arguments[4]:0,a=r;if("selectionchange"===e&&9!==r.nodeType&&(a=r.ownerDocument),null!==n&&!t&&Sn.has(e)){if("scroll"!==e)return;o|=2,a=n}var i=no(a),l=e+"__"+(t?"capture":"bubble");i.has(l)||(t&&(o|=4),Nn(a,e,o,t),i.add(l))}function Nn(e,t,r,n){var o=At.get(t);switch(void 0===o?2:o){case 0:o=Kt;break;case 1:o=Xt;break;default:o=Jt}r=o.bind(null,t,r,e),o=void 0,!Fe||"touchstart"!==t&&"touchmove"!==t&&"wheel"!==t||(o=!0),n?void 0!==o?e.addEventListener(t,r,{capture:!0,passive:o}):e.addEventListener(t,r,!0):void 0!==o?e.addEventListener(t,r,{passive:o}):e.addEventListener(t,r,!1)}function Ln(e,t,r,n,o){var a=n;if(0===(1&t)&&0===(2&t)&&null!==n)e:for(;;){if(null===n)return;var i=n.tag;if(3===i||4===i){var l=n.stateNode.containerInfo;if(l===o||8===l.nodeType&&l.parentNode===o)break;if(4===i)for(i=n.return;null!==i;){var u=i.tag;if((3===u||4===u)&&((u=i.stateNode.containerInfo)===o||8===u.nodeType&&u.parentNode===o))return;i=i.return}for(;null!==l;){if(null===(i=Zn(l)))return;if(5===(u=i.tag)||6===u){n=a=i;continue e}l=l.parentNode}}n=n.return}!function(e,t,r){if(qe)return e(t,r);qe=!0;try{Me(e,t,r)}finally{qe=!1,ze()}}((function(){var n=a,o=Te(r),i=[];e:{var l=Lt.get(e);if(void 0!==l){var u=dr,c=e;switch(e){case"keypress":if(0===or(r))break e;case"keydown":case"keyup":u=Cr;break;case"focusin":c="focus",u=yr;break;case"focusout":c="blur",u=yr;break;case"beforeblur":case"afterblur":u=yr;break;case"click":if(2===r.button)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":u=vr;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":u=mr;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":u=Pr;break;case Ot:case Pt:case Rt:u=br;break;case Nt:u=Rr;break;case"scroll":u=hr;break;case"wheel":u=Nr;break;case"copy":case"cut":case"paste":u=wr;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":u=Or}var s=0!==(4&t),f=!s&&"scroll"===e,d=s?null!==l?l+"Capture":null:l;s=[];for(var p,h=n;null!==h;){var g=(p=h).stateNode;if(5===p.tag&&null!==g&&(p=g,null!==d&&(null!=(g=Ue(h,d))&&s.push(An(h,g,p)))),f)break;h=h.return}0<s.length&&(l=new u(l,c,null,r,o),i.push({event:l,listeners:s}))}}if(0===(7&t)){if(u="mouseout"===e||"pointerout"===e,(!(l="mouseover"===e||"pointerover"===e)||0!==(16&t)||!(c=r.relatedTarget||r.fromElement)||!Zn(c)&&!c[Xn])&&(u||l)&&(l=o.window===o?o:(l=o.ownerDocument)?l.defaultView||l.parentWindow:window,u?(u=n,null!==(c=(c=r.relatedTarget||r.toElement)?Zn(c):null)&&(c!==(f=Ke(c))||5!==c.tag&&6!==c.tag)&&(c=null)):(u=null,c=n),u!==c)){if(s=vr,g="onMouseLeave",d="onMouseEnter",h="mouse","pointerout"!==e&&"pointerover"!==e||(s=Or,g="onPointerLeave",d="onPointerEnter",h="pointer"),f=null==u?l:to(u),p=null==c?l:to(c),(l=new s(g,h+"leave",u,r,o)).target=f,l.relatedTarget=p,g=null,Zn(o)===n&&((s=new s(d,h+"enter",c,r,o)).target=p,s.relatedTarget=f,g=s),f=g,u&&c)e:{for(d=c,h=0,p=s=u;p;p=jn(p))h++;for(p=0,g=d;g;g=jn(g))p++;for(;0<h-p;)s=jn(s),h--;for(;0<p-h;)d=jn(d),p--;for(;h--;){if(s===d||null!==d&&s===d.alternate)break e;s=jn(s),d=jn(d)}s=null}else s=null;null!==u&&Mn(i,l,u,s,!1),null!==c&&null!==f&&Mn(i,f,c,s,!0)}if("select"===(u=(l=n?to(n):window).nodeName&&l.nodeName.toLowerCase())||"input"===u&&"file"===l.type)var v=Yr;else if(Vr(l))if(Kr)v=an;else{v=nn;var m=rn}else(u=l.nodeName)&&"input"===u.toLowerCase()&&("checkbox"===l.type||"radio"===l.type)&&(v=on);switch(v&&(v=v(e,n))?Hr(i,v,r,o):(m&&m(e,l,n),"focusout"===e&&(m=l._wrapperState)&&m.controlled&&"number"===l.type&&oe(l,"number",l.value)),m=n?to(n):window,e){case"focusin":(Vr(m)||"true"===m.contentEditable)&&(vn=m,mn=n,yn=null);break;case"focusout":yn=mn=vn=null;break;case"mousedown":bn=!0;break;case"contextmenu":case"mouseup":case"dragend":bn=!1,wn(i,r,o);break;case"selectionchange":if(gn)break;case"keydown":case"keyup":wn(i,r,o)}var y;if(Ar)e:{switch(e){case"compositionstart":var b="onCompositionStart";break e;case"compositionend":b="onCompositionEnd";break e;case"compositionupdate":b="onCompositionUpdate";break e}b=void 0}else Fr?zr(e,r)&&(b="onCompositionEnd"):"keydown"===e&&229===r.keyCode&&(b="onCompositionStart");b&&(Mr&&"ko"!==r.locale&&(Fr||"onCompositionStart"!==b?"onCompositionEnd"===b&&Fr&&(y=nr()):(tr="value"in(er=o)?er.value:er.textContent,Fr=!0)),0<(m=In(n,b)).length&&(b=new kr(b,e,null,r,o),i.push({event:b,listeners:m}),y?b.data=y:null!==(y=Ur(r))&&(b.data=y))),(y=jr?function(e,t){switch(e){case"compositionend":return Ur(t);case"keypress":return 32!==t.which?null:(qr=!0,Dr);case"textInput":return(e=t.data)===Dr&&qr?null:e;default:return null}}(e,r):function(e,t){if(Fr)return"compositionend"===e||!Ar&&zr(e,t)?(e=nr(),rr=tr=er=null,Fr=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return Mr&&"ko"!==t.locale?null:t.data;default:return null}}(e,r))&&(0<(n=In(n,"onBeforeInput")).length&&(o=new kr("onBeforeInput","beforeinput",null,r,o),i.push({event:o,listeners:n}),o.data=y))}Tn(i,t)}))}function An(e,t,r){return{instance:e,listener:t,currentTarget:r}}function In(e,t){for(var r=t+"Capture",n=[];null!==e;){var o=e,a=o.stateNode;5===o.tag&&null!==a&&(o=a,null!=(a=Ue(e,r))&&n.unshift(An(e,a,o)),null!=(a=Ue(e,t))&&n.push(An(e,a,o))),e=e.return}return n}function jn(e){if(null===e)return null;do{e=e.return}while(e&&5!==e.tag);return e||null}function Mn(e,t,r,n,o){for(var a=t._reactName,i=[];null!==r&&r!==n;){var l=r,u=l.alternate,c=l.stateNode;if(null!==u&&u===n)break;5===l.tag&&null!==c&&(l=c,o?null!=(u=Ue(r,a))&&i.unshift(An(r,u,l)):o||null!=(u=Ue(r,a))&&i.push(An(r,u,l))),r=r.return}0!==i.length&&e.push({event:t,listeners:i})}function Dn(){}var qn=null,zn=null;function Un(e,t){switch(e){case"button":case"input":case"select":case"textarea":return!!t.autoFocus}return!1}function Fn(e,t){return"textarea"===e||"option"===e||"noscript"===e||"string"===typeof t.children||"number"===typeof t.children||"object"===typeof t.dangerouslySetInnerHTML&&null!==t.dangerouslySetInnerHTML&&null!=t.dangerouslySetInnerHTML.__html}var Bn="function"===typeof setTimeout?setTimeout:void 0,Vn="function"===typeof clearTimeout?clearTimeout:void 0;function Hn(e){1===e.nodeType?e.textContent="":9===e.nodeType&&(null!=(e=e.body)&&(e.textContent=""))}function Wn(e){for(;null!=e;e=e.nextSibling){var t=e.nodeType;if(1===t||3===t)break}return e}function $n(e){e=e.previousSibling;for(var t=0;e;){if(8===e.nodeType){var r=e.data;if("$"===r||"$!"===r||"$?"===r){if(0===t)return e;t--}else"/$"===r&&t++}e=e.previousSibling}return null}var Gn=0;var Qn=Math.random().toString(36).slice(2),Yn="__reactFiber$"+Qn,Kn="__reactProps$"+Qn,Xn="__reactContainer$"+Qn,Jn="__reactEvents$"+Qn;function Zn(e){var t=e[Yn];if(t)return t;for(var r=e.parentNode;r;){if(t=r[Xn]||r[Yn]){if(r=t.alternate,null!==t.child||null!==r&&null!==r.child)for(e=$n(e);null!==e;){if(r=e[Yn])return r;e=$n(e)}return t}r=(e=r).parentNode}return null}function eo(e){return!(e=e[Yn]||e[Xn])||5!==e.tag&&6!==e.tag&&13!==e.tag&&3!==e.tag?null:e}function to(e){if(5===e.tag||6===e.tag)return e.stateNode;throw Error(i(33))}function ro(e){return e[Kn]||null}function no(e){var t=e[Jn];return void 0===t&&(t=e[Jn]=new Set),t}var oo=[],ao=-1;function io(e){return{current:e}}function lo(e){0>ao||(e.current=oo[ao],oo[ao]=null,ao--)}function uo(e,t){ao++,oo[ao]=e.current,e.current=t}var co={},so=io(co),fo=io(!1),po=co;function ho(e,t){var r=e.type.contextTypes;if(!r)return co;var n=e.stateNode;if(n&&n.__reactInternalMemoizedUnmaskedChildContext===t)return n.__reactInternalMemoizedMaskedChildContext;var o,a={};for(o in r)a[o]=t[o];return n&&((e=e.stateNode).__reactInternalMemoizedUnmaskedChildContext=t,e.__reactInternalMemoizedMaskedChildContext=a),a}function go(e){return null!==(e=e.childContextTypes)&&void 0!==e}function vo(){lo(fo),lo(so)}function mo(e,t,r){if(so.current!==co)throw Error(i(168));uo(so,t),uo(fo,r)}function yo(e,t,r){var n=e.stateNode;if(e=t.childContextTypes,"function"!==typeof n.getChildContext)return r;for(var a in n=n.getChildContext())if(!(a in e))throw Error(i(108,G(t)||"Unknown",a));return o({},r,n)}function bo(e){return e=(e=e.stateNode)&&e.__reactInternalMemoizedMergedChildContext||co,po=so.current,uo(so,e),uo(fo,fo.current),!0}function wo(e,t,r){var n=e.stateNode;if(!n)throw Error(i(169));r?(e=yo(e,t,po),n.__reactInternalMemoizedMergedChildContext=e,lo(fo),lo(so),uo(so,e)):lo(fo),uo(fo,r)}var ko=null,Eo=null,xo=a.unstable_runWithPriority,So=a.unstable_scheduleCallback,_o=a.unstable_cancelCallback,To=a.unstable_shouldYield,Co=a.unstable_requestPaint,Oo=a.unstable_now,Po=a.unstable_getCurrentPriorityLevel,Ro=a.unstable_ImmediatePriority,No=a.unstable_UserBlockingPriority,Lo=a.unstable_NormalPriority,Ao=a.unstable_LowPriority,Io=a.unstable_IdlePriority,jo={},Mo=void 0!==Co?Co:function(){},Do=null,qo=null,zo=!1,Uo=Oo(),Fo=1e4>Uo?Oo:function(){return Oo()-Uo};function Bo(){switch(Po()){case Ro:return 99;case No:return 98;case Lo:return 97;case Ao:return 96;case Io:return 95;default:throw Error(i(332))}}function Vo(e){switch(e){case 99:return Ro;case 98:return No;case 97:return Lo;case 96:return Ao;case 95:return Io;default:throw Error(i(332))}}function Ho(e,t){return e=Vo(e),xo(e,t)}function Wo(e,t,r){return e=Vo(e),So(e,t,r)}function $o(){if(null!==qo){var e=qo;qo=null,_o(e)}Go()}function Go(){if(!zo&&null!==Do){zo=!0;var e=0;try{var t=Do;Ho(99,(function(){for(;e<t.length;e++){var r=t[e];do{r=r(!0)}while(null!==r)}})),Do=null}catch(t){throw null!==Do&&(Do=Do.slice(e+1)),So(Ro,$o),t}finally{zo=!1}}}var Qo=k.ReactCurrentBatchConfig;function Yo(e,t){if(e&&e.defaultProps){for(var r in t=o({},t),e=e.defaultProps)void 0===t[r]&&(t[r]=e[r]);return t}return t}var Ko=io(null),Xo=null,Jo=null,Zo=null;function ea(){Zo=Jo=Xo=null}function ta(e){var t=Ko.current;lo(Ko),e.type._context._currentValue=t}function ra(e,t){for(;null!==e;){var r=e.alternate;if((e.childLanes&t)===t){if(null===r||(r.childLanes&t)===t)break;r.childLanes|=t}else e.childLanes|=t,null!==r&&(r.childLanes|=t);e=e.return}}function na(e,t){Xo=e,Zo=Jo=null,null!==(e=e.dependencies)&&null!==e.firstContext&&(0!==(e.lanes&t)&&(Ii=!0),e.firstContext=null)}function oa(e,t){if(Zo!==e&&!1!==t&&0!==t)if("number"===typeof t&&1073741823!==t||(Zo=e,t=1073741823),t={context:e,observedBits:t,next:null},null===Jo){if(null===Xo)throw Error(i(308));Jo=t,Xo.dependencies={lanes:0,firstContext:t,responders:null}}else Jo=Jo.next=t;return e._currentValue}var aa=!1;function ia(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null},effects:null}}function la(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,effects:e.effects})}function ua(e,t){return{eventTime:e,lane:t,tag:0,payload:null,callback:null,next:null}}function ca(e,t){if(null!==(e=e.updateQueue)){var r=(e=e.shared).pending;null===r?t.next=t:(t.next=r.next,r.next=t),e.pending=t}}function sa(e,t){var r=e.updateQueue,n=e.alternate;if(null!==n&&r===(n=n.updateQueue)){var o=null,a=null;if(null!==(r=r.firstBaseUpdate)){do{var i={eventTime:r.eventTime,lane:r.lane,tag:r.tag,payload:r.payload,callback:r.callback,next:null};null===a?o=a=i:a=a.next=i,r=r.next}while(null!==r);null===a?o=a=t:a=a.next=t}else o=a=t;return r={baseState:n.baseState,firstBaseUpdate:o,lastBaseUpdate:a,shared:n.shared,effects:n.effects},void(e.updateQueue=r)}null===(e=r.lastBaseUpdate)?r.firstBaseUpdate=t:e.next=t,r.lastBaseUpdate=t}function fa(e,t,r,n){var a=e.updateQueue;aa=!1;var i=a.firstBaseUpdate,l=a.lastBaseUpdate,u=a.shared.pending;if(null!==u){a.shared.pending=null;var c=u,s=c.next;c.next=null,null===l?i=s:l.next=s,l=c;var f=e.alternate;if(null!==f){var d=(f=f.updateQueue).lastBaseUpdate;d!==l&&(null===d?f.firstBaseUpdate=s:d.next=s,f.lastBaseUpdate=c)}}if(null!==i){for(d=a.baseState,l=0,f=s=c=null;;){u=i.lane;var p=i.eventTime;if((n&u)===u){null!==f&&(f=f.next={eventTime:p,lane:0,tag:i.tag,payload:i.payload,callback:i.callback,next:null});e:{var h=e,g=i;switch(u=t,p=r,g.tag){case 1:if("function"===typeof(h=g.payload)){d=h.call(p,d,u);break e}d=h;break e;case 3:h.flags=-4097&h.flags|64;case 0:if(null===(u="function"===typeof(h=g.payload)?h.call(p,d,u):h)||void 0===u)break e;d=o({},d,u);break e;case 2:aa=!0}}null!==i.callback&&(e.flags|=32,null===(u=a.effects)?a.effects=[i]:u.push(i))}else p={eventTime:p,lane:u,tag:i.tag,payload:i.payload,callback:i.callback,next:null},null===f?(s=f=p,c=d):f=f.next=p,l|=u;if(null===(i=i.next)){if(null===(u=a.shared.pending))break;i=u.next,u.next=null,a.lastBaseUpdate=u,a.shared.pending=null}}null===f&&(c=d),a.baseState=c,a.firstBaseUpdate=s,a.lastBaseUpdate=f,ql|=l,e.lanes=l,e.memoizedState=d}}function da(e,t,r){if(e=t.effects,t.effects=null,null!==e)for(t=0;t<e.length;t++){var n=e[t],o=n.callback;if(null!==o){if(n.callback=null,n=r,"function"!==typeof o)throw Error(i(191,o));o.call(n)}}}var pa=(new n.Component).refs;function ha(e,t,r,n){r=null===(r=r(n,t=e.memoizedState))||void 0===r?t:o({},t,r),e.memoizedState=r,0===e.lanes&&(e.updateQueue.baseState=r)}var ga={isMounted:function(e){return!!(e=e._reactInternals)&&Ke(e)===e},enqueueSetState:function(e,t,r){e=e._reactInternals;var n=cu(),o=su(e),a=ua(n,o);a.payload=t,void 0!==r&&null!==r&&(a.callback=r),ca(e,a),fu(e,o,n)},enqueueReplaceState:function(e,t,r){e=e._reactInternals;var n=cu(),o=su(e),a=ua(n,o);a.tag=1,a.payload=t,void 0!==r&&null!==r&&(a.callback=r),ca(e,a),fu(e,o,n)},enqueueForceUpdate:function(e,t){e=e._reactInternals;var r=cu(),n=su(e),o=ua(r,n);o.tag=2,void 0!==t&&null!==t&&(o.callback=t),ca(e,o),fu(e,n,r)}};function va(e,t,r,n,o,a,i){return"function"===typeof(e=e.stateNode).shouldComponentUpdate?e.shouldComponentUpdate(n,a,i):!t.prototype||!t.prototype.isPureReactComponent||(!cn(r,n)||!cn(o,a))}function ma(e,t,r){var n=!1,o=co,a=t.contextType;return"object"===typeof a&&null!==a?a=oa(a):(o=go(t)?po:so.current,a=(n=null!==(n=t.contextTypes)&&void 0!==n)?ho(e,o):co),t=new t(r,a),e.memoizedState=null!==t.state&&void 0!==t.state?t.state:null,t.updater=ga,e.stateNode=t,t._reactInternals=e,n&&((e=e.stateNode).__reactInternalMemoizedUnmaskedChildContext=o,e.__reactInternalMemoizedMaskedChildContext=a),t}function ya(e,t,r,n){e=t.state,"function"===typeof t.componentWillReceiveProps&&t.componentWillReceiveProps(r,n),"function"===typeof t.UNSAFE_componentWillReceiveProps&&t.UNSAFE_componentWillReceiveProps(r,n),t.state!==e&&ga.enqueueReplaceState(t,t.state,null)}function ba(e,t,r,n){var o=e.stateNode;o.props=r,o.state=e.memoizedState,o.refs=pa,ia(e);var a=t.contextType;"object"===typeof a&&null!==a?o.context=oa(a):(a=go(t)?po:so.current,o.context=ho(e,a)),fa(e,r,o,n),o.state=e.memoizedState,"function"===typeof(a=t.getDerivedStateFromProps)&&(ha(e,t,a,r),o.state=e.memoizedState),"function"===typeof t.getDerivedStateFromProps||"function"===typeof o.getSnapshotBeforeUpdate||"function"!==typeof o.UNSAFE_componentWillMount&&"function"!==typeof o.componentWillMount||(t=o.state,"function"===typeof o.componentWillMount&&o.componentWillMount(),"function"===typeof o.UNSAFE_componentWillMount&&o.UNSAFE_componentWillMount(),t!==o.state&&ga.enqueueReplaceState(o,o.state,null),fa(e,r,o,n),o.state=e.memoizedState),"function"===typeof o.componentDidMount&&(e.flags|=4)}var wa=Array.isArray;function ka(e,t,r){if(null!==(e=r.ref)&&"function"!==typeof e&&"object"!==typeof e){if(r._owner){if(r=r._owner){if(1!==r.tag)throw Error(i(309));var n=r.stateNode}if(!n)throw Error(i(147,e));var o=""+e;return null!==t&&null!==t.ref&&"function"===typeof t.ref&&t.ref._stringRef===o?t.ref:((t=function(e){var t=n.refs;t===pa&&(t=n.refs={}),null===e?delete t[o]:t[o]=e})._stringRef=o,t)}if("string"!==typeof e)throw Error(i(284));if(!r._owner)throw Error(i(290,e))}return e}function Ea(e,t){if("textarea"!==e.type)throw Error(i(31,"[object Object]"===Object.prototype.toString.call(t)?"object with keys {"+Object.keys(t).join(", ")+"}":t))}function xa(e){function t(t,r){if(e){var n=t.lastEffect;null!==n?(n.nextEffect=r,t.lastEffect=r):t.firstEffect=t.lastEffect=r,r.nextEffect=null,r.flags=8}}function r(r,n){if(!e)return null;for(;null!==n;)t(r,n),n=n.sibling;return null}function n(e,t){for(e=new Map;null!==t;)null!==t.key?e.set(t.key,t):e.set(t.index,t),t=t.sibling;return e}function o(e,t){return(e=Vu(e,t)).index=0,e.sibling=null,e}function a(t,r,n){return t.index=n,e?null!==(n=t.alternate)?(n=n.index)<r?(t.flags=2,r):n:(t.flags=2,r):r}function l(t){return e&&null===t.alternate&&(t.flags=2),t}function u(e,t,r,n){return null===t||6!==t.tag?((t=Gu(r,e.mode,n)).return=e,t):((t=o(t,r)).return=e,t)}function c(e,t,r,n){return null!==t&&t.elementType===r.type?((n=o(t,r.props)).ref=ka(e,t,r),n.return=e,n):((n=Hu(r.type,r.key,r.props,null,e.mode,n)).ref=ka(e,t,r),n.return=e,n)}function s(e,t,r,n){return null===t||4!==t.tag||t.stateNode.containerInfo!==r.containerInfo||t.stateNode.implementation!==r.implementation?((t=Qu(r,e.mode,n)).return=e,t):((t=o(t,r.children||[])).return=e,t)}function f(e,t,r,n,a){return null===t||7!==t.tag?((t=Wu(r,e.mode,n,a)).return=e,t):((t=o(t,r)).return=e,t)}function d(e,t,r){if("string"===typeof t||"number"===typeof t)return(t=Gu(""+t,e.mode,r)).return=e,t;if("object"===typeof t&&null!==t){switch(t.$$typeof){case E:return(r=Hu(t.type,t.key,t.props,null,e.mode,r)).ref=ka(e,null,t),r.return=e,r;case x:return(t=Qu(t,e.mode,r)).return=e,t}if(wa(t)||B(t))return(t=Wu(t,e.mode,r,null)).return=e,t;Ea(e,t)}return null}function p(e,t,r,n){var o=null!==t?t.key:null;if("string"===typeof r||"number"===typeof r)return null!==o?null:u(e,t,""+r,n);if("object"===typeof r&&null!==r){switch(r.$$typeof){case E:return r.key===o?r.type===S?f(e,t,r.props.children,n,o):c(e,t,r,n):null;case x:return r.key===o?s(e,t,r,n):null}if(wa(r)||B(r))return null!==o?null:f(e,t,r,n,null);Ea(e,r)}return null}function h(e,t,r,n,o){if("string"===typeof n||"number"===typeof n)return u(t,e=e.get(r)||null,""+n,o);if("object"===typeof n&&null!==n){switch(n.$$typeof){case E:return e=e.get(null===n.key?r:n.key)||null,n.type===S?f(t,e,n.props.children,o,n.key):c(t,e,n,o);case x:return s(t,e=e.get(null===n.key?r:n.key)||null,n,o)}if(wa(n)||B(n))return f(t,e=e.get(r)||null,n,o,null);Ea(t,n)}return null}function g(o,i,l,u){for(var c=null,s=null,f=i,g=i=0,v=null;null!==f&&g<l.length;g++){f.index>g?(v=f,f=null):v=f.sibling;var m=p(o,f,l[g],u);if(null===m){null===f&&(f=v);break}e&&f&&null===m.alternate&&t(o,f),i=a(m,i,g),null===s?c=m:s.sibling=m,s=m,f=v}if(g===l.length)return r(o,f),c;if(null===f){for(;g<l.length;g++)null!==(f=d(o,l[g],u))&&(i=a(f,i,g),null===s?c=f:s.sibling=f,s=f);return c}for(f=n(o,f);g<l.length;g++)null!==(v=h(f,o,g,l[g],u))&&(e&&null!==v.alternate&&f.delete(null===v.key?g:v.key),i=a(v,i,g),null===s?c=v:s.sibling=v,s=v);return e&&f.forEach((function(e){return t(o,e)})),c}function v(o,l,u,c){var s=B(u);if("function"!==typeof s)throw Error(i(150));if(null==(u=s.call(u)))throw Error(i(151));for(var f=s=null,g=l,v=l=0,m=null,y=u.next();null!==g&&!y.done;v++,y=u.next()){g.index>v?(m=g,g=null):m=g.sibling;var b=p(o,g,y.value,c);if(null===b){null===g&&(g=m);break}e&&g&&null===b.alternate&&t(o,g),l=a(b,l,v),null===f?s=b:f.sibling=b,f=b,g=m}if(y.done)return r(o,g),s;if(null===g){for(;!y.done;v++,y=u.next())null!==(y=d(o,y.value,c))&&(l=a(y,l,v),null===f?s=y:f.sibling=y,f=y);return s}for(g=n(o,g);!y.done;v++,y=u.next())null!==(y=h(g,o,v,y.value,c))&&(e&&null!==y.alternate&&g.delete(null===y.key?v:y.key),l=a(y,l,v),null===f?s=y:f.sibling=y,f=y);return e&&g.forEach((function(e){return t(o,e)})),s}return function(e,n,a,u){var c="object"===typeof a&&null!==a&&a.type===S&&null===a.key;c&&(a=a.props.children);var s="object"===typeof a&&null!==a;if(s)switch(a.$$typeof){case E:e:{for(s=a.key,c=n;null!==c;){if(c.key===s){switch(c.tag){case 7:if(a.type===S){r(e,c.sibling),(n=o(c,a.props.children)).return=e,e=n;break e}break;default:if(c.elementType===a.type){r(e,c.sibling),(n=o(c,a.props)).ref=ka(e,c,a),n.return=e,e=n;break e}}r(e,c);break}t(e,c),c=c.sibling}a.type===S?((n=Wu(a.props.children,e.mode,u,a.key)).return=e,e=n):((u=Hu(a.type,a.key,a.props,null,e.mode,u)).ref=ka(e,n,a),u.return=e,e=u)}return l(e);case x:e:{for(c=a.key;null!==n;){if(n.key===c){if(4===n.tag&&n.stateNode.containerInfo===a.containerInfo&&n.stateNode.implementation===a.implementation){r(e,n.sibling),(n=o(n,a.children||[])).return=e,e=n;break e}r(e,n);break}t(e,n),n=n.sibling}(n=Qu(a,e.mode,u)).return=e,e=n}return l(e)}if("string"===typeof a||"number"===typeof a)return a=""+a,null!==n&&6===n.tag?(r(e,n.sibling),(n=o(n,a)).return=e,e=n):(r(e,n),(n=Gu(a,e.mode,u)).return=e,e=n),l(e);if(wa(a))return g(e,n,a,u);if(B(a))return v(e,n,a,u);if(s&&Ea(e,a),"undefined"===typeof a&&!c)switch(e.tag){case 1:case 22:case 0:case 11:case 15:throw Error(i(152,G(e.type)||"Component"))}return r(e,n)}}var Sa=xa(!0),_a=xa(!1),Ta={},Ca=io(Ta),Oa=io(Ta),Pa=io(Ta);function Ra(e){if(e===Ta)throw Error(i(174));return e}function Na(e,t){switch(uo(Pa,t),uo(Oa,e),uo(Ca,Ta),e=t.nodeType){case 9:case 11:t=(t=t.documentElement)?t.namespaceURI:he(null,"");break;default:t=he(t=(e=8===e?t.parentNode:t).namespaceURI||null,e=e.tagName)}lo(Ca),uo(Ca,t)}function La(){lo(Ca),lo(Oa),lo(Pa)}function Aa(e){Ra(Pa.current);var t=Ra(Ca.current),r=he(t,e.type);t!==r&&(uo(Oa,e),uo(Ca,r))}function Ia(e){Oa.current===e&&(lo(Ca),lo(Oa))}var ja=io(0);function Ma(e){for(var t=e;null!==t;){if(13===t.tag){var r=t.memoizedState;if(null!==r&&(null===(r=r.dehydrated)||"$?"===r.data||"$!"===r.data))return t}else if(19===t.tag&&void 0!==t.memoizedProps.revealOrder){if(0!==(64&t.flags))return t}else if(null!==t.child){t.child.return=t,t=t.child;continue}if(t===e)break;for(;null===t.sibling;){if(null===t.return||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var Da=null,qa=null,za=!1;function Ua(e,t){var r=Fu(5,null,null,0);r.elementType="DELETED",r.type="DELETED",r.stateNode=t,r.return=e,r.flags=8,null!==e.lastEffect?(e.lastEffect.nextEffect=r,e.lastEffect=r):e.firstEffect=e.lastEffect=r}function Fa(e,t){switch(e.tag){case 5:var r=e.type;return null!==(t=1!==t.nodeType||r.toLowerCase()!==t.nodeName.toLowerCase()?null:t)&&(e.stateNode=t,!0);case 6:return null!==(t=""===e.pendingProps||3!==t.nodeType?null:t)&&(e.stateNode=t,!0);case 13:default:return!1}}function Ba(e){if(za){var t=qa;if(t){var r=t;if(!Fa(e,t)){if(!(t=Wn(r.nextSibling))||!Fa(e,t))return e.flags=-1025&e.flags|2,za=!1,void(Da=e);Ua(Da,r)}Da=e,qa=Wn(t.firstChild)}else e.flags=-1025&e.flags|2,za=!1,Da=e}}function Va(e){for(e=e.return;null!==e&&5!==e.tag&&3!==e.tag&&13!==e.tag;)e=e.return;Da=e}function Ha(e){if(e!==Da)return!1;if(!za)return Va(e),za=!0,!1;var t=e.type;if(5!==e.tag||"head"!==t&&"body"!==t&&!Fn(t,e.memoizedProps))for(t=qa;t;)Ua(e,t),t=Wn(t.nextSibling);if(Va(e),13===e.tag){if(!(e=null!==(e=e.memoizedState)?e.dehydrated:null))throw Error(i(317));e:{for(e=e.nextSibling,t=0;e;){if(8===e.nodeType){var r=e.data;if("/$"===r){if(0===t){qa=Wn(e.nextSibling);break e}t--}else"$"!==r&&"$!"!==r&&"$?"!==r||t++}e=e.nextSibling}qa=null}}else qa=Da?Wn(e.stateNode.nextSibling):null;return!0}function Wa(){qa=Da=null,za=!1}var $a=[];function Ga(){for(var e=0;e<$a.length;e++)$a[e]._workInProgressVersionPrimary=null;$a.length=0}var Qa=k.ReactCurrentDispatcher,Ya=k.ReactCurrentBatchConfig,Ka=0,Xa=null,Ja=null,Za=null,ei=!1,ti=!1;function ri(){throw Error(i(321))}function ni(e,t){if(null===t)return!1;for(var r=0;r<t.length&&r<e.length;r++)if(!ln(e[r],t[r]))return!1;return!0}function oi(e,t,r,n,o,a){if(Ka=a,Xa=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,Qa.current=null===e||null===e.memoizedState?Ri:Ni,e=r(n,o),ti){a=0;do{if(ti=!1,!(25>a))throw Error(i(301));a+=1,Za=Ja=null,t.updateQueue=null,Qa.current=Li,e=r(n,o)}while(ti)}if(Qa.current=Pi,t=null!==Ja&&null!==Ja.next,Ka=0,Za=Ja=Xa=null,ei=!1,t)throw Error(i(300));return e}function ai(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return null===Za?Xa.memoizedState=Za=e:Za=Za.next=e,Za}function ii(){if(null===Ja){var e=Xa.alternate;e=null!==e?e.memoizedState:null}else e=Ja.next;var t=null===Za?Xa.memoizedState:Za.next;if(null!==t)Za=t,Ja=e;else{if(null===e)throw Error(i(310));e={memoizedState:(Ja=e).memoizedState,baseState:Ja.baseState,baseQueue:Ja.baseQueue,queue:Ja.queue,next:null},null===Za?Xa.memoizedState=Za=e:Za=Za.next=e}return Za}function li(e,t){return"function"===typeof t?t(e):t}function ui(e){var t=ii(),r=t.queue;if(null===r)throw Error(i(311));r.lastRenderedReducer=e;var n=Ja,o=n.baseQueue,a=r.pending;if(null!==a){if(null!==o){var l=o.next;o.next=a.next,a.next=l}n.baseQueue=o=a,r.pending=null}if(null!==o){o=o.next,n=n.baseState;var u=l=a=null,c=o;do{var s=c.lane;if((Ka&s)===s)null!==u&&(u=u.next={lane:0,action:c.action,eagerReducer:c.eagerReducer,eagerState:c.eagerState,next:null}),n=c.eagerReducer===e?c.eagerState:e(n,c.action);else{var f={lane:s,action:c.action,eagerReducer:c.eagerReducer,eagerState:c.eagerState,next:null};null===u?(l=u=f,a=n):u=u.next=f,Xa.lanes|=s,ql|=s}c=c.next}while(null!==c&&c!==o);null===u?a=n:u.next=l,ln(n,t.memoizedState)||(Ii=!0),t.memoizedState=n,t.baseState=a,t.baseQueue=u,r.lastRenderedState=n}return[t.memoizedState,r.dispatch]}function ci(e){var t=ii(),r=t.queue;if(null===r)throw Error(i(311));r.lastRenderedReducer=e;var n=r.dispatch,o=r.pending,a=t.memoizedState;if(null!==o){r.pending=null;var l=o=o.next;do{a=e(a,l.action),l=l.next}while(l!==o);ln(a,t.memoizedState)||(Ii=!0),t.memoizedState=a,null===t.baseQueue&&(t.baseState=a),r.lastRenderedState=a}return[a,n]}function si(e,t,r){var n=t._getVersion;n=n(t._source);var o=t._workInProgressVersionPrimary;if(null!==o?e=o===n:(e=e.mutableReadLanes,(e=(Ka&e)===e)&&(t._workInProgressVersionPrimary=n,$a.push(t))),e)return r(t._source);throw $a.push(t),Error(i(350))}function fi(e,t,r,n){var o=Rl;if(null===o)throw Error(i(349));var a=t._getVersion,l=a(t._source),u=Qa.current,c=u.useState((function(){return si(o,t,r)})),s=c[1],f=c[0];c=Za;var d=e.memoizedState,p=d.refs,h=p.getSnapshot,g=d.source;d=d.subscribe;var v=Xa;return e.memoizedState={refs:p,source:t,subscribe:n},u.useEffect((function(){p.getSnapshot=r,p.setSnapshot=s;var e=a(t._source);if(!ln(l,e)){e=r(t._source),ln(f,e)||(s(e),e=su(v),o.mutableReadLanes|=e&o.pendingLanes),e=o.mutableReadLanes,o.entangledLanes|=e;for(var n=o.entanglements,i=e;0<i;){var u=31-Ht(i),c=1<<u;n[u]|=e,i&=~c}}}),[r,t,n]),u.useEffect((function(){return n(t._source,(function(){var e=p.getSnapshot,r=p.setSnapshot;try{r(e(t._source));var n=su(v);o.mutableReadLanes|=n&o.pendingLanes}catch(e){r((function(){throw e}))}}))}),[t,n]),ln(h,r)&&ln(g,t)&&ln(d,n)||((e={pending:null,dispatch:null,lastRenderedReducer:li,lastRenderedState:f}).dispatch=s=Oi.bind(null,Xa,e),c.queue=e,c.baseQueue=null,f=si(o,t,r),c.memoizedState=c.baseState=f),f}function di(e,t,r){return fi(ii(),e,t,r)}function pi(e){var t=ai();return"function"===typeof e&&(e=e()),t.memoizedState=t.baseState=e,e=(e=t.queue={pending:null,dispatch:null,lastRenderedReducer:li,lastRenderedState:e}).dispatch=Oi.bind(null,Xa,e),[t.memoizedState,e]}function hi(e,t,r,n){return e={tag:e,create:t,destroy:r,deps:n,next:null},null===(t=Xa.updateQueue)?(t={lastEffect:null},Xa.updateQueue=t,t.lastEffect=e.next=e):null===(r=t.lastEffect)?t.lastEffect=e.next=e:(n=r.next,r.next=e,e.next=n,t.lastEffect=e),e}function gi(e){return e={current:e},ai().memoizedState=e}function vi(){return ii().memoizedState}function mi(e,t,r,n){var o=ai();Xa.flags|=e,o.memoizedState=hi(1|t,r,void 0,void 0===n?null:n)}function yi(e,t,r,n){var o=ii();n=void 0===n?null:n;var a=void 0;if(null!==Ja){var i=Ja.memoizedState;if(a=i.destroy,null!==n&&ni(n,i.deps))return void hi(t,r,a,n)}Xa.flags|=e,o.memoizedState=hi(1|t,r,a,n)}function bi(e,t){return mi(516,4,e,t)}function wi(e,t){return yi(516,4,e,t)}function ki(e,t){return yi(4,2,e,t)}function Ei(e,t){return"function"===typeof t?(e=e(),t(e),function(){t(null)}):null!==t&&void 0!==t?(e=e(),t.current=e,function(){t.current=null}):void 0}function xi(e,t,r){return r=null!==r&&void 0!==r?r.concat([e]):null,yi(4,2,Ei.bind(null,t,e),r)}function Si(){}function _i(e,t){var r=ii();t=void 0===t?null:t;var n=r.memoizedState;return null!==n&&null!==t&&ni(t,n[1])?n[0]:(r.memoizedState=[e,t],e)}function Ti(e,t){var r=ii();t=void 0===t?null:t;var n=r.memoizedState;return null!==n&&null!==t&&ni(t,n[1])?n[0]:(e=e(),r.memoizedState=[e,t],e)}function Ci(e,t){var r=Bo();Ho(98>r?98:r,(function(){e(!0)})),Ho(97<r?97:r,(function(){var r=Ya.transition;Ya.transition=1;try{e(!1),t()}finally{Ya.transition=r}}))}function Oi(e,t,r){var n=cu(),o=su(e),a={lane:o,action:r,eagerReducer:null,eagerState:null,next:null},i=t.pending;if(null===i?a.next=a:(a.next=i.next,i.next=a),t.pending=a,i=e.alternate,e===Xa||null!==i&&i===Xa)ti=ei=!0;else{if(0===e.lanes&&(null===i||0===i.lanes)&&null!==(i=t.lastRenderedReducer))try{var l=t.lastRenderedState,u=i(l,r);if(a.eagerReducer=i,a.eagerState=u,ln(u,l))return}catch(e){}fu(e,o,n)}}var Pi={readContext:oa,useCallback:ri,useContext:ri,useEffect:ri,useImperativeHandle:ri,useLayoutEffect:ri,useMemo:ri,useReducer:ri,useRef:ri,useState:ri,useDebugValue:ri,useDeferredValue:ri,useTransition:ri,useMutableSource:ri,useOpaqueIdentifier:ri,unstable_isNewReconciler:!1},Ri={readContext:oa,useCallback:function(e,t){return ai().memoizedState=[e,void 0===t?null:t],e},useContext:oa,useEffect:bi,useImperativeHandle:function(e,t,r){return r=null!==r&&void 0!==r?r.concat([e]):null,mi(4,2,Ei.bind(null,t,e),r)},useLayoutEffect:function(e,t){return mi(4,2,e,t)},useMemo:function(e,t){var r=ai();return t=void 0===t?null:t,e=e(),r.memoizedState=[e,t],e},useReducer:function(e,t,r){var n=ai();return t=void 0!==r?r(t):t,n.memoizedState=n.baseState=t,e=(e=n.queue={pending:null,dispatch:null,lastRenderedReducer:e,lastRenderedState:t}).dispatch=Oi.bind(null,Xa,e),[n.memoizedState,e]},useRef:gi,useState:pi,useDebugValue:Si,useDeferredValue:function(e){var t=pi(e),r=t[0],n=t[1];return bi((function(){var t=Ya.transition;Ya.transition=1;try{n(e)}finally{Ya.transition=t}}),[e]),r},useTransition:function(){var e=pi(!1),t=e[0];return gi(e=Ci.bind(null,e[1])),[e,t]},useMutableSource:function(e,t,r){var n=ai();return n.memoizedState={refs:{getSnapshot:t,setSnapshot:null},source:e,subscribe:r},fi(n,e,t,r)},useOpaqueIdentifier:function(){if(za){var e=!1,t=function(e){return{$$typeof:j,toString:e,valueOf:e}}((function(){throw e||(e=!0,r("r:"+(Gn++).toString(36))),Error(i(355))})),r=pi(t)[1];return 0===(2&Xa.mode)&&(Xa.flags|=516,hi(5,(function(){r("r:"+(Gn++).toString(36))}),void 0,null)),t}return pi(t="r:"+(Gn++).toString(36)),t},unstable_isNewReconciler:!1},Ni={readContext:oa,useCallback:_i,useContext:oa,useEffect:wi,useImperativeHandle:xi,useLayoutEffect:ki,useMemo:Ti,useReducer:ui,useRef:vi,useState:function(){return ui(li)},useDebugValue:Si,useDeferredValue:function(e){var t=ui(li),r=t[0],n=t[1];return wi((function(){var t=Ya.transition;Ya.transition=1;try{n(e)}finally{Ya.transition=t}}),[e]),r},useTransition:function(){var e=ui(li)[0];return[vi().current,e]},useMutableSource:di,useOpaqueIdentifier:function(){return ui(li)[0]},unstable_isNewReconciler:!1},Li={readContext:oa,useCallback:_i,useContext:oa,useEffect:wi,useImperativeHandle:xi,useLayoutEffect:ki,useMemo:Ti,useReducer:ci,useRef:vi,useState:function(){return ci(li)},useDebugValue:Si,useDeferredValue:function(e){var t=ci(li),r=t[0],n=t[1];return wi((function(){var t=Ya.transition;Ya.transition=1;try{n(e)}finally{Ya.transition=t}}),[e]),r},useTransition:function(){var e=ci(li)[0];return[vi().current,e]},useMutableSource:di,useOpaqueIdentifier:function(){return ci(li)[0]},unstable_isNewReconciler:!1},Ai=k.ReactCurrentOwner,Ii=!1;function ji(e,t,r,n){t.child=null===e?_a(t,null,r,n):Sa(t,e.child,r,n)}function Mi(e,t,r,n,o){r=r.render;var a=t.ref;return na(t,o),n=oi(e,t,r,n,a,o),null===e||Ii?(t.flags|=1,ji(e,t,n,o),t.child):(t.updateQueue=e.updateQueue,t.flags&=-517,e.lanes&=~o,rl(e,t,o))}function Di(e,t,r,n,o,a){if(null===e){var i=r.type;return"function"!==typeof i||Bu(i)||void 0!==i.defaultProps||null!==r.compare||void 0!==r.defaultProps?((e=Hu(r.type,null,n,t,t.mode,a)).ref=t.ref,e.return=t,t.child=e):(t.tag=15,t.type=i,qi(e,t,i,n,o,a))}return i=e.child,0===(o&a)&&(o=i.memoizedProps,(r=null!==(r=r.compare)?r:cn)(o,n)&&e.ref===t.ref)?rl(e,t,a):(t.flags|=1,(e=Vu(i,n)).ref=t.ref,e.return=t,t.child=e)}function qi(e,t,r,n,o,a){if(null!==e&&cn(e.memoizedProps,n)&&e.ref===t.ref){if(Ii=!1,0===(a&o))return t.lanes=e.lanes,rl(e,t,a);0!==(16384&e.flags)&&(Ii=!0)}return Fi(e,t,r,n,a)}function zi(e,t,r){var n=t.pendingProps,o=n.children,a=null!==e?e.memoizedState:null;if("hidden"===n.mode||"unstable-defer-without-hiding"===n.mode)if(0===(4&t.mode))t.memoizedState={baseLanes:0},bu(t,r);else{if(0===(1073741824&r))return e=null!==a?a.baseLanes|r:r,t.lanes=t.childLanes=1073741824,t.memoizedState={baseLanes:e},bu(t,e),null;t.memoizedState={baseLanes:0},bu(t,null!==a?a.baseLanes:r)}else null!==a?(n=a.baseLanes|r,t.memoizedState=null):n=r,bu(t,n);return ji(e,t,o,r),t.child}function Ui(e,t){var r=t.ref;(null===e&&null!==r||null!==e&&e.ref!==r)&&(t.flags|=128)}function Fi(e,t,r,n,o){var a=go(r)?po:so.current;return a=ho(t,a),na(t,o),r=oi(e,t,r,n,a,o),null===e||Ii?(t.flags|=1,ji(e,t,r,o),t.child):(t.updateQueue=e.updateQueue,t.flags&=-517,e.lanes&=~o,rl(e,t,o))}function Bi(e,t,r,n,o){if(go(r)){var a=!0;bo(t)}else a=!1;if(na(t,o),null===t.stateNode)null!==e&&(e.alternate=null,t.alternate=null,t.flags|=2),ma(t,r,n),ba(t,r,n,o),n=!0;else if(null===e){var i=t.stateNode,l=t.memoizedProps;i.props=l;var u=i.context,c=r.contextType;"object"===typeof c&&null!==c?c=oa(c):c=ho(t,c=go(r)?po:so.current);var s=r.getDerivedStateFromProps,f="function"===typeof s||"function"===typeof i.getSnapshotBeforeUpdate;f||"function"!==typeof i.UNSAFE_componentWillReceiveProps&&"function"!==typeof i.componentWillReceiveProps||(l!==n||u!==c)&&ya(t,i,n,c),aa=!1;var d=t.memoizedState;i.state=d,fa(t,n,i,o),u=t.memoizedState,l!==n||d!==u||fo.current||aa?("function"===typeof s&&(ha(t,r,s,n),u=t.memoizedState),(l=aa||va(t,r,l,n,d,u,c))?(f||"function"!==typeof i.UNSAFE_componentWillMount&&"function"!==typeof i.componentWillMount||("function"===typeof i.componentWillMount&&i.componentWillMount(),"function"===typeof i.UNSAFE_componentWillMount&&i.UNSAFE_componentWillMount()),"function"===typeof i.componentDidMount&&(t.flags|=4)):("function"===typeof i.componentDidMount&&(t.flags|=4),t.memoizedProps=n,t.memoizedState=u),i.props=n,i.state=u,i.context=c,n=l):("function"===typeof i.componentDidMount&&(t.flags|=4),n=!1)}else{i=t.stateNode,la(e,t),l=t.memoizedProps,c=t.type===t.elementType?l:Yo(t.type,l),i.props=c,f=t.pendingProps,d=i.context,"object"===typeof(u=r.contextType)&&null!==u?u=oa(u):u=ho(t,u=go(r)?po:so.current);var p=r.getDerivedStateFromProps;(s="function"===typeof p||"function"===typeof i.getSnapshotBeforeUpdate)||"function"!==typeof i.UNSAFE_componentWillReceiveProps&&"function"!==typeof i.componentWillReceiveProps||(l!==f||d!==u)&&ya(t,i,n,u),aa=!1,d=t.memoizedState,i.state=d,fa(t,n,i,o);var h=t.memoizedState;l!==f||d!==h||fo.current||aa?("function"===typeof p&&(ha(t,r,p,n),h=t.memoizedState),(c=aa||va(t,r,c,n,d,h,u))?(s||"function"!==typeof i.UNSAFE_componentWillUpdate&&"function"!==typeof i.componentWillUpdate||("function"===typeof i.componentWillUpdate&&i.componentWillUpdate(n,h,u),"function"===typeof i.UNSAFE_componentWillUpdate&&i.UNSAFE_componentWillUpdate(n,h,u)),"function"===typeof i.componentDidUpdate&&(t.flags|=4),"function"===typeof i.getSnapshotBeforeUpdate&&(t.flags|=256)):("function"!==typeof i.componentDidUpdate||l===e.memoizedProps&&d===e.memoizedState||(t.flags|=4),"function"!==typeof i.getSnapshotBeforeUpdate||l===e.memoizedProps&&d===e.memoizedState||(t.flags|=256),t.memoizedProps=n,t.memoizedState=h),i.props=n,i.state=h,i.context=u,n=c):("function"!==typeof i.componentDidUpdate||l===e.memoizedProps&&d===e.memoizedState||(t.flags|=4),"function"!==typeof i.getSnapshotBeforeUpdate||l===e.memoizedProps&&d===e.memoizedState||(t.flags|=256),n=!1)}return Vi(e,t,r,n,a,o)}function Vi(e,t,r,n,o,a){Ui(e,t);var i=0!==(64&t.flags);if(!n&&!i)return o&&wo(t,r,!1),rl(e,t,a);n=t.stateNode,Ai.current=t;var l=i&&"function"!==typeof r.getDerivedStateFromError?null:n.render();return t.flags|=1,null!==e&&i?(t.child=Sa(t,e.child,null,a),t.child=Sa(t,null,l,a)):ji(e,t,l,a),t.memoizedState=n.state,o&&wo(t,r,!0),t.child}function Hi(e){var t=e.stateNode;t.pendingContext?mo(0,t.pendingContext,t.pendingContext!==t.context):t.context&&mo(0,t.context,!1),Na(e,t.containerInfo)}var Wi,$i,Gi,Qi={dehydrated:null,retryLane:0};function Yi(e,t,r){var n,o=t.pendingProps,a=ja.current,i=!1;return(n=0!==(64&t.flags))||(n=(null===e||null!==e.memoizedState)&&0!==(2&a)),n?(i=!0,t.flags&=-65):null!==e&&null===e.memoizedState||void 0===o.fallback||!0===o.unstable_avoidThisFallback||(a|=1),uo(ja,1&a),null===e?(void 0!==o.fallback&&Ba(t),e=o.children,a=o.fallback,i?(e=Ki(t,e,a,r),t.child.memoizedState={baseLanes:r},t.memoizedState=Qi,e):"number"===typeof o.unstable_expectedLoadTime?(e=Ki(t,e,a,r),t.child.memoizedState={baseLanes:r},t.memoizedState=Qi,t.lanes=33554432,e):((r=$u({mode:"visible",children:e},t.mode,r,null)).return=t,t.child=r)):(e.memoizedState,i?(o=Ji(e,t,o.children,o.fallback,r),i=t.child,a=e.child.memoizedState,i.memoizedState=null===a?{baseLanes:r}:{baseLanes:a.baseLanes|r},i.childLanes=e.childLanes&~r,t.memoizedState=Qi,o):(r=Xi(e,t,o.children,r),t.memoizedState=null,r))}function Ki(e,t,r,n){var o=e.mode,a=e.child;return t={mode:"hidden",children:t},0===(2&o)&&null!==a?(a.childLanes=0,a.pendingProps=t):a=$u(t,o,0,null),r=Wu(r,o,n,null),a.return=e,r.return=e,a.sibling=r,e.child=a,r}function Xi(e,t,r,n){var o=e.child;return e=o.sibling,r=Vu(o,{mode:"visible",children:r}),0===(2&t.mode)&&(r.lanes=n),r.return=t,r.sibling=null,null!==e&&(e.nextEffect=null,e.flags=8,t.firstEffect=t.lastEffect=e),t.child=r}function Ji(e,t,r,n,o){var a=t.mode,i=e.child;e=i.sibling;var l={mode:"hidden",children:r};return 0===(2&a)&&t.child!==i?((r=t.child).childLanes=0,r.pendingProps=l,null!==(i=r.lastEffect)?(t.firstEffect=r.firstEffect,t.lastEffect=i,i.nextEffect=null):t.firstEffect=t.lastEffect=null):r=Vu(i,l),null!==e?n=Vu(e,n):(n=Wu(n,a,o,null)).flags|=2,n.return=t,r.return=t,r.sibling=n,t.child=r,n}function Zi(e,t){e.lanes|=t;var r=e.alternate;null!==r&&(r.lanes|=t),ra(e.return,t)}function el(e,t,r,n,o,a){var i=e.memoizedState;null===i?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:n,tail:r,tailMode:o,lastEffect:a}:(i.isBackwards=t,i.rendering=null,i.renderingStartTime=0,i.last=n,i.tail=r,i.tailMode=o,i.lastEffect=a)}function tl(e,t,r){var n=t.pendingProps,o=n.revealOrder,a=n.tail;if(ji(e,t,n.children,r),0!==(2&(n=ja.current)))n=1&n|2,t.flags|=64;else{if(null!==e&&0!==(64&e.flags))e:for(e=t.child;null!==e;){if(13===e.tag)null!==e.memoizedState&&Zi(e,r);else if(19===e.tag)Zi(e,r);else if(null!==e.child){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;null===e.sibling;){if(null===e.return||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}n&=1}if(uo(ja,n),0===(2&t.mode))t.memoizedState=null;else switch(o){case"forwards":for(r=t.child,o=null;null!==r;)null!==(e=r.alternate)&&null===Ma(e)&&(o=r),r=r.sibling;null===(r=o)?(o=t.child,t.child=null):(o=r.sibling,r.sibling=null),el(t,!1,o,r,a,t.lastEffect);break;case"backwards":for(r=null,o=t.child,t.child=null;null!==o;){if(null!==(e=o.alternate)&&null===Ma(e)){t.child=o;break}e=o.sibling,o.sibling=r,r=o,o=e}el(t,!0,r,null,a,t.lastEffect);break;case"together":el(t,!1,null,null,void 0,t.lastEffect);break;default:t.memoizedState=null}return t.child}function rl(e,t,r){if(null!==e&&(t.dependencies=e.dependencies),ql|=t.lanes,0!==(r&t.childLanes)){if(null!==e&&t.child!==e.child)throw Error(i(153));if(null!==t.child){for(r=Vu(e=t.child,e.pendingProps),t.child=r,r.return=t;null!==e.sibling;)e=e.sibling,(r=r.sibling=Vu(e,e.pendingProps)).return=t;r.sibling=null}return t.child}return null}function nl(e,t){if(!za)switch(e.tailMode){case"hidden":t=e.tail;for(var r=null;null!==t;)null!==t.alternate&&(r=t),t=t.sibling;null===r?e.tail=null:r.sibling=null;break;case"collapsed":r=e.tail;for(var n=null;null!==r;)null!==r.alternate&&(n=r),r=r.sibling;null===n?t||null===e.tail?e.tail=null:e.tail.sibling=null:n.sibling=null}}function ol(e,t,r){var n=t.pendingProps;switch(t.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return null;case 1:return go(t.type)&&vo(),null;case 3:return La(),lo(fo),lo(so),Ga(),(n=t.stateNode).pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),null!==e&&null!==e.child||(Ha(t)?t.flags|=4:n.hydrate||(t.flags|=256)),null;case 5:Ia(t);var a=Ra(Pa.current);if(r=t.type,null!==e&&null!=t.stateNode)$i(e,t,r,n),e.ref!==t.ref&&(t.flags|=128);else{if(!n){if(null===t.stateNode)throw Error(i(166));return null}if(e=Ra(Ca.current),Ha(t)){n=t.stateNode,r=t.type;var l=t.memoizedProps;switch(n[Yn]=t,n[Kn]=l,r){case"dialog":Cn("cancel",n),Cn("close",n);break;case"iframe":case"object":case"embed":Cn("load",n);break;case"video":case"audio":for(e=0;e<xn.length;e++)Cn(xn[e],n);break;case"source":Cn("error",n);break;case"img":case"image":case"link":Cn("error",n),Cn("load",n);break;case"details":Cn("toggle",n);break;case"input":ee(n,l),Cn("invalid",n);break;case"select":n._wrapperState={wasMultiple:!!l.multiple},Cn("invalid",n);break;case"textarea":ue(n,l),Cn("invalid",n)}for(var c in Se(r,l),e=null,l)l.hasOwnProperty(c)&&(a=l[c],"children"===c?"string"===typeof a?n.textContent!==a&&(e=["children",a]):"number"===typeof a&&n.textContent!==""+a&&(e=["children",""+a]):u.hasOwnProperty(c)&&null!=a&&"onScroll"===c&&Cn("scroll",n));switch(r){case"input":K(n),ne(n,l,!0);break;case"textarea":K(n),se(n);break;case"select":case"option":break;default:"function"===typeof l.onClick&&(n.onclick=Dn)}n=e,t.updateQueue=n,null!==n&&(t.flags|=4)}else{switch(c=9===a.nodeType?a:a.ownerDocument,e===fe&&(e=pe(r)),e===fe?"script"===r?((e=c.createElement("div")).innerHTML="<script><\\/script>",e=e.removeChild(e.firstChild)):"string"===typeof n.is?e=c.createElement(r,{is:n.is}):(e=c.createElement(r),"select"===r&&(c=e,n.multiple?c.multiple=!0:n.size&&(c.size=n.size))):e=c.createElementNS(e,r),e[Yn]=t,e[Kn]=n,Wi(e,t),t.stateNode=e,c=_e(r,n),r){case"dialog":Cn("cancel",e),Cn("close",e),a=n;break;case"iframe":case"object":case"embed":Cn("load",e),a=n;break;case"video":case"audio":for(a=0;a<xn.length;a++)Cn(xn[a],e);a=n;break;case"source":Cn("error",e),a=n;break;case"img":case"image":case"link":Cn("error",e),Cn("load",e),a=n;break;case"details":Cn("toggle",e),a=n;break;case"input":ee(e,n),a=Z(e,n),Cn("invalid",e);break;case"option":a=ae(e,n);break;case"select":e._wrapperState={wasMultiple:!!n.multiple},a=o({},n,{value:void 0}),Cn("invalid",e);break;case"textarea":ue(e,n),a=le(e,n),Cn("invalid",e);break;default:a=n}Se(r,a);var s=a;for(l in s)if(s.hasOwnProperty(l)){var f=s[l];"style"===l?Ee(e,f):"dangerouslySetInnerHTML"===l?null!=(f=f?f.__html:void 0)&&me(e,f):"children"===l?"string"===typeof f?("textarea"!==r||""!==f)&&ye(e,f):"number"===typeof f&&ye(e,""+f):"suppressContentEditableWarning"!==l&&"suppressHydrationWarning"!==l&&"autoFocus"!==l&&(u.hasOwnProperty(l)?null!=f&&"onScroll"===l&&Cn("scroll",e):null!=f&&w(e,l,f,c))}switch(r){case"input":K(e),ne(e,n,!1);break;case"textarea":K(e),se(e);break;case"option":null!=n.value&&e.setAttribute("value",""+Q(n.value));break;case"select":e.multiple=!!n.multiple,null!=(l=n.value)?ie(e,!!n.multiple,l,!1):null!=n.defaultValue&&ie(e,!!n.multiple,n.defaultValue,!0);break;default:"function"===typeof a.onClick&&(e.onclick=Dn)}Un(r,n)&&(t.flags|=4)}null!==t.ref&&(t.flags|=128)}return null;case 6:if(e&&null!=t.stateNode)Gi(0,t,e.memoizedProps,n);else{if("string"!==typeof n&&null===t.stateNode)throw Error(i(166));r=Ra(Pa.current),Ra(Ca.current),Ha(t)?(n=t.stateNode,r=t.memoizedProps,n[Yn]=t,n.nodeValue!==r&&(t.flags|=4)):((n=(9===r.nodeType?r:r.ownerDocument).createTextNode(n))[Yn]=t,t.stateNode=n)}return null;case 13:return lo(ja),n=t.memoizedState,0!==(64&t.flags)?(t.lanes=r,t):(n=null!==n,r=!1,null===e?void 0!==t.memoizedProps.fallback&&Ha(t):r=null!==e.memoizedState,n&&!r&&0!==(2&t.mode)&&(null===e&&!0!==t.memoizedProps.unstable_avoidThisFallback||0!==(1&ja.current)?0===jl&&(jl=3):(0!==jl&&3!==jl||(jl=4),null===Rl||0===(134217727&ql)&&0===(134217727&zl)||gu(Rl,Ll))),(n||r)&&(t.flags|=4),null);case 4:return La(),null===e&&Pn(t.stateNode.containerInfo),null;case 10:return ta(t),null;case 17:return go(t.type)&&vo(),null;case 19:if(lo(ja),null===(n=t.memoizedState))return null;if(l=0!==(64&t.flags),null===(c=n.rendering))if(l)nl(n,!1);else{if(0!==jl||null!==e&&0!==(64&e.flags))for(e=t.child;null!==e;){if(null!==(c=Ma(e))){for(t.flags|=64,nl(n,!1),null!==(l=c.updateQueue)&&(t.updateQueue=l,t.flags|=4),null===n.lastEffect&&(t.firstEffect=null),t.lastEffect=n.lastEffect,n=r,r=t.child;null!==r;)e=n,(l=r).flags&=2,l.nextEffect=null,l.firstEffect=null,l.lastEffect=null,null===(c=l.alternate)?(l.childLanes=0,l.lanes=e,l.child=null,l.memoizedProps=null,l.memoizedState=null,l.updateQueue=null,l.dependencies=null,l.stateNode=null):(l.childLanes=c.childLanes,l.lanes=c.lanes,l.child=c.child,l.memoizedProps=c.memoizedProps,l.memoizedState=c.memoizedState,l.updateQueue=c.updateQueue,l.type=c.type,e=c.dependencies,l.dependencies=null===e?null:{lanes:e.lanes,firstContext:e.firstContext}),r=r.sibling;return uo(ja,1&ja.current|2),t.child}e=e.sibling}null!==n.tail&&Fo()>Vl&&(t.flags|=64,l=!0,nl(n,!1),t.lanes=33554432)}else{if(!l)if(null!==(e=Ma(c))){if(t.flags|=64,l=!0,null!==(r=e.updateQueue)&&(t.updateQueue=r,t.flags|=4),nl(n,!0),null===n.tail&&"hidden"===n.tailMode&&!c.alternate&&!za)return null!==(t=t.lastEffect=n.lastEffect)&&(t.nextEffect=null),null}else 2*Fo()-n.renderingStartTime>Vl&&1073741824!==r&&(t.flags|=64,l=!0,nl(n,!1),t.lanes=33554432);n.isBackwards?(c.sibling=t.child,t.child=c):(null!==(r=n.last)?r.sibling=c:t.child=c,n.last=c)}return null!==n.tail?(r=n.tail,n.rendering=r,n.tail=r.sibling,n.lastEffect=t.lastEffect,n.renderingStartTime=Fo(),r.sibling=null,t=ja.current,uo(ja,l?1&t|2:1&t),r):null;case 23:case 24:return wu(),null!==e&&null!==e.memoizedState!==(null!==t.memoizedState)&&"unstable-defer-without-hiding"!==n.mode&&(t.flags|=4),null}throw Error(i(156,t.tag))}function al(e){switch(e.tag){case 1:go(e.type)&&vo();var t=e.flags;return 4096&t?(e.flags=-4097&t|64,e):null;case 3:if(La(),lo(fo),lo(so),Ga(),0!==(64&(t=e.flags)))throw Error(i(285));return e.flags=-4097&t|64,e;case 5:return Ia(e),null;case 13:return lo(ja),4096&(t=e.flags)?(e.flags=-4097&t|64,e):null;case 19:return lo(ja),null;case 4:return La(),null;case 10:return ta(e),null;case 23:case 24:return wu(),null;default:return null}}function il(e,t){try{var r="",n=t;do{r+=$(n),n=n.return}while(n);var o=r}catch(e){o="\\nError generating stack: "+e.message+"\\n"+e.stack}return{value:e,source:t,stack:o}}function ll(e,t){try{console.error(t.value)}catch(e){setTimeout((function(){throw e}))}}Wi=function(e,t){for(var r=t.child;null!==r;){if(5===r.tag||6===r.tag)e.appendChild(r.stateNode);else if(4!==r.tag&&null!==r.child){r.child.return=r,r=r.child;continue}if(r===t)break;for(;null===r.sibling;){if(null===r.return||r.return===t)return;r=r.return}r.sibling.return=r.return,r=r.sibling}},$i=function(e,t,r,n){var a=e.memoizedProps;if(a!==n){e=t.stateNode,Ra(Ca.current);var i,l=null;switch(r){case"input":a=Z(e,a),n=Z(e,n),l=[];break;case"option":a=ae(e,a),n=ae(e,n),l=[];break;case"select":a=o({},a,{value:void 0}),n=o({},n,{value:void 0}),l=[];break;case"textarea":a=le(e,a),n=le(e,n),l=[];break;default:"function"!==typeof a.onClick&&"function"===typeof n.onClick&&(e.onclick=Dn)}for(f in Se(r,n),r=null,a)if(!n.hasOwnProperty(f)&&a.hasOwnProperty(f)&&null!=a[f])if("style"===f){var c=a[f];for(i in c)c.hasOwnProperty(i)&&(r||(r={}),r[i]="")}else"dangerouslySetInnerHTML"!==f&&"children"!==f&&"suppressContentEditableWarning"!==f&&"suppressHydrationWarning"!==f&&"autoFocus"!==f&&(u.hasOwnProperty(f)?l||(l=[]):(l=l||[]).push(f,null));for(f in n){var s=n[f];if(c=null!=a?a[f]:void 0,n.hasOwnProperty(f)&&s!==c&&(null!=s||null!=c))if("style"===f)if(c){for(i in c)!c.hasOwnProperty(i)||s&&s.hasOwnProperty(i)||(r||(r={}),r[i]="");for(i in s)s.hasOwnProperty(i)&&c[i]!==s[i]&&(r||(r={}),r[i]=s[i])}else r||(l||(l=[]),l.push(f,r)),r=s;else"dangerouslySetInnerHTML"===f?(s=s?s.__html:void 0,c=c?c.__html:void 0,null!=s&&c!==s&&(l=l||[]).push(f,s)):"children"===f?"string"!==typeof s&&"number"!==typeof s||(l=l||[]).push(f,""+s):"suppressContentEditableWarning"!==f&&"suppressHydrationWarning"!==f&&(u.hasOwnProperty(f)?(null!=s&&"onScroll"===f&&Cn("scroll",e),l||c===s||(l=[])):"object"===typeof s&&null!==s&&s.$$typeof===j?s.toString():(l=l||[]).push(f,s))}r&&(l=l||[]).push("style",r);var f=l;(t.updateQueue=f)&&(t.flags|=4)}},Gi=function(e,t,r,n){r!==n&&(t.flags|=4)};var ul="function"===typeof WeakMap?WeakMap:Map;function cl(e,t,r){(r=ua(-1,r)).tag=3,r.payload={element:null};var n=t.value;return r.callback=function(){Gl||(Gl=!0,Ql=n),ll(0,t)},r}function sl(e,t,r){(r=ua(-1,r)).tag=3;var n=e.type.getDerivedStateFromError;if("function"===typeof n){var o=t.value;r.payload=function(){return ll(0,t),n(o)}}var a=e.stateNode;return null!==a&&"function"===typeof a.componentDidCatch&&(r.callback=function(){"function"!==typeof n&&(null===Yl?Yl=new Set([this]):Yl.add(this),ll(0,t));var e=t.stack;this.componentDidCatch(t.value,{componentStack:null!==e?e:""})}),r}var fl="function"===typeof WeakSet?WeakSet:Set;function dl(e){var t=e.ref;if(null!==t)if("function"===typeof t)try{t(null)}catch(t){Du(e,t)}else t.current=null}function pl(e,t){switch(t.tag){case 0:case 11:case 15:case 22:return;case 1:if(256&t.flags&&null!==e){var r=e.memoizedProps,n=e.memoizedState;t=(e=t.stateNode).getSnapshotBeforeUpdate(t.elementType===t.type?r:Yo(t.type,r),n),e.__reactInternalSnapshotBeforeUpdate=t}return;case 3:return void(256&t.flags&&Hn(t.stateNode.containerInfo));case 5:case 6:case 4:case 17:return}throw Error(i(163))}function hl(e,t,r){switch(r.tag){case 0:case 11:case 15:case 22:if(null!==(t=null!==(t=r.updateQueue)?t.lastEffect:null)){e=t=t.next;do{if(3===(3&e.tag)){var n=e.create;e.destroy=n()}e=e.next}while(e!==t)}if(null!==(t=null!==(t=r.updateQueue)?t.lastEffect:null)){e=t=t.next;do{var o=e;n=o.next,0!==(4&(o=o.tag))&&0!==(1&o)&&(Iu(r,e),Au(r,e)),e=n}while(e!==t)}return;case 1:return e=r.stateNode,4&r.flags&&(null===t?e.componentDidMount():(n=r.elementType===r.type?t.memoizedProps:Yo(r.type,t.memoizedProps),e.componentDidUpdate(n,t.memoizedState,e.__reactInternalSnapshotBeforeUpdate))),void(null!==(t=r.updateQueue)&&da(r,t,e));case 3:if(null!==(t=r.updateQueue)){if(e=null,null!==r.child)switch(r.child.tag){case 5:e=r.child.stateNode;break;case 1:e=r.child.stateNode}da(r,t,e)}return;case 5:return e=r.stateNode,void(null===t&&4&r.flags&&Un(r.type,r.memoizedProps)&&e.focus());case 6:case 4:case 12:return;case 13:return void(null===r.memoizedState&&(r=r.alternate,null!==r&&(r=r.memoizedState,null!==r&&(r=r.dehydrated,null!==r&&Et(r)))));case 19:case 17:case 20:case 21:case 23:case 24:return}throw Error(i(163))}function gl(e,t){for(var r=e;;){if(5===r.tag){var n=r.stateNode;if(t)"function"===typeof(n=n.style).setProperty?n.setProperty("display","none","important"):n.display="none";else{n=r.stateNode;var o=r.memoizedProps.style;o=void 0!==o&&null!==o&&o.hasOwnProperty("display")?o.display:null,n.style.display=ke("display",o)}}else if(6===r.tag)r.stateNode.nodeValue=t?"":r.memoizedProps;else if((23!==r.tag&&24!==r.tag||null===r.memoizedState||r===e)&&null!==r.child){r.child.return=r,r=r.child;continue}if(r===e)break;for(;null===r.sibling;){if(null===r.return||r.return===e)return;r=r.return}r.sibling.return=r.return,r=r.sibling}}function vl(e,t){if(Eo&&"function"===typeof Eo.onCommitFiberUnmount)try{Eo.onCommitFiberUnmount(ko,t)}catch(e){}switch(t.tag){case 0:case 11:case 14:case 15:case 22:if(null!==(e=t.updateQueue)&&null!==(e=e.lastEffect)){var r=e=e.next;do{var n=r,o=n.destroy;if(n=n.tag,void 0!==o)if(0!==(4&n))Iu(t,r);else{n=t;try{o()}catch(e){Du(n,e)}}r=r.next}while(r!==e)}break;case 1:if(dl(t),"function"===typeof(e=t.stateNode).componentWillUnmount)try{e.props=t.memoizedProps,e.state=t.memoizedState,e.componentWillUnmount()}catch(e){Du(t,e)}break;case 5:dl(t);break;case 4:El(e,t)}}function ml(e){e.alternate=null,e.child=null,e.dependencies=null,e.firstEffect=null,e.lastEffect=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.return=null,e.updateQueue=null}function yl(e){return 5===e.tag||3===e.tag||4===e.tag}function bl(e){e:{for(var t=e.return;null!==t;){if(yl(t))break e;t=t.return}throw Error(i(160))}var r=t;switch(t=r.stateNode,r.tag){case 5:var n=!1;break;case 3:case 4:t=t.containerInfo,n=!0;break;default:throw Error(i(161))}16&r.flags&&(ye(t,""),r.flags&=-17);e:t:for(r=e;;){for(;null===r.sibling;){if(null===r.return||yl(r.return)){r=null;break e}r=r.return}for(r.sibling.return=r.return,r=r.sibling;5!==r.tag&&6!==r.tag&&18!==r.tag;){if(2&r.flags)continue t;if(null===r.child||4===r.tag)continue t;r.child.return=r,r=r.child}if(!(2&r.flags)){r=r.stateNode;break e}}n?wl(e,r,t):kl(e,r,t)}function wl(e,t,r){var n=e.tag,o=5===n||6===n;if(o)e=o?e.stateNode:e.stateNode.instance,t?8===r.nodeType?r.parentNode.insertBefore(e,t):r.insertBefore(e,t):(8===r.nodeType?(t=r.parentNode).insertBefore(e,r):(t=r).appendChild(e),null!==(r=r._reactRootContainer)&&void 0!==r||null!==t.onclick||(t.onclick=Dn));else if(4!==n&&null!==(e=e.child))for(wl(e,t,r),e=e.sibling;null!==e;)wl(e,t,r),e=e.sibling}function kl(e,t,r){var n=e.tag,o=5===n||6===n;if(o)e=o?e.stateNode:e.stateNode.instance,t?r.insertBefore(e,t):r.appendChild(e);else if(4!==n&&null!==(e=e.child))for(kl(e,t,r),e=e.sibling;null!==e;)kl(e,t,r),e=e.sibling}function El(e,t){for(var r,n,o=t,a=!1;;){if(!a){a=o.return;e:for(;;){if(null===a)throw Error(i(160));switch(r=a.stateNode,a.tag){case 5:n=!1;break e;case 3:case 4:r=r.containerInfo,n=!0;break e}a=a.return}a=!0}if(5===o.tag||6===o.tag){e:for(var l=e,u=o,c=u;;)if(vl(l,c),null!==c.child&&4!==c.tag)c.child.return=c,c=c.child;else{if(c===u)break e;for(;null===c.sibling;){if(null===c.return||c.return===u)break e;c=c.return}c.sibling.return=c.return,c=c.sibling}n?(l=r,u=o.stateNode,8===l.nodeType?l.parentNode.removeChild(u):l.removeChild(u)):r.removeChild(o.stateNode)}else if(4===o.tag){if(null!==o.child){r=o.stateNode.containerInfo,n=!0,o.child.return=o,o=o.child;continue}}else if(vl(e,o),null!==o.child){o.child.return=o,o=o.child;continue}if(o===t)break;for(;null===o.sibling;){if(null===o.return||o.return===t)return;4===(o=o.return).tag&&(a=!1)}o.sibling.return=o.return,o=o.sibling}}function xl(e,t){switch(t.tag){case 0:case 11:case 14:case 15:case 22:var r=t.updateQueue;if(null!==(r=null!==r?r.lastEffect:null)){var n=r=r.next;do{3===(3&n.tag)&&(e=n.destroy,n.destroy=void 0,void 0!==e&&e()),n=n.next}while(n!==r)}return;case 1:return;case 5:if(null!=(r=t.stateNode)){n=t.memoizedProps;var o=null!==e?e.memoizedProps:n;e=t.type;var a=t.updateQueue;if(t.updateQueue=null,null!==a){for(r[Kn]=n,"input"===e&&"radio"===n.type&&null!=n.name&&te(r,n),_e(e,o),t=_e(e,n),o=0;o<a.length;o+=2){var l=a[o],u=a[o+1];"style"===l?Ee(r,u):"dangerouslySetInnerHTML"===l?me(r,u):"children"===l?ye(r,u):w(r,l,u,t)}switch(e){case"input":re(r,n);break;case"textarea":ce(r,n);break;case"select":e=r._wrapperState.wasMultiple,r._wrapperState.wasMultiple=!!n.multiple,null!=(a=n.value)?ie(r,!!n.multiple,a,!1):e!==!!n.multiple&&(null!=n.defaultValue?ie(r,!!n.multiple,n.defaultValue,!0):ie(r,!!n.multiple,n.multiple?[]:"",!1))}}}return;case 6:if(null===t.stateNode)throw Error(i(162));return void(t.stateNode.nodeValue=t.memoizedProps);case 3:return void((r=t.stateNode).hydrate&&(r.hydrate=!1,Et(r.containerInfo)));case 12:return;case 13:return null!==t.memoizedState&&(Bl=Fo(),gl(t.child,!0)),void Sl(t);case 19:return void Sl(t);case 17:return;case 23:case 24:return void gl(t,null!==t.memoizedState)}throw Error(i(163))}function Sl(e){var t=e.updateQueue;if(null!==t){e.updateQueue=null;var r=e.stateNode;null===r&&(r=e.stateNode=new fl),t.forEach((function(t){var n=zu.bind(null,e,t);r.has(t)||(r.add(t),t.then(n,n))}))}}function _l(e,t){return null!==e&&(null===(e=e.memoizedState)||null!==e.dehydrated)&&(null!==(t=t.memoizedState)&&null===t.dehydrated)}var Tl=Math.ceil,Cl=k.ReactCurrentDispatcher,Ol=k.ReactCurrentOwner,Pl=0,Rl=null,Nl=null,Ll=0,Al=0,Il=io(0),jl=0,Ml=null,Dl=0,ql=0,zl=0,Ul=0,Fl=null,Bl=0,Vl=1/0;function Hl(){Vl=Fo()+500}var Wl,$l=null,Gl=!1,Ql=null,Yl=null,Kl=!1,Xl=null,Jl=90,Zl=[],eu=[],tu=null,ru=0,nu=null,ou=-1,au=0,iu=0,lu=null,uu=!1;function cu(){return 0!==(48&Pl)?Fo():-1!==ou?ou:ou=Fo()}function su(e){if(0===(2&(e=e.mode)))return 1;if(0===(4&e))return 99===Bo()?1:2;if(0===au&&(au=Dl),0!==Qo.transition){0!==iu&&(iu=null!==Fl?Fl.pendingLanes:0),e=au;var t=4186112&~iu;return 0===(t&=-t)&&(0===(t=(e=4186112&~e)&-e)&&(t=8192)),t}return e=Bo(),0!==(4&Pl)&&98===e?e=Ut(12,au):e=Ut(e=function(e){switch(e){case 99:return 15;case 98:return 10;case 97:case 96:return 8;case 95:return 2;default:return 0}}(e),au),e}function fu(e,t,r){if(50<ru)throw ru=0,nu=null,Error(i(185));if(null===(e=du(e,t)))return null;Vt(e,t,r),e===Rl&&(zl|=t,4===jl&&gu(e,Ll));var n=Bo();1===t?0!==(8&Pl)&&0===(48&Pl)?vu(e):(pu(e,r),0===Pl&&(Hl(),$o())):(0===(4&Pl)||98!==n&&99!==n||(null===tu?tu=new Set([e]):tu.add(e)),pu(e,r)),Fl=e}function du(e,t){e.lanes|=t;var r=e.alternate;for(null!==r&&(r.lanes|=t),r=e,e=e.return;null!==e;)e.childLanes|=t,null!==(r=e.alternate)&&(r.childLanes|=t),r=e,e=e.return;return 3===r.tag?r.stateNode:null}function pu(e,t){for(var r=e.callbackNode,n=e.suspendedLanes,o=e.pingedLanes,a=e.expirationTimes,l=e.pendingLanes;0<l;){var u=31-Ht(l),c=1<<u,s=a[u];if(-1===s){if(0===(c&n)||0!==(c&o)){s=t,Dt(c);var f=Mt;a[u]=10<=f?s+250:6<=f?s+5e3:-1}}else s<=t&&(e.expiredLanes|=c);l&=~c}if(n=qt(e,e===Rl?Ll:0),t=Mt,0===n)null!==r&&(r!==jo&&_o(r),e.callbackNode=null,e.callbackPriority=0);else{if(null!==r){if(e.callbackPriority===t)return;r!==jo&&_o(r)}15===t?(r=vu.bind(null,e),null===Do?(Do=[r],qo=So(Ro,Go)):Do.push(r),r=jo):14===t?r=Wo(99,vu.bind(null,e)):r=Wo(r=function(e){switch(e){case 15:case 14:return 99;case 13:case 12:case 11:case 10:return 98;case 9:case 8:case 7:case 6:case 4:case 5:return 97;case 3:case 2:case 1:return 95;case 0:return 90;default:throw Error(i(358,e))}}(t),hu.bind(null,e)),e.callbackPriority=t,e.callbackNode=r}}function hu(e){if(ou=-1,iu=au=0,0!==(48&Pl))throw Error(i(327));var t=e.callbackNode;if(Lu()&&e.callbackNode!==t)return null;var r=qt(e,e===Rl?Ll:0);if(0===r)return null;var n=r,o=Pl;Pl|=16;var a=xu();for(Rl===e&&Ll===n||(Hl(),ku(e,n));;)try{Tu();break}catch(t){Eu(e,t)}if(ea(),Cl.current=a,Pl=o,null!==Nl?n=0:(Rl=null,Ll=0,n=jl),0!==(Dl&zl))ku(e,0);else if(0!==n){if(2===n&&(Pl|=64,e.hydrate&&(e.hydrate=!1,Hn(e.containerInfo)),0!==(r=zt(e))&&(n=Su(e,r))),1===n)throw t=Ml,ku(e,0),gu(e,r),pu(e,Fo()),t;switch(e.finishedWork=e.current.alternate,e.finishedLanes=r,n){case 0:case 1:throw Error(i(345));case 2:Pu(e);break;case 3:if(gu(e,r),(62914560&r)===r&&10<(n=Bl+500-Fo())){if(0!==qt(e,0))break;if(((o=e.suspendedLanes)&r)!==r){cu(),e.pingedLanes|=e.suspendedLanes&o;break}e.timeoutHandle=Bn(Pu.bind(null,e),n);break}Pu(e);break;case 4:if(gu(e,r),(4186112&r)===r)break;for(n=e.eventTimes,o=-1;0<r;){var l=31-Ht(r);a=1<<l,(l=n[l])>o&&(o=l),r&=~a}if(r=o,10<(r=(120>(r=Fo()-r)?120:480>r?480:1080>r?1080:1920>r?1920:3e3>r?3e3:4320>r?4320:1960*Tl(r/1960))-r)){e.timeoutHandle=Bn(Pu.bind(null,e),r);break}Pu(e);break;case 5:Pu(e);break;default:throw Error(i(329))}}return pu(e,Fo()),e.callbackNode===t?hu.bind(null,e):null}function gu(e,t){for(t&=~Ul,t&=~zl,e.suspendedLanes|=t,e.pingedLanes&=~t,e=e.expirationTimes;0<t;){var r=31-Ht(t),n=1<<r;e[r]=-1,t&=~n}}function vu(e){if(0!==(48&Pl))throw Error(i(327));if(Lu(),e===Rl&&0!==(e.expiredLanes&Ll)){var t=Ll,r=Su(e,t);0!==(Dl&zl)&&(r=Su(e,t=qt(e,t)))}else r=Su(e,t=qt(e,0));if(0!==e.tag&&2===r&&(Pl|=64,e.hydrate&&(e.hydrate=!1,Hn(e.containerInfo)),0!==(t=zt(e))&&(r=Su(e,t))),1===r)throw r=Ml,ku(e,0),gu(e,t),pu(e,Fo()),r;return e.finishedWork=e.current.alternate,e.finishedLanes=t,Pu(e),pu(e,Fo()),null}function mu(e,t){var r=Pl;Pl|=1;try{return e(t)}finally{0===(Pl=r)&&(Hl(),$o())}}function yu(e,t){var r=Pl;Pl&=-2,Pl|=8;try{return e(t)}finally{0===(Pl=r)&&(Hl(),$o())}}function bu(e,t){uo(Il,Al),Al|=t,Dl|=t}function wu(){Al=Il.current,lo(Il)}function ku(e,t){e.finishedWork=null,e.finishedLanes=0;var r=e.timeoutHandle;if(-1!==r&&(e.timeoutHandle=-1,Vn(r)),null!==Nl)for(r=Nl.return;null!==r;){var n=r;switch(n.tag){case 1:null!==(n=n.type.childContextTypes)&&void 0!==n&&vo();break;case 3:La(),lo(fo),lo(so),Ga();break;case 5:Ia(n);break;case 4:La();break;case 13:case 19:lo(ja);break;case 10:ta(n);break;case 23:case 24:wu()}r=r.return}Rl=e,Nl=Vu(e.current,null),Ll=Al=Dl=t,jl=0,Ml=null,Ul=zl=ql=0}function Eu(e,t){for(;;){var r=Nl;try{if(ea(),Qa.current=Pi,ei){for(var n=Xa.memoizedState;null!==n;){var o=n.queue;null!==o&&(o.pending=null),n=n.next}ei=!1}if(Ka=0,Za=Ja=Xa=null,ti=!1,Ol.current=null,null===r||null===r.return){jl=1,Ml=t,Nl=null;break}e:{var a=e,i=r.return,l=r,u=t;if(t=Ll,l.flags|=2048,l.firstEffect=l.lastEffect=null,null!==u&&"object"===typeof u&&"function"===typeof u.then){var c=u;if(0===(2&l.mode)){var s=l.alternate;s?(l.updateQueue=s.updateQueue,l.memoizedState=s.memoizedState,l.lanes=s.lanes):(l.updateQueue=null,l.memoizedState=null)}var f=0!==(1&ja.current),d=i;do{var p;if(p=13===d.tag){var h=d.memoizedState;if(null!==h)p=null!==h.dehydrated;else{var g=d.memoizedProps;p=void 0!==g.fallback&&(!0!==g.unstable_avoidThisFallback||!f)}}if(p){var v=d.updateQueue;if(null===v){var m=new Set;m.add(c),d.updateQueue=m}else v.add(c);if(0===(2&d.mode)){if(d.flags|=64,l.flags|=16384,l.flags&=-2981,1===l.tag)if(null===l.alternate)l.tag=17;else{var y=ua(-1,1);y.tag=2,ca(l,y)}l.lanes|=1;break e}u=void 0,l=t;var b=a.pingCache;if(null===b?(b=a.pingCache=new ul,u=new Set,b.set(c,u)):void 0===(u=b.get(c))&&(u=new Set,b.set(c,u)),!u.has(l)){u.add(l);var w=qu.bind(null,a,c,l);c.then(w,w)}d.flags|=4096,d.lanes=t;break e}d=d.return}while(null!==d);u=Error((G(l.type)||"A React component")+" suspended while rendering, but no fallback UI was specified.\\n\\nAdd a <Suspense fallback=...> component higher in the tree to provide a loading indicator or placeholder to display.")}5!==jl&&(jl=2),u=il(u,l),d=i;do{switch(d.tag){case 3:a=u,d.flags|=4096,t&=-t,d.lanes|=t,sa(d,cl(0,a,t));break e;case 1:a=u;var k=d.type,E=d.stateNode;if(0===(64&d.flags)&&("function"===typeof k.getDerivedStateFromError||null!==E&&"function"===typeof E.componentDidCatch&&(null===Yl||!Yl.has(E)))){d.flags|=4096,t&=-t,d.lanes|=t,sa(d,sl(d,a,t));break e}}d=d.return}while(null!==d)}Ou(r)}catch(e){t=e,Nl===r&&null!==r&&(Nl=r=r.return);continue}break}}function xu(){var e=Cl.current;return Cl.current=Pi,null===e?Pi:e}function Su(e,t){var r=Pl;Pl|=16;var n=xu();for(Rl===e&&Ll===t||ku(e,t);;)try{_u();break}catch(t){Eu(e,t)}if(ea(),Pl=r,Cl.current=n,null!==Nl)throw Error(i(261));return Rl=null,Ll=0,jl}function _u(){for(;null!==Nl;)Cu(Nl)}function Tu(){for(;null!==Nl&&!To();)Cu(Nl)}function Cu(e){var t=Wl(e.alternate,e,Al);e.memoizedProps=e.pendingProps,null===t?Ou(e):Nl=t,Ol.current=null}function Ou(e){var t=e;do{var r=t.alternate;if(e=t.return,0===(2048&t.flags)){if(null!==(r=ol(r,t,Al)))return void(Nl=r);if(24!==(r=t).tag&&23!==r.tag||null===r.memoizedState||0!==(1073741824&Al)||0===(4&r.mode)){for(var n=0,o=r.child;null!==o;)n|=o.lanes|o.childLanes,o=o.sibling;r.childLanes=n}null!==e&&0===(2048&e.flags)&&(null===e.firstEffect&&(e.firstEffect=t.firstEffect),null!==t.lastEffect&&(null!==e.lastEffect&&(e.lastEffect.nextEffect=t.firstEffect),e.lastEffect=t.lastEffect),1<t.flags&&(null!==e.lastEffect?e.lastEffect.nextEffect=t:e.firstEffect=t,e.lastEffect=t))}else{if(null!==(r=al(t)))return r.flags&=2047,void(Nl=r);null!==e&&(e.firstEffect=e.lastEffect=null,e.flags|=2048)}if(null!==(t=t.sibling))return void(Nl=t);Nl=t=e}while(null!==t);0===jl&&(jl=5)}function Pu(e){var t=Bo();return Ho(99,Ru.bind(null,e,t)),null}function Ru(e,t){do{Lu()}while(null!==Xl);if(0!==(48&Pl))throw Error(i(327));var r=e.finishedWork;if(null===r)return null;if(e.finishedWork=null,e.finishedLanes=0,r===e.current)throw Error(i(177));e.callbackNode=null;var n=r.lanes|r.childLanes,o=n,a=e.pendingLanes&~o;e.pendingLanes=o,e.suspendedLanes=0,e.pingedLanes=0,e.expiredLanes&=o,e.mutableReadLanes&=o,e.entangledLanes&=o,o=e.entanglements;for(var l=e.eventTimes,u=e.expirationTimes;0<a;){var c=31-Ht(a),s=1<<c;o[c]=0,l[c]=-1,u[c]=-1,a&=~s}if(null!==tu&&0===(24&n)&&tu.has(e)&&tu.delete(e),e===Rl&&(Nl=Rl=null,Ll=0),1<r.flags?null!==r.lastEffect?(r.lastEffect.nextEffect=r,n=r.firstEffect):n=r:n=r.firstEffect,null!==n){if(o=Pl,Pl|=32,Ol.current=null,qn=Yt,hn(l=pn())){if("selectionStart"in l)u={start:l.selectionStart,end:l.selectionEnd};else e:if(u=(u=l.ownerDocument)&&u.defaultView||window,(s=u.getSelection&&u.getSelection())&&0!==s.rangeCount){u=s.anchorNode,a=s.anchorOffset,c=s.focusNode,s=s.focusOffset;try{u.nodeType,c.nodeType}catch(e){u=null;break e}var f=0,d=-1,p=-1,h=0,g=0,v=l,m=null;t:for(;;){for(var y;v!==u||0!==a&&3!==v.nodeType||(d=f+a),v!==c||0!==s&&3!==v.nodeType||(p=f+s),3===v.nodeType&&(f+=v.nodeValue.length),null!==(y=v.firstChild);)m=v,v=y;for(;;){if(v===l)break t;if(m===u&&++h===a&&(d=f),m===c&&++g===s&&(p=f),null!==(y=v.nextSibling))break;m=(v=m).parentNode}v=y}u=-1===d||-1===p?null:{start:d,end:p}}else u=null;u=u||{start:0,end:0}}else u=null;zn={focusedElem:l,selectionRange:u},Yt=!1,lu=null,uu=!1,$l=n;do{try{Nu()}catch(e){if(null===$l)throw Error(i(330));Du($l,e),$l=$l.nextEffect}}while(null!==$l);lu=null,$l=n;do{try{for(l=e;null!==$l;){var b=$l.flags;if(16&b&&ye($l.stateNode,""),128&b){var w=$l.alternate;if(null!==w){var k=w.ref;null!==k&&("function"===typeof k?k(null):k.current=null)}}switch(1038&b){case 2:bl($l),$l.flags&=-3;break;case 6:bl($l),$l.flags&=-3,xl($l.alternate,$l);break;case 1024:$l.flags&=-1025;break;case 1028:$l.flags&=-1025,xl($l.alternate,$l);break;case 4:xl($l.alternate,$l);break;case 8:El(l,u=$l);var E=u.alternate;ml(u),null!==E&&ml(E)}$l=$l.nextEffect}}catch(e){if(null===$l)throw Error(i(330));Du($l,e),$l=$l.nextEffect}}while(null!==$l);if(k=zn,w=pn(),b=k.focusedElem,l=k.selectionRange,w!==b&&b&&b.ownerDocument&&dn(b.ownerDocument.documentElement,b)){null!==l&&hn(b)&&(w=l.start,void 0===(k=l.end)&&(k=w),"selectionStart"in b?(b.selectionStart=w,b.selectionEnd=Math.min(k,b.value.length)):(k=(w=b.ownerDocument||document)&&w.defaultView||window).getSelection&&(k=k.getSelection(),u=b.textContent.length,E=Math.min(l.start,u),l=void 0===l.end?E:Math.min(l.end,u),!k.extend&&E>l&&(u=l,l=E,E=u),u=fn(b,E),a=fn(b,l),u&&a&&(1!==k.rangeCount||k.anchorNode!==u.node||k.anchorOffset!==u.offset||k.focusNode!==a.node||k.focusOffset!==a.offset)&&((w=w.createRange()).setStart(u.node,u.offset),k.removeAllRanges(),E>l?(k.addRange(w),k.extend(a.node,a.offset)):(w.setEnd(a.node,a.offset),k.addRange(w))))),w=[];for(k=b;k=k.parentNode;)1===k.nodeType&&w.push({element:k,left:k.scrollLeft,top:k.scrollTop});for("function"===typeof b.focus&&b.focus(),b=0;b<w.length;b++)(k=w[b]).element.scrollLeft=k.left,k.element.scrollTop=k.top}Yt=!!qn,zn=qn=null,e.current=r,$l=n;do{try{for(b=e;null!==$l;){var x=$l.flags;if(36&x&&hl(b,$l.alternate,$l),128&x){w=void 0;var S=$l.ref;if(null!==S){var _=$l.stateNode;switch($l.tag){case 5:w=_;break;default:w=_}"function"===typeof S?S(w):S.current=w}}$l=$l.nextEffect}}catch(e){if(null===$l)throw Error(i(330));Du($l,e),$l=$l.nextEffect}}while(null!==$l);$l=null,Mo(),Pl=o}else e.current=r;if(Kl)Kl=!1,Xl=e,Jl=t;else for($l=n;null!==$l;)t=$l.nextEffect,$l.nextEffect=null,8&$l.flags&&((x=$l).sibling=null,x.stateNode=null),$l=t;if(0===(n=e.pendingLanes)&&(Yl=null),1===n?e===nu?ru++:(ru=0,nu=e):ru=0,r=r.stateNode,Eo&&"function"===typeof Eo.onCommitFiberRoot)try{Eo.onCommitFiberRoot(ko,r,void 0,64===(64&r.current.flags))}catch(e){}if(pu(e,Fo()),Gl)throw Gl=!1,e=Ql,Ql=null,e;return 0!==(8&Pl)||$o(),null}function Nu(){for(;null!==$l;){var e=$l.alternate;uu||null===lu||(0!==(8&$l.flags)?et($l,lu)&&(uu=!0):13===$l.tag&&_l(e,$l)&&et($l,lu)&&(uu=!0));var t=$l.flags;0!==(256&t)&&pl(e,$l),0===(512&t)||Kl||(Kl=!0,Wo(97,(function(){return Lu(),null}))),$l=$l.nextEffect}}function Lu(){if(90!==Jl){var e=97<Jl?97:Jl;return Jl=90,Ho(e,ju)}return!1}function Au(e,t){Zl.push(t,e),Kl||(Kl=!0,Wo(97,(function(){return Lu(),null})))}function Iu(e,t){eu.push(t,e),Kl||(Kl=!0,Wo(97,(function(){return Lu(),null})))}function ju(){if(null===Xl)return!1;var e=Xl;if(Xl=null,0!==(48&Pl))throw Error(i(331));var t=Pl;Pl|=32;var r=eu;eu=[];for(var n=0;n<r.length;n+=2){var o=r[n],a=r[n+1],l=o.destroy;if(o.destroy=void 0,"function"===typeof l)try{l()}catch(e){if(null===a)throw Error(i(330));Du(a,e)}}for(r=Zl,Zl=[],n=0;n<r.length;n+=2){o=r[n],a=r[n+1];try{var u=o.create;o.destroy=u()}catch(e){if(null===a)throw Error(i(330));Du(a,e)}}for(u=e.current.firstEffect;null!==u;)e=u.nextEffect,u.nextEffect=null,8&u.flags&&(u.sibling=null,u.stateNode=null),u=e;return Pl=t,$o(),!0}function Mu(e,t,r){ca(e,t=cl(0,t=il(r,t),1)),t=cu(),null!==(e=du(e,1))&&(Vt(e,1,t),pu(e,t))}function Du(e,t){if(3===e.tag)Mu(e,e,t);else for(var r=e.return;null!==r;){if(3===r.tag){Mu(r,e,t);break}if(1===r.tag){var n=r.stateNode;if("function"===typeof r.type.getDerivedStateFromError||"function"===typeof n.componentDidCatch&&(null===Yl||!Yl.has(n))){var o=sl(r,e=il(t,e),1);if(ca(r,o),o=cu(),null!==(r=du(r,1)))Vt(r,1,o),pu(r,o);else if("function"===typeof n.componentDidCatch&&(null===Yl||!Yl.has(n)))try{n.componentDidCatch(t,e)}catch(e){}break}}r=r.return}}function qu(e,t,r){var n=e.pingCache;null!==n&&n.delete(t),t=cu(),e.pingedLanes|=e.suspendedLanes&r,Rl===e&&(Ll&r)===r&&(4===jl||3===jl&&(62914560&Ll)===Ll&&500>Fo()-Bl?ku(e,0):Ul|=r),pu(e,t)}function zu(e,t){var r=e.stateNode;null!==r&&r.delete(t),0===(t=0)&&(0===(2&(t=e.mode))?t=1:0===(4&t)?t=99===Bo()?1:2:(0===au&&(au=Dl),0===(t=Ft(62914560&~au))&&(t=4194304))),r=cu(),null!==(e=du(e,t))&&(Vt(e,t,r),pu(e,r))}function Uu(e,t,r,n){this.tag=e,this.key=r,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=n,this.flags=0,this.lastEffect=this.firstEffect=this.nextEffect=null,this.childLanes=this.lanes=0,this.alternate=null}function Fu(e,t,r,n){return new Uu(e,t,r,n)}function Bu(e){return!(!(e=e.prototype)||!e.isReactComponent)}function Vu(e,t){var r=e.alternate;return null===r?((r=Fu(e.tag,t,e.key,e.mode)).elementType=e.elementType,r.type=e.type,r.stateNode=e.stateNode,r.alternate=e,e.alternate=r):(r.pendingProps=t,r.type=e.type,r.flags=0,r.nextEffect=null,r.firstEffect=null,r.lastEffect=null),r.childLanes=e.childLanes,r.lanes=e.lanes,r.child=e.child,r.memoizedProps=e.memoizedProps,r.memoizedState=e.memoizedState,r.updateQueue=e.updateQueue,t=e.dependencies,r.dependencies=null===t?null:{lanes:t.lanes,firstContext:t.firstContext},r.sibling=e.sibling,r.index=e.index,r.ref=e.ref,r}function Hu(e,t,r,n,o,a){var l=2;if(n=e,"function"===typeof e)Bu(e)&&(l=1);else if("string"===typeof e)l=5;else e:switch(e){case S:return Wu(r.children,o,a,t);case M:l=8,o|=16;break;case _:l=8,o|=1;break;case T:return(e=Fu(12,r,t,8|o)).elementType=T,e.type=T,e.lanes=a,e;case R:return(e=Fu(13,r,t,o)).type=R,e.elementType=R,e.lanes=a,e;case N:return(e=Fu(19,r,t,o)).elementType=N,e.lanes=a,e;case D:return $u(r,o,a,t);case q:return(e=Fu(24,r,t,o)).elementType=q,e.lanes=a,e;default:if("object"===typeof e&&null!==e)switch(e.$$typeof){case C:l=10;break e;case O:l=9;break e;case P:l=11;break e;case L:l=14;break e;case A:l=16,n=null;break e;case I:l=22;break e}throw Error(i(130,null==e?e:typeof e,""))}return(t=Fu(l,r,t,o)).elementType=e,t.type=n,t.lanes=a,t}function Wu(e,t,r,n){return(e=Fu(7,e,n,t)).lanes=r,e}function $u(e,t,r,n){return(e=Fu(23,e,n,t)).elementType=D,e.lanes=r,e}function Gu(e,t,r){return(e=Fu(6,e,null,t)).lanes=r,e}function Qu(e,t,r){return(t=Fu(4,null!==e.children?e.children:[],e.key,t)).lanes=r,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}function Yu(e,t,r){this.tag=t,this.containerInfo=e,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.pendingContext=this.context=null,this.hydrate=r,this.callbackNode=null,this.callbackPriority=0,this.eventTimes=Bt(0),this.expirationTimes=Bt(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Bt(0),this.mutableSourceEagerHydrationData=null}function Ku(e,t,r){var n=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;return{$$typeof:x,key:null==n?null:""+n,children:e,containerInfo:t,implementation:r}}function Xu(e,t,r,n){var o=t.current,a=cu(),l=su(o);e:if(r){t:{if(Ke(r=r._reactInternals)!==r||1!==r.tag)throw Error(i(170));var u=r;do{switch(u.tag){case 3:u=u.stateNode.context;break t;case 1:if(go(u.type)){u=u.stateNode.__reactInternalMemoizedMergedChildContext;break t}}u=u.return}while(null!==u);throw Error(i(171))}if(1===r.tag){var c=r.type;if(go(c)){r=yo(r,c,u);break e}}r=u}else r=co;return null===t.context?t.context=r:t.pendingContext=r,(t=ua(a,l)).payload={element:e},null!==(n=void 0===n?null:n)&&(t.callback=n),ca(o,t),fu(o,l,a),l}function Ju(e){if(!(e=e.current).child)return null;switch(e.child.tag){case 5:default:return e.child.stateNode}}function Zu(e,t){if(null!==(e=e.memoizedState)&&null!==e.dehydrated){var r=e.retryLane;e.retryLane=0!==r&&r<t?r:t}}function ec(e,t){Zu(e,t),(e=e.alternate)&&Zu(e,t)}function tc(e,t,r){var n=null!=r&&null!=r.hydrationOptions&&r.hydrationOptions.mutableSources||null;if(r=new Yu(e,t,null!=r&&!0===r.hydrate),t=Fu(3,null,null,2===t?7:1===t?3:0),r.current=t,t.stateNode=r,ia(t),e[Xn]=r.current,Pn(8===e.nodeType?e.parentNode:e),n)for(e=0;e<n.length;e++){var o=(t=n[e])._getVersion;o=o(t._source),null==r.mutableSourceEagerHydrationData?r.mutableSourceEagerHydrationData=[t,o]:r.mutableSourceEagerHydrationData.push(t,o)}this._internalRoot=r}function rc(e){return!(!e||1!==e.nodeType&&9!==e.nodeType&&11!==e.nodeType&&(8!==e.nodeType||" react-mount-point-unstable "!==e.nodeValue))}function nc(e,t,r,n,o){var a=r._reactRootContainer;if(a){var i=a._internalRoot;if("function"===typeof o){var l=o;o=function(){var e=Ju(i);l.call(e)}}Xu(t,i,e,o)}else{if(a=r._reactRootContainer=function(e,t){if(t||(t=!(!(t=e?9===e.nodeType?e.documentElement:e.firstChild:null)||1!==t.nodeType||!t.hasAttribute("data-reactroot"))),!t)for(var r;r=e.lastChild;)e.removeChild(r);return new tc(e,0,t?{hydrate:!0}:void 0)}(r,n),i=a._internalRoot,"function"===typeof o){var u=o;o=function(){var e=Ju(i);u.call(e)}}yu((function(){Xu(t,i,e,o)}))}return Ju(i)}function oc(e,t){var r=2<arguments.length&&void 0!==arguments[2]?arguments[2]:null;if(!rc(t))throw Error(i(200));return Ku(e,t,null,r)}Wl=function(e,t,r){var n=t.lanes;if(null!==e)if(e.memoizedProps!==t.pendingProps||fo.current)Ii=!0;else{if(0===(r&n)){switch(Ii=!1,t.tag){case 3:Hi(t),Wa();break;case 5:Aa(t);break;case 1:go(t.type)&&bo(t);break;case 4:Na(t,t.stateNode.containerInfo);break;case 10:n=t.memoizedProps.value;var o=t.type._context;uo(Ko,o._currentValue),o._currentValue=n;break;case 13:if(null!==t.memoizedState)return 0!==(r&t.child.childLanes)?Yi(e,t,r):(uo(ja,1&ja.current),null!==(t=rl(e,t,r))?t.sibling:null);uo(ja,1&ja.current);break;case 19:if(n=0!==(r&t.childLanes),0!==(64&e.flags)){if(n)return tl(e,t,r);t.flags|=64}if(null!==(o=t.memoizedState)&&(o.rendering=null,o.tail=null,o.lastEffect=null),uo(ja,ja.current),n)break;return null;case 23:case 24:return t.lanes=0,zi(e,t,r)}return rl(e,t,r)}Ii=0!==(16384&e.flags)}else Ii=!1;switch(t.lanes=0,t.tag){case 2:if(n=t.type,null!==e&&(e.alternate=null,t.alternate=null,t.flags|=2),e=t.pendingProps,o=ho(t,so.current),na(t,r),o=oi(null,t,n,e,o,r),t.flags|=1,"object"===typeof o&&null!==o&&"function"===typeof o.render&&void 0===o.$$typeof){if(t.tag=1,t.memoizedState=null,t.updateQueue=null,go(n)){var a=!0;bo(t)}else a=!1;t.memoizedState=null!==o.state&&void 0!==o.state?o.state:null,ia(t);var l=n.getDerivedStateFromProps;"function"===typeof l&&ha(t,n,l,e),o.updater=ga,t.stateNode=o,o._reactInternals=t,ba(t,n,e,r),t=Vi(null,t,n,!0,a,r)}else t.tag=0,ji(null,t,o,r),t=t.child;return t;case 16:o=t.elementType;e:{switch(null!==e&&(e.alternate=null,t.alternate=null,t.flags|=2),e=t.pendingProps,o=(a=o._init)(o._payload),t.type=o,a=t.tag=function(e){if("function"===typeof e)return Bu(e)?1:0;if(void 0!==e&&null!==e){if((e=e.$$typeof)===P)return 11;if(e===L)return 14}return 2}(o),e=Yo(o,e),a){case 0:t=Fi(null,t,o,e,r);break e;case 1:t=Bi(null,t,o,e,r);break e;case 11:t=Mi(null,t,o,e,r);break e;case 14:t=Di(null,t,o,Yo(o.type,e),n,r);break e}throw Error(i(306,o,""))}return t;case 0:return n=t.type,o=t.pendingProps,Fi(e,t,n,o=t.elementType===n?o:Yo(n,o),r);case 1:return n=t.type,o=t.pendingProps,Bi(e,t,n,o=t.elementType===n?o:Yo(n,o),r);case 3:if(Hi(t),n=t.updateQueue,null===e||null===n)throw Error(i(282));if(n=t.pendingProps,o=null!==(o=t.memoizedState)?o.element:null,la(e,t),fa(t,n,null,r),(n=t.memoizedState.element)===o)Wa(),t=rl(e,t,r);else{if((a=(o=t.stateNode).hydrate)&&(qa=Wn(t.stateNode.containerInfo.firstChild),Da=t,a=za=!0),a){if(null!=(e=o.mutableSourceEagerHydrationData))for(o=0;o<e.length;o+=2)(a=e[o])._workInProgressVersionPrimary=e[o+1],$a.push(a);for(r=_a(t,null,n,r),t.child=r;r;)r.flags=-3&r.flags|1024,r=r.sibling}else ji(e,t,n,r),Wa();t=t.child}return t;case 5:return Aa(t),null===e&&Ba(t),n=t.type,o=t.pendingProps,a=null!==e?e.memoizedProps:null,l=o.children,Fn(n,o)?l=null:null!==a&&Fn(n,a)&&(t.flags|=16),Ui(e,t),ji(e,t,l,r),t.child;case 6:return null===e&&Ba(t),null;case 13:return Yi(e,t,r);case 4:return Na(t,t.stateNode.containerInfo),n=t.pendingProps,null===e?t.child=Sa(t,null,n,r):ji(e,t,n,r),t.child;case 11:return n=t.type,o=t.pendingProps,Mi(e,t,n,o=t.elementType===n?o:Yo(n,o),r);case 7:return ji(e,t,t.pendingProps,r),t.child;case 8:case 12:return ji(e,t,t.pendingProps.children,r),t.child;case 10:e:{n=t.type._context,o=t.pendingProps,l=t.memoizedProps,a=o.value;var u=t.type._context;if(uo(Ko,u._currentValue),u._currentValue=a,null!==l)if(u=l.value,0===(a=ln(u,a)?0:0|("function"===typeof n._calculateChangedBits?n._calculateChangedBits(u,a):1073741823))){if(l.children===o.children&&!fo.current){t=rl(e,t,r);break e}}else for(null!==(u=t.child)&&(u.return=t);null!==u;){var c=u.dependencies;if(null!==c){l=u.child;for(var s=c.firstContext;null!==s;){if(s.context===n&&0!==(s.observedBits&a)){1===u.tag&&((s=ua(-1,r&-r)).tag=2,ca(u,s)),u.lanes|=r,null!==(s=u.alternate)&&(s.lanes|=r),ra(u.return,r),c.lanes|=r;break}s=s.next}}else l=10===u.tag&&u.type===t.type?null:u.child;if(null!==l)l.return=u;else for(l=u;null!==l;){if(l===t){l=null;break}if(null!==(u=l.sibling)){u.return=l.return,l=u;break}l=l.return}u=l}ji(e,t,o.children,r),t=t.child}return t;case 9:return o=t.type,n=(a=t.pendingProps).children,na(t,r),n=n(o=oa(o,a.unstable_observedBits)),t.flags|=1,ji(e,t,n,r),t.child;case 14:return a=Yo(o=t.type,t.pendingProps),Di(e,t,o,a=Yo(o.type,a),n,r);case 15:return qi(e,t,t.type,t.pendingProps,n,r);case 17:return n=t.type,o=t.pendingProps,o=t.elementType===n?o:Yo(n,o),null!==e&&(e.alternate=null,t.alternate=null,t.flags|=2),t.tag=1,go(n)?(e=!0,bo(t)):e=!1,na(t,r),ma(t,n,o),ba(t,n,o,r),Vi(null,t,n,!0,e,r);case 19:return tl(e,t,r);case 23:case 24:return zi(e,t,r)}throw Error(i(156,t.tag))},tc.prototype.render=function(e){Xu(e,this._internalRoot,null,null)},tc.prototype.unmount=function(){var e=this._internalRoot,t=e.containerInfo;Xu(null,e,null,(function(){t[Xn]=null}))},tt=function(e){13===e.tag&&(fu(e,4,cu()),ec(e,4))},rt=function(e){13===e.tag&&(fu(e,67108864,cu()),ec(e,67108864))},nt=function(e){if(13===e.tag){var t=cu(),r=su(e);fu(e,r,t),ec(e,r)}},ot=function(e,t){return t()},Ce=function(e,t,r){switch(t){case"input":if(re(e,r),t=r.name,"radio"===r.type&&null!=t){for(r=e;r.parentNode;)r=r.parentNode;for(r=r.querySelectorAll("input[name="+JSON.stringify(""+t)+\'][type="radio"]\'),t=0;t<r.length;t++){var n=r[t];if(n!==e&&n.form===e.form){var o=ro(n);if(!o)throw Error(i(90));X(n),re(n,o)}}}break;case"textarea":ce(e,r);break;case"select":null!=(t=r.value)&&ie(e,!!r.multiple,t,!1)}},Ae=mu,Ie=function(e,t,r,n,o){var a=Pl;Pl|=4;try{return Ho(98,e.bind(null,t,r,n,o))}finally{0===(Pl=a)&&(Hl(),$o())}},je=function(){0===(49&Pl)&&(function(){if(null!==tu){var e=tu;tu=null,e.forEach((function(e){e.expiredLanes|=24&e.pendingLanes,pu(e,Fo())}))}$o()}(),Lu())},Me=function(e,t){var r=Pl;Pl|=2;try{return e(t)}finally{0===(Pl=r)&&(Hl(),$o())}};var ac={Events:[eo,to,ro,Ne,Le,Lu,{current:!1}]},ic={findFiberByHostInstance:Zn,bundleType:0,version:"17.0.1",rendererPackageName:"react-dom"},lc={bundleType:ic.bundleType,version:ic.version,rendererPackageName:ic.rendererPackageName,rendererConfig:ic.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:k.ReactCurrentDispatcher,findHostInstanceByFiber:function(e){return null===(e=Ze(e))?null:e.stateNode},findFiberByHostInstance:ic.findFiberByHostInstance||function(){return null},findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null};if("undefined"!==typeof{}){var uc={};if(!uc.isDisabled&&uc.supportsFiber)try{ko=uc.inject(lc),Eo=uc}catch(ve){}}t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=ac,t.createPortal=oc,t.findDOMNode=function(e){if(null==e)return null;if(1===e.nodeType)return e;var t=e._reactInternals;if(void 0===t){if("function"===typeof e.render)throw Error(i(188));throw Error(i(268,Object.keys(e)))}return e=null===(e=Ze(t))?null:e.stateNode},t.flushSync=function(e,t){var r=Pl;if(0!==(48&r))return e(t);Pl|=1;try{if(e)return Ho(99,e.bind(null,t))}finally{Pl=r,$o()}},t.hydrate=function(e,t,r){if(!rc(t))throw Error(i(200));return nc(null,e,t,!0,r)},t.render=function(e,t,r){if(!rc(t))throw Error(i(200));return nc(null,e,t,!1,r)},t.unmountComponentAtNode=function(e){if(!rc(e))throw Error(i(40));return!!e._reactRootContainer&&(yu((function(){nc(null,null,e,!1,(function(){e._reactRootContainer=null,e[Xn]=null}))})),!0)},t.unstable_batchedUpdates=mu,t.unstable_createPortal=function(e,t){return oc(e,t,2<arguments.length&&void 0!==arguments[2]?arguments[2]:null)},t.unstable_renderSubtreeIntoContainer=function(e,t,r,n){if(!rc(r))throw Error(i(200));if(null==e||void 0===e._reactInternals)throw Error(i(38));return nc(e,t,r,!1,n)},t.version="17.0.1"},function(e,t,r){"use strict";e.exports=r(186)},function(e,t,r){"use strict";var n,o,a,i;if("object"===typeof performance&&"function"===typeof performance.now){var l=performance;t.unstable_now=function(){return l.now()}}else{var u=Date,c=u.now();t.unstable_now=function(){return u.now()-c}}if("undefined"===typeof window||"function"!==typeof MessageChannel){var s=null,f=null,d=function e(){if(null!==s)try{var r=t.unstable_now();s(!0,r),s=null}catch(t){throw setTimeout(e,0),t}};n=function(e){null!==s?setTimeout(n,0,e):(s=e,setTimeout(d,0))},o=function(e,t){f=setTimeout(e,t)},a=function(){clearTimeout(f)},t.unstable_shouldYield=function(){return!1},i=t.unstable_forceFrameRate=function(){}}else{var p=window.setTimeout,h=window.clearTimeout;if("undefined"!==typeof console){var g=window.cancelAnimationFrame;"function"!==typeof window.requestAnimationFrame&&console.error("This browser doesn\'t support requestAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills"),"function"!==typeof g&&console.error("This browser doesn\'t support cancelAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills")}var v=!1,m=null,y=-1,b=5,w=0;t.unstable_shouldYield=function(){return t.unstable_now()>=w},i=function(){},t.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):b=0<e?Math.floor(1e3/e):5};var k=new MessageChannel,E=k.port2;k.port1.onmessage=function(){if(null!==m){var e=t.unstable_now();w=e+b;try{m(!0,e)?E.postMessage(null):(v=!1,m=null)}catch(e){throw E.postMessage(null),e}}else v=!1},n=function(e){m=e,v||(v=!0,E.postMessage(null))},o=function(e,r){y=p((function(){e(t.unstable_now())}),r)},a=function(){h(y),y=-1}}function x(e,t){var r=e.length;e.push(t);e:for(;;){var n=r-1>>>1,o=e[n];if(!(void 0!==o&&0<T(o,t)))break e;e[n]=t,e[r]=o,r=n}}function S(e){return void 0===(e=e[0])?null:e}function _(e){var t=e[0];if(void 0!==t){var r=e.pop();if(r!==t){e[0]=r;e:for(var n=0,o=e.length;n<o;){var a=2*(n+1)-1,i=e[a],l=a+1,u=e[l];if(void 0!==i&&0>T(i,r))void 0!==u&&0>T(u,i)?(e[n]=u,e[l]=r,n=l):(e[n]=i,e[a]=r,n=a);else{if(!(void 0!==u&&0>T(u,r)))break e;e[n]=u,e[l]=r,n=l}}}return t}return null}function T(e,t){var r=e.sortIndex-t.sortIndex;return 0!==r?r:e.id-t.id}var C=[],O=[],P=1,R=null,N=3,L=!1,A=!1,I=!1;function j(e){for(var t=S(O);null!==t;){if(null===t.callback)_(O);else{if(!(t.startTime<=e))break;_(O),t.sortIndex=t.expirationTime,x(C,t)}t=S(O)}}function M(e){if(I=!1,j(e),!A)if(null!==S(C))A=!0,n(D);else{var t=S(O);null!==t&&o(M,t.startTime-e)}}function D(e,r){A=!1,I&&(I=!1,a()),L=!0;var n=N;try{for(j(r),R=S(C);null!==R&&(!(R.expirationTime>r)||e&&!t.unstable_shouldYield());){var i=R.callback;if("function"===typeof i){R.callback=null,N=R.priorityLevel;var l=i(R.expirationTime<=r);r=t.unstable_now(),"function"===typeof l?R.callback=l:R===S(C)&&_(C),j(r)}else _(C);R=S(C)}if(null!==R)var u=!0;else{var c=S(O);null!==c&&o(M,c.startTime-r),u=!1}return u}finally{R=null,N=n,L=!1}}var q=i;t.unstable_IdlePriority=5,t.unstable_ImmediatePriority=1,t.unstable_LowPriority=4,t.unstable_NormalPriority=3,t.unstable_Profiling=null,t.unstable_UserBlockingPriority=2,t.unstable_cancelCallback=function(e){e.callback=null},t.unstable_continueExecution=function(){A||L||(A=!0,n(D))},t.unstable_getCurrentPriorityLevel=function(){return N},t.unstable_getFirstCallbackNode=function(){return S(C)},t.unstable_next=function(e){switch(N){case 1:case 2:case 3:var t=3;break;default:t=N}var r=N;N=t;try{return e()}finally{N=r}},t.unstable_pauseExecution=function(){},t.unstable_requestPaint=q,t.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var r=N;N=e;try{return t()}finally{N=r}},t.unstable_scheduleCallback=function(e,r,i){var l=t.unstable_now();switch("object"===typeof i&&null!==i?i="number"===typeof(i=i.delay)&&0<i?l+i:l:i=l,e){case 1:var u=-1;break;case 2:u=250;break;case 5:u=1073741823;break;case 4:u=1e4;break;default:u=5e3}return e={id:P++,callback:r,priorityLevel:e,startTime:i,expirationTime:u=i+u,sortIndex:-1},i>l?(e.sortIndex=i,x(O,e),null===S(C)&&e===S(O)&&(I?a():I=!0,o(M,i-l))):(e.sortIndex=u,x(C,e),A||L||(A=!0,n(D))),e},t.unstable_wrapCallback=function(e){var t=N;return function(){var r=N;N=t;try{return e.apply(this,arguments)}finally{N=r}}}},function(e,t,r){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var n={"&lt":"<","&gt":">","&quot":\'"\',"&apos":"\'","&amp":"&","&lt;":"<","&gt;":">","&quot;":\'"\',"&apos;":"\'","&amp;":"&"},o={60:"lt",62:"gt",34:"quot",39:"apos",38:"amp"},a={"<":"&lt;",">":"&gt;",\'"\':"&quot;","\'":"&apos;","&":"&amp;"},i=function(){function e(){}return e.prototype.encode=function(e){return e&&e.length?e.replace(/[<>"\'&]/g,(function(e){return a[e]})):""},e.encode=function(t){return(new e).encode(t)},e.prototype.decode=function(e){return e&&e.length?e.replace(/&#?[0-9a-zA-Z]+;?/g,(function(e){if("#"===e.charAt(1)){var t="x"===e.charAt(2).toLowerCase()?parseInt(e.substr(3),16):parseInt(e.substr(2));return isNaN(t)||t<-32768||t>65535?"":String.fromCharCode(t)}return n[e]||e})):""},e.decode=function(t){return(new e).decode(t)},e.prototype.encodeNonUTF=function(e){if(!e||!e.length)return"";for(var t=e.length,r="",n=0;n<t;){var a=e.charCodeAt(n),i=o[a];i?(r+="&"+i+";",n++):(r+=a<32||a>126?"&#"+a+";":e.charAt(n),n++)}return r},e.encodeNonUTF=function(t){return(new e).encodeNonUTF(t)},e.prototype.encodeNonASCII=function(e){if(!e||!e.length)return"";for(var t=e.length,r="",n=0;n<t;){var o=e.charCodeAt(n);o<=255?r+=e[n++]:(r+="&#"+o+";",n++)}return r},e.encodeNonASCII=function(t){return(new e).encodeNonASCII(t)},e}();t.XmlEntities=i},function(e,t,r){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var n=["apos","nbsp","iexcl","cent","pound","curren","yen","brvbar","sect","uml","copy","ordf","laquo","not","shy","reg","macr","deg","plusmn","sup2","sup3","acute","micro","para","middot","cedil","sup1","ordm","raquo","frac14","frac12","frac34","iquest","Agrave","Aacute","Acirc","Atilde","Auml","Aring","Aelig","Ccedil","Egrave","Eacute","Ecirc","Euml","Igrave","Iacute","Icirc","Iuml","ETH","Ntilde","Ograve","Oacute","Ocirc","Otilde","Ouml","times","Oslash","Ugrave","Uacute","Ucirc","Uuml","Yacute","THORN","szlig","agrave","aacute","acirc","atilde","auml","aring","aelig","ccedil","egrave","eacute","ecirc","euml","igrave","iacute","icirc","iuml","eth","ntilde","ograve","oacute","ocirc","otilde","ouml","divide","oslash","ugrave","uacute","ucirc","uuml","yacute","thorn","yuml","quot","amp","lt","gt","OElig","oelig","Scaron","scaron","Yuml","circ","tilde","ensp","emsp","thinsp","zwnj","zwj","lrm","rlm","ndash","mdash","lsquo","rsquo","sbquo","ldquo","rdquo","bdquo","dagger","Dagger","permil","lsaquo","rsaquo","euro","fnof","Alpha","Beta","Gamma","Delta","Epsilon","Zeta","Eta","Theta","Iota","Kappa","Lambda","Mu","Nu","Xi","Omicron","Pi","Rho","Sigma","Tau","Upsilon","Phi","Chi","Psi","Omega","alpha","beta","gamma","delta","epsilon","zeta","eta","theta","iota","kappa","lambda","mu","nu","xi","omicron","pi","rho","sigmaf","sigma","tau","upsilon","phi","chi","psi","omega","thetasym","upsih","piv","bull","hellip","prime","Prime","oline","frasl","weierp","image","real","trade","alefsym","larr","uarr","rarr","darr","harr","crarr","lArr","uArr","rArr","dArr","hArr","forall","part","exist","empty","nabla","isin","notin","ni","prod","sum","minus","lowast","radic","prop","infin","ang","and","or","cap","cup","int","there4","sim","cong","asymp","ne","equiv","le","ge","sub","sup","nsub","sube","supe","oplus","otimes","perp","sdot","lceil","rceil","lfloor","rfloor","lang","rang","loz","spades","clubs","hearts","diams"],o=[39,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,34,38,60,62,338,339,352,353,376,710,732,8194,8195,8201,8204,8205,8206,8207,8211,8212,8216,8217,8218,8220,8221,8222,8224,8225,8240,8249,8250,8364,402,913,914,915,916,917,918,919,920,921,922,923,924,925,926,927,928,929,931,932,933,934,935,936,937,945,946,947,948,949,950,951,952,953,954,955,956,957,958,959,960,961,962,963,964,965,966,967,968,969,977,978,982,8226,8230,8242,8243,8254,8260,8472,8465,8476,8482,8501,8592,8593,8594,8595,8596,8629,8656,8657,8658,8659,8660,8704,8706,8707,8709,8711,8712,8713,8715,8719,8721,8722,8727,8730,8733,8734,8736,8743,8744,8745,8746,8747,8756,8764,8773,8776,8800,8801,8804,8805,8834,8835,8836,8838,8839,8853,8855,8869,8901,8968,8969,8970,8971,9001,9002,9674,9824,9827,9829,9830],a={},i={};!function(){for(var e=0,t=n.length;e<t;){var r=n[e],l=o[e];a[r]=String.fromCharCode(l),i[l]=r,e++}}();var l=function(){function e(){}return e.prototype.decode=function(e){return e&&e.length?e.replace(/&(#?[\\w\\d]+);?/g,(function(e,t){var r;if("#"===t.charAt(0)){var n="x"===t.charAt(1).toLowerCase()?parseInt(t.substr(2),16):parseInt(t.substr(1));isNaN(n)||n<-32768||n>65535||(r=String.fromCharCode(n))}else r=a[t];return r||e})):""},e.decode=function(t){return(new e).decode(t)},e.prototype.encode=function(e){if(!e||!e.length)return"";for(var t=e.length,r="",n=0;n<t;){var o=i[e.charCodeAt(n)];r+=o?"&"+o+";":e.charAt(n),n++}return r},e.encode=function(t){return(new e).encode(t)},e.prototype.encodeNonUTF=function(e){if(!e||!e.length)return"";for(var t=e.length,r="",n=0;n<t;){var o=e.charCodeAt(n),a=i[o];r+=a?"&"+a+";":o<32||o>126?"&#"+o+";":e.charAt(n),n++}return r},e.encodeNonUTF=function(t){return(new e).encodeNonUTF(t)},e.prototype.encodeNonASCII=function(e){if(!e||!e.length)return"";for(var t=e.length,r="",n=0;n<t;){var o=e.charCodeAt(n);o<=255?r+=e[n++]:(r+="&#"+o+";",n++)}return r},e.encodeNonASCII=function(t){return(new e).encodeNonASCII(t)},e}();t.Html4Entities=l},function(e,t,r){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var n=[["Aacute",[193]],["aacute",[225]],["Abreve",[258]],["abreve",[259]],["ac",[8766]],["acd",[8767]],["acE",[8766,819]],["Acirc",[194]],["acirc",[226]],["acute",[180]],["Acy",[1040]],["acy",[1072]],["AElig",[198]],["aelig",[230]],["af",[8289]],["Afr",[120068]],["afr",[120094]],["Agrave",[192]],["agrave",[224]],["alefsym",[8501]],["aleph",[8501]],["Alpha",[913]],["alpha",[945]],["Amacr",[256]],["amacr",[257]],["amalg",[10815]],["amp",[38]],["AMP",[38]],["andand",[10837]],["And",[10835]],["and",[8743]],["andd",[10844]],["andslope",[10840]],["andv",[10842]],["ang",[8736]],["ange",[10660]],["angle",[8736]],["angmsdaa",[10664]],["angmsdab",[10665]],["angmsdac",[10666]],["angmsdad",[10667]],["angmsdae",[10668]],["angmsdaf",[10669]],["angmsdag",[10670]],["angmsdah",[10671]],["angmsd",[8737]],["angrt",[8735]],["angrtvb",[8894]],["angrtvbd",[10653]],["angsph",[8738]],["angst",[197]],["angzarr",[9084]],["Aogon",[260]],["aogon",[261]],["Aopf",[120120]],["aopf",[120146]],["apacir",[10863]],["ap",[8776]],["apE",[10864]],["ape",[8778]],["apid",[8779]],["apos",[39]],["ApplyFunction",[8289]],["approx",[8776]],["approxeq",[8778]],["Aring",[197]],["aring",[229]],["Ascr",[119964]],["ascr",[119990]],["Assign",[8788]],["ast",[42]],["asymp",[8776]],["asympeq",[8781]],["Atilde",[195]],["atilde",[227]],["Auml",[196]],["auml",[228]],["awconint",[8755]],["awint",[10769]],["backcong",[8780]],["backepsilon",[1014]],["backprime",[8245]],["backsim",[8765]],["backsimeq",[8909]],["Backslash",[8726]],["Barv",[10983]],["barvee",[8893]],["barwed",[8965]],["Barwed",[8966]],["barwedge",[8965]],["bbrk",[9141]],["bbrktbrk",[9142]],["bcong",[8780]],["Bcy",[1041]],["bcy",[1073]],["bdquo",[8222]],["becaus",[8757]],["because",[8757]],["Because",[8757]],["bemptyv",[10672]],["bepsi",[1014]],["bernou",[8492]],["Bernoullis",[8492]],["Beta",[914]],["beta",[946]],["beth",[8502]],["between",[8812]],["Bfr",[120069]],["bfr",[120095]],["bigcap",[8898]],["bigcirc",[9711]],["bigcup",[8899]],["bigodot",[10752]],["bigoplus",[10753]],["bigotimes",[10754]],["bigsqcup",[10758]],["bigstar",[9733]],["bigtriangledown",[9661]],["bigtriangleup",[9651]],["biguplus",[10756]],["bigvee",[8897]],["bigwedge",[8896]],["bkarow",[10509]],["blacklozenge",[10731]],["blacksquare",[9642]],["blacktriangle",[9652]],["blacktriangledown",[9662]],["blacktriangleleft",[9666]],["blacktriangleright",[9656]],["blank",[9251]],["blk12",[9618]],["blk14",[9617]],["blk34",[9619]],["block",[9608]],["bne",[61,8421]],["bnequiv",[8801,8421]],["bNot",[10989]],["bnot",[8976]],["Bopf",[120121]],["bopf",[120147]],["bot",[8869]],["bottom",[8869]],["bowtie",[8904]],["boxbox",[10697]],["boxdl",[9488]],["boxdL",[9557]],["boxDl",[9558]],["boxDL",[9559]],["boxdr",[9484]],["boxdR",[9554]],["boxDr",[9555]],["boxDR",[9556]],["boxh",[9472]],["boxH",[9552]],["boxhd",[9516]],["boxHd",[9572]],["boxhD",[9573]],["boxHD",[9574]],["boxhu",[9524]],["boxHu",[9575]],["boxhU",[9576]],["boxHU",[9577]],["boxminus",[8863]],["boxplus",[8862]],["boxtimes",[8864]],["boxul",[9496]],["boxuL",[9563]],["boxUl",[9564]],["boxUL",[9565]],["boxur",[9492]],["boxuR",[9560]],["boxUr",[9561]],["boxUR",[9562]],["boxv",[9474]],["boxV",[9553]],["boxvh",[9532]],["boxvH",[9578]],["boxVh",[9579]],["boxVH",[9580]],["boxvl",[9508]],["boxvL",[9569]],["boxVl",[9570]],["boxVL",[9571]],["boxvr",[9500]],["boxvR",[9566]],["boxVr",[9567]],["boxVR",[9568]],["bprime",[8245]],["breve",[728]],["Breve",[728]],["brvbar",[166]],["bscr",[119991]],["Bscr",[8492]],["bsemi",[8271]],["bsim",[8765]],["bsime",[8909]],["bsolb",[10693]],["bsol",[92]],["bsolhsub",[10184]],["bull",[8226]],["bullet",[8226]],["bump",[8782]],["bumpE",[10926]],["bumpe",[8783]],["Bumpeq",[8782]],["bumpeq",[8783]],["Cacute",[262]],["cacute",[263]],["capand",[10820]],["capbrcup",[10825]],["capcap",[10827]],["cap",[8745]],["Cap",[8914]],["capcup",[10823]],["capdot",[10816]],["CapitalDifferentialD",[8517]],["caps",[8745,65024]],["caret",[8257]],["caron",[711]],["Cayleys",[8493]],["ccaps",[10829]],["Ccaron",[268]],["ccaron",[269]],["Ccedil",[199]],["ccedil",[231]],["Ccirc",[264]],["ccirc",[265]],["Cconint",[8752]],["ccups",[10828]],["ccupssm",[10832]],["Cdot",[266]],["cdot",[267]],["cedil",[184]],["Cedilla",[184]],["cemptyv",[10674]],["cent",[162]],["centerdot",[183]],["CenterDot",[183]],["cfr",[120096]],["Cfr",[8493]],["CHcy",[1063]],["chcy",[1095]],["check",[10003]],["checkmark",[10003]],["Chi",[935]],["chi",[967]],["circ",[710]],["circeq",[8791]],["circlearrowleft",[8634]],["circlearrowright",[8635]],["circledast",[8859]],["circledcirc",[8858]],["circleddash",[8861]],["CircleDot",[8857]],["circledR",[174]],["circledS",[9416]],["CircleMinus",[8854]],["CirclePlus",[8853]],["CircleTimes",[8855]],["cir",[9675]],["cirE",[10691]],["cire",[8791]],["cirfnint",[10768]],["cirmid",[10991]],["cirscir",[10690]],["ClockwiseContourIntegral",[8754]],["clubs",[9827]],["clubsuit",[9827]],["colon",[58]],["Colon",[8759]],["Colone",[10868]],["colone",[8788]],["coloneq",[8788]],["comma",[44]],["commat",[64]],["comp",[8705]],["compfn",[8728]],["complement",[8705]],["complexes",[8450]],["cong",[8773]],["congdot",[10861]],["Congruent",[8801]],["conint",[8750]],["Conint",[8751]],["ContourIntegral",[8750]],["copf",[120148]],["Copf",[8450]],["coprod",[8720]],["Coproduct",[8720]],["copy",[169]],["COPY",[169]],["copysr",[8471]],["CounterClockwiseContourIntegral",[8755]],["crarr",[8629]],["cross",[10007]],["Cross",[10799]],["Cscr",[119966]],["cscr",[119992]],["csub",[10959]],["csube",[10961]],["csup",[10960]],["csupe",[10962]],["ctdot",[8943]],["cudarrl",[10552]],["cudarrr",[10549]],["cuepr",[8926]],["cuesc",[8927]],["cularr",[8630]],["cularrp",[10557]],["cupbrcap",[10824]],["cupcap",[10822]],["CupCap",[8781]],["cup",[8746]],["Cup",[8915]],["cupcup",[10826]],["cupdot",[8845]],["cupor",[10821]],["cups",[8746,65024]],["curarr",[8631]],["curarrm",[10556]],["curlyeqprec",[8926]],["curlyeqsucc",[8927]],["curlyvee",[8910]],["curlywedge",[8911]],["curren",[164]],["curvearrowleft",[8630]],["curvearrowright",[8631]],["cuvee",[8910]],["cuwed",[8911]],["cwconint",[8754]],["cwint",[8753]],["cylcty",[9005]],["dagger",[8224]],["Dagger",[8225]],["daleth",[8504]],["darr",[8595]],["Darr",[8609]],["dArr",[8659]],["dash",[8208]],["Dashv",[10980]],["dashv",[8867]],["dbkarow",[10511]],["dblac",[733]],["Dcaron",[270]],["dcaron",[271]],["Dcy",[1044]],["dcy",[1076]],["ddagger",[8225]],["ddarr",[8650]],["DD",[8517]],["dd",[8518]],["DDotrahd",[10513]],["ddotseq",[10871]],["deg",[176]],["Del",[8711]],["Delta",[916]],["delta",[948]],["demptyv",[10673]],["dfisht",[10623]],["Dfr",[120071]],["dfr",[120097]],["dHar",[10597]],["dharl",[8643]],["dharr",[8642]],["DiacriticalAcute",[180]],["DiacriticalDot",[729]],["DiacriticalDoubleAcute",[733]],["DiacriticalGrave",[96]],["DiacriticalTilde",[732]],["diam",[8900]],["diamond",[8900]],["Diamond",[8900]],["diamondsuit",[9830]],["diams",[9830]],["die",[168]],["DifferentialD",[8518]],["digamma",[989]],["disin",[8946]],["div",[247]],["divide",[247]],["divideontimes",[8903]],["divonx",[8903]],["DJcy",[1026]],["djcy",[1106]],["dlcorn",[8990]],["dlcrop",[8973]],["dollar",[36]],["Dopf",[120123]],["dopf",[120149]],["Dot",[168]],["dot",[729]],["DotDot",[8412]],["doteq",[8784]],["doteqdot",[8785]],["DotEqual",[8784]],["dotminus",[8760]],["dotplus",[8724]],["dotsquare",[8865]],["doublebarwedge",[8966]],["DoubleContourIntegral",[8751]],["DoubleDot",[168]],["DoubleDownArrow",[8659]],["DoubleLeftArrow",[8656]],["DoubleLeftRightArrow",[8660]],["DoubleLeftTee",[10980]],["DoubleLongLeftArrow",[10232]],["DoubleLongLeftRightArrow",[10234]],["DoubleLongRightArrow",[10233]],["DoubleRightArrow",[8658]],["DoubleRightTee",[8872]],["DoubleUpArrow",[8657]],["DoubleUpDownArrow",[8661]],["DoubleVerticalBar",[8741]],["DownArrowBar",[10515]],["downarrow",[8595]],["DownArrow",[8595]],["Downarrow",[8659]],["DownArrowUpArrow",[8693]],["DownBreve",[785]],["downdownarrows",[8650]],["downharpoonleft",[8643]],["downharpoonright",[8642]],["DownLeftRightVector",[10576]],["DownLeftTeeVector",[10590]],["DownLeftVectorBar",[10582]],["DownLeftVector",[8637]],["DownRightTeeVector",[10591]],["DownRightVectorBar",[10583]],["DownRightVector",[8641]],["DownTeeArrow",[8615]],["DownTee",[8868]],["drbkarow",[10512]],["drcorn",[8991]],["drcrop",[8972]],["Dscr",[119967]],["dscr",[119993]],["DScy",[1029]],["dscy",[1109]],["dsol",[10742]],["Dstrok",[272]],["dstrok",[273]],["dtdot",[8945]],["dtri",[9663]],["dtrif",[9662]],["duarr",[8693]],["duhar",[10607]],["dwangle",[10662]],["DZcy",[1039]],["dzcy",[1119]],["dzigrarr",[10239]],["Eacute",[201]],["eacute",[233]],["easter",[10862]],["Ecaron",[282]],["ecaron",[283]],["Ecirc",[202]],["ecirc",[234]],["ecir",[8790]],["ecolon",[8789]],["Ecy",[1069]],["ecy",[1101]],["eDDot",[10871]],["Edot",[278]],["edot",[279]],["eDot",[8785]],["ee",[8519]],["efDot",[8786]],["Efr",[120072]],["efr",[120098]],["eg",[10906]],["Egrave",[200]],["egrave",[232]],["egs",[10902]],["egsdot",[10904]],["el",[10905]],["Element",[8712]],["elinters",[9191]],["ell",[8467]],["els",[10901]],["elsdot",[10903]],["Emacr",[274]],["emacr",[275]],["empty",[8709]],["emptyset",[8709]],["EmptySmallSquare",[9723]],["emptyv",[8709]],["EmptyVerySmallSquare",[9643]],["emsp13",[8196]],["emsp14",[8197]],["emsp",[8195]],["ENG",[330]],["eng",[331]],["ensp",[8194]],["Eogon",[280]],["eogon",[281]],["Eopf",[120124]],["eopf",[120150]],["epar",[8917]],["eparsl",[10723]],["eplus",[10865]],["epsi",[949]],["Epsilon",[917]],["epsilon",[949]],["epsiv",[1013]],["eqcirc",[8790]],["eqcolon",[8789]],["eqsim",[8770]],["eqslantgtr",[10902]],["eqslantless",[10901]],["Equal",[10869]],["equals",[61]],["EqualTilde",[8770]],["equest",[8799]],["Equilibrium",[8652]],["equiv",[8801]],["equivDD",[10872]],["eqvparsl",[10725]],["erarr",[10609]],["erDot",[8787]],["escr",[8495]],["Escr",[8496]],["esdot",[8784]],["Esim",[10867]],["esim",[8770]],["Eta",[919]],["eta",[951]],["ETH",[208]],["eth",[240]],["Euml",[203]],["euml",[235]],["euro",[8364]],["excl",[33]],["exist",[8707]],["Exists",[8707]],["expectation",[8496]],["exponentiale",[8519]],["ExponentialE",[8519]],["fallingdotseq",[8786]],["Fcy",[1060]],["fcy",[1092]],["female",[9792]],["ffilig",[64259]],["fflig",[64256]],["ffllig",[64260]],["Ffr",[120073]],["ffr",[120099]],["filig",[64257]],["FilledSmallSquare",[9724]],["FilledVerySmallSquare",[9642]],["fjlig",[102,106]],["flat",[9837]],["fllig",[64258]],["fltns",[9649]],["fnof",[402]],["Fopf",[120125]],["fopf",[120151]],["forall",[8704]],["ForAll",[8704]],["fork",[8916]],["forkv",[10969]],["Fouriertrf",[8497]],["fpartint",[10765]],["frac12",[189]],["frac13",[8531]],["frac14",[188]],["frac15",[8533]],["frac16",[8537]],["frac18",[8539]],["frac23",[8532]],["frac25",[8534]],["frac34",[190]],["frac35",[8535]],["frac38",[8540]],["frac45",[8536]],["frac56",[8538]],["frac58",[8541]],["frac78",[8542]],["frasl",[8260]],["frown",[8994]],["fscr",[119995]],["Fscr",[8497]],["gacute",[501]],["Gamma",[915]],["gamma",[947]],["Gammad",[988]],["gammad",[989]],["gap",[10886]],["Gbreve",[286]],["gbreve",[287]],["Gcedil",[290]],["Gcirc",[284]],["gcirc",[285]],["Gcy",[1043]],["gcy",[1075]],["Gdot",[288]],["gdot",[289]],["ge",[8805]],["gE",[8807]],["gEl",[10892]],["gel",[8923]],["geq",[8805]],["geqq",[8807]],["geqslant",[10878]],["gescc",[10921]],["ges",[10878]],["gesdot",[10880]],["gesdoto",[10882]],["gesdotol",[10884]],["gesl",[8923,65024]],["gesles",[10900]],["Gfr",[120074]],["gfr",[120100]],["gg",[8811]],["Gg",[8921]],["ggg",[8921]],["gimel",[8503]],["GJcy",[1027]],["gjcy",[1107]],["gla",[10917]],["gl",[8823]],["glE",[10898]],["glj",[10916]],["gnap",[10890]],["gnapprox",[10890]],["gne",[10888]],["gnE",[8809]],["gneq",[10888]],["gneqq",[8809]],["gnsim",[8935]],["Gopf",[120126]],["gopf",[120152]],["grave",[96]],["GreaterEqual",[8805]],["GreaterEqualLess",[8923]],["GreaterFullEqual",[8807]],["GreaterGreater",[10914]],["GreaterLess",[8823]],["GreaterSlantEqual",[10878]],["GreaterTilde",[8819]],["Gscr",[119970]],["gscr",[8458]],["gsim",[8819]],["gsime",[10894]],["gsiml",[10896]],["gtcc",[10919]],["gtcir",[10874]],["gt",[62]],["GT",[62]],["Gt",[8811]],["gtdot",[8919]],["gtlPar",[10645]],["gtquest",[10876]],["gtrapprox",[10886]],["gtrarr",[10616]],["gtrdot",[8919]],["gtreqless",[8923]],["gtreqqless",[10892]],["gtrless",[8823]],["gtrsim",[8819]],["gvertneqq",[8809,65024]],["gvnE",[8809,65024]],["Hacek",[711]],["hairsp",[8202]],["half",[189]],["hamilt",[8459]],["HARDcy",[1066]],["hardcy",[1098]],["harrcir",[10568]],["harr",[8596]],["hArr",[8660]],["harrw",[8621]],["Hat",[94]],["hbar",[8463]],["Hcirc",[292]],["hcirc",[293]],["hearts",[9829]],["heartsuit",[9829]],["hellip",[8230]],["hercon",[8889]],["hfr",[120101]],["Hfr",[8460]],["HilbertSpace",[8459]],["hksearow",[10533]],["hkswarow",[10534]],["hoarr",[8703]],["homtht",[8763]],["hookleftarrow",[8617]],["hookrightarrow",[8618]],["hopf",[120153]],["Hopf",[8461]],["horbar",[8213]],["HorizontalLine",[9472]],["hscr",[119997]],["Hscr",[8459]],["hslash",[8463]],["Hstrok",[294]],["hstrok",[295]],["HumpDownHump",[8782]],["HumpEqual",[8783]],["hybull",[8259]],["hyphen",[8208]],["Iacute",[205]],["iacute",[237]],["ic",[8291]],["Icirc",[206]],["icirc",[238]],["Icy",[1048]],["icy",[1080]],["Idot",[304]],["IEcy",[1045]],["iecy",[1077]],["iexcl",[161]],["iff",[8660]],["ifr",[120102]],["Ifr",[8465]],["Igrave",[204]],["igrave",[236]],["ii",[8520]],["iiiint",[10764]],["iiint",[8749]],["iinfin",[10716]],["iiota",[8489]],["IJlig",[306]],["ijlig",[307]],["Imacr",[298]],["imacr",[299]],["image",[8465]],["ImaginaryI",[8520]],["imagline",[8464]],["imagpart",[8465]],["imath",[305]],["Im",[8465]],["imof",[8887]],["imped",[437]],["Implies",[8658]],["incare",[8453]],["in",[8712]],["infin",[8734]],["infintie",[10717]],["inodot",[305]],["intcal",[8890]],["int",[8747]],["Int",[8748]],["integers",[8484]],["Integral",[8747]],["intercal",[8890]],["Intersection",[8898]],["intlarhk",[10775]],["intprod",[10812]],["InvisibleComma",[8291]],["InvisibleTimes",[8290]],["IOcy",[1025]],["iocy",[1105]],["Iogon",[302]],["iogon",[303]],["Iopf",[120128]],["iopf",[120154]],["Iota",[921]],["iota",[953]],["iprod",[10812]],["iquest",[191]],["iscr",[119998]],["Iscr",[8464]],["isin",[8712]],["isindot",[8949]],["isinE",[8953]],["isins",[8948]],["isinsv",[8947]],["isinv",[8712]],["it",[8290]],["Itilde",[296]],["itilde",[297]],["Iukcy",[1030]],["iukcy",[1110]],["Iuml",[207]],["iuml",[239]],["Jcirc",[308]],["jcirc",[309]],["Jcy",[1049]],["jcy",[1081]],["Jfr",[120077]],["jfr",[120103]],["jmath",[567]],["Jopf",[120129]],["jopf",[120155]],["Jscr",[119973]],["jscr",[119999]],["Jsercy",[1032]],["jsercy",[1112]],["Jukcy",[1028]],["jukcy",[1108]],["Kappa",[922]],["kappa",[954]],["kappav",[1008]],["Kcedil",[310]],["kcedil",[311]],["Kcy",[1050]],["kcy",[1082]],["Kfr",[120078]],["kfr",[120104]],["kgreen",[312]],["KHcy",[1061]],["khcy",[1093]],["KJcy",[1036]],["kjcy",[1116]],["Kopf",[120130]],["kopf",[120156]],["Kscr",[119974]],["kscr",[12e4]],["lAarr",[8666]],["Lacute",[313]],["lacute",[314]],["laemptyv",[10676]],["lagran",[8466]],["Lambda",[923]],["lambda",[955]],["lang",[10216]],["Lang",[10218]],["langd",[10641]],["langle",[10216]],["lap",[10885]],["Laplacetrf",[8466]],["laquo",[171]],["larrb",[8676]],["larrbfs",[10527]],["larr",[8592]],["Larr",[8606]],["lArr",[8656]],["larrfs",[10525]],["larrhk",[8617]],["larrlp",[8619]],["larrpl",[10553]],["larrsim",[10611]],["larrtl",[8610]],["latail",[10521]],["lAtail",[10523]],["lat",[10923]],["late",[10925]],["lates",[10925,65024]],["lbarr",[10508]],["lBarr",[10510]],["lbbrk",[10098]],["lbrace",[123]],["lbrack",[91]],["lbrke",[10635]],["lbrksld",[10639]],["lbrkslu",[10637]],["Lcaron",[317]],["lcaron",[318]],["Lcedil",[315]],["lcedil",[316]],["lceil",[8968]],["lcub",[123]],["Lcy",[1051]],["lcy",[1083]],["ldca",[10550]],["ldquo",[8220]],["ldquor",[8222]],["ldrdhar",[10599]],["ldrushar",[10571]],["ldsh",[8626]],["le",[8804]],["lE",[8806]],["LeftAngleBracket",[10216]],["LeftArrowBar",[8676]],["leftarrow",[8592]],["LeftArrow",[8592]],["Leftarrow",[8656]],["LeftArrowRightArrow",[8646]],["leftarrowtail",[8610]],["LeftCeiling",[8968]],["LeftDoubleBracket",[10214]],["LeftDownTeeVector",[10593]],["LeftDownVectorBar",[10585]],["LeftDownVector",[8643]],["LeftFloor",[8970]],["leftharpoondown",[8637]],["leftharpoonup",[8636]],["leftleftarrows",[8647]],["leftrightarrow",[8596]],["LeftRightArrow",[8596]],["Leftrightarrow",[8660]],["leftrightarrows",[8646]],["leftrightharpoons",[8651]],["leftrightsquigarrow",[8621]],["LeftRightVector",[10574]],["LeftTeeArrow",[8612]],["LeftTee",[8867]],["LeftTeeVector",[10586]],["leftthreetimes",[8907]],["LeftTriangleBar",[10703]],["LeftTriangle",[8882]],["LeftTriangleEqual",[8884]],["LeftUpDownVector",[10577]],["LeftUpTeeVector",[10592]],["LeftUpVectorBar",[10584]],["LeftUpVector",[8639]],["LeftVectorBar",[10578]],["LeftVector",[8636]],["lEg",[10891]],["leg",[8922]],["leq",[8804]],["leqq",[8806]],["leqslant",[10877]],["lescc",[10920]],["les",[10877]],["lesdot",[10879]],["lesdoto",[10881]],["lesdotor",[10883]],["lesg",[8922,65024]],["lesges",[10899]],["lessapprox",[10885]],["lessdot",[8918]],["lesseqgtr",[8922]],["lesseqqgtr",[10891]],["LessEqualGreater",[8922]],["LessFullEqual",[8806]],["LessGreater",[8822]],["lessgtr",[8822]],["LessLess",[10913]],["lesssim",[8818]],["LessSlantEqual",[10877]],["LessTilde",[8818]],["lfisht",[10620]],["lfloor",[8970]],["Lfr",[120079]],["lfr",[120105]],["lg",[8822]],["lgE",[10897]],["lHar",[10594]],["lhard",[8637]],["lharu",[8636]],["lharul",[10602]],["lhblk",[9604]],["LJcy",[1033]],["ljcy",[1113]],["llarr",[8647]],["ll",[8810]],["Ll",[8920]],["llcorner",[8990]],["Lleftarrow",[8666]],["llhard",[10603]],["lltri",[9722]],["Lmidot",[319]],["lmidot",[320]],["lmoustache",[9136]],["lmoust",[9136]],["lnap",[10889]],["lnapprox",[10889]],["lne",[10887]],["lnE",[8808]],["lneq",[10887]],["lneqq",[8808]],["lnsim",[8934]],["loang",[10220]],["loarr",[8701]],["lobrk",[10214]],["longleftarrow",[10229]],["LongLeftArrow",[10229]],["Longleftarrow",[10232]],["longleftrightarrow",[10231]],["LongLeftRightArrow",[10231]],["Longleftrightarrow",[10234]],["longmapsto",[10236]],["longrightarrow",[10230]],["LongRightArrow",[10230]],["Longrightarrow",[10233]],["looparrowleft",[8619]],["looparrowright",[8620]],["lopar",[10629]],["Lopf",[120131]],["lopf",[120157]],["loplus",[10797]],["lotimes",[10804]],["lowast",[8727]],["lowbar",[95]],["LowerLeftArrow",[8601]],["LowerRightArrow",[8600]],["loz",[9674]],["lozenge",[9674]],["lozf",[10731]],["lpar",[40]],["lparlt",[10643]],["lrarr",[8646]],["lrcorner",[8991]],["lrhar",[8651]],["lrhard",[10605]],["lrm",[8206]],["lrtri",[8895]],["lsaquo",[8249]],["lscr",[120001]],["Lscr",[8466]],["lsh",[8624]],["Lsh",[8624]],["lsim",[8818]],["lsime",[10893]],["lsimg",[10895]],["lsqb",[91]],["lsquo",[8216]],["lsquor",[8218]],["Lstrok",[321]],["lstrok",[322]],["ltcc",[10918]],["ltcir",[10873]],["lt",[60]],["LT",[60]],["Lt",[8810]],["ltdot",[8918]],["lthree",[8907]],["ltimes",[8905]],["ltlarr",[10614]],["ltquest",[10875]],["ltri",[9667]],["ltrie",[8884]],["ltrif",[9666]],["ltrPar",[10646]],["lurdshar",[10570]],["luruhar",[10598]],["lvertneqq",[8808,65024]],["lvnE",[8808,65024]],["macr",[175]],["male",[9794]],["malt",[10016]],["maltese",[10016]],["Map",[10501]],["map",[8614]],["mapsto",[8614]],["mapstodown",[8615]],["mapstoleft",[8612]],["mapstoup",[8613]],["marker",[9646]],["mcomma",[10793]],["Mcy",[1052]],["mcy",[1084]],["mdash",[8212]],["mDDot",[8762]],["measuredangle",[8737]],["MediumSpace",[8287]],["Mellintrf",[8499]],["Mfr",[120080]],["mfr",[120106]],["mho",[8487]],["micro",[181]],["midast",[42]],["midcir",[10992]],["mid",[8739]],["middot",[183]],["minusb",[8863]],["minus",[8722]],["minusd",[8760]],["minusdu",[10794]],["MinusPlus",[8723]],["mlcp",[10971]],["mldr",[8230]],["mnplus",[8723]],["models",[8871]],["Mopf",[120132]],["mopf",[120158]],["mp",[8723]],["mscr",[120002]],["Mscr",[8499]],["mstpos",[8766]],["Mu",[924]],["mu",[956]],["multimap",[8888]],["mumap",[8888]],["nabla",[8711]],["Nacute",[323]],["nacute",[324]],["nang",[8736,8402]],["nap",[8777]],["napE",[10864,824]],["napid",[8779,824]],["napos",[329]],["napprox",[8777]],["natural",[9838]],["naturals",[8469]],["natur",[9838]],["nbsp",[160]],["nbump",[8782,824]],["nbumpe",[8783,824]],["ncap",[10819]],["Ncaron",[327]],["ncaron",[328]],["Ncedil",[325]],["ncedil",[326]],["ncong",[8775]],["ncongdot",[10861,824]],["ncup",[10818]],["Ncy",[1053]],["ncy",[1085]],["ndash",[8211]],["nearhk",[10532]],["nearr",[8599]],["neArr",[8663]],["nearrow",[8599]],["ne",[8800]],["nedot",[8784,824]],["NegativeMediumSpace",[8203]],["NegativeThickSpace",[8203]],["NegativeThinSpace",[8203]],["NegativeVeryThinSpace",[8203]],["nequiv",[8802]],["nesear",[10536]],["nesim",[8770,824]],["NestedGreaterGreater",[8811]],["NestedLessLess",[8810]],["nexist",[8708]],["nexists",[8708]],["Nfr",[120081]],["nfr",[120107]],["ngE",[8807,824]],["nge",[8817]],["ngeq",[8817]],["ngeqq",[8807,824]],["ngeqslant",[10878,824]],["nges",[10878,824]],["nGg",[8921,824]],["ngsim",[8821]],["nGt",[8811,8402]],["ngt",[8815]],["ngtr",[8815]],["nGtv",[8811,824]],["nharr",[8622]],["nhArr",[8654]],["nhpar",[10994]],["ni",[8715]],["nis",[8956]],["nisd",[8954]],["niv",[8715]],["NJcy",[1034]],["njcy",[1114]],["nlarr",[8602]],["nlArr",[8653]],["nldr",[8229]],["nlE",[8806,824]],["nle",[8816]],["nleftarrow",[8602]],["nLeftarrow",[8653]],["nleftrightarrow",[8622]],["nLeftrightarrow",[8654]],["nleq",[8816]],["nleqq",[8806,824]],["nleqslant",[10877,824]],["nles",[10877,824]],["nless",[8814]],["nLl",[8920,824]],["nlsim",[8820]],["nLt",[8810,8402]],["nlt",[8814]],["nltri",[8938]],["nltrie",[8940]],["nLtv",[8810,824]],["nmid",[8740]],["NoBreak",[8288]],["NonBreakingSpace",[160]],["nopf",[120159]],["Nopf",[8469]],["Not",[10988]],["not",[172]],["NotCongruent",[8802]],["NotCupCap",[8813]],["NotDoubleVerticalBar",[8742]],["NotElement",[8713]],["NotEqual",[8800]],["NotEqualTilde",[8770,824]],["NotExists",[8708]],["NotGreater",[8815]],["NotGreaterEqual",[8817]],["NotGreaterFullEqual",[8807,824]],["NotGreaterGreater",[8811,824]],["NotGreaterLess",[8825]],["NotGreaterSlantEqual",[10878,824]],["NotGreaterTilde",[8821]],["NotHumpDownHump",[8782,824]],["NotHumpEqual",[8783,824]],["notin",[8713]],["notindot",[8949,824]],["notinE",[8953,824]],["notinva",[8713]],["notinvb",[8951]],["notinvc",[8950]],["NotLeftTriangleBar",[10703,824]],["NotLeftTriangle",[8938]],["NotLeftTriangleEqual",[8940]],["NotLess",[8814]],["NotLessEqual",[8816]],["NotLessGreater",[8824]],["NotLessLess",[8810,824]],["NotLessSlantEqual",[10877,824]],["NotLessTilde",[8820]],["NotNestedGreaterGreater",[10914,824]],["NotNestedLessLess",[10913,824]],["notni",[8716]],["notniva",[8716]],["notnivb",[8958]],["notnivc",[8957]],["NotPrecedes",[8832]],["NotPrecedesEqual",[10927,824]],["NotPrecedesSlantEqual",[8928]],["NotReverseElement",[8716]],["NotRightTriangleBar",[10704,824]],["NotRightTriangle",[8939]],["NotRightTriangleEqual",[8941]],["NotSquareSubset",[8847,824]],["NotSquareSubsetEqual",[8930]],["NotSquareSuperset",[8848,824]],["NotSquareSupersetEqual",[8931]],["NotSubset",[8834,8402]],["NotSubsetEqual",[8840]],["NotSucceeds",[8833]],["NotSucceedsEqual",[10928,824]],["NotSucceedsSlantEqual",[8929]],["NotSucceedsTilde",[8831,824]],["NotSuperset",[8835,8402]],["NotSupersetEqual",[8841]],["NotTilde",[8769]],["NotTildeEqual",[8772]],["NotTildeFullEqual",[8775]],["NotTildeTilde",[8777]],["NotVerticalBar",[8740]],["nparallel",[8742]],["npar",[8742]],["nparsl",[11005,8421]],["npart",[8706,824]],["npolint",[10772]],["npr",[8832]],["nprcue",[8928]],["nprec",[8832]],["npreceq",[10927,824]],["npre",[10927,824]],["nrarrc",[10547,824]],["nrarr",[8603]],["nrArr",[8655]],["nrarrw",[8605,824]],["nrightarrow",[8603]],["nRightarrow",[8655]],["nrtri",[8939]],["nrtrie",[8941]],["nsc",[8833]],["nsccue",[8929]],["nsce",[10928,824]],["Nscr",[119977]],["nscr",[120003]],["nshortmid",[8740]],["nshortparallel",[8742]],["nsim",[8769]],["nsime",[8772]],["nsimeq",[8772]],["nsmid",[8740]],["nspar",[8742]],["nsqsube",[8930]],["nsqsupe",[8931]],["nsub",[8836]],["nsubE",[10949,824]],["nsube",[8840]],["nsubset",[8834,8402]],["nsubseteq",[8840]],["nsubseteqq",[10949,824]],["nsucc",[8833]],["nsucceq",[10928,824]],["nsup",[8837]],["nsupE",[10950,824]],["nsupe",[8841]],["nsupset",[8835,8402]],["nsupseteq",[8841]],["nsupseteqq",[10950,824]],["ntgl",[8825]],["Ntilde",[209]],["ntilde",[241]],["ntlg",[8824]],["ntriangleleft",[8938]],["ntrianglelefteq",[8940]],["ntriangleright",[8939]],["ntrianglerighteq",[8941]],["Nu",[925]],["nu",[957]],["num",[35]],["numero",[8470]],["numsp",[8199]],["nvap",[8781,8402]],["nvdash",[8876]],["nvDash",[8877]],["nVdash",[8878]],["nVDash",[8879]],["nvge",[8805,8402]],["nvgt",[62,8402]],["nvHarr",[10500]],["nvinfin",[10718]],["nvlArr",[10498]],["nvle",[8804,8402]],["nvlt",[60,8402]],["nvltrie",[8884,8402]],["nvrArr",[10499]],["nvrtrie",[8885,8402]],["nvsim",[8764,8402]],["nwarhk",[10531]],["nwarr",[8598]],["nwArr",[8662]],["nwarrow",[8598]],["nwnear",[10535]],["Oacute",[211]],["oacute",[243]],["oast",[8859]],["Ocirc",[212]],["ocirc",[244]],["ocir",[8858]],["Ocy",[1054]],["ocy",[1086]],["odash",[8861]],["Odblac",[336]],["odblac",[337]],["odiv",[10808]],["odot",[8857]],["odsold",[10684]],["OElig",[338]],["oelig",[339]],["ofcir",[10687]],["Ofr",[120082]],["ofr",[120108]],["ogon",[731]],["Ograve",[210]],["ograve",[242]],["ogt",[10689]],["ohbar",[10677]],["ohm",[937]],["oint",[8750]],["olarr",[8634]],["olcir",[10686]],["olcross",[10683]],["oline",[8254]],["olt",[10688]],["Omacr",[332]],["omacr",[333]],["Omega",[937]],["omega",[969]],["Omicron",[927]],["omicron",[959]],["omid",[10678]],["ominus",[8854]],["Oopf",[120134]],["oopf",[120160]],["opar",[10679]],["OpenCurlyDoubleQuote",[8220]],["OpenCurlyQuote",[8216]],["operp",[10681]],["oplus",[8853]],["orarr",[8635]],["Or",[10836]],["or",[8744]],["ord",[10845]],["order",[8500]],["orderof",[8500]],["ordf",[170]],["ordm",[186]],["origof",[8886]],["oror",[10838]],["orslope",[10839]],["orv",[10843]],["oS",[9416]],["Oscr",[119978]],["oscr",[8500]],["Oslash",[216]],["oslash",[248]],["osol",[8856]],["Otilde",[213]],["otilde",[245]],["otimesas",[10806]],["Otimes",[10807]],["otimes",[8855]],["Ouml",[214]],["ouml",[246]],["ovbar",[9021]],["OverBar",[8254]],["OverBrace",[9182]],["OverBracket",[9140]],["OverParenthesis",[9180]],["para",[182]],["parallel",[8741]],["par",[8741]],["parsim",[10995]],["parsl",[11005]],["part",[8706]],["PartialD",[8706]],["Pcy",[1055]],["pcy",[1087]],["percnt",[37]],["period",[46]],["permil",[8240]],["perp",[8869]],["pertenk",[8241]],["Pfr",[120083]],["pfr",[120109]],["Phi",[934]],["phi",[966]],["phiv",[981]],["phmmat",[8499]],["phone",[9742]],["Pi",[928]],["pi",[960]],["pitchfork",[8916]],["piv",[982]],["planck",[8463]],["planckh",[8462]],["plankv",[8463]],["plusacir",[10787]],["plusb",[8862]],["pluscir",[10786]],["plus",[43]],["plusdo",[8724]],["plusdu",[10789]],["pluse",[10866]],["PlusMinus",[177]],["plusmn",[177]],["plussim",[10790]],["plustwo",[10791]],["pm",[177]],["Poincareplane",[8460]],["pointint",[10773]],["popf",[120161]],["Popf",[8473]],["pound",[163]],["prap",[10935]],["Pr",[10939]],["pr",[8826]],["prcue",[8828]],["precapprox",[10935]],["prec",[8826]],["preccurlyeq",[8828]],["Precedes",[8826]],["PrecedesEqual",[10927]],["PrecedesSlantEqual",[8828]],["PrecedesTilde",[8830]],["preceq",[10927]],["precnapprox",[10937]],["precneqq",[10933]],["precnsim",[8936]],["pre",[10927]],["prE",[10931]],["precsim",[8830]],["prime",[8242]],["Prime",[8243]],["primes",[8473]],["prnap",[10937]],["prnE",[10933]],["prnsim",[8936]],["prod",[8719]],["Product",[8719]],["profalar",[9006]],["profline",[8978]],["profsurf",[8979]],["prop",[8733]],["Proportional",[8733]],["Proportion",[8759]],["propto",[8733]],["prsim",[8830]],["prurel",[8880]],["Pscr",[119979]],["pscr",[120005]],["Psi",[936]],["psi",[968]],["puncsp",[8200]],["Qfr",[120084]],["qfr",[120110]],["qint",[10764]],["qopf",[120162]],["Qopf",[8474]],["qprime",[8279]],["Qscr",[119980]],["qscr",[120006]],["quaternions",[8461]],["quatint",[10774]],["quest",[63]],["questeq",[8799]],["quot",[34]],["QUOT",[34]],["rAarr",[8667]],["race",[8765,817]],["Racute",[340]],["racute",[341]],["radic",[8730]],["raemptyv",[10675]],["rang",[10217]],["Rang",[10219]],["rangd",[10642]],["range",[10661]],["rangle",[10217]],["raquo",[187]],["rarrap",[10613]],["rarrb",[8677]],["rarrbfs",[10528]],["rarrc",[10547]],["rarr",[8594]],["Rarr",[8608]],["rArr",[8658]],["rarrfs",[10526]],["rarrhk",[8618]],["rarrlp",[8620]],["rarrpl",[10565]],["rarrsim",[10612]],["Rarrtl",[10518]],["rarrtl",[8611]],["rarrw",[8605]],["ratail",[10522]],["rAtail",[10524]],["ratio",[8758]],["rationals",[8474]],["rbarr",[10509]],["rBarr",[10511]],["RBarr",[10512]],["rbbrk",[10099]],["rbrace",[125]],["rbrack",[93]],["rbrke",[10636]],["rbrksld",[10638]],["rbrkslu",[10640]],["Rcaron",[344]],["rcaron",[345]],["Rcedil",[342]],["rcedil",[343]],["rceil",[8969]],["rcub",[125]],["Rcy",[1056]],["rcy",[1088]],["rdca",[10551]],["rdldhar",[10601]],["rdquo",[8221]],["rdquor",[8221]],["CloseCurlyDoubleQuote",[8221]],["rdsh",[8627]],["real",[8476]],["realine",[8475]],["realpart",[8476]],["reals",[8477]],["Re",[8476]],["rect",[9645]],["reg",[174]],["REG",[174]],["ReverseElement",[8715]],["ReverseEquilibrium",[8651]],["ReverseUpEquilibrium",[10607]],["rfisht",[10621]],["rfloor",[8971]],["rfr",[120111]],["Rfr",[8476]],["rHar",[10596]],["rhard",[8641]],["rharu",[8640]],["rharul",[10604]],["Rho",[929]],["rho",[961]],["rhov",[1009]],["RightAngleBracket",[10217]],["RightArrowBar",[8677]],["rightarrow",[8594]],["RightArrow",[8594]],["Rightarrow",[8658]],["RightArrowLeftArrow",[8644]],["rightarrowtail",[8611]],["RightCeiling",[8969]],["RightDoubleBracket",[10215]],["RightDownTeeVector",[10589]],["RightDownVectorBar",[10581]],["RightDownVector",[8642]],["RightFloor",[8971]],["rightharpoondown",[8641]],["rightharpoonup",[8640]],["rightleftarrows",[8644]],["rightleftharpoons",[8652]],["rightrightarrows",[8649]],["rightsquigarrow",[8605]],["RightTeeArrow",[8614]],["RightTee",[8866]],["RightTeeVector",[10587]],["rightthreetimes",[8908]],["RightTriangleBar",[10704]],["RightTriangle",[8883]],["RightTriangleEqual",[8885]],["RightUpDownVector",[10575]],["RightUpTeeVector",[10588]],["RightUpVectorBar",[10580]],["RightUpVector",[8638]],["RightVectorBar",[10579]],["RightVector",[8640]],["ring",[730]],["risingdotseq",[8787]],["rlarr",[8644]],["rlhar",[8652]],["rlm",[8207]],["rmoustache",[9137]],["rmoust",[9137]],["rnmid",[10990]],["roang",[10221]],["roarr",[8702]],["robrk",[10215]],["ropar",[10630]],["ropf",[120163]],["Ropf",[8477]],["roplus",[10798]],["rotimes",[10805]],["RoundImplies",[10608]],["rpar",[41]],["rpargt",[10644]],["rppolint",[10770]],["rrarr",[8649]],["Rrightarrow",[8667]],["rsaquo",[8250]],["rscr",[120007]],["Rscr",[8475]],["rsh",[8625]],["Rsh",[8625]],["rsqb",[93]],["rsquo",[8217]],["rsquor",[8217]],["CloseCurlyQuote",[8217]],["rthree",[8908]],["rtimes",[8906]],["rtri",[9657]],["rtrie",[8885]],["rtrif",[9656]],["rtriltri",[10702]],["RuleDelayed",[10740]],["ruluhar",[10600]],["rx",[8478]],["Sacute",[346]],["sacute",[347]],["sbquo",[8218]],["scap",[10936]],["Scaron",[352]],["scaron",[353]],["Sc",[10940]],["sc",[8827]],["sccue",[8829]],["sce",[10928]],["scE",[10932]],["Scedil",[350]],["scedil",[351]],["Scirc",[348]],["scirc",[349]],["scnap",[10938]],["scnE",[10934]],["scnsim",[8937]],["scpolint",[10771]],["scsim",[8831]],["Scy",[1057]],["scy",[1089]],["sdotb",[8865]],["sdot",[8901]],["sdote",[10854]],["searhk",[10533]],["searr",[8600]],["seArr",[8664]],["searrow",[8600]],["sect",[167]],["semi",[59]],["seswar",[10537]],["setminus",[8726]],["setmn",[8726]],["sext",[10038]],["Sfr",[120086]],["sfr",[120112]],["sfrown",[8994]],["sharp",[9839]],["SHCHcy",[1065]],["shchcy",[1097]],["SHcy",[1064]],["shcy",[1096]],["ShortDownArrow",[8595]],["ShortLeftArrow",[8592]],["shortmid",[8739]],["shortparallel",[8741]],["ShortRightArrow",[8594]],["ShortUpArrow",[8593]],["shy",[173]],["Sigma",[931]],["sigma",[963]],["sigmaf",[962]],["sigmav",[962]],["sim",[8764]],["simdot",[10858]],["sime",[8771]],["simeq",[8771]],["simg",[10910]],["simgE",[10912]],["siml",[10909]],["simlE",[10911]],["simne",[8774]],["simplus",[10788]],["simrarr",[10610]],["slarr",[8592]],["SmallCircle",[8728]],["smallsetminus",[8726]],["smashp",[10803]],["smeparsl",[10724]],["smid",[8739]],["smile",[8995]],["smt",[10922]],["smte",[10924]],["smtes",[10924,65024]],["SOFTcy",[1068]],["softcy",[1100]],["solbar",[9023]],["solb",[10692]],["sol",[47]],["Sopf",[120138]],["sopf",[120164]],["spades",[9824]],["spadesuit",[9824]],["spar",[8741]],["sqcap",[8851]],["sqcaps",[8851,65024]],["sqcup",[8852]],["sqcups",[8852,65024]],["Sqrt",[8730]],["sqsub",[8847]],["sqsube",[8849]],["sqsubset",[8847]],["sqsubseteq",[8849]],["sqsup",[8848]],["sqsupe",[8850]],["sqsupset",[8848]],["sqsupseteq",[8850]],["square",[9633]],["Square",[9633]],["SquareIntersection",[8851]],["SquareSubset",[8847]],["SquareSubsetEqual",[8849]],["SquareSuperset",[8848]],["SquareSupersetEqual",[8850]],["SquareUnion",[8852]],["squarf",[9642]],["squ",[9633]],["squf",[9642]],["srarr",[8594]],["Sscr",[119982]],["sscr",[120008]],["ssetmn",[8726]],["ssmile",[8995]],["sstarf",[8902]],["Star",[8902]],["star",[9734]],["starf",[9733]],["straightepsilon",[1013]],["straightphi",[981]],["strns",[175]],["sub",[8834]],["Sub",[8912]],["subdot",[10941]],["subE",[10949]],["sube",[8838]],["subedot",[10947]],["submult",[10945]],["subnE",[10955]],["subne",[8842]],["subplus",[10943]],["subrarr",[10617]],["subset",[8834]],["Subset",[8912]],["subseteq",[8838]],["subseteqq",[10949]],["SubsetEqual",[8838]],["subsetneq",[8842]],["subsetneqq",[10955]],["subsim",[10951]],["subsub",[10965]],["subsup",[10963]],["succapprox",[10936]],["succ",[8827]],["succcurlyeq",[8829]],["Succeeds",[8827]],["SucceedsEqual",[10928]],["SucceedsSlantEqual",[8829]],["SucceedsTilde",[8831]],["succeq",[10928]],["succnapprox",[10938]],["succneqq",[10934]],["succnsim",[8937]],["succsim",[8831]],["SuchThat",[8715]],["sum",[8721]],["Sum",[8721]],["sung",[9834]],["sup1",[185]],["sup2",[178]],["sup3",[179]],["sup",[8835]],["Sup",[8913]],["supdot",[10942]],["supdsub",[10968]],["supE",[10950]],["supe",[8839]],["supedot",[10948]],["Superset",[8835]],["SupersetEqual",[8839]],["suphsol",[10185]],["suphsub",[10967]],["suplarr",[10619]],["supmult",[10946]],["supnE",[10956]],["supne",[8843]],["supplus",[10944]],["supset",[8835]],["Supset",[8913]],["supseteq",[8839]],["supseteqq",[10950]],["supsetneq",[8843]],["supsetneqq",[10956]],["supsim",[10952]],["supsub",[10964]],["supsup",[10966]],["swarhk",[10534]],["swarr",[8601]],["swArr",[8665]],["swarrow",[8601]],["swnwar",[10538]],["szlig",[223]],["Tab",[9]],["target",[8982]],["Tau",[932]],["tau",[964]],["tbrk",[9140]],["Tcaron",[356]],["tcaron",[357]],["Tcedil",[354]],["tcedil",[355]],["Tcy",[1058]],["tcy",[1090]],["tdot",[8411]],["telrec",[8981]],["Tfr",[120087]],["tfr",[120113]],["there4",[8756]],["therefore",[8756]],["Therefore",[8756]],["Theta",[920]],["theta",[952]],["thetasym",[977]],["thetav",[977]],["thickapprox",[8776]],["thicksim",[8764]],["ThickSpace",[8287,8202]],["ThinSpace",[8201]],["thinsp",[8201]],["thkap",[8776]],["thksim",[8764]],["THORN",[222]],["thorn",[254]],["tilde",[732]],["Tilde",[8764]],["TildeEqual",[8771]],["TildeFullEqual",[8773]],["TildeTilde",[8776]],["timesbar",[10801]],["timesb",[8864]],["times",[215]],["timesd",[10800]],["tint",[8749]],["toea",[10536]],["topbot",[9014]],["topcir",[10993]],["top",[8868]],["Topf",[120139]],["topf",[120165]],["topfork",[10970]],["tosa",[10537]],["tprime",[8244]],["trade",[8482]],["TRADE",[8482]],["triangle",[9653]],["triangledown",[9663]],["triangleleft",[9667]],["trianglelefteq",[8884]],["triangleq",[8796]],["triangleright",[9657]],["trianglerighteq",[8885]],["tridot",[9708]],["trie",[8796]],["triminus",[10810]],["TripleDot",[8411]],["triplus",[10809]],["trisb",[10701]],["tritime",[10811]],["trpezium",[9186]],["Tscr",[119983]],["tscr",[120009]],["TScy",[1062]],["tscy",[1094]],["TSHcy",[1035]],["tshcy",[1115]],["Tstrok",[358]],["tstrok",[359]],["twixt",[8812]],["twoheadleftarrow",[8606]],["twoheadrightarrow",[8608]],["Uacute",[218]],["uacute",[250]],["uarr",[8593]],["Uarr",[8607]],["uArr",[8657]],["Uarrocir",[10569]],["Ubrcy",[1038]],["ubrcy",[1118]],["Ubreve",[364]],["ubreve",[365]],["Ucirc",[219]],["ucirc",[251]],["Ucy",[1059]],["ucy",[1091]],["udarr",[8645]],["Udblac",[368]],["udblac",[369]],["udhar",[10606]],["ufisht",[10622]],["Ufr",[120088]],["ufr",[120114]],["Ugrave",[217]],["ugrave",[249]],["uHar",[10595]],["uharl",[8639]],["uharr",[8638]],["uhblk",[9600]],["ulcorn",[8988]],["ulcorner",[8988]],["ulcrop",[8975]],["ultri",[9720]],["Umacr",[362]],["umacr",[363]],["uml",[168]],["UnderBar",[95]],["UnderBrace",[9183]],["UnderBracket",[9141]],["UnderParenthesis",[9181]],["Union",[8899]],["UnionPlus",[8846]],["Uogon",[370]],["uogon",[371]],["Uopf",[120140]],["uopf",[120166]],["UpArrowBar",[10514]],["uparrow",[8593]],["UpArrow",[8593]],["Uparrow",[8657]],["UpArrowDownArrow",[8645]],["updownarrow",[8597]],["UpDownArrow",[8597]],["Updownarrow",[8661]],["UpEquilibrium",[10606]],["upharpoonleft",[8639]],["upharpoonright",[8638]],["uplus",[8846]],["UpperLeftArrow",[8598]],["UpperRightArrow",[8599]],["upsi",[965]],["Upsi",[978]],["upsih",[978]],["Upsilon",[933]],["upsilon",[965]],["UpTeeArrow",[8613]],["UpTee",[8869]],["upuparrows",[8648]],["urcorn",[8989]],["urcorner",[8989]],["urcrop",[8974]],["Uring",[366]],["uring",[367]],["urtri",[9721]],["Uscr",[119984]],["uscr",[120010]],["utdot",[8944]],["Utilde",[360]],["utilde",[361]],["utri",[9653]],["utrif",[9652]],["uuarr",[8648]],["Uuml",[220]],["uuml",[252]],["uwangle",[10663]],["vangrt",[10652]],["varepsilon",[1013]],["varkappa",[1008]],["varnothing",[8709]],["varphi",[981]],["varpi",[982]],["varpropto",[8733]],["varr",[8597]],["vArr",[8661]],["varrho",[1009]],["varsigma",[962]],["varsubsetneq",[8842,65024]],["varsubsetneqq",[10955,65024]],["varsupsetneq",[8843,65024]],["varsupsetneqq",[10956,65024]],["vartheta",[977]],["vartriangleleft",[8882]],["vartriangleright",[8883]],["vBar",[10984]],["Vbar",[10987]],["vBarv",[10985]],["Vcy",[1042]],["vcy",[1074]],["vdash",[8866]],["vDash",[8872]],["Vdash",[8873]],["VDash",[8875]],["Vdashl",[10982]],["veebar",[8891]],["vee",[8744]],["Vee",[8897]],["veeeq",[8794]],["vellip",[8942]],["verbar",[124]],["Verbar",[8214]],["vert",[124]],["Vert",[8214]],["VerticalBar",[8739]],["VerticalLine",[124]],["VerticalSeparator",[10072]],["VerticalTilde",[8768]],["VeryThinSpace",[8202]],["Vfr",[120089]],["vfr",[120115]],["vltri",[8882]],["vnsub",[8834,8402]],["vnsup",[8835,8402]],["Vopf",[120141]],["vopf",[120167]],["vprop",[8733]],["vrtri",[8883]],["Vscr",[119985]],["vscr",[120011]],["vsubnE",[10955,65024]],["vsubne",[8842,65024]],["vsupnE",[10956,65024]],["vsupne",[8843,65024]],["Vvdash",[8874]],["vzigzag",[10650]],["Wcirc",[372]],["wcirc",[373]],["wedbar",[10847]],["wedge",[8743]],["Wedge",[8896]],["wedgeq",[8793]],["weierp",[8472]],["Wfr",[120090]],["wfr",[120116]],["Wopf",[120142]],["wopf",[120168]],["wp",[8472]],["wr",[8768]],["wreath",[8768]],["Wscr",[119986]],["wscr",[120012]],["xcap",[8898]],["xcirc",[9711]],["xcup",[8899]],["xdtri",[9661]],["Xfr",[120091]],["xfr",[120117]],["xharr",[10231]],["xhArr",[10234]],["Xi",[926]],["xi",[958]],["xlarr",[10229]],["xlArr",[10232]],["xmap",[10236]],["xnis",[8955]],["xodot",[10752]],["Xopf",[120143]],["xopf",[120169]],["xoplus",[10753]],["xotime",[10754]],["xrarr",[10230]],["xrArr",[10233]],["Xscr",[119987]],["xscr",[120013]],["xsqcup",[10758]],["xuplus",[10756]],["xutri",[9651]],["xvee",[8897]],["xwedge",[8896]],["Yacute",[221]],["yacute",[253]],["YAcy",[1071]],["yacy",[1103]],["Ycirc",[374]],["ycirc",[375]],["Ycy",[1067]],["ycy",[1099]],["yen",[165]],["Yfr",[120092]],["yfr",[120118]],["YIcy",[1031]],["yicy",[1111]],["Yopf",[120144]],["yopf",[120170]],["Yscr",[119988]],["yscr",[120014]],["YUcy",[1070]],["yucy",[1102]],["yuml",[255]],["Yuml",[376]],["Zacute",[377]],["zacute",[378]],["Zcaron",[381]],["zcaron",[382]],["Zcy",[1047]],["zcy",[1079]],["Zdot",[379]],["zdot",[380]],["zeetrf",[8488]],["ZeroWidthSpace",[8203]],["Zeta",[918]],["zeta",[950]],["zfr",[120119]],["Zfr",[8488]],["ZHcy",[1046]],["zhcy",[1078]],["zigrarr",[8669]],["zopf",[120171]],["Zopf",[8484]],["Zscr",[119989]],["zscr",[120015]],["zwj",[8205]],["zwnj",[8204]]],o={},a={};!function(e,t){var r=n.length;for(;r--;){var o=n[r],a=o[0],i=o[1],l=i[0],u=l<32||l>126||62===l||60===l||38===l||34===l||39===l,c=void 0;if(u&&(c=t[l]=t[l]||{}),i[1]){var s=i[1];e[a]=String.fromCharCode(l)+String.fromCharCode(s),u&&(c[s]=a)}else e[a]=String.fromCharCode(l),u&&(c[""]=a)}}(o,a);var i=function(){function e(){}return e.prototype.decode=function(e){return e&&e.length?e.replace(/&(#?[\\w\\d]+);?/g,(function(e,t){var r;if("#"===t.charAt(0)){var n="x"===t.charAt(1)?parseInt(t.substr(2).toLowerCase(),16):parseInt(t.substr(1));isNaN(n)||n<-32768||n>65535||(r=String.fromCharCode(n))}else r=o[t];return r||e})):""},e.decode=function(t){return(new e).decode(t)},e.prototype.encode=function(e){if(!e||!e.length)return"";for(var t=e.length,r="",n=0;n<t;){var o=a[e.charCodeAt(n)];if(o){var i=o[e.charCodeAt(n+1)];if(i?n++:i=o[""],i){r+="&"+i+";",n++;continue}}r+=e.charAt(n),n++}return r},e.encode=function(t){return(new e).encode(t)},e.prototype.encodeNonUTF=function(e){if(!e||!e.length)return"";for(var t=e.length,r="",n=0;n<t;){var o=e.charCodeAt(n),i=a[o];if(i){var l=i[e.charCodeAt(n+1)];if(l?n++:l=i[""],l){r+="&"+l+";",n++;continue}}r+=o<32||o>126?"&#"+o+";":e.charAt(n),n++}return r},e.encodeNonUTF=function(t){return(new e).encodeNonUTF(t)},e.prototype.encodeNonASCII=function(e){if(!e||!e.length)return"";for(var t=e.length,r="",n=0;n<t;){var o=e.charCodeAt(n);o<=255?r+=e[n++]:(r+="&#"+o+";",n++)}return r},e.encodeNonASCII=function(t){return(new e).encodeNonASCII(t)},e}();t.Html5Entities=i},function(e,t,r){"use strict";var n=r(52),o=r(193);Object.defineProperty(t,"__esModule",{value:!0}),t.shouldHighlight=b,t.getChalk=w,t.default=function(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};if(b(t)){var r=w(t),n=f(r);return y(n,e)}return e};var a,i=function(e){if(e&&e.__esModule)return e;if(null===e||"object"!==typeof e&&"function"!==typeof e)return{default:e};var t=c();if(t&&t.has(e))return t.get(e);var r={},n=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var o in e)if(Object.prototype.hasOwnProperty.call(e,o)){var a=n?Object.getOwnPropertyDescriptor(e,o):null;a&&(a.get||a.set)?Object.defineProperty(r,o,a):r[o]=e[o]}r.default=e,t&&t.set(e,r);return r}(r(195)),l=r(196),u=(a=r(199))&&a.__esModule?a:{default:a};function c(){if("function"!==typeof WeakMap)return null;var e=new WeakMap;return c=function(){return e},e}var s=new Set(["as","async","from","get","of","set"]);function f(e){return{keyword:e.cyan,capitalized:e.yellow,jsxIdentifier:e.yellow,punctuator:e.yellow,number:e.magenta,string:e.green,regex:e.magenta,comment:e.grey,invalid:e.white.bgRed.bold}}var d,p=/\\r\\n|[\\n\\r\\u2028\\u2029]/,h=/^[()[\\]{}]$/,g=i.matchToToken,v=/^[a-z][\\w-]*$/i,m=function(e,t,r){if("name"===e.type){if((0,l.isKeyword)(e.value)||(0,l.isStrictReservedWord)(e.value,!0)||s.has(e.value))return"keyword";if(v.test(e.value)&&("<"===r[t-1]||"</"==r.substr(t-2,2)))return"jsxIdentifier";if(e.value[0]!==e.value[0].toLowerCase())return"capitalized"}return"punctuator"===e.type&&h.test(e.value)?"bracket":"invalid"!==e.type||"@"!==e.value&&"#"!==e.value?e.type:"punctuator"};function y(e,t){var r,o="",a=n(d(t));try{var i=function(){var t=r.value,n=t.type,a=t.value,i=e[n];o+=i?a.split(p).map((function(e){return i(e)})).join("\\n"):a};for(a.s();!(r=a.n()).done;)i()}catch(e){a.e(e)}finally{a.f()}return o}function b(e){return u.default.supportsColor||e.forceColor}function w(e){var t=u.default;return e.forceColor&&(t=new u.default.constructor({enabled:!0,level:1})),t}d=o.mark((function e(t){var r,n;return o.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:if(!(r=i.default.exec(t))){e.next=6;break}return n=g(r),e.next=4,{type:m(n,r.index,t),value:n.value};case 4:e.next=0;break;case 6:case"end":return e.stop()}}),e)}))},function(e,t,r){var n=r(192);e.exports=function(e,t){if(e){if("string"===typeof e)return n(e,t);var r=Object.prototype.toString.call(e).slice(8,-1);return"Object"===r&&e.constructor&&(r=e.constructor.name),"Map"===r||"Set"===r?Array.from(e):"Arguments"===r||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)?n(e,t):void 0}}},function(e,t){e.exports=function(e,t){(null==t||t>e.length)&&(t=e.length);for(var r=0,n=new Array(t);r<t;r++)n[r]=e[r];return n}},function(e,t,r){e.exports=r(194)},function(e,t,r){var n=function(e){"use strict";var t,r=Object.prototype,n=r.hasOwnProperty,o="function"===typeof Symbol?Symbol:{},a=o.iterator||"@@iterator",i=o.asyncIterator||"@@asyncIterator",l=o.toStringTag||"@@toStringTag";function u(e,t,r){return Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}),e[t]}try{u({},"")}catch(e){u=function(e,t,r){return e[t]=r}}function c(e,t,r,n){var o=t&&t.prototype instanceof v?t:v,a=Object.create(o.prototype),i=new O(n||[]);return a._invoke=function(e,t,r){var n=f;return function(o,a){if(n===p)throw new Error("Generator is already running");if(n===h){if("throw"===o)throw a;return R()}for(r.method=o,r.arg=a;;){var i=r.delegate;if(i){var l=_(i,r);if(l){if(l===g)continue;return l}}if("next"===r.method)r.sent=r._sent=r.arg;else if("throw"===r.method){if(n===f)throw n=h,r.arg;r.dispatchException(r.arg)}else"return"===r.method&&r.abrupt("return",r.arg);n=p;var u=s(e,t,r);if("normal"===u.type){if(n=r.done?h:d,u.arg===g)continue;return{value:u.arg,done:r.done}}"throw"===u.type&&(n=h,r.method="throw",r.arg=u.arg)}}}(e,r,i),a}function s(e,t,r){try{return{type:"normal",arg:e.call(t,r)}}catch(e){return{type:"throw",arg:e}}}e.wrap=c;var f="suspendedStart",d="suspendedYield",p="executing",h="completed",g={};function v(){}function m(){}function y(){}var b={};b[a]=function(){return this};var w=Object.getPrototypeOf,k=w&&w(w(P([])));k&&k!==r&&n.call(k,a)&&(b=k);var E=y.prototype=v.prototype=Object.create(b);function x(e){["next","throw","return"].forEach((function(t){u(e,t,(function(e){return this._invoke(t,e)}))}))}function S(e,t){function r(o,a,i,l){var u=s(e[o],e,a);if("throw"!==u.type){var c=u.arg,f=c.value;return f&&"object"===typeof f&&n.call(f,"__await")?t.resolve(f.__await).then((function(e){r("next",e,i,l)}),(function(e){r("throw",e,i,l)})):t.resolve(f).then((function(e){c.value=e,i(c)}),(function(e){return r("throw",e,i,l)}))}l(u.arg)}var o;this._invoke=function(e,n){function a(){return new t((function(t,o){r(e,n,t,o)}))}return o=o?o.then(a,a):a()}}function _(e,r){var n=e.iterator[r.method];if(n===t){if(r.delegate=null,"throw"===r.method){if(e.iterator.return&&(r.method="return",r.arg=t,_(e,r),"throw"===r.method))return g;r.method="throw",r.arg=new TypeError("The iterator does not provide a \'throw\' method")}return g}var o=s(n,e.iterator,r.arg);if("throw"===o.type)return r.method="throw",r.arg=o.arg,r.delegate=null,g;var a=o.arg;return a?a.done?(r[e.resultName]=a.value,r.next=e.nextLoc,"return"!==r.method&&(r.method="next",r.arg=t),r.delegate=null,g):a:(r.method="throw",r.arg=new TypeError("iterator result is not an object"),r.delegate=null,g)}function T(e){var t={tryLoc:e[0]};1 in e&&(t.catchLoc=e[1]),2 in e&&(t.finallyLoc=e[2],t.afterLoc=e[3]),this.tryEntries.push(t)}function C(e){var t=e.completion||{};t.type="normal",delete t.arg,e.completion=t}function O(e){this.tryEntries=[{tryLoc:"root"}],e.forEach(T,this),this.reset(!0)}function P(e){if(e){var r=e[a];if(r)return r.call(e);if("function"===typeof e.next)return e;if(!isNaN(e.length)){var o=-1,i=function r(){for(;++o<e.length;)if(n.call(e,o))return r.value=e[o],r.done=!1,r;return r.value=t,r.done=!0,r};return i.next=i}}return{next:R}}function R(){return{value:t,done:!0}}return m.prototype=E.constructor=y,y.constructor=m,m.displayName=u(y,l,"GeneratorFunction"),e.isGeneratorFunction=function(e){var t="function"===typeof e&&e.constructor;return!!t&&(t===m||"GeneratorFunction"===(t.displayName||t.name))},e.mark=function(e){return Object.setPrototypeOf?Object.setPrototypeOf(e,y):(e.__proto__=y,u(e,l,"GeneratorFunction")),e.prototype=Object.create(E),e},e.awrap=function(e){return{__await:e}},x(S.prototype),S.prototype[i]=function(){return this},e.AsyncIterator=S,e.async=function(t,r,n,o,a){void 0===a&&(a=Promise);var i=new S(c(t,r,n,o),a);return e.isGeneratorFunction(r)?i:i.next().then((function(e){return e.done?e.value:i.next()}))},x(E),u(E,l,"Generator"),E[a]=function(){return this},E.toString=function(){return"[object Generator]"},e.keys=function(e){var t=[];for(var r in e)t.push(r);return t.reverse(),function r(){for(;t.length;){var n=t.pop();if(n in e)return r.value=n,r.done=!1,r}return r.done=!0,r}},e.values=P,O.prototype={constructor:O,reset:function(e){if(this.prev=0,this.next=0,this.sent=this._sent=t,this.done=!1,this.delegate=null,this.method="next",this.arg=t,this.tryEntries.forEach(C),!e)for(var r in this)"t"===r.charAt(0)&&n.call(this,r)&&!isNaN(+r.slice(1))&&(this[r]=t)},stop:function(){this.done=!0;var e=this.tryEntries[0].completion;if("throw"===e.type)throw e.arg;return this.rval},dispatchException:function(e){if(this.done)throw e;var r=this;function o(n,o){return l.type="throw",l.arg=e,r.next=n,o&&(r.method="next",r.arg=t),!!o}for(var a=this.tryEntries.length-1;a>=0;--a){var i=this.tryEntries[a],l=i.completion;if("root"===i.tryLoc)return o("end");if(i.tryLoc<=this.prev){var u=n.call(i,"catchLoc"),c=n.call(i,"finallyLoc");if(u&&c){if(this.prev<i.catchLoc)return o(i.catchLoc,!0);if(this.prev<i.finallyLoc)return o(i.finallyLoc)}else if(u){if(this.prev<i.catchLoc)return o(i.catchLoc,!0)}else{if(!c)throw new Error("try statement without catch or finally");if(this.prev<i.finallyLoc)return o(i.finallyLoc)}}}},abrupt:function(e,t){for(var r=this.tryEntries.length-1;r>=0;--r){var o=this.tryEntries[r];if(o.tryLoc<=this.prev&&n.call(o,"finallyLoc")&&this.prev<o.finallyLoc){var a=o;break}}a&&("break"===e||"continue"===e)&&a.tryLoc<=t&&t<=a.finallyLoc&&(a=null);var i=a?a.completion:{};return i.type=e,i.arg=t,a?(this.method="next",this.next=a.finallyLoc,g):this.complete(i)},complete:function(e,t){if("throw"===e.type)throw e.arg;return"break"===e.type||"continue"===e.type?this.next=e.arg:"return"===e.type?(this.rval=this.arg=e.arg,this.method="return",this.next="end"):"normal"===e.type&&t&&(this.next=t),g},finish:function(e){for(var t=this.tryEntries.length-1;t>=0;--t){var r=this.tryEntries[t];if(r.finallyLoc===e)return this.complete(r.completion,r.afterLoc),C(r),g}},catch:function(e){for(var t=this.tryEntries.length-1;t>=0;--t){var r=this.tryEntries[t];if(r.tryLoc===e){var n=r.completion;if("throw"===n.type){var o=n.arg;C(r)}return o}}throw new Error("illegal catch attempt")},delegateYield:function(e,r,n){return this.delegate={iterator:P(e),resultName:r,nextLoc:n},"next"===this.method&&(this.arg=t),g}},e}(e.exports);try{regeneratorRuntime=n}catch(e){Function("r","regeneratorRuntime = r")(n)}},function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.default=/(([\'"])(?:(?!\\2|\\\\).|\\\\(?:\\r\\n|[\\s\\S]))*(\\2)?|`(?:[^`\\\\$]|\\\\[\\s\\S]|\\$(?!\\{)|\\$\\{(?:[^{}]|\\{[^}]*\\}?)*\\}?)*(`)?)|(\\/\\/.*)|(\\/\\*(?:[^*]|\\*(?!\\/))*(\\*\\/)?)|(\\/(?!\\*)(?:\\[(?:(?![\\]\\\\]).|\\\\.)*\\]|(?![\\/\\]\\\\]).|\\\\.)+\\/(?:(?!\\s*(?:\\b|[\\u0080-\\uFFFF$\\\\\'"~({]|[+\\-!](?!=)|\\.?\\d))|[gmiyus]{1,6}\\b(?![\\u0080-\\uFFFF$\\\\]|\\s*(?:[+\\-*%&|^<>!=?({]|\\/(?![\\/*])))))|(0[xX][\\da-fA-F]+|0[oO][0-7]+|0[bB][01]+|(?:\\d*\\.\\d+|\\d+\\.?)(?:[eE][+-]?\\d+)?)|((?!\\d)(?:(?!\\s)[$\\w\\u0080-\\uFFFF]|\\\\u[\\da-fA-F]{4}|\\\\u\\{[\\da-fA-F]+\\})+)|(--|\\+\\+|&&|\\|\\||=>|\\.{3}|(?:[+\\-\\/%&|^]|\\*{1,2}|<{1,2}|>{1,3}|!=?|={1,2})=?|[?~.,:;[\\](){}])|(\\s+)|(^$|[\\s\\S])/g,t.matchToToken=function(e){var t={type:"invalid",value:e[0],closed:void 0};return e[1]?(t.type="string",t.closed=!(!e[3]&&!e[4])):e[5]?t.type="comment":e[6]?(t.type="comment",t.closed=!!e[7]):e[8]?t.type="regex":e[9]?t.type="number":e[10]?t.type="name":e[11]?t.type="punctuator":e[12]&&(t.type="whitespace"),t}},function(e,t,r){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"isIdentifierName",{enumerable:!0,get:function(){return n.isIdentifierName}}),Object.defineProperty(t,"isIdentifierChar",{enumerable:!0,get:function(){return n.isIdentifierChar}}),Object.defineProperty(t,"isIdentifierStart",{enumerable:!0,get:function(){return n.isIdentifierStart}}),Object.defineProperty(t,"isReservedWord",{enumerable:!0,get:function(){return o.isReservedWord}}),Object.defineProperty(t,"isStrictBindOnlyReservedWord",{enumerable:!0,get:function(){return o.isStrictBindOnlyReservedWord}}),Object.defineProperty(t,"isStrictBindReservedWord",{enumerable:!0,get:function(){return o.isStrictBindReservedWord}}),Object.defineProperty(t,"isStrictReservedWord",{enumerable:!0,get:function(){return o.isStrictReservedWord}}),Object.defineProperty(t,"isKeyword",{enumerable:!0,get:function(){return o.isKeyword}});var n=r(197),o=r(198)},function(e,t,r){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.isIdentifierStart=s,t.isIdentifierChar=f,t.isIdentifierName=function(e){for(var t=!0,r=0,n=Array.from(e);r<n.length;r++){var o=n[r].codePointAt(0);if(t){if(!s(o))return!1;t=!1}else if(!f(o))return!1}return!t};var n="\xaa\xb5\xba\xc0-\xd6\xd8-\xf6\xf8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u08A0-\u08B4\u08B6-\u08C7\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u170C\u170E-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1878\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C88\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2118-\u211D\u2124\u2126\u2128\u212A-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309B-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\u9FFC\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7BF\uA7C2-\uA7CA\uA7F5-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC",o="\u200C\u200D\xb7\u0300-\u036F\u0387\u0483-\u0487\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u0610-\u061A\u064B-\u0669\u0670\u06D6-\u06DC\u06DF-\u06E4\u06E7\u06E8\u06EA-\u06ED\u06F0-\u06F9\u0711\u0730-\u074A\u07A6-\u07B0\u07C0-\u07C9\u07EB-\u07F3\u07FD\u0816-\u0819\u081B-\u0823\u0825-\u0827\u0829-\u082D\u0859-\u085B\u08D3-\u08E1\u08E3-\u0903\u093A-\u093C\u093E-\u094F\u0951-\u0957\u0962\u0963\u0966-\u096F\u0981-\u0983\u09BC\u09BE-\u09C4\u09C7\u09C8\u09CB-\u09CD\u09D7\u09E2\u09E3\u09E6-\u09EF\u09FE\u0A01-\u0A03\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A66-\u0A71\u0A75\u0A81-\u0A83\u0ABC\u0ABE-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AE2\u0AE3\u0AE6-\u0AEF\u0AFA-\u0AFF\u0B01-\u0B03\u0B3C\u0B3E-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B55-\u0B57\u0B62\u0B63\u0B66-\u0B6F\u0B82\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD7\u0BE6-\u0BEF\u0C00-\u0C04\u0C3E-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C62\u0C63\u0C66-\u0C6F\u0C81-\u0C83\u0CBC\u0CBE-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CE2\u0CE3\u0CE6-\u0CEF\u0D00-\u0D03\u0D3B\u0D3C\u0D3E-\u0D44\u0D46-\u0D48\u0D4A-\u0D4D\u0D57\u0D62\u0D63\u0D66-\u0D6F\u0D81-\u0D83\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DE6-\u0DEF\u0DF2\u0DF3\u0E31\u0E34-\u0E3A\u0E47-\u0E4E\u0E50-\u0E59\u0EB1\u0EB4-\u0EBC\u0EC8-\u0ECD\u0ED0-\u0ED9\u0F18\u0F19\u0F20-\u0F29\u0F35\u0F37\u0F39\u0F3E\u0F3F\u0F71-\u0F84\u0F86\u0F87\u0F8D-\u0F97\u0F99-\u0FBC\u0FC6\u102B-\u103E\u1040-\u1049\u1056-\u1059\u105E-\u1060\u1062-\u1064\u1067-\u106D\u1071-\u1074\u1082-\u108D\u108F-\u109D\u135D-\u135F\u1369-\u1371\u1712-\u1714\u1732-\u1734\u1752\u1753\u1772\u1773\u17B4-\u17D3\u17DD\u17E0-\u17E9\u180B-\u180D\u1810-\u1819\u18A9\u1920-\u192B\u1930-\u193B\u1946-\u194F\u19D0-\u19DA\u1A17-\u1A1B\u1A55-\u1A5E\u1A60-\u1A7C\u1A7F-\u1A89\u1A90-\u1A99\u1AB0-\u1ABD\u1ABF\u1AC0\u1B00-\u1B04\u1B34-\u1B44\u1B50-\u1B59\u1B6B-\u1B73\u1B80-\u1B82\u1BA1-\u1BAD\u1BB0-\u1BB9\u1BE6-\u1BF3\u1C24-\u1C37\u1C40-\u1C49\u1C50-\u1C59\u1CD0-\u1CD2\u1CD4-\u1CE8\u1CED\u1CF4\u1CF7-\u1CF9\u1DC0-\u1DF9\u1DFB-\u1DFF\u203F\u2040\u2054\u20D0-\u20DC\u20E1\u20E5-\u20F0\u2CEF-\u2CF1\u2D7F\u2DE0-\u2DFF\u302A-\u302F\u3099\u309A\uA620-\uA629\uA66F\uA674-\uA67D\uA69E\uA69F\uA6F0\uA6F1\uA802\uA806\uA80B\uA823-\uA827\uA82C\uA880\uA881\uA8B4-\uA8C5\uA8D0-\uA8D9\uA8E0-\uA8F1\uA8FF-\uA909\uA926-\uA92D\uA947-\uA953\uA980-\uA983\uA9B3-\uA9C0\uA9D0-\uA9D9\uA9E5\uA9F0-\uA9F9\uAA29-\uAA36\uAA43\uAA4C\uAA4D\uAA50-\uAA59\uAA7B-\uAA7D\uAAB0\uAAB2-\uAAB4\uAAB7\uAAB8\uAABE\uAABF\uAAC1\uAAEB-\uAAEF\uAAF5\uAAF6\uABE3-\uABEA\uABEC\uABED\uABF0-\uABF9\uFB1E\uFE00-\uFE0F\uFE20-\uFE2F\uFE33\uFE34\uFE4D-\uFE4F\uFF10-\uFF19\uFF3F",a=new RegExp("["+n+"]"),i=new RegExp("["+n+o+"]");n=o=null;var l=[0,11,2,25,2,18,2,1,2,14,3,13,35,122,70,52,268,28,4,48,48,31,14,29,6,37,11,29,3,35,5,7,2,4,43,157,19,35,5,35,5,39,9,51,157,310,10,21,11,7,153,5,3,0,2,43,2,1,4,0,3,22,11,22,10,30,66,18,2,1,11,21,11,25,71,55,7,1,65,0,16,3,2,2,2,28,43,28,4,28,36,7,2,27,28,53,11,21,11,18,14,17,111,72,56,50,14,50,14,35,349,41,7,1,79,28,11,0,9,21,107,20,28,22,13,52,76,44,33,24,27,35,30,0,3,0,9,34,4,0,13,47,15,3,22,0,2,0,36,17,2,24,85,6,2,0,2,3,2,14,2,9,8,46,39,7,3,1,3,21,2,6,2,1,2,4,4,0,19,0,13,4,159,52,19,3,21,2,31,47,21,1,2,0,185,46,42,3,37,47,21,0,60,42,14,0,72,26,230,43,117,63,32,7,3,0,3,7,2,1,2,23,16,0,2,0,95,7,3,38,17,0,2,0,29,0,11,39,8,0,22,0,12,45,20,0,35,56,264,8,2,36,18,0,50,29,113,6,2,1,2,37,22,0,26,5,2,1,2,31,15,0,328,18,190,0,80,921,103,110,18,195,2749,1070,4050,582,8634,568,8,30,114,29,19,47,17,3,32,20,6,18,689,63,129,74,6,0,67,12,65,1,2,0,29,6135,9,1237,43,8,8952,286,50,2,18,3,9,395,2309,106,6,12,4,8,8,9,5991,84,2,70,2,1,3,0,3,1,3,3,2,11,2,0,2,6,2,64,2,3,3,7,2,6,2,27,2,3,2,4,2,0,4,6,2,339,3,24,2,24,2,30,2,24,2,30,2,24,2,30,2,24,2,30,2,24,2,7,2357,44,11,6,17,0,370,43,1301,196,60,67,8,0,1205,3,2,26,2,1,2,0,3,0,2,9,2,3,2,0,2,0,7,0,5,0,2,0,2,0,2,2,2,1,2,0,3,0,2,0,2,0,2,0,2,0,2,1,2,0,3,3,2,6,2,3,2,3,2,0,2,9,2,16,6,2,2,4,2,16,4421,42717,35,4148,12,221,3,5761,15,7472,3104,541,1507,4938],u=[509,0,227,0,150,4,294,9,1368,2,2,1,6,3,41,2,5,0,166,1,574,3,9,9,370,1,154,10,176,2,54,14,32,9,16,3,46,10,54,9,7,2,37,13,2,9,6,1,45,0,13,2,49,13,9,3,2,11,83,11,7,0,161,11,6,9,7,3,56,1,2,6,3,1,3,2,10,0,11,1,3,6,4,4,193,17,10,9,5,0,82,19,13,9,214,6,3,8,28,1,83,16,16,9,82,12,9,9,84,14,5,9,243,14,166,9,71,5,2,1,3,3,2,0,2,1,13,9,120,6,3,6,4,0,29,9,41,6,2,3,9,0,10,10,47,15,406,7,2,7,17,9,57,21,2,13,123,5,4,0,2,1,2,6,2,0,9,9,49,4,2,1,2,4,9,9,330,3,19306,9,135,4,60,6,26,9,1014,0,2,54,8,3,82,0,12,1,19628,1,5319,4,4,5,9,7,3,6,31,3,149,2,1418,49,513,54,5,49,9,0,15,0,23,4,2,14,1361,6,2,16,3,6,2,1,2,4,262,6,10,9,419,13,1495,6,110,6,6,9,4759,9,787719,239];function c(e,t){for(var r=65536,n=0,o=t.length;n<o;n+=2){if((r+=t[n])>e)return!1;if((r+=t[n+1])>=e)return!0}return!1}function s(e){return e<65?36===e:e<=90||(e<97?95===e:e<=122||(e<=65535?e>=170&&a.test(String.fromCharCode(e)):c(e,l)))}function f(e){return e<48?36===e:e<58||!(e<65)&&(e<=90||(e<97?95===e:e<=122||(e<=65535?e>=170&&i.test(String.fromCharCode(e)):c(e,l)||c(e,u))))}},function(e,t,r){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.isReservedWord=u,t.isStrictReservedWord=c,t.isStrictBindOnlyReservedWord=s,t.isStrictBindReservedWord=function(e,t){return c(e,t)||s(e)},t.isKeyword=function(e){return a.has(e)};var n=["implements","interface","let","package","private","protected","public","static","yield"],o=["eval","arguments"],a=new Set(["break","case","catch","continue","debugger","default","do","else","finally","for","function","if","return","switch","throw","try","var","const","while","with","new","this","super","class","extends","export","import","null","true","false","in","instanceof","typeof","void","delete"]),i=new Set(n),l=new Set(o);function u(e,t){return t&&"await"===e||"enum"===e}function c(e,t){return u(e,t)||i.has(e)}function s(e){return l.has(e)}},function(e,t,r){"use strict";(function(t){var n=r(52),o=r(200),a=r(201),i=r(206).stdout,l=r(207),u="win32"===t.platform&&!(Object({NODE_ENV:"production"}).TERM||"").toLowerCase().startsWith("xterm"),c=["ansi","ansi","ansi256","ansi16m"],s=new Set(["gray"]),f=Object.create(null);function d(e,t){t=t||{};var r=i?i.level:0;e.level=void 0===t.level?r:t.level,e.enabled="enabled"in t?t.enabled:e.level>0}function p(e){if(!this||!(this instanceof p)||this.template){var t={};return d(t,e),t.template=function(){var e=[].slice.call(arguments);return T.apply(null,[t.template].concat(e))},Object.setPrototypeOf(t,p.prototype),Object.setPrototypeOf(t.template,t),t.template.constructor=p,t.template}d(this,e)}u&&(a.blue.open="\x1b[94m");for(var h=function(){var e=v[g];a[e].closeRe=new RegExp(o(a[e].close),"g"),f[e]={get:function(){var t=a[e];return S.call(this,this._styles?this._styles.concat(t):[t],this._empty,e)}}},g=0,v=Object.keys(a);g<v.length;g++)h();f.visible={get:function(){return S.call(this,this._styles||[],!0,"visible")}},a.color.closeRe=new RegExp(o(a.color.close),"g");for(var m=function(){var e=b[y];if(s.has(e))return"continue";f[e]={get:function(){var t=this.level;return function(){var r=a.color[c[t]][e].apply(null,arguments),n={open:r,close:a.color.close,closeRe:a.color.closeRe};return S.call(this,this._styles?this._styles.concat(n):[n],this._empty,e)}}}},y=0,b=Object.keys(a.color.ansi);y<b.length;y++)m();a.bgColor.closeRe=new RegExp(o(a.bgColor.close),"g");for(var w=function(){var e=E[k];if(s.has(e))return"continue";var t="bg"+e[0].toUpperCase()+e.slice(1);f[t]={get:function(){var t=this.level;return function(){var r=a.bgColor[c[t]][e].apply(null,arguments),n={open:r,close:a.bgColor.close,closeRe:a.bgColor.closeRe};return S.call(this,this._styles?this._styles.concat(n):[n],this._empty,e)}}}},k=0,E=Object.keys(a.bgColor.ansi);k<E.length;k++)w();var x=Object.defineProperties((function(){}),f);function S(e,t,r){var n=function e(){return _.apply(e,arguments)};n._styles=e,n._empty=t;var o=this;return Object.defineProperty(n,"level",{enumerable:!0,get:function(){return o.level},set:function(e){o.level=e}}),Object.defineProperty(n,"enabled",{enumerable:!0,get:function(){return o.enabled},set:function(e){o.enabled=e}}),n.hasGrey=this.hasGrey||"gray"===r||"grey"===r,n.__proto__=x,n}function _(){var e=arguments,t=e.length,r=String(arguments[0]);if(0===t)return"";if(t>1)for(var o=1;o<t;o++)r+=" "+e[o];if(!this.enabled||this.level<=0||!r)return this._empty?"":r;var i=a.dim.open;u&&this.hasGrey&&(a.dim.open="");var l,c=n(this._styles.slice().reverse());try{for(c.s();!(l=c.n()).done;){var s=l.value;r=(r=s.open+r.replace(s.closeRe,s.open)+s.close).replace(/\\r?\\n/g,"".concat(s.close,"$&").concat(s.open))}}catch(e){c.e(e)}finally{c.f()}return a.dim.open=i,r}function T(e,t){if(!Array.isArray(t))return[].slice.call(arguments,1).join(" ");for(var r=[].slice.call(arguments,2),n=[t.raw[0]],o=1;o<t.length;o++)n.push(String(r[o-1]).replace(/[{}\\\\]/g,"\\\\$&")),n.push(String(t.raw[o]));return l(e,n.join(""))}Object.defineProperties(p.prototype,f),e.exports=p(),e.exports.supportsColor=i,e.exports.default=e.exports}).call(this,r(51))},function(e,t,r){"use strict";var n=/[|\\\\{}()[\\]^$+*?.]/g;e.exports=function(e){if("string"!==typeof e)throw new TypeError("Expected a string");return e.replace(n,"\\\\$&")}},function(e,t,r){"use strict";(function(e){var t=r(203),n=function(e,r){return function(){var n=e.apply(t,arguments);return"\x1b[".concat(n+r,"m")}},o=function(e,r){return function(){var n=e.apply(t,arguments);return"\x1b[".concat(38+r,";5;").concat(n,"m")}},a=function(e,r){return function(){var n=e.apply(t,arguments);return"\x1b[".concat(38+r,";2;").concat(n[0],";").concat(n[1],";").concat(n[2],"m")}};Object.defineProperty(e,"exports",{enumerable:!0,get:function(){var e=new Map,r={modifier:{reset:[0,0],bold:[1,22],dim:[2,22],italic:[3,23],underline:[4,24],inverse:[7,27],hidden:[8,28],strikethrough:[9,29]},color:{black:[30,39],red:[31,39],green:[32,39],yellow:[33,39],blue:[34,39],magenta:[35,39],cyan:[36,39],white:[37,39],gray:[90,39],redBright:[91,39],greenBright:[92,39],yellowBright:[93,39],blueBright:[94,39],magentaBright:[95,39],cyanBright:[96,39],whiteBright:[97,39]},bgColor:{bgBlack:[40,49],bgRed:[41,49],bgGreen:[42,49],bgYellow:[43,49],bgBlue:[44,49],bgMagenta:[45,49],bgCyan:[46,49],bgWhite:[47,49],bgBlackBright:[100,49],bgRedBright:[101,49],bgGreenBright:[102,49],bgYellowBright:[103,49],bgBlueBright:[104,49],bgMagentaBright:[105,49],bgCyanBright:[106,49],bgWhiteBright:[107,49]}};r.color.grey=r.color.gray;for(var i=0,l=Object.keys(r);i<l.length;i++){for(var u=l[i],c=r[u],s=0,f=Object.keys(c);s<f.length;s++){var d=f[s],p=c[d];r[d]={open:"\x1b[".concat(p[0],"m"),close:"\x1b[".concat(p[1],"m")},c[d]=r[d],e.set(p[0],p[1])}Object.defineProperty(r,u,{value:c,enumerable:!1}),Object.defineProperty(r,"codes",{value:e,enumerable:!1})}var h=function(e){return e},g=function(e,t,r){return[e,t,r]};r.color.close="\x1b[39m",r.bgColor.close="\x1b[49m",r.color.ansi={ansi:n(h,0)},r.color.ansi256={ansi256:o(h,0)},r.color.ansi16m={rgb:a(g,0)},r.bgColor.ansi={ansi:n(h,10)},r.bgColor.ansi256={ansi256:o(h,10)},r.bgColor.ansi16m={rgb:a(g,10)};for(var v=0,m=Object.keys(t);v<m.length;v++){var y=m[v];if("object"===typeof t[y]){var b=t[y];"ansi16"===y&&(y="ansi"),"ansi16"in b&&(r.color.ansi[y]=n(b.ansi16,0),r.bgColor.ansi[y]=n(b.ansi16,10)),"ansi256"in b&&(r.color.ansi256[y]=o(b.ansi256,0),r.bgColor.ansi256[y]=o(b.ansi256,10)),"rgb"in b&&(r.color.ansi16m[y]=a(b.rgb,0),r.bgColor.ansi16m[y]=a(b.rgb,10))}}return r}})}).call(this,r(202)(e))},function(e,t){e.exports=function(e){return e.webpackPolyfill||(e.deprecate=function(){},e.paths=[],e.children||(e.children=[]),Object.defineProperty(e,"loaded",{enumerable:!0,get:function(){return e.l}}),Object.defineProperty(e,"id",{enumerable:!0,get:function(){return e.i}}),e.webpackPolyfill=1),e}},function(e,t,r){var n=r(87),o=r(205),a={};Object.keys(n).forEach((function(e){a[e]={},Object.defineProperty(a[e],"channels",{value:n[e].channels}),Object.defineProperty(a[e],"labels",{value:n[e].labels});var t=o(e);Object.keys(t).forEach((function(r){var n=t[r];a[e][r]=function(e){var t=function(t){if(void 0===t||null===t)return t;arguments.length>1&&(t=Array.prototype.slice.call(arguments));var r=e(t);if("object"===typeof r)for(var n=r.length,o=0;o<n;o++)r[o]=Math.round(r[o]);return r};return"conversion"in e&&(t.conversion=e.conversion),t}(n),a[e][r].raw=function(e){var t=function(t){return void 0===t||null===t?t:(arguments.length>1&&(t=Array.prototype.slice.call(arguments)),e(t))};return"conversion"in e&&(t.conversion=e.conversion),t}(n)}))})),e.exports=a},function(e,t,r){"use strict";e.exports={aliceblue:[240,248,255],antiquewhite:[250,235,215],aqua:[0,255,255],aquamarine:[127,255,212],azure:[240,255,255],beige:[245,245,220],bisque:[255,228,196],black:[0,0,0],blanchedalmond:[255,235,205],blue:[0,0,255],blueviolet:[138,43,226],brown:[165,42,42],burlywood:[222,184,135],cadetblue:[95,158,160],chartreuse:[127,255,0],chocolate:[210,105,30],coral:[255,127,80],cornflowerblue:[100,149,237],cornsilk:[255,248,220],crimson:[220,20,60],cyan:[0,255,255],darkblue:[0,0,139],darkcyan:[0,139,139],darkgoldenrod:[184,134,11],darkgray:[169,169,169],darkgreen:[0,100,0],darkgrey:[169,169,169],darkkhaki:[189,183,107],darkmagenta:[139,0,139],darkolivegreen:[85,107,47],darkorange:[255,140,0],darkorchid:[153,50,204],darkred:[139,0,0],darksalmon:[233,150,122],darkseagreen:[143,188,143],darkslateblue:[72,61,139],darkslategray:[47,79,79],darkslategrey:[47,79,79],darkturquoise:[0,206,209],darkviolet:[148,0,211],deeppink:[255,20,147],deepskyblue:[0,191,255],dimgray:[105,105,105],dimgrey:[105,105,105],dodgerblue:[30,144,255],firebrick:[178,34,34],floralwhite:[255,250,240],forestgreen:[34,139,34],fuchsia:[255,0,255],gainsboro:[220,220,220],ghostwhite:[248,248,255],gold:[255,215,0],goldenrod:[218,165,32],gray:[128,128,128],green:[0,128,0],greenyellow:[173,255,47],grey:[128,128,128],honeydew:[240,255,240],hotpink:[255,105,180],indianred:[205,92,92],indigo:[75,0,130],ivory:[255,255,240],khaki:[240,230,140],lavender:[230,230,250],lavenderblush:[255,240,245],lawngreen:[124,252,0],lemonchiffon:[255,250,205],lightblue:[173,216,230],lightcoral:[240,128,128],lightcyan:[224,255,255],lightgoldenrodyellow:[250,250,210],lightgray:[211,211,211],lightgreen:[144,238,144],lightgrey:[211,211,211],lightpink:[255,182,193],lightsalmon:[255,160,122],lightseagreen:[32,178,170],lightskyblue:[135,206,250],lightslategray:[119,136,153],lightslategrey:[119,136,153],lightsteelblue:[176,196,222],lightyellow:[255,255,224],lime:[0,255,0],limegreen:[50,205,50],linen:[250,240,230],magenta:[255,0,255],maroon:[128,0,0],mediumaquamarine:[102,205,170],mediumblue:[0,0,205],mediumorchid:[186,85,211],mediumpurple:[147,112,219],mediumseagreen:[60,179,113],mediumslateblue:[123,104,238],mediumspringgreen:[0,250,154],mediumturquoise:[72,209,204],mediumvioletred:[199,21,133],midnightblue:[25,25,112],mintcream:[245,255,250],mistyrose:[255,228,225],moccasin:[255,228,181],navajowhite:[255,222,173],navy:[0,0,128],oldlace:[253,245,230],olive:[128,128,0],olivedrab:[107,142,35],orange:[255,165,0],orangered:[255,69,0],orchid:[218,112,214],palegoldenrod:[238,232,170],palegreen:[152,251,152],paleturquoise:[175,238,238],palevioletred:[219,112,147],papayawhip:[255,239,213],peachpuff:[255,218,185],peru:[205,133,63],pink:[255,192,203],plum:[221,160,221],powderblue:[176,224,230],purple:[128,0,128],rebeccapurple:[102,51,153],red:[255,0,0],rosybrown:[188,143,143],royalblue:[65,105,225],saddlebrown:[139,69,19],salmon:[250,128,114],sandybrown:[244,164,96],seagreen:[46,139,87],seashell:[255,245,238],sienna:[160,82,45],silver:[192,192,192],skyblue:[135,206,235],slateblue:[106,90,205],slategray:[112,128,144],slategrey:[112,128,144],snow:[255,250,250],springgreen:[0,255,127],steelblue:[70,130,180],tan:[210,180,140],teal:[0,128,128],thistle:[216,191,216],tomato:[255,99,71],turquoise:[64,224,208],violet:[238,130,238],wheat:[245,222,179],white:[255,255,255],whitesmoke:[245,245,245],yellow:[255,255,0],yellowgreen:[154,205,50]}},function(e,t,r){var n=r(87);function o(e){var t=function(){for(var e={},t=Object.keys(n),r=t.length,o=0;o<r;o++)e[t[o]]={distance:-1,parent:null};return e}(),r=[e];for(t[e].distance=0;r.length;)for(var o=r.pop(),a=Object.keys(n[o]),i=a.length,l=0;l<i;l++){var u=a[l],c=t[u];-1===c.distance&&(c.distance=t[o].distance+1,c.parent=o,r.unshift(u))}return t}function a(e,t){return function(r){return t(e(r))}}function i(e,t){for(var r=[t[e].parent,e],o=n[t[e].parent][e],i=t[e].parent;t[i].parent;)r.unshift(t[i].parent),o=a(n[t[i].parent][i],o),i=t[i].parent;return o.conversion=r,o}e.exports=function(e){for(var t=o(e),r={},n=Object.keys(t),a=n.length,l=0;l<a;l++){var u=n[l];null!==t[u].parent&&(r[u]=i(u,t))}return r}},function(e,t,r){"use strict";e.exports={stdout:!1,stderr:!1}},function(e,t,r){"use strict";var n=r(52),o=/(?:\\\\(u[a-f\\d]{4}|x[a-f\\d]{2}|.))|(?:\\{(~)?(\\w+(?:\\([^)]*\\))?(?:\\.\\w+(?:\\([^)]*\\))?)*)(?:[ \\t]|(?=\\r?\\n)))|(\\})|((?:.|[\\r\\n\\f])+?)/gi,a=/(?:^|\\.)(\\w+)(?:\\(([^)]*)\\))?/g,i=/^([\'"])((?:\\\\.|(?!\\1)[^\\\\])*)\\1$/,l=/\\\\(u[a-f\\d]{4}|x[a-f\\d]{2}|.)|([^\\\\])/gi,u=new Map([["n","\\n"],["r","\\r"],["t","\\t"],["b","\\b"],["f","\\f"],["v","\\v"],["0","\\0"],["\\\\","\\\\"],["e","\x1b"],["a","\x07"]]);function c(e){return"u"===e[0]&&5===e.length||"x"===e[0]&&3===e.length?String.fromCharCode(parseInt(e.slice(1),16)):u.get(e)||e}function s(e,t){var r,o,a=[],u=t.trim().split(/\\s*,\\s*/g),s=n(u);try{for(s.s();!(o=s.n()).done;){var f=o.value;if(isNaN(f)){if(!(r=f.match(i)))throw new Error("Invalid Chalk template style argument: ".concat(f," (in style \'").concat(e,"\')"));a.push(r[2].replace(l,(function(e,t,r){return t?c(t):r})))}else a.push(Number(f))}}catch(e){s.e(e)}finally{s.f()}return a}function f(e){a.lastIndex=0;for(var t,r=[];null!==(t=a.exec(e));){var n=t[1];if(t[2]){var o=s(n,t[2]);r.push([n].concat(o))}else r.push([n])}return r}function d(e,t){var r,o={},a=n(t);try{for(a.s();!(r=a.n()).done;){var i,l=r.value,u=n(l.styles);try{for(u.s();!(i=u.n()).done;){var c=i.value;o[c[0]]=l.inverse?null:c.slice(1)}}catch(e){u.e(e)}finally{u.f()}}}catch(e){a.e(e)}finally{a.f()}for(var s=e,f=0,d=Object.keys(o);f<d.length;f++){var p=d[f];if(Array.isArray(o[p])){if(!(p in s))throw new Error("Unknown Chalk style: ".concat(p));s=o[p].length>0?s[p].apply(s,o[p]):s[p]}}return s}e.exports=function(e,t){var r=[],n=[],a=[];if(t.replace(o,(function(t,o,i,l,u,s){if(o)a.push(c(o));else if(l){var p=a.join("");a=[],n.push(0===r.length?p:d(e,r)(p)),r.push({inverse:i,styles:f(l)})}else if(u){if(0===r.length)throw new Error("Found extraneous } in Chalk template literal");n.push(d(e,r)(a.join(""))),a=[],r.pop()}else a.push(s)})),n.push(a.join("")),r.length>0){var i="Chalk template literal is missing ".concat(r.length," closing bracket").concat(1===r.length?"":"s"," (`}`)");throw new Error(i)}return n.join("")}},function(e,t,r){"use strict";r.r(t),r.d(t,"ThemeContext",(function(){return me}));r(90);var n=r(0),o=r.n(n),a=r(53),i=r.n(a),l=function(e){return{position:"relative",display:"inline-flex",flexDirection:"column",height:"100%",width:"1024px",maxWidth:"100%",overflowX:"hidden",overflowY:"auto",padding:"0.5rem",boxSizing:"border-box",textAlign:"left",fontFamily:"Consolas, Menlo, monospace",fontSize:"11px",whiteSpace:"pre-wrap",wordBreak:"break-word",lineHeight:1.5,color:e.color}},u=null;var c=function(e){var t=Object(n.useContext)(me),r=e.shortcutHandler;return Object(n.useEffect)((function(){var e=function(e){r&&r(e.key)};return window.addEventListener("keydown",e),u&&u.addEventListener("keydown",e),function(){window.removeEventListener("keydown",e),u&&u.removeEventListener("keydown",e)}}),[r]),o.a.createElement("div",{style:l(t),ref:function(e){if(e){var t=e.ownerDocument;u=t.defaultView}}},e.children)},s=function(e){return{fontFamily:"sans-serif",color:e.footer,marginTop:"0.5rem",flex:"0 0 auto"}};var f=function(e){var t=Object(n.useContext)(me);return o.a.createElement("div",{style:s(t)},e.line1,o.a.createElement("br",null),e.line2)},d=function(e){return{fontSize:"2em",fontFamily:"sans-serif",color:e.headerColor,whiteSpace:"pre-wrap",margin:"0 2rem 0.75rem 0",flex:"0 0 auto",maxHeight:"50%",overflow:"auto"}};var p=function(e){var t=Object(n.useContext)(me);return o.a.createElement("div",{style:d(t)},e.headerText)};function h(e,t,r){return t in e?Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[t]=r,e}function g(e,t){var r=Object.keys(e);if(Object.getOwnPropertySymbols){var n=Object.getOwnPropertySymbols(e);t&&(n=n.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),r.push.apply(r,n)}return r}function v(e){for(var t=1;t<arguments.length;t++){var r=null!=arguments[t]?arguments[t]:{};t%2?g(Object(r),!0).forEach((function(t){h(e,t,r[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(r)):g(Object(r)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(r,t))}))}return e}var m={position:"relative",display:"block",padding:"0.5em",marginTop:"0.5em",marginBottom:"0.5em",overflowX:"auto",whiteSpace:"pre-wrap",borderRadius:"0.25rem"},y={fontFamily:"Consolas, Menlo, monospace"};var b=function(e){var t=e.main,r=e.codeHTML,a=Object(n.useContext)(me),i=v(v({},m),{},{backgroundColor:a.primaryPreBackground,color:a.primaryPreColor}),l=v(v({},m),{},{backgroundColor:a.secondaryPreBackground,color:a.secondaryPreColor}),u=t?i:l,c={__html:r};return o.a.createElement("pre",{style:u},o.a.createElement("code",{style:y,dangerouslySetInnerHTML:c}))},w=r(33),k=r.n(w),E=new(r(88).AllHtmlEntities),x=function(e){return{reset:[e.base05,"transparent"],black:e.base05,red:e.base08,green:e.base0B,yellow:e.base08,blue:e.base0C,magenta:e.base0C,cyan:e.base0E,gray:e.base03,lightgrey:e.base01,darkgrey:e.base03}},S={"ansi-bright-black":"black","ansi-bright-yellow":"yellow","ansi-yellow":"yellow","ansi-bright-green":"green","ansi-green":"green","ansi-bright-cyan":"cyan","ansi-cyan":"cyan","ansi-bright-red":"red","ansi-red":"red","ansi-bright-magenta":"magenta","ansi-magenta":"magenta","ansi-white":"darkgrey"};var _=function(e,t){for(var r=(new k.a).ansiToJson(E.encode(e),{use_classes:!0}),n="",o=!1,a=0;a<r.length;++a)for(var i=r[a],l=i.content,u=i.fg,c=l.split("\\n"),s=0;s<c.length;++s){o||(n+=\'<span data-ansi-line="true">\',o=!0);var f=c[s].replace("\\r",""),d=x(t)[S[u]];null!=d?n+=\'<span style="color: \'+d+\';">\'+f+"</span>":(null!=u&&console.log("Missing color mapping: ",u),n+="<span>"+f+"</span>"),s<c.length-1&&(n+="</span>",o=!1,n+="<br/>")}return o&&(n+="</span>",o=!1),n},T=/^\\.(\\/[^/\\n ]+)+\\.[^/\\n ]+$/,C=[/^.*\\((\\d+):(\\d+)\\)$/,/^Line (\\d+):.+$/];var O=function(e){for(var t=e.split("\\n"),r="",n=0,o=0,a=0;a<t.length;a++){var i=k.a.ansiToText(t[a]).trim();if(i){!r&&i.match(T)&&(r=i);for(var l=0;l<C.length;){var u=i.match(C[l]);if(u){n=parseInt(u[1],10),o=parseInt(u[2],10)+1||1;break}l++}if(r&&n)break}}return r&&n?{fileName:r,lineNumber:n,colNumber:o}:null},P={cursor:"pointer"};var R=function(e){var t=Object(n.useContext)(me),r=e.error,a=e.editorHandler,i=O(r),l=null!==i&&null!==a;return o.a.createElement(c,null,o.a.createElement(p,{headerText:"Failed to compile"}),o.a.createElement("div",{onClick:l&&i?function(){return a(i)}:null,style:l?P:null},o.a.createElement(b,{main:!0,codeHTML:_(r,t)})),o.a.createElement(f,{line1:"This error occurred during the build time and cannot be dismissed."}))};function N(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function L(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}function A(e,t,r){return t&&L(e.prototype,t),r&&L(e,r),e}function I(e,t){return(I=Object.setPrototypeOf||function(e,t){return e.__proto__=t,e})(e,t)}function j(e,t){if("function"!==typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function");e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,writable:!0,configurable:!0}}),t&&I(e,t)}function M(e){return(M=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)})(e)}function D(e){return(D="function"===typeof Symbol&&"symbol"===typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"===typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e})(e)}function q(e,t){return!t||"object"!==D(t)&&"function"!==typeof t?function(e){if(void 0===e)throw new ReferenceError("this hasn\'t been initialised - super() hasn\'t been called");return e}(e):t}function z(e){var t=function(){if("undefined"===typeof Reflect||!Reflect.construct)return!1;if(Reflect.construct.sham)return!1;if("function"===typeof Proxy)return!0;try{return Date.prototype.toString.call(Reflect.construct(Date,[],(function(){}))),!0}catch(e){return!1}}();return function(){var r,n=M(e);if(t){var o=M(this).constructor;r=Reflect.construct(n,arguments,o)}else r=n.apply(this,arguments);return q(this,r)}}var U=function(e){return{color:e.closeColor,lineHeight:"1rem",fontSize:"1.5rem",padding:"1rem",cursor:"pointer",position:"absolute",right:0,top:0}};var F=function(e){var t=e.close,r=Object(n.useContext)(me);return o.a.createElement("span",{title:"Click or press Escape to dismiss.",onClick:t,style:U(r)},"\xd7")},B={marginBottom:"0.5rem"},V={marginRight:"1em"},H={border:"none",borderRadius:"4px",padding:"3px 6px",cursor:"pointer"},W=function(e){return v(v({},H),{},{backgroundColor:e.navBackground,color:e.navArrow,borderTopRightRadius:"0px",borderBottomRightRadius:"0px",marginRight:"1px"})},$=function(e){return v(v({},H),{},{backgroundColor:e.navBackground,color:e.navArrow,borderTopLeftRadius:"0px",borderBottomLeftRadius:"0px"})};var G=function(e){var t=Object(n.useContext)(me),r=e.currentError,a=e.totalErrors,i=e.previous,l=e.next;return o.a.createElement("div",{style:B},o.a.createElement("span",{style:V},o.a.createElement("button",{onClick:i,style:W(t)},"\u2190"),o.a.createElement("button",{onClick:l,style:$(t)},"\u2192")),"".concat(r," of ").concat(a," errors on the page"))};function Q(e,t){(null==t||t>e.length)&&(t=e.length);for(var r=0,n=new Array(t);r<t;r++)n[r]=e[r];return n}function Y(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){if("undefined"!==typeof Symbol&&Symbol.iterator in Object(e)){var r=[],n=!0,o=!1,a=void 0;try{for(var i,l=e[Symbol.iterator]();!(n=(i=l.next()).done)&&(r.push(i.value),!t||r.length!==t);n=!0);}catch(e){o=!0,a=e}finally{try{n||null==l.return||l.return()}finally{if(o)throw a}}return r}}(e,t)||function(e,t){if(e){if("string"===typeof e)return Q(e,t);var r=Object.prototype.toString.call(e).slice(8,-1);return"Object"===r&&e.constructor&&(r=e.constructor.name),"Map"===r||"Set"===r?Array.from(e):"Arguments"===r||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)?Q(e,t):void 0}}(e,t)||function(){throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function K(e,t){for(;null!=t&&"br"!==t.tagName.toLowerCase();)t=t.nextElementSibling;null!=t&&e.removeChild(t)}var X=r(89);var J=function(e){var t=Object(n.useContext)(me),r=e.lines,a=e.lineNum,i=e.columnNum,l=e.contextSize,u=e.main,c=[],s=1/0;r.forEach((function(e){var t=e.content,r=t.match(/^\\s*/);""!==t&&(s=r&&r[0]?Math.min(s,r[0].length):0)})),r.forEach((function(e){var t=e.content,r=e.lineNumber;isFinite(s)&&(t=t.substring(s)),c[r-1]=t}));var f=Object(X.codeFrameColumns)(c.join("\\n"),{start:{line:a,column:null==i?0:i-(isFinite(s)?s:0)}},{forceColor:!0,linesAbove:l,linesBelow:l}),d=_(f,t),p=document.createElement("code");p.innerHTML=d,function(e){for(var t=e.childNodes,r=0;r<t.length;++r){var n=t[r];if("span"===n.tagName.toLowerCase()){var o=n.innerText;null!=o&&"|^"===o.replace(/\\s/g,"")&&(n.style.position="absolute",K(e,n))}}}(p);var h=p.childNodes;e:for(var g=0;g<h.length;++g)for(var v=h[g].childNodes,m=0;m<v.length;++m){var y=v[m].innerText;if(null!=y&&-1!==y.indexOf(" "+a+" |"))break e}return o.a.createElement(b,{main:u,codeHTML:p.innerHTML})};function Z(e,t,r,n,o,a,i){var l;if(!i&&e&&"number"===typeof t){var u=/^[/|\\\\].*?[/|\\\\]((src|node_modules)[/|\\\\].*)/.exec(e);l=u&&u[1]?u[1]:e,l+=":"+t,r&&(l+=":"+r)}else n&&"number"===typeof o?(l=n+":"+o,a&&(l+=":"+a)):l="unknown";return l.replace("webpack://",".")}var ee=function(e){return{textDecoration:"none",color:e.anchorColor,cursor:"pointer"}},te=function(e){return{marginBottom:"1.5em",color:e.toggleColor,cursor:"pointer",border:"none",display:"block",width:"100%",textAlign:"left",background:e.toggleBackground,fontFamily:"Consolas, Menlo, monospace",fontSize:"1em",padding:"0px",lineHeight:"1.5"}};var re=function(e){var t=Object(n.useContext)(me),r=Y(Object(n.useState)(!1),2),a=r[0],i=r[1],l=function(){var t=e.frame,r=t._originalFileName,n=t._originalLineNumber;return r?-1!==r.trim().indexOf(" ")?null:{fileName:r,lineNumber:n||1}:null},u=function(){var t=l();t&&e.editorHandler(t)},c=e.frame,s=e.contextSize,f=e.critical,d=e.showCode,p=c.fileName,h=c.lineNumber,g=c.columnNumber,v=c._scriptCode,m=c._originalFileName,y=c._originalLineNumber,b=c._originalColumnNumber,w=c._originalScriptCode,k=c.getFunctionName(),E=Z(m,y,b,p,h,g,a),x=null;d&&(a&&v&&0!==v.length&&null!=h?x={lines:v,lineNum:h,columnNum:g,contextSize:s,main:f}:!a&&w&&0!==w.length&&null!=y&&(x={lines:w,lineNum:y,columnNum:b,contextSize:s,main:f}));var S=null!==l()&&null!==e.editorHandler;return o.a.createElement("div",null,o.a.createElement("div",null,k),o.a.createElement("div",{style:{fontSize:"0.9em",marginBottom:"0.9em"}},o.a.createElement("span",{style:S?ee(t):null,onClick:S?u:null,onKeyDown:S?function(e){"Enter"===e.key&&u()}:null,tabIndex:S?"0":null},E)),x&&o.a.createElement("span",null,o.a.createElement("span",{onClick:S?u:null,style:S?{cursor:"pointer"}:null},o.a.createElement(J,x)),o.a.createElement("button",{style:te(t),onClick:function(){i(!a)}},"View "+(a?"source":"compiled"))))},ne={cursor:"pointer",border:"none",display:"block",width:"100%",textAlign:"left",fontFamily:"Consolas, Menlo, monospace",fontSize:"1em",padding:"0px",lineHeight:"1.5"},oe=function(e){return v(v({},ne),{},{color:e.color,background:e.background,marginBottom:"1.5em"})},ae=function(e){return v(v({},ne),{},{color:e.color,background:e.background,marginBottom:"0.6em"})};var ie=function(e){var t=Object(n.useContext)(me),r=Y(Object(n.useState)(!0),2),a=r[0],i=r[1],l=function(){i(!a)},u=e.children.length;return o.a.createElement("div",null,o.a.createElement("button",{onClick:l,style:a?oe(t):ae(t)},(a?"\u25B6":"\u25BC")+" ".concat(u," stack frames were ")+(a?"collapsed.":"expanded.")),o.a.createElement("div",{style:{display:a?"none":"block"}},e.children,o.a.createElement("button",{onClick:l,style:ae(t)},"\u25B2 ".concat(u," stack frames were expanded."))))};function le(e){switch(e){case"EvalError":case"InternalError":case"RangeError":case"ReferenceError":case"SyntaxError":case"TypeError":case"URIError":return!0;default:return!1}}var ue={fontSize:"1em",flex:"0 1 auto",minHeight:"0px",overflow:"auto"},ce=function(e){j(r,e);var t=z(r);function r(){return N(this,r),t.apply(this,arguments)}return A(r,[{key:"renderFrames",value:function(){var e=this.props,t=e.stackFrames,r=e.errorName,n=e.contextSize,a=e.editorHandler,i=[],l=!1,u=[],c=0;return t.forEach((function(e,s){var f=e.fileName,d=function(e,t){return null==e||""===e||-1!==e.indexOf("/~/")||-1!==e.indexOf("/node_modules/")||-1!==e.trim().indexOf(" ")||null==t||""===t}(e._originalFileName,f),p=!le(r),h=d&&(p||l);d||(l=!0);var g=o.a.createElement(re,{key:"frame-"+s,frame:e,contextSize:n,critical:0===s,showCode:!h,editorHandler:a}),v=s===t.length-1;h&&u.push(g),h&&!v||(1===u.length?i.push(u[0]):u.length>1&&(c++,i.push(o.a.createElement(ie,{key:"bundle-"+c},u))),u=[]),h||i.push(g)})),i}},{key:"render",value:function(){return o.a.createElement("div",{style:ue},this.renderFrames())}}]),r}(n.Component),se={display:"flex",flexDirection:"column"};var fe=function(e){var t=e.errorRecord,r=e.editorHandler,n=t.error,a=t.unhandledRejection,i=t.contextSize,l=t.stackFrames,u=a?"Unhandled Rejection ("+n.name+")":n.name,c=n.message,s=c.match(/^\\w*:/)||!u?c:u+": "+c;return s=s.replace(/^Invariant Violation:\\s*/,"").replace(/^Warning:\\s*/,"").replace(" Check the render method","\\n\\nCheck the render method").replace(" Check your code at","\\n\\nCheck your code at"),o.a.createElement("div",{style:se},o.a.createElement(p,{headerText:s}),o.a.createElement(ce,{stackFrames:l,errorName:u,contextSize:i,editorHandler:r}))},de=function(e){j(r,e);var t=z(r);function r(){var e;N(this,r);for(var n=arguments.length,o=new Array(n),a=0;a<n;a++)o[a]=arguments[a];return(e=t.call.apply(t,[this].concat(o))).state={currentIndex:0},e.previous=function(){e.setState((function(e,t){return{currentIndex:e.currentIndex>0?e.currentIndex-1:t.errorRecords.length-1}}))},e.next=function(){e.setState((function(e,t){return{currentIndex:e.currentIndex<t.errorRecords.length-1?e.currentIndex+1:0}}))},e.shortcutHandler=function(t){"Escape"===t?e.props.close():"ArrowLeft"===t?e.previous():"ArrowRight"===t&&e.next()},e}return A(r,[{key:"render",value:function(){var e=this.props,t=e.errorRecords,r=e.close,n=t.length;return o.a.createElement(c,{shortcutHandler:this.shortcutHandler},o.a.createElement(F,{close:r}),n>1&&o.a.createElement(G,{currentError:this.state.currentIndex+1,totalErrors:n,previous:this.previous,next:this.next}),o.a.createElement(fe,{errorRecord:t[this.state.currentIndex],editorHandler:this.props.editorHandler}),o.a.createElement(f,{line1:"This screen is visible only in development. It will not appear if the app crashes in production.",line2:"Open your browser\u2019s developer console to further inspect this error.  Click the \'X\' or hit ESC to dismiss this message."}))}}]),r}(n.PureComponent),pe={background:"white",color:"black",headerColor:"#ce1126",primaryPreBackground:"rgba(206, 17, 38, 0.05)",primaryPreColor:"inherit",secondaryPreBackground:"rgba(251, 245, 180, 0.3)",secondaryPreColor:"inherit",footer:"#878e91",anchorColor:"#878e91",toggleBackground:"transparent",toggleColor:"#878e91",closeColor:"#293238",navBackground:"rgba(206, 17, 38, 0.05)",navArrow:"#ce1126",base01:"#f5f5f5",base03:"#6e6e6e",base05:"#333333",base08:"#881280",base0B:"#1155cc",base0C:"#994500",base0E:"#c80000"},he={background:"#353535",color:"white",headerColor:"#e83b46",primaryPreBackground:"rgba(206, 17, 38, 0.1)",primaryPreColor:"#fccfcf",secondaryPreBackground:"rgba(251, 245, 180, 0.1)",secondaryPreColor:"#fbf5b4",footer:"#878e91",anchorColor:"#878e91",toggleBackground:"transparent",toggleColor:"#878e91",closeColor:"#ffffff",navBackground:"rgba(206, 17, 38, 0.2)",navArrow:"#ce1126",base01:"#282a2e",base03:"#969896",base05:"#c5c8c6",base08:"#cc6666",base0B:"#b5bd68",base0C:"#8abeb7",base0E:"#b294bb"};var ge=null,ve=window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches?he:pe,me=Object(n.createContext)();window.updateContent=function(e){var t,r,n,a,l,u=(r=(t=e).currentBuildError,n=t.currentRuntimeErrorRecords,a=t.dismissRuntimeErrors,l=t.editorHandler,r?o.a.createElement(me.Provider,{value:ve},o.a.createElement(R,{error:r,editorHandler:l})):n.length>0?o.a.createElement(me.Provider,{value:ve},o.a.createElement(de,{errorRecords:n,close:a,editorHandler:l})):null);return null===u?(i.a.unmountComponentAtNode(ge),!1):(i.a.render(u,ge),!0)},document.body.style.margin="0",document.body.style["max-width"]="100vw",function(e,t){for(var r in e.setAttribute("style",""),t)t.hasOwnProperty(r)&&(e.style[r]=t[r])}(ge=document.createElement("div"),{width:"100%",height:"100%","box-sizing":"border-box","text-align":"center","background-color":ve.background}),document.body.appendChild(ge),window.parent.__REACT_ERROR_OVERLAY_GLOBAL_HOOK__.iframeReady()}]);', ee = null, te = !1, re = !1, ne = null, oe = null, ae = [], ie = null, le = null;
            function ue(e) {
                ne = e, ee && me();
            }
            function ce(e) {
                oe = e, me();
            }
            function se(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                ie = t, X(pe(t))(e);
            }
            function fe() {
                oe = null, me();
            }
            function de(e) {
                if (null !== le) throw new Error("Already listening");
                e.launchEditorEndpoint && console.warn("Warning: `startReportingRuntimeErrors` doesn\u2019t accept `launchEditorEndpoint` argument anymore. Use `listenToOpenInEditor` instead with your own implementation to open errors in editor "), ie = e, le = K(pe(e), e.filename);
            }
            var pe = function(e) {
                return function(t) {
                    try {
                        "function" == typeof e.onError && e.onError.call(null);
                    } finally{
                        if (ae.some(function(e) {
                            return e.error === t.error;
                        })) return;
                        ae = ae.concat([
                            t
                        ]), me();
                    }
                };
            };
            function he() {
                ae = [], me();
            }
            function ge() {
                if (null === le) throw new Error("Not currently listening");
                ie = null;
                try {
                    le();
                } finally{
                    le = null;
                }
            }
            function me() {
                if (!te) {
                    if (re) ve();
                    else {
                        te = !0;
                        var e = window.document.createElement("iframe");
                        !function(e, t) {
                            for(var r in e.setAttribute("style", ""), t)t.hasOwnProperty(r) && (e.style[r] = t[r]);
                        }(e, J), e.onload = function() {
                            var t = e.contentDocument;
                            if (null != t && null != t.body) {
                                ee = e;
                                var r = e.contentWindow.document.createElement("script");
                                r.type = "text/javascript", r.innerHTML = Z, t.body.appendChild(r);
                            }
                        }, window.document.body.appendChild(e);
                    }
                }
            }
            function ve() {
                if (!ie) throw new Error("Expected options to be injected.");
                if (!ee) throw new Error("Iframe has not been created yet.");
                ee.contentWindow.updateContent({
                    currentBuildError: oe,
                    currentRuntimeErrorRecords: ae,
                    dismissRuntimeErrors: he,
                    editorHandler: ne
                }) || (window.document.body.removeChild(ee), ee = null, re = !1);
            }
            window.__REACT_ERROR_OVERLAY_GLOBAL_HOOK__ = window.__REACT_ERROR_OVERLAY_GLOBAL_HOOK__ || {}, window.__REACT_ERROR_OVERLAY_GLOBAL_HOOK__.iframeReady = function() {
                re = !0, te = !1, ve();
            };
        }
    ]);
});

},{"d1546958eb39fdcf":"d5jf4"}],"d5jf4":[function(require,module,exports) {
// shim for using process in browser
var process = module.exports = {};
// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.
var cachedSetTimeout;
var cachedClearTimeout;
function defaultSetTimout() {
    throw new Error("setTimeout has not been defined");
}
function defaultClearTimeout() {
    throw new Error("clearTimeout has not been defined");
}
(function() {
    try {
        if (typeof setTimeout === "function") cachedSetTimeout = setTimeout;
        else cachedSetTimeout = defaultSetTimout;
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === "function") cachedClearTimeout = clearTimeout;
        else cachedClearTimeout = defaultClearTimeout;
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
})();
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) //normal enviroments in sane situations
    return setTimeout(fun, 0);
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch (e) {
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch (e) {
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }
}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) //normal enviroments in sane situations
    return clearTimeout(marker);
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e) {
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e) {
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }
}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;
function cleanUpNextTick() {
    if (!draining || !currentQueue) return;
    draining = false;
    if (currentQueue.length) queue = currentQueue.concat(queue);
    else queueIndex = -1;
    if (queue.length) drainQueue();
}
function drainQueue() {
    if (draining) return;
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;
    var len = queue.length;
    while(len){
        currentQueue = queue;
        queue = [];
        while(++queueIndex < len)if (currentQueue) currentQueue[queueIndex].run();
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}
process.nextTick = function(fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) for(var i = 1; i < arguments.length; i++)args[i - 1] = arguments[i];
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) runTimeout(drainQueue);
};
// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function() {
    this.fun.apply(null, this.array);
};
process.title = "browser";
process.browser = true;
process.env = {};
process.argv = [];
process.version = ""; // empty string to avoid regexp issues
process.versions = {};
function noop() {}
process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;
process.listeners = function(name) {
    return [];
};
process.binding = function(name) {
    throw new Error("process.binding is not supported");
};
process.cwd = function() {
    return "/";
};
process.chdir = function(dir) {
    throw new Error("process.chdir is not supported");
};
process.umask = function() {
    return 0;
};

},{}],"4vE77":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
var _appVue = require("./App.vue");
var _appVueDefault = parcelHelpers.interopDefault(_appVue);
var _notesJs = require("./revealPlugins/notes/notes.js");
var _notesJsDefault = parcelHelpers.interopDefault(_notesJs);
var _vue = require("vue");
var _log = require("../utilities/Log");
/**
 * Slides.com internally uses [Reveal.js framework](https://revealjs.com/)
 * so we can access its API using the Reveal global object
 */ const Slides = window.Reveal;
/**
 * start pinging until on the page does not appear a presentation
 * This may occur when a presentation is password protected and the user must first login
 */ function checkForSlides() {
    (0, _log.Log).info("injectable check for slides");
    if (typeof window.Reveal === "undefined") {
        (0, _log.Log).info("Slides not found, waiting for them the instance");
        setTimeout(checkForSlides, 500);
        return;
    }
    if (Slides && Slides.isReady && Slides.isReady()) {
        (0, _log.Log).info("Slides already loaded.");
        onSlidesReady();
    } else {
        (0, _log.Log).info("Waiting for Slides to be ready.");
        Slides.on("ready", onSlidesReady);
    }
}
function onSlidesReady() {
    (0, _log.Log).info("Starting Vue...");
    // Register notes plugin to enable speaker view
    Slides.registerPlugin((0, _notesJsDefault.default));
    initVue();
}
function initVue() {
    const parent = document.querySelector(".reveal-viewport > .reveal");
    const vueContainer = document.createElement("div");
    if (!parent) {
        (0, _log.Log).error("No parent found");
        return;
    }
    vueContainer.id = "slides-extension";
    parent.appendChild(vueContainer);
    (0, _vue.createApp)((0, _appVueDefault.default)).mount("#" + vueContainer.id);
}
checkForSlides();

},{"./App.vue":"jcHwk","./revealPlugins/notes/notes.js":"bbfjI","vue":"gzxs9","../utilities/Log":"8wG4i","@parcel/transformer-js/src/esmodule-helpers.js":"gkKU3"}],"jcHwk":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("aaf427b6f85f30fd");
    if (script.__esModule) script = script.default;
    script.render = require("c98606c7964b3d2c").render;
    script.__cssModules = require("39bc04a7ca4307f").default;
    require("1359e7116e7074fa").default(script);
    script.__scopeId = "data-v-3cca5d";
    script.__file = "/Users/florianleica/WAB/slides_com_companion/src/injectable/App.vue";
};
initialize();
if (module.hot) {
    script.__hmrId = "3cca5d-hmr";
    module.hot.accept(()=>{
        setTimeout(()=>{
            initialize();
            if (!__VUE_HMR_RUNTIME__.createRecord("3cca5d-hmr", script)) __VUE_HMR_RUNTIME__.reload("3cca5d-hmr", script);
        }, 0);
    });
}
exports.default = script;

},{"aaf427b6f85f30fd":"8yW52","c98606c7964b3d2c":"l5ThS","39bc04a7ca4307f":"jABBs","1359e7116e7074fa":"dywpD","@parcel/transformer-js/src/esmodule-helpers.js":"gkKU3"}],"8yW52":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _vue = require("vue");
var _settings = require("../composables/Settings");
exports.default = (0, _vue.defineComponent)({
    setup () {
        const toolbar = (0, _vue.ref)();
        const active = (0, _vue.ref)(false);
        const settingsInstance = new (0, _settings.Settings)();
        const settings = (0, _vue.ref)();
        settingsInstance.addListener("settingsLoaded", (newSettings)=>{
            settings.value = newSettings;
        });
        settingsInstance.addListener("settingsChanged", (newSettings)=>{
            settings.value = newSettings;
        });
        function onPrintClick() {
            // window.Reveal.configure({ view: 'print' })
            // window.Reveal.initialize().then(() => {
            // window.SL.view.init()
            window.SL.util.setupReveal({
                view: "print"
            });
            const slidesEl = document.querySelector(".slides");
            if (slidesEl) // remove the transform to avoid the slides to be cropped
            slidesEl.style.transform = "";
            setTimeout(()=>{
                window.print();
            }, 500);
            // wait for the rerendering of the view
            window.addEventListener("afterprint", function() {
                window.location.reload();
            });
        }
        function onSpeakerViewClick() {
            window.Reveal.getPlugin("notes").open();
        }
        function afterPrinting() {
            const searchParams = new URL(window.location.toString()).searchParams;
            searchParams.has("print-pdf");
        }
        function triggerPrint() {
            window.addEventListener("afterprint", afterPrinting);
            // Wait for the initial animation to complete before printing
            setTimeout(()=>{
                window.print();
            }, 500);
        }
        (0, _vue.onMounted)(()=>{
            const url = new URL(window.location.toString());
            const searchParams = url.searchParams;
            if (searchParams.has("print-pdf")) triggerPrint();
        });
        return {
            active,
            toolbar,
            settings,
            onPrintClick,
            onSpeakerViewClick
        };
    }
});

},{"vue":"gzxs9","../composables/Settings":"aohMd","@parcel/transformer-js/src/esmodule-helpers.js":"gkKU3"}],"gzxs9":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "compile", ()=>compile);
var _runtimeDom = require("@vue/runtime-dom");
parcelHelpers.exportAll(_runtimeDom, exports);
function initDev() {
    (0, _runtimeDom.initCustomFormatter)();
}
initDev();
const compile = ()=>{
    (0, _runtimeDom.warn)(`Runtime compilation is not supported in this build of Vue.` + ` Configure your bundler to alias "vue" to "vue/dist/vue.esm-bundler.js".`);
};

},{"@vue/runtime-dom":"9wNvI","@parcel/transformer-js/src/esmodule-helpers.js":"gkKU3"}],"9wNvI":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "Transition", ()=>Transition);
parcelHelpers.export(exports, "TransitionGroup", ()=>TransitionGroup);
parcelHelpers.export(exports, "VueElement", ()=>VueElement);
parcelHelpers.export(exports, "createApp", ()=>createApp);
parcelHelpers.export(exports, "createSSRApp", ()=>createSSRApp);
parcelHelpers.export(exports, "defineCustomElement", ()=>defineCustomElement);
parcelHelpers.export(exports, "defineSSRCustomElement", ()=>defineSSRCustomElement);
parcelHelpers.export(exports, "hydrate", ()=>hydrate);
parcelHelpers.export(exports, "initDirectivesForSSR", ()=>initDirectivesForSSR);
parcelHelpers.export(exports, "render", ()=>render);
parcelHelpers.export(exports, "useCssModule", ()=>useCssModule);
parcelHelpers.export(exports, "useCssVars", ()=>useCssVars);
parcelHelpers.export(exports, "vModelCheckbox", ()=>vModelCheckbox);
parcelHelpers.export(exports, "vModelDynamic", ()=>vModelDynamic);
parcelHelpers.export(exports, "vModelRadio", ()=>vModelRadio);
parcelHelpers.export(exports, "vModelSelect", ()=>vModelSelect);
parcelHelpers.export(exports, "vModelText", ()=>vModelText);
parcelHelpers.export(exports, "vShow", ()=>vShow);
parcelHelpers.export(exports, "withKeys", ()=>withKeys);
parcelHelpers.export(exports, "withModifiers", ()=>withModifiers);
var _runtimeCore = require("@vue/runtime-core");
parcelHelpers.exportAll(_runtimeCore, exports);
var _shared = require("@vue/shared");
const svgNS = "http://www.w3.org/2000/svg";
const doc = typeof document !== "undefined" ? document : null;
const templateContainer = doc && /* @__PURE__ */ doc.createElement("template");
const nodeOps = {
    insert: (child, parent, anchor)=>{
        parent.insertBefore(child, anchor || null);
    },
    remove: (child)=>{
        const parent = child.parentNode;
        if (parent) parent.removeChild(child);
    },
    createElement: (tag, isSVG, is, props)=>{
        const el = isSVG ? doc.createElementNS(svgNS, tag) : doc.createElement(tag, is ? {
            is
        } : void 0);
        if (tag === "select" && props && props.multiple != null) el.setAttribute("multiple", props.multiple);
        return el;
    },
    createText: (text)=>doc.createTextNode(text),
    createComment: (text)=>doc.createComment(text),
    setText: (node, text)=>{
        node.nodeValue = text;
    },
    setElementText: (el, text)=>{
        el.textContent = text;
    },
    parentNode: (node)=>node.parentNode,
    nextSibling: (node)=>node.nextSibling,
    querySelector: (selector)=>doc.querySelector(selector),
    setScopeId (el, id) {
        el.setAttribute(id, "");
    },
    // __UNSAFE__
    // Reason: innerHTML.
    // Static content here can only come from compiled templates.
    // As long as the user only uses trusted templates, this is safe.
    insertStaticContent (content, parent, anchor, isSVG, start, end) {
        const before = anchor ? anchor.previousSibling : parent.lastChild;
        if (start && (start === end || start.nextSibling)) while(true){
            parent.insertBefore(start.cloneNode(true), anchor);
            if (start === end || !(start = start.nextSibling)) break;
        }
        else {
            templateContainer.innerHTML = isSVG ? `<svg>${content}</svg>` : content;
            const template = templateContainer.content;
            if (isSVG) {
                const wrapper = template.firstChild;
                while(wrapper.firstChild)template.appendChild(wrapper.firstChild);
                template.removeChild(wrapper);
            }
            parent.insertBefore(template, anchor);
        }
        return [
            // first
            before ? before.nextSibling : parent.firstChild,
            // last
            anchor ? anchor.previousSibling : parent.lastChild
        ];
    }
};
const TRANSITION = "transition";
const ANIMATION = "animation";
const vtcKey = Symbol("_vtc");
const Transition = (props, { slots })=>(0, _runtimeCore.h)((0, _runtimeCore.BaseTransition), resolveTransitionProps(props), slots);
Transition.displayName = "Transition";
const DOMTransitionPropsValidators = {
    name: String,
    type: String,
    css: {
        type: Boolean,
        default: true
    },
    duration: [
        String,
        Number,
        Object
    ],
    enterFromClass: String,
    enterActiveClass: String,
    enterToClass: String,
    appearFromClass: String,
    appearActiveClass: String,
    appearToClass: String,
    leaveFromClass: String,
    leaveActiveClass: String,
    leaveToClass: String
};
const TransitionPropsValidators = Transition.props = /* @__PURE__ */ (0, _shared.extend)({}, (0, _runtimeCore.BaseTransitionPropsValidators), DOMTransitionPropsValidators);
const callHook = (hook, args = [])=>{
    if ((0, _shared.isArray)(hook)) hook.forEach((h2)=>h2(...args));
    else if (hook) hook(...args);
};
const hasExplicitCallback = (hook)=>{
    return hook ? (0, _shared.isArray)(hook) ? hook.some((h2)=>h2.length > 1) : hook.length > 1 : false;
};
function resolveTransitionProps(rawProps) {
    const baseProps = {};
    for(const key in rawProps)if (!(key in DOMTransitionPropsValidators)) baseProps[key] = rawProps[key];
    if (rawProps.css === false) return baseProps;
    const { name = "v", type, duration, enterFromClass = `${name}-enter-from`, enterActiveClass = `${name}-enter-active`, enterToClass = `${name}-enter-to`, appearFromClass = enterFromClass, appearActiveClass = enterActiveClass, appearToClass = enterToClass, leaveFromClass = `${name}-leave-from`, leaveActiveClass = `${name}-leave-active`, leaveToClass = `${name}-leave-to` } = rawProps;
    const durations = normalizeDuration(duration);
    const enterDuration = durations && durations[0];
    const leaveDuration = durations && durations[1];
    const { onBeforeEnter, onEnter, onEnterCancelled, onLeave, onLeaveCancelled, onBeforeAppear = onBeforeEnter, onAppear = onEnter, onAppearCancelled = onEnterCancelled } = baseProps;
    const finishEnter = (el, isAppear, done)=>{
        removeTransitionClass(el, isAppear ? appearToClass : enterToClass);
        removeTransitionClass(el, isAppear ? appearActiveClass : enterActiveClass);
        done && done();
    };
    const finishLeave = (el, done)=>{
        el._isLeaving = false;
        removeTransitionClass(el, leaveFromClass);
        removeTransitionClass(el, leaveToClass);
        removeTransitionClass(el, leaveActiveClass);
        done && done();
    };
    const makeEnterHook = (isAppear)=>{
        return (el, done)=>{
            const hook = isAppear ? onAppear : onEnter;
            const resolve = ()=>finishEnter(el, isAppear, done);
            callHook(hook, [
                el,
                resolve
            ]);
            nextFrame(()=>{
                removeTransitionClass(el, isAppear ? appearFromClass : enterFromClass);
                addTransitionClass(el, isAppear ? appearToClass : enterToClass);
                if (!hasExplicitCallback(hook)) whenTransitionEnds(el, type, enterDuration, resolve);
            });
        };
    };
    return (0, _shared.extend)(baseProps, {
        onBeforeEnter (el) {
            callHook(onBeforeEnter, [
                el
            ]);
            addTransitionClass(el, enterFromClass);
            addTransitionClass(el, enterActiveClass);
        },
        onBeforeAppear (el) {
            callHook(onBeforeAppear, [
                el
            ]);
            addTransitionClass(el, appearFromClass);
            addTransitionClass(el, appearActiveClass);
        },
        onEnter: makeEnterHook(false),
        onAppear: makeEnterHook(true),
        onLeave (el, done) {
            el._isLeaving = true;
            const resolve = ()=>finishLeave(el, done);
            addTransitionClass(el, leaveFromClass);
            forceReflow();
            addTransitionClass(el, leaveActiveClass);
            nextFrame(()=>{
                if (!el._isLeaving) return;
                removeTransitionClass(el, leaveFromClass);
                addTransitionClass(el, leaveToClass);
                if (!hasExplicitCallback(onLeave)) whenTransitionEnds(el, type, leaveDuration, resolve);
            });
            callHook(onLeave, [
                el,
                resolve
            ]);
        },
        onEnterCancelled (el) {
            finishEnter(el, false);
            callHook(onEnterCancelled, [
                el
            ]);
        },
        onAppearCancelled (el) {
            finishEnter(el, true);
            callHook(onAppearCancelled, [
                el
            ]);
        },
        onLeaveCancelled (el) {
            finishLeave(el);
            callHook(onLeaveCancelled, [
                el
            ]);
        }
    });
}
function normalizeDuration(duration) {
    if (duration == null) return null;
    else if ((0, _shared.isObject)(duration)) return [
        NumberOf(duration.enter),
        NumberOf(duration.leave)
    ];
    else {
        const n = NumberOf(duration);
        return [
            n,
            n
        ];
    }
}
function NumberOf(val) {
    const res = (0, _shared.toNumber)(val);
    (0, _runtimeCore.assertNumber)(res, "<transition> explicit duration");
    return res;
}
function addTransitionClass(el, cls) {
    cls.split(/\s+/).forEach((c)=>c && el.classList.add(c));
    (el[vtcKey] || (el[vtcKey] = /* @__PURE__ */ new Set())).add(cls);
}
function removeTransitionClass(el, cls) {
    cls.split(/\s+/).forEach((c)=>c && el.classList.remove(c));
    const _vtc = el[vtcKey];
    if (_vtc) {
        _vtc.delete(cls);
        if (!_vtc.size) el[vtcKey] = void 0;
    }
}
function nextFrame(cb) {
    requestAnimationFrame(()=>{
        requestAnimationFrame(cb);
    });
}
let endId = 0;
function whenTransitionEnds(el, expectedType, explicitTimeout, resolve) {
    const id = el._endId = ++endId;
    const resolveIfNotStale = ()=>{
        if (id === el._endId) resolve();
    };
    if (explicitTimeout) return setTimeout(resolveIfNotStale, explicitTimeout);
    const { type, timeout, propCount } = getTransitionInfo(el, expectedType);
    if (!type) return resolve();
    const endEvent = type + "end";
    let ended = 0;
    const end = ()=>{
        el.removeEventListener(endEvent, onEnd);
        resolveIfNotStale();
    };
    const onEnd = (e)=>{
        if (e.target === el && ++ended >= propCount) end();
    };
    setTimeout(()=>{
        if (ended < propCount) end();
    }, timeout + 1);
    el.addEventListener(endEvent, onEnd);
}
function getTransitionInfo(el, expectedType) {
    const styles = window.getComputedStyle(el);
    const getStyleProperties = (key)=>(styles[key] || "").split(", ");
    const transitionDelays = getStyleProperties(`${TRANSITION}Delay`);
    const transitionDurations = getStyleProperties(`${TRANSITION}Duration`);
    const transitionTimeout = getTimeout(transitionDelays, transitionDurations);
    const animationDelays = getStyleProperties(`${ANIMATION}Delay`);
    const animationDurations = getStyleProperties(`${ANIMATION}Duration`);
    const animationTimeout = getTimeout(animationDelays, animationDurations);
    let type = null;
    let timeout = 0;
    let propCount = 0;
    if (expectedType === TRANSITION) {
        if (transitionTimeout > 0) {
            type = TRANSITION;
            timeout = transitionTimeout;
            propCount = transitionDurations.length;
        }
    } else if (expectedType === ANIMATION) {
        if (animationTimeout > 0) {
            type = ANIMATION;
            timeout = animationTimeout;
            propCount = animationDurations.length;
        }
    } else {
        timeout = Math.max(transitionTimeout, animationTimeout);
        type = timeout > 0 ? transitionTimeout > animationTimeout ? TRANSITION : ANIMATION : null;
        propCount = type ? type === TRANSITION ? transitionDurations.length : animationDurations.length : 0;
    }
    const hasTransform = type === TRANSITION && /\b(transform|all)(,|$)/.test(getStyleProperties(`${TRANSITION}Property`).toString());
    return {
        type,
        timeout,
        propCount,
        hasTransform
    };
}
function getTimeout(delays, durations) {
    while(delays.length < durations.length)delays = delays.concat(delays);
    return Math.max(...durations.map((d, i)=>toMs(d) + toMs(delays[i])));
}
function toMs(s) {
    if (s === "auto") return 0;
    return Number(s.slice(0, -1).replace(",", ".")) * 1e3;
}
function forceReflow() {
    return document.body.offsetHeight;
}
function patchClass(el, value, isSVG) {
    const transitionClasses = el[vtcKey];
    if (transitionClasses) value = (value ? [
        value,
        ...transitionClasses
    ] : [
        ...transitionClasses
    ]).join(" ");
    if (value == null) el.removeAttribute("class");
    else if (isSVG) el.setAttribute("class", value);
    else el.className = value;
}
const vShowOldKey = Symbol("_vod");
const vShow = {
    beforeMount (el, { value }, { transition }) {
        el[vShowOldKey] = el.style.display === "none" ? "" : el.style.display;
        if (transition && value) transition.beforeEnter(el);
        else setDisplay(el, value);
    },
    mounted (el, { value }, { transition }) {
        if (transition && value) transition.enter(el);
    },
    updated (el, { value, oldValue }, { transition }) {
        if (!value === !oldValue) return;
        if (transition) {
            if (value) {
                transition.beforeEnter(el);
                setDisplay(el, true);
                transition.enter(el);
            } else transition.leave(el, ()=>{
                setDisplay(el, false);
            });
        } else setDisplay(el, value);
    },
    beforeUnmount (el, { value }) {
        setDisplay(el, value);
    }
};
function setDisplay(el, value) {
    el.style.display = value ? el[vShowOldKey] : "none";
}
function initVShowForSSR() {
    vShow.getSSRProps = ({ value })=>{
        if (!value) return {
            style: {
                display: "none"
            }
        };
    };
}
const CSS_VAR_TEXT = Symbol("CSS_VAR_TEXT");
function useCssVars(getter) {
    const instance = (0, _runtimeCore.getCurrentInstance)();
    if (!instance) {
        (0, _runtimeCore.warn)(`useCssVars is called without current active component instance.`);
        return;
    }
    const updateTeleports = instance.ut = (vars = getter(instance.proxy))=>{
        Array.from(document.querySelectorAll(`[data-v-owner="${instance.uid}"]`)).forEach((node)=>setVarsOnNode(node, vars));
    };
    const setVars = ()=>{
        const vars = getter(instance.proxy);
        setVarsOnVNode(instance.subTree, vars);
        updateTeleports(vars);
    };
    (0, _runtimeCore.watchPostEffect)(setVars);
    (0, _runtimeCore.onMounted)(()=>{
        const ob = new MutationObserver(setVars);
        ob.observe(instance.subTree.el.parentNode, {
            childList: true
        });
        (0, _runtimeCore.onUnmounted)(()=>ob.disconnect());
    });
}
function setVarsOnVNode(vnode, vars) {
    if (vnode.shapeFlag & 128) {
        const suspense = vnode.suspense;
        vnode = suspense.activeBranch;
        if (suspense.pendingBranch && !suspense.isHydrating) suspense.effects.push(()=>{
            setVarsOnVNode(suspense.activeBranch, vars);
        });
    }
    while(vnode.component)vnode = vnode.component.subTree;
    if (vnode.shapeFlag & 1 && vnode.el) setVarsOnNode(vnode.el, vars);
    else if (vnode.type === (0, _runtimeCore.Fragment)) vnode.children.forEach((c)=>setVarsOnVNode(c, vars));
    else if (vnode.type === (0, _runtimeCore.Static)) {
        let { el, anchor } = vnode;
        while(el){
            setVarsOnNode(el, vars);
            if (el === anchor) break;
            el = el.nextSibling;
        }
    }
}
function setVarsOnNode(el, vars) {
    if (el.nodeType === 1) {
        const style = el.style;
        let cssText = "";
        for(const key in vars){
            style.setProperty(`--${key}`, vars[key]);
            cssText += `--${key}: ${vars[key]};`;
        }
        style[CSS_VAR_TEXT] = cssText;
    }
}
function patchStyle(el, prev, next) {
    const style = el.style;
    const isCssString = (0, _shared.isString)(next);
    if (next && !isCssString) {
        if (prev && !(0, _shared.isString)(prev)) {
            for(const key in prev)if (next[key] == null) setStyle(style, key, "");
        }
        for(const key in next)setStyle(style, key, next[key]);
    } else {
        const currentDisplay = style.display;
        if (isCssString) {
            if (prev !== next) {
                const cssVarText = style[CSS_VAR_TEXT];
                if (cssVarText) next += ";" + cssVarText;
                style.cssText = next;
            }
        } else if (prev) el.removeAttribute("style");
        if (vShowOldKey in el) style.display = currentDisplay;
    }
}
const semicolonRE = /[^\\];\s*$/;
const importantRE = /\s*!important$/;
function setStyle(style, name, val) {
    if ((0, _shared.isArray)(val)) val.forEach((v)=>setStyle(style, name, v));
    else {
        if (val == null) val = "";
        if (semicolonRE.test(val)) (0, _runtimeCore.warn)(`Unexpected semicolon at the end of '${name}' style value: '${val}'`);
        if (name.startsWith("--")) style.setProperty(name, val);
        else {
            const prefixed = autoPrefix(style, name);
            if (importantRE.test(val)) style.setProperty((0, _shared.hyphenate)(prefixed), val.replace(importantRE, ""), "important");
            else style[prefixed] = val;
        }
    }
}
const prefixes = [
    "Webkit",
    "Moz",
    "ms"
];
const prefixCache = {};
function autoPrefix(style, rawName) {
    const cached = prefixCache[rawName];
    if (cached) return cached;
    let name = (0, _runtimeCore.camelize)(rawName);
    if (name !== "filter" && name in style) return prefixCache[rawName] = name;
    name = (0, _shared.capitalize)(name);
    for(let i = 0; i < prefixes.length; i++){
        const prefixed = prefixes[i] + name;
        if (prefixed in style) return prefixCache[rawName] = prefixed;
    }
    return rawName;
}
const xlinkNS = "http://www.w3.org/1999/xlink";
function patchAttr(el, key, value, isSVG, instance) {
    if (isSVG && key.startsWith("xlink:")) {
        if (value == null) el.removeAttributeNS(xlinkNS, key.slice(6, key.length));
        else el.setAttributeNS(xlinkNS, key, value);
    } else {
        const isBoolean = (0, _shared.isSpecialBooleanAttr)(key);
        if (value == null || isBoolean && !(0, _shared.includeBooleanAttr)(value)) el.removeAttribute(key);
        else el.setAttribute(key, isBoolean ? "" : value);
    }
}
function patchDOMProp(el, key, value, prevChildren, parentComponent, parentSuspense, unmountChildren) {
    if (key === "innerHTML" || key === "textContent") {
        if (prevChildren) unmountChildren(prevChildren, parentComponent, parentSuspense);
        el[key] = value == null ? "" : value;
        return;
    }
    const tag = el.tagName;
    if (key === "value" && tag !== "PROGRESS" && // custom elements may use _value internally
    !tag.includes("-")) {
        el._value = value;
        const oldValue = tag === "OPTION" ? el.getAttribute("value") : el.value;
        const newValue = value == null ? "" : value;
        if (oldValue !== newValue) el.value = newValue;
        if (value == null) el.removeAttribute(key);
        return;
    }
    let needRemove = false;
    if (value === "" || value == null) {
        const type = typeof el[key];
        if (type === "boolean") value = (0, _shared.includeBooleanAttr)(value);
        else if (value == null && type === "string") {
            value = "";
            needRemove = true;
        } else if (type === "number") {
            value = 0;
            needRemove = true;
        }
    }
    try {
        el[key] = value;
    } catch (e) {
        if (!needRemove) (0, _runtimeCore.warn)(`Failed setting prop "${key}" on <${tag.toLowerCase()}>: value ${value} is invalid.`, e);
    }
    needRemove && el.removeAttribute(key);
}
function addEventListener(el, event, handler, options) {
    el.addEventListener(event, handler, options);
}
function removeEventListener(el, event, handler, options) {
    el.removeEventListener(event, handler, options);
}
const veiKey = Symbol("_vei");
function patchEvent(el, rawName, prevValue, nextValue, instance = null) {
    const invokers = el[veiKey] || (el[veiKey] = {});
    const existingInvoker = invokers[rawName];
    if (nextValue && existingInvoker) existingInvoker.value = nextValue;
    else {
        const [name, options] = parseName(rawName);
        if (nextValue) {
            const invoker = invokers[rawName] = createInvoker(nextValue, instance);
            addEventListener(el, name, invoker, options);
        } else if (existingInvoker) {
            removeEventListener(el, name, existingInvoker, options);
            invokers[rawName] = void 0;
        }
    }
}
const optionsModifierRE = /(?:Once|Passive|Capture)$/;
function parseName(name) {
    let options;
    if (optionsModifierRE.test(name)) {
        options = {};
        let m;
        while(m = name.match(optionsModifierRE)){
            name = name.slice(0, name.length - m[0].length);
            options[m[0].toLowerCase()] = true;
        }
    }
    const event = name[2] === ":" ? name.slice(3) : (0, _shared.hyphenate)(name.slice(2));
    return [
        event,
        options
    ];
}
let cachedNow = 0;
const p = /* @__PURE__ */ Promise.resolve();
const getNow = ()=>cachedNow || (p.then(()=>cachedNow = 0), cachedNow = Date.now());
function createInvoker(initialValue, instance) {
    const invoker = (e)=>{
        if (!e._vts) e._vts = Date.now();
        else if (e._vts <= invoker.attached) return;
        (0, _runtimeCore.callWithAsyncErrorHandling)(patchStopImmediatePropagation(e, invoker.value), instance, 5, [
            e
        ]);
    };
    invoker.value = initialValue;
    invoker.attached = getNow();
    return invoker;
}
function patchStopImmediatePropagation(e, value) {
    if ((0, _shared.isArray)(value)) {
        const originalStop = e.stopImmediatePropagation;
        e.stopImmediatePropagation = ()=>{
            originalStop.call(e);
            e._stopped = true;
        };
        return value.map((fn)=>(e2)=>!e2._stopped && fn && fn(e2));
    } else return value;
}
const isNativeOn = (key)=>key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && // lowercase letter
    key.charCodeAt(2) > 96 && key.charCodeAt(2) < 123;
const patchProp = (el, key, prevValue, nextValue, isSVG = false, prevChildren, parentComponent, parentSuspense, unmountChildren)=>{
    if (key === "class") patchClass(el, nextValue, isSVG);
    else if (key === "style") patchStyle(el, prevValue, nextValue);
    else if ((0, _shared.isOn)(key)) {
        if (!(0, _shared.isModelListener)(key)) patchEvent(el, key, prevValue, nextValue, parentComponent);
    } else if (key[0] === "." ? (key = key.slice(1), true) : key[0] === "^" ? (key = key.slice(1), false) : shouldSetAsProp(el, key, nextValue, isSVG)) patchDOMProp(el, key, nextValue, prevChildren, parentComponent, parentSuspense, unmountChildren);
    else {
        if (key === "true-value") el._trueValue = nextValue;
        else if (key === "false-value") el._falseValue = nextValue;
        patchAttr(el, key, nextValue, isSVG);
    }
};
function shouldSetAsProp(el, key, value, isSVG) {
    if (isSVG) {
        if (key === "innerHTML" || key === "textContent") return true;
        if (key in el && isNativeOn(key) && (0, _shared.isFunction)(value)) return true;
        return false;
    }
    if (key === "spellcheck" || key === "draggable" || key === "translate") return false;
    if (key === "form") return false;
    if (key === "list" && el.tagName === "INPUT") return false;
    if (key === "type" && el.tagName === "TEXTAREA") return false;
    if (key === "width" || key === "height") {
        const tag = el.tagName;
        if (tag === "IMG" || tag === "VIDEO" || tag === "CANVAS" || tag === "SOURCE") return false;
    }
    if (isNativeOn(key) && (0, _shared.isString)(value)) return false;
    return key in el;
}
/*! #__NO_SIDE_EFFECTS__ */ // @__NO_SIDE_EFFECTS__
function defineCustomElement(options, hydrate2) {
    const Comp = (0, _runtimeCore.defineComponent)(options);
    class VueCustomElement extends VueElement {
        constructor(initialProps){
            super(Comp, initialProps, hydrate2);
        }
    }
    VueCustomElement.def = Comp;
    return VueCustomElement;
}
/*! #__NO_SIDE_EFFECTS__ */ const defineSSRCustomElement = /* @__NO_SIDE_EFFECTS__ */ (options)=>{
    return /* @__PURE__ */ defineCustomElement(options, hydrate);
};
const BaseClass = typeof HTMLElement !== "undefined" ? HTMLElement : class {
};
class VueElement extends BaseClass {
    constructor(_def, _props = {}, hydrate2){
        super();
        this._def = _def;
        this._props = _props;
        /**
     * @internal
     */ this._instance = null;
        this._connected = false;
        this._resolved = false;
        this._numberProps = null;
        this._ob = null;
        if (this.shadowRoot && hydrate2) hydrate2(this._createVNode(), this.shadowRoot);
        else {
            if (0, this.shadowRoot) (0, _runtimeCore.warn)(`Custom element has pre-rendered declarative shadow root but is not defined as hydratable. Use \`defineSSRCustomElement\`.`);
            this.attachShadow({
                mode: "open"
            });
            if (!this._def.__asyncLoader) this._resolveProps(this._def);
        }
    }
    connectedCallback() {
        this._connected = true;
        if (!this._instance) {
            if (this._resolved) this._update();
            else this._resolveDef();
        }
    }
    disconnectedCallback() {
        this._connected = false;
        if (this._ob) {
            this._ob.disconnect();
            this._ob = null;
        }
        (0, _runtimeCore.nextTick)(()=>{
            if (!this._connected) {
                render(null, this.shadowRoot);
                this._instance = null;
            }
        });
    }
    /**
   * resolve inner component definition (handle possible async component)
   */ _resolveDef() {
        this._resolved = true;
        for(let i = 0; i < this.attributes.length; i++)this._setAttr(this.attributes[i].name);
        this._ob = new MutationObserver((mutations)=>{
            for (const m of mutations)this._setAttr(m.attributeName);
        });
        this._ob.observe(this, {
            attributes: true
        });
        const resolve = (def, isAsync = false)=>{
            const { props, styles } = def;
            let numberProps;
            if (props && !(0, _shared.isArray)(props)) for(const key in props){
                const opt = props[key];
                if (opt === Number || opt && opt.type === Number) {
                    if (key in this._props) this._props[key] = (0, _shared.toNumber)(this._props[key]);
                    (numberProps || (numberProps = /* @__PURE__ */ Object.create(null)))[(0, _shared.camelize)(key)] = true;
                }
            }
            this._numberProps = numberProps;
            if (isAsync) this._resolveProps(def);
            this._applyStyles(styles);
            this._update();
        };
        const asyncDef = this._def.__asyncLoader;
        if (asyncDef) asyncDef().then((def)=>resolve(def, true));
        else resolve(this._def);
    }
    _resolveProps(def) {
        const { props } = def;
        const declaredPropKeys = (0, _shared.isArray)(props) ? props : Object.keys(props || {});
        for (const key of Object.keys(this))if (key[0] !== "_" && declaredPropKeys.includes(key)) this._setProp(key, this[key], true, false);
        for (const key of declaredPropKeys.map((0, _shared.camelize)))Object.defineProperty(this, key, {
            get () {
                return this._getProp(key);
            },
            set (val) {
                this._setProp(key, val);
            }
        });
    }
    _setAttr(key) {
        let value = this.getAttribute(key);
        const camelKey = (0, _shared.camelize)(key);
        if (this._numberProps && this._numberProps[camelKey]) value = (0, _shared.toNumber)(value);
        this._setProp(camelKey, value, false);
    }
    /**
   * @internal
   */ _getProp(key) {
        return this._props[key];
    }
    /**
   * @internal
   */ _setProp(key, val, shouldReflect = true, shouldUpdate = true) {
        if (val !== this._props[key]) {
            this._props[key] = val;
            if (shouldUpdate && this._instance) this._update();
            if (shouldReflect) {
                if (val === true) this.setAttribute((0, _shared.hyphenate)(key), "");
                else if (typeof val === "string" || typeof val === "number") this.setAttribute((0, _shared.hyphenate)(key), val + "");
                else if (!val) this.removeAttribute((0, _shared.hyphenate)(key));
            }
        }
    }
    _update() {
        render(this._createVNode(), this.shadowRoot);
    }
    _createVNode() {
        const vnode = (0, _runtimeCore.createVNode)(this._def, (0, _shared.extend)({}, this._props));
        if (!this._instance) vnode.ce = (instance)=>{
            this._instance = instance;
            instance.isCE = true;
            instance.ceReload = (newStyles)=>{
                if (this._styles) {
                    this._styles.forEach((s)=>this.shadowRoot.removeChild(s));
                    this._styles.length = 0;
                }
                this._applyStyles(newStyles);
                this._instance = null;
                this._update();
            };
            const dispatch = (event, args)=>{
                this.dispatchEvent(new CustomEvent(event, {
                    detail: args
                }));
            };
            instance.emit = (event, ...args)=>{
                dispatch(event, args);
                if ((0, _shared.hyphenate)(event) !== event) dispatch((0, _shared.hyphenate)(event), args);
            };
            let parent = this;
            while(parent = parent && (parent.parentNode || parent.host))if (parent instanceof VueElement) {
                instance.parent = parent._instance;
                instance.provides = parent._instance.provides;
                break;
            }
        };
        return vnode;
    }
    _applyStyles(styles) {
        if (styles) styles.forEach((css)=>{
            const s = document.createElement("style");
            s.textContent = css;
            this.shadowRoot.appendChild(s);
            (this._styles || (this._styles = [])).push(s);
        });
    }
}
function useCssModule(name = "$style") {
    {
        const instance = (0, _runtimeCore.getCurrentInstance)();
        if (!instance) {
            (0, _runtimeCore.warn)(`useCssModule must be called inside setup()`);
            return 0, _shared.EMPTY_OBJ;
        }
        const modules = instance.type.__cssModules;
        if (!modules) {
            (0, _runtimeCore.warn)(`Current instance does not have CSS modules injected.`);
            return 0, _shared.EMPTY_OBJ;
        }
        const mod = modules[name];
        if (!mod) {
            (0, _runtimeCore.warn)(`Current instance does not have CSS module named "${name}".`);
            return 0, _shared.EMPTY_OBJ;
        }
        return mod;
    }
}
const positionMap = /* @__PURE__ */ new WeakMap();
const newPositionMap = /* @__PURE__ */ new WeakMap();
const moveCbKey = Symbol("_moveCb");
const enterCbKey = Symbol("_enterCb");
const TransitionGroupImpl = {
    name: "TransitionGroup",
    props: /* @__PURE__ */ (0, _shared.extend)({}, TransitionPropsValidators, {
        tag: String,
        moveClass: String
    }),
    setup (props, { slots }) {
        const instance = (0, _runtimeCore.getCurrentInstance)();
        const state = (0, _runtimeCore.useTransitionState)();
        let prevChildren;
        let children;
        (0, _runtimeCore.onUpdated)(()=>{
            if (!prevChildren.length) return;
            const moveClass = props.moveClass || `${props.name || "v"}-move`;
            if (!hasCSSTransform(prevChildren[0].el, instance.vnode.el, moveClass)) return;
            prevChildren.forEach(callPendingCbs);
            prevChildren.forEach(recordPosition);
            const movedChildren = prevChildren.filter(applyTranslation);
            forceReflow();
            movedChildren.forEach((c)=>{
                const el = c.el;
                const style = el.style;
                addTransitionClass(el, moveClass);
                style.transform = style.webkitTransform = style.transitionDuration = "";
                const cb = el[moveCbKey] = (e)=>{
                    if (e && e.target !== el) return;
                    if (!e || /transform$/.test(e.propertyName)) {
                        el.removeEventListener("transitionend", cb);
                        el[moveCbKey] = null;
                        removeTransitionClass(el, moveClass);
                    }
                };
                el.addEventListener("transitionend", cb);
            });
        });
        return ()=>{
            const rawProps = (0, _runtimeCore.toRaw)(props);
            const cssTransitionProps = resolveTransitionProps(rawProps);
            let tag = rawProps.tag || (0, _runtimeCore.Fragment);
            prevChildren = children;
            children = slots.default ? (0, _runtimeCore.getTransitionRawChildren)(slots.default()) : [];
            for(let i = 0; i < children.length; i++){
                const child = children[i];
                if (child.key != null) (0, _runtimeCore.setTransitionHooks)(child, (0, _runtimeCore.resolveTransitionHooks)(child, cssTransitionProps, state, instance));
                else (0, _runtimeCore.warn)(`<TransitionGroup> children must be keyed.`);
            }
            if (prevChildren) for(let i = 0; i < prevChildren.length; i++){
                const child = prevChildren[i];
                (0, _runtimeCore.setTransitionHooks)(child, (0, _runtimeCore.resolveTransitionHooks)(child, cssTransitionProps, state, instance));
                positionMap.set(child, child.el.getBoundingClientRect());
            }
            return (0, _runtimeCore.createVNode)(tag, null, children);
        };
    }
};
const removeMode = (props)=>delete props.mode;
/* @__PURE__ */ removeMode(TransitionGroupImpl.props);
const TransitionGroup = TransitionGroupImpl;
function callPendingCbs(c) {
    const el = c.el;
    if (el[moveCbKey]) el[moveCbKey]();
    if (el[enterCbKey]) el[enterCbKey]();
}
function recordPosition(c) {
    newPositionMap.set(c, c.el.getBoundingClientRect());
}
function applyTranslation(c) {
    const oldPos = positionMap.get(c);
    const newPos = newPositionMap.get(c);
    const dx = oldPos.left - newPos.left;
    const dy = oldPos.top - newPos.top;
    if (dx || dy) {
        const s = c.el.style;
        s.transform = s.webkitTransform = `translate(${dx}px,${dy}px)`;
        s.transitionDuration = "0s";
        return c;
    }
}
function hasCSSTransform(el, root, moveClass) {
    const clone = el.cloneNode();
    const _vtc = el[vtcKey];
    if (_vtc) _vtc.forEach((cls)=>{
        cls.split(/\s+/).forEach((c)=>c && clone.classList.remove(c));
    });
    moveClass.split(/\s+/).forEach((c)=>c && clone.classList.add(c));
    clone.style.display = "none";
    const container = root.nodeType === 1 ? root : root.parentNode;
    container.appendChild(clone);
    const { hasTransform } = getTransitionInfo(clone);
    container.removeChild(clone);
    return hasTransform;
}
const getModelAssigner = (vnode)=>{
    const fn = vnode.props["onUpdate:modelValue"] || false;
    return (0, _shared.isArray)(fn) ? (value)=>(0, _shared.invokeArrayFns)(fn, value) : fn;
};
function onCompositionStart(e) {
    e.target.composing = true;
}
function onCompositionEnd(e) {
    const target = e.target;
    if (target.composing) {
        target.composing = false;
        target.dispatchEvent(new Event("input"));
    }
}
const assignKey = Symbol("_assign");
const vModelText = {
    created (el, { modifiers: { lazy, trim, number } }, vnode) {
        el[assignKey] = getModelAssigner(vnode);
        const castToNumber = number || vnode.props && vnode.props.type === "number";
        addEventListener(el, lazy ? "change" : "input", (e)=>{
            if (e.target.composing) return;
            let domValue = el.value;
            if (trim) domValue = domValue.trim();
            if (castToNumber) domValue = (0, _shared.looseToNumber)(domValue);
            el[assignKey](domValue);
        });
        if (trim) addEventListener(el, "change", ()=>{
            el.value = el.value.trim();
        });
        if (!lazy) {
            addEventListener(el, "compositionstart", onCompositionStart);
            addEventListener(el, "compositionend", onCompositionEnd);
            addEventListener(el, "change", onCompositionEnd);
        }
    },
    // set value on mounted so it's after min/max for type="range"
    mounted (el, { value }) {
        el.value = value == null ? "" : value;
    },
    beforeUpdate (el, { value, modifiers: { lazy, trim, number } }, vnode) {
        el[assignKey] = getModelAssigner(vnode);
        if (el.composing) return;
        const elValue = number || el.type === "number" ? (0, _shared.looseToNumber)(el.value) : el.value;
        const newValue = value == null ? "" : value;
        if (elValue === newValue) return;
        if (document.activeElement === el && el.type !== "range") {
            if (lazy) return;
            if (trim && el.value.trim() === newValue) return;
        }
        el.value = newValue;
    }
};
const vModelCheckbox = {
    // #4096 array checkboxes need to be deep traversed
    deep: true,
    created (el, _, vnode) {
        el[assignKey] = getModelAssigner(vnode);
        addEventListener(el, "change", ()=>{
            const modelValue = el._modelValue;
            const elementValue = getValue(el);
            const checked = el.checked;
            const assign = el[assignKey];
            if ((0, _shared.isArray)(modelValue)) {
                const index = (0, _shared.looseIndexOf)(modelValue, elementValue);
                const found = index !== -1;
                if (checked && !found) assign(modelValue.concat(elementValue));
                else if (!checked && found) {
                    const filtered = [
                        ...modelValue
                    ];
                    filtered.splice(index, 1);
                    assign(filtered);
                }
            } else if ((0, _shared.isSet)(modelValue)) {
                const cloned = new Set(modelValue);
                if (checked) cloned.add(elementValue);
                else cloned.delete(elementValue);
                assign(cloned);
            } else assign(getCheckboxValue(el, checked));
        });
    },
    // set initial checked on mount to wait for true-value/false-value
    mounted: setChecked,
    beforeUpdate (el, binding, vnode) {
        el[assignKey] = getModelAssigner(vnode);
        setChecked(el, binding, vnode);
    }
};
function setChecked(el, { value, oldValue }, vnode) {
    el._modelValue = value;
    if ((0, _shared.isArray)(value)) el.checked = (0, _shared.looseIndexOf)(value, vnode.props.value) > -1;
    else if ((0, _shared.isSet)(value)) el.checked = value.has(vnode.props.value);
    else if (value !== oldValue) el.checked = (0, _shared.looseEqual)(value, getCheckboxValue(el, true));
}
const vModelRadio = {
    created (el, { value }, vnode) {
        el.checked = (0, _shared.looseEqual)(value, vnode.props.value);
        el[assignKey] = getModelAssigner(vnode);
        addEventListener(el, "change", ()=>{
            el[assignKey](getValue(el));
        });
    },
    beforeUpdate (el, { value, oldValue }, vnode) {
        el[assignKey] = getModelAssigner(vnode);
        if (value !== oldValue) el.checked = (0, _shared.looseEqual)(value, vnode.props.value);
    }
};
const vModelSelect = {
    // <select multiple> value need to be deep traversed
    deep: true,
    created (el, { value, modifiers: { number } }, vnode) {
        const isSetModel = (0, _shared.isSet)(value);
        addEventListener(el, "change", ()=>{
            const selectedVal = Array.prototype.filter.call(el.options, (o)=>o.selected).map((o)=>number ? (0, _shared.looseToNumber)(getValue(o)) : getValue(o));
            el[assignKey](el.multiple ? isSetModel ? new Set(selectedVal) : selectedVal : selectedVal[0]);
        });
        el[assignKey] = getModelAssigner(vnode);
    },
    // set value in mounted & updated because <select> relies on its children
    // <option>s.
    mounted (el, { value }) {
        setSelected(el, value);
    },
    beforeUpdate (el, _binding, vnode) {
        el[assignKey] = getModelAssigner(vnode);
    },
    updated (el, { value }) {
        setSelected(el, value);
    }
};
function setSelected(el, value) {
    const isMultiple = el.multiple;
    if (isMultiple && !(0, _shared.isArray)(value) && !(0, _shared.isSet)(value)) {
        (0, _runtimeCore.warn)(`<select multiple v-model> expects an Array or Set value for its binding, but got ${Object.prototype.toString.call(value).slice(8, -1)}.`);
        return;
    }
    for(let i = 0, l = el.options.length; i < l; i++){
        const option = el.options[i];
        const optionValue = getValue(option);
        if (isMultiple) {
            if ((0, _shared.isArray)(value)) option.selected = (0, _shared.looseIndexOf)(value, optionValue) > -1;
            else option.selected = value.has(optionValue);
        } else if ((0, _shared.looseEqual)(getValue(option), value)) {
            if (el.selectedIndex !== i) el.selectedIndex = i;
            return;
        }
    }
    if (!isMultiple && el.selectedIndex !== -1) el.selectedIndex = -1;
}
function getValue(el) {
    return "_value" in el ? el._value : el.value;
}
function getCheckboxValue(el, checked) {
    const key = checked ? "_trueValue" : "_falseValue";
    return key in el ? el[key] : checked;
}
const vModelDynamic = {
    created (el, binding, vnode) {
        callModelHook(el, binding, vnode, null, "created");
    },
    mounted (el, binding, vnode) {
        callModelHook(el, binding, vnode, null, "mounted");
    },
    beforeUpdate (el, binding, vnode, prevVNode) {
        callModelHook(el, binding, vnode, prevVNode, "beforeUpdate");
    },
    updated (el, binding, vnode, prevVNode) {
        callModelHook(el, binding, vnode, prevVNode, "updated");
    }
};
function resolveDynamicModel(tagName, type) {
    switch(tagName){
        case "SELECT":
            return vModelSelect;
        case "TEXTAREA":
            return vModelText;
        default:
            switch(type){
                case "checkbox":
                    return vModelCheckbox;
                case "radio":
                    return vModelRadio;
                default:
                    return vModelText;
            }
    }
}
function callModelHook(el, binding, vnode, prevVNode, hook) {
    const modelToUse = resolveDynamicModel(el.tagName, vnode.props && vnode.props.type);
    const fn = modelToUse[hook];
    fn && fn(el, binding, vnode, prevVNode);
}
function initVModelForSSR() {
    vModelText.getSSRProps = ({ value })=>({
            value
        });
    vModelRadio.getSSRProps = ({ value }, vnode)=>{
        if (vnode.props && (0, _shared.looseEqual)(vnode.props.value, value)) return {
            checked: true
        };
    };
    vModelCheckbox.getSSRProps = ({ value }, vnode)=>{
        if ((0, _shared.isArray)(value)) {
            if (vnode.props && (0, _shared.looseIndexOf)(value, vnode.props.value) > -1) return {
                checked: true
            };
        } else if ((0, _shared.isSet)(value)) {
            if (vnode.props && value.has(vnode.props.value)) return {
                checked: true
            };
        } else if (value) return {
            checked: true
        };
    };
    vModelDynamic.getSSRProps = (binding, vnode)=>{
        if (typeof vnode.type !== "string") return;
        const modelToUse = resolveDynamicModel(// resolveDynamicModel expects an uppercase tag name, but vnode.type is lowercase
        vnode.type.toUpperCase(), vnode.props && vnode.props.type);
        if (modelToUse.getSSRProps) return modelToUse.getSSRProps(binding, vnode);
    };
}
const systemModifiers = [
    "ctrl",
    "shift",
    "alt",
    "meta"
];
const modifierGuards = {
    stop: (e)=>e.stopPropagation(),
    prevent: (e)=>e.preventDefault(),
    self: (e)=>e.target !== e.currentTarget,
    ctrl: (e)=>!e.ctrlKey,
    shift: (e)=>!e.shiftKey,
    alt: (e)=>!e.altKey,
    meta: (e)=>!e.metaKey,
    left: (e)=>"button" in e && e.button !== 0,
    middle: (e)=>"button" in e && e.button !== 1,
    right: (e)=>"button" in e && e.button !== 2,
    exact: (e, modifiers)=>systemModifiers.some((m)=>e[`${m}Key`] && !modifiers.includes(m))
};
const withModifiers = (fn, modifiers)=>{
    const cache = fn._withMods || (fn._withMods = {});
    const cacheKey = modifiers.join(".");
    return cache[cacheKey] || (cache[cacheKey] = (event, ...args)=>{
        for(let i = 0; i < modifiers.length; i++){
            const guard = modifierGuards[modifiers[i]];
            if (guard && guard(event, modifiers)) return;
        }
        return fn(event, ...args);
    });
};
const keyNames = {
    esc: "escape",
    space: " ",
    up: "arrow-up",
    left: "arrow-left",
    right: "arrow-right",
    down: "arrow-down",
    delete: "backspace"
};
const withKeys = (fn, modifiers)=>{
    const cache = fn._withKeys || (fn._withKeys = {});
    const cacheKey = modifiers.join(".");
    return cache[cacheKey] || (cache[cacheKey] = (event)=>{
        if (!("key" in event)) return;
        const eventKey = (0, _shared.hyphenate)(event.key);
        if (modifiers.some((k)=>k === eventKey || keyNames[k] === eventKey)) return fn(event);
    });
};
const rendererOptions = /* @__PURE__ */ (0, _shared.extend)({
    patchProp
}, nodeOps);
let renderer;
let enabledHydration = false;
function ensureRenderer() {
    return renderer || (renderer = (0, _runtimeCore.createRenderer)(rendererOptions));
}
function ensureHydrationRenderer() {
    renderer = enabledHydration ? renderer : (0, _runtimeCore.createHydrationRenderer)(rendererOptions);
    enabledHydration = true;
    return renderer;
}
const render = (...args)=>{
    ensureRenderer().render(...args);
};
const hydrate = (...args)=>{
    ensureHydrationRenderer().hydrate(...args);
};
const createApp = (...args)=>{
    const app = ensureRenderer().createApp(...args);
    injectNativeTagCheck(app);
    injectCompilerOptionsCheck(app);
    const { mount } = app;
    app.mount = (containerOrSelector)=>{
        const container = normalizeContainer(containerOrSelector);
        if (!container) return;
        const component = app._component;
        if (!(0, _shared.isFunction)(component) && !component.render && !component.template) component.template = container.innerHTML;
        container.innerHTML = "";
        const proxy = mount(container, false, container instanceof SVGElement);
        if (container instanceof Element) {
            container.removeAttribute("v-cloak");
            container.setAttribute("data-v-app", "");
        }
        return proxy;
    };
    return app;
};
const createSSRApp = (...args)=>{
    const app = ensureHydrationRenderer().createApp(...args);
    injectNativeTagCheck(app);
    injectCompilerOptionsCheck(app);
    const { mount } = app;
    app.mount = (containerOrSelector)=>{
        const container = normalizeContainer(containerOrSelector);
        if (container) return mount(container, true, container instanceof SVGElement);
    };
    return app;
};
function injectNativeTagCheck(app) {
    Object.defineProperty(app.config, "isNativeTag", {
        value: (tag)=>(0, _shared.isHTMLTag)(tag) || (0, _shared.isSVGTag)(tag),
        writable: false
    });
}
function injectCompilerOptionsCheck(app) {
    if ((0, _runtimeCore.isRuntimeOnly)()) {
        const isCustomElement = app.config.isCustomElement;
        Object.defineProperty(app.config, "isCustomElement", {
            get () {
                return isCustomElement;
            },
            set () {
                (0, _runtimeCore.warn)(`The \`isCustomElement\` config option is deprecated. Use \`compilerOptions.isCustomElement\` instead.`);
            }
        });
        const compilerOptions = app.config.compilerOptions;
        const msg = `The \`compilerOptions\` config option is only respected when using a build of Vue.js that includes the runtime compiler (aka "full build"). Since you are using the runtime-only build, \`compilerOptions\` must be passed to \`@vue/compiler-dom\` in the build setup instead.
- For vue-loader: pass it via vue-loader's \`compilerOptions\` loader option.
- For vue-cli: see https://cli.vuejs.org/guide/webpack.html#modifying-options-of-a-loader
- For vite: pass it via @vitejs/plugin-vue options. See https://github.com/vitejs/vite-plugin-vue/tree/main/packages/plugin-vue#example-for-passing-options-to-vuecompiler-sfc`;
        Object.defineProperty(app.config, "compilerOptions", {
            get () {
                (0, _runtimeCore.warn)(msg);
                return compilerOptions;
            },
            set () {
                (0, _runtimeCore.warn)(msg);
            }
        });
    }
}
function normalizeContainer(container) {
    if ((0, _shared.isString)(container)) {
        const res = document.querySelector(container);
        if (!res) (0, _runtimeCore.warn)(`Failed to mount app: mount target selector "${container}" returned null.`);
        return res;
    }
    if ((0, window.ShadowRoot) && container instanceof window.ShadowRoot && container.mode === "closed") (0, _runtimeCore.warn)(`mounting on a ShadowRoot with \`{mode: "closed"}\` may lead to unpredictable bugs`);
    return container;
}
let ssrDirectiveInitialized = false;
const initDirectivesForSSR = ()=>{
    if (!ssrDirectiveInitialized) {
        ssrDirectiveInitialized = true;
        initVModelForSSR();
        initVShowForSSR();
    }
};

},{"@vue/runtime-core":"lmqBl","@vue/shared":"3SM3y","@parcel/transformer-js/src/esmodule-helpers.js":"gkKU3"}],"lmqBl":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "EffectScope", ()=>(0, _reactivity.EffectScope));
parcelHelpers.export(exports, "ReactiveEffect", ()=>(0, _reactivity.ReactiveEffect));
parcelHelpers.export(exports, "customRef", ()=>(0, _reactivity.customRef));
parcelHelpers.export(exports, "effect", ()=>(0, _reactivity.effect));
parcelHelpers.export(exports, "effectScope", ()=>(0, _reactivity.effectScope));
parcelHelpers.export(exports, "getCurrentScope", ()=>(0, _reactivity.getCurrentScope));
parcelHelpers.export(exports, "isProxy", ()=>(0, _reactivity.isProxy));
parcelHelpers.export(exports, "isReactive", ()=>(0, _reactivity.isReactive));
parcelHelpers.export(exports, "isReadonly", ()=>(0, _reactivity.isReadonly));
parcelHelpers.export(exports, "isRef", ()=>(0, _reactivity.isRef));
parcelHelpers.export(exports, "isShallow", ()=>(0, _reactivity.isShallow));
parcelHelpers.export(exports, "markRaw", ()=>(0, _reactivity.markRaw));
parcelHelpers.export(exports, "onScopeDispose", ()=>(0, _reactivity.onScopeDispose));
parcelHelpers.export(exports, "proxyRefs", ()=>(0, _reactivity.proxyRefs));
parcelHelpers.export(exports, "reactive", ()=>(0, _reactivity.reactive));
parcelHelpers.export(exports, "readonly", ()=>(0, _reactivity.readonly));
parcelHelpers.export(exports, "ref", ()=>(0, _reactivity.ref));
parcelHelpers.export(exports, "shallowReactive", ()=>(0, _reactivity.shallowReactive));
parcelHelpers.export(exports, "shallowReadonly", ()=>(0, _reactivity.shallowReadonly));
parcelHelpers.export(exports, "shallowRef", ()=>(0, _reactivity.shallowRef));
parcelHelpers.export(exports, "stop", ()=>(0, _reactivity.stop));
parcelHelpers.export(exports, "toRaw", ()=>(0, _reactivity.toRaw));
parcelHelpers.export(exports, "toRef", ()=>(0, _reactivity.toRef));
parcelHelpers.export(exports, "toRefs", ()=>(0, _reactivity.toRefs));
parcelHelpers.export(exports, "toValue", ()=>(0, _reactivity.toValue));
parcelHelpers.export(exports, "triggerRef", ()=>(0, _reactivity.triggerRef));
parcelHelpers.export(exports, "unref", ()=>(0, _reactivity.unref));
parcelHelpers.export(exports, "camelize", ()=>(0, _shared.camelize));
parcelHelpers.export(exports, "capitalize", ()=>(0, _shared.capitalize));
parcelHelpers.export(exports, "normalizeClass", ()=>(0, _shared.normalizeClass));
parcelHelpers.export(exports, "normalizeProps", ()=>(0, _shared.normalizeProps));
parcelHelpers.export(exports, "normalizeStyle", ()=>(0, _shared.normalizeStyle));
parcelHelpers.export(exports, "toDisplayString", ()=>(0, _shared.toDisplayString));
parcelHelpers.export(exports, "toHandlerKey", ()=>(0, _shared.toHandlerKey));
parcelHelpers.export(exports, "BaseTransition", ()=>BaseTransition);
parcelHelpers.export(exports, "BaseTransitionPropsValidators", ()=>BaseTransitionPropsValidators);
parcelHelpers.export(exports, "Comment", ()=>Comment);
parcelHelpers.export(exports, "Fragment", ()=>Fragment);
parcelHelpers.export(exports, "KeepAlive", ()=>KeepAlive);
parcelHelpers.export(exports, "Static", ()=>Static);
parcelHelpers.export(exports, "Suspense", ()=>Suspense);
parcelHelpers.export(exports, "Teleport", ()=>Teleport);
parcelHelpers.export(exports, "Text", ()=>Text);
parcelHelpers.export(exports, "assertNumber", ()=>assertNumber);
parcelHelpers.export(exports, "callWithAsyncErrorHandling", ()=>callWithAsyncErrorHandling);
parcelHelpers.export(exports, "callWithErrorHandling", ()=>callWithErrorHandling);
parcelHelpers.export(exports, "cloneVNode", ()=>cloneVNode);
parcelHelpers.export(exports, "compatUtils", ()=>compatUtils);
parcelHelpers.export(exports, "computed", ()=>computed);
parcelHelpers.export(exports, "createBlock", ()=>createBlock);
parcelHelpers.export(exports, "createCommentVNode", ()=>createCommentVNode);
parcelHelpers.export(exports, "createElementBlock", ()=>createElementBlock);
parcelHelpers.export(exports, "createElementVNode", ()=>createBaseVNode);
parcelHelpers.export(exports, "createHydrationRenderer", ()=>createHydrationRenderer);
parcelHelpers.export(exports, "createPropsRestProxy", ()=>createPropsRestProxy);
parcelHelpers.export(exports, "createRenderer", ()=>createRenderer);
parcelHelpers.export(exports, "createSlots", ()=>createSlots);
parcelHelpers.export(exports, "createStaticVNode", ()=>createStaticVNode);
parcelHelpers.export(exports, "createTextVNode", ()=>createTextVNode);
parcelHelpers.export(exports, "createVNode", ()=>createVNode);
parcelHelpers.export(exports, "defineAsyncComponent", ()=>defineAsyncComponent);
parcelHelpers.export(exports, "defineComponent", ()=>defineComponent);
parcelHelpers.export(exports, "defineEmits", ()=>defineEmits);
parcelHelpers.export(exports, "defineExpose", ()=>defineExpose);
parcelHelpers.export(exports, "defineModel", ()=>defineModel);
parcelHelpers.export(exports, "defineOptions", ()=>defineOptions);
parcelHelpers.export(exports, "defineProps", ()=>defineProps);
parcelHelpers.export(exports, "defineSlots", ()=>defineSlots);
parcelHelpers.export(exports, "devtools", ()=>devtools);
parcelHelpers.export(exports, "getCurrentInstance", ()=>getCurrentInstance);
parcelHelpers.export(exports, "getTransitionRawChildren", ()=>getTransitionRawChildren);
parcelHelpers.export(exports, "guardReactiveProps", ()=>guardReactiveProps);
parcelHelpers.export(exports, "h", ()=>h);
parcelHelpers.export(exports, "handleError", ()=>handleError);
parcelHelpers.export(exports, "hasInjectionContext", ()=>hasInjectionContext);
parcelHelpers.export(exports, "initCustomFormatter", ()=>initCustomFormatter);
parcelHelpers.export(exports, "inject", ()=>inject);
parcelHelpers.export(exports, "isMemoSame", ()=>isMemoSame);
parcelHelpers.export(exports, "isRuntimeOnly", ()=>isRuntimeOnly);
parcelHelpers.export(exports, "isVNode", ()=>isVNode);
parcelHelpers.export(exports, "mergeDefaults", ()=>mergeDefaults);
parcelHelpers.export(exports, "mergeModels", ()=>mergeModels);
parcelHelpers.export(exports, "mergeProps", ()=>mergeProps);
parcelHelpers.export(exports, "nextTick", ()=>nextTick);
parcelHelpers.export(exports, "onActivated", ()=>onActivated);
parcelHelpers.export(exports, "onBeforeMount", ()=>onBeforeMount);
parcelHelpers.export(exports, "onBeforeUnmount", ()=>onBeforeUnmount);
parcelHelpers.export(exports, "onBeforeUpdate", ()=>onBeforeUpdate);
parcelHelpers.export(exports, "onDeactivated", ()=>onDeactivated);
parcelHelpers.export(exports, "onErrorCaptured", ()=>onErrorCaptured);
parcelHelpers.export(exports, "onMounted", ()=>onMounted);
parcelHelpers.export(exports, "onRenderTracked", ()=>onRenderTracked);
parcelHelpers.export(exports, "onRenderTriggered", ()=>onRenderTriggered);
parcelHelpers.export(exports, "onServerPrefetch", ()=>onServerPrefetch);
parcelHelpers.export(exports, "onUnmounted", ()=>onUnmounted);
parcelHelpers.export(exports, "onUpdated", ()=>onUpdated);
parcelHelpers.export(exports, "openBlock", ()=>openBlock);
parcelHelpers.export(exports, "popScopeId", ()=>popScopeId);
parcelHelpers.export(exports, "provide", ()=>provide);
parcelHelpers.export(exports, "pushScopeId", ()=>pushScopeId);
parcelHelpers.export(exports, "queuePostFlushCb", ()=>queuePostFlushCb);
parcelHelpers.export(exports, "registerRuntimeCompiler", ()=>registerRuntimeCompiler);
parcelHelpers.export(exports, "renderList", ()=>renderList);
parcelHelpers.export(exports, "renderSlot", ()=>renderSlot);
parcelHelpers.export(exports, "resolveComponent", ()=>resolveComponent);
parcelHelpers.export(exports, "resolveDirective", ()=>resolveDirective);
parcelHelpers.export(exports, "resolveDynamicComponent", ()=>resolveDynamicComponent);
parcelHelpers.export(exports, "resolveFilter", ()=>resolveFilter);
parcelHelpers.export(exports, "resolveTransitionHooks", ()=>resolveTransitionHooks);
parcelHelpers.export(exports, "setBlockTracking", ()=>setBlockTracking);
parcelHelpers.export(exports, "setDevtoolsHook", ()=>setDevtoolsHook);
parcelHelpers.export(exports, "setTransitionHooks", ()=>setTransitionHooks);
parcelHelpers.export(exports, "ssrContextKey", ()=>ssrContextKey);
parcelHelpers.export(exports, "ssrUtils", ()=>ssrUtils);
parcelHelpers.export(exports, "toHandlers", ()=>toHandlers);
parcelHelpers.export(exports, "transformVNodeArgs", ()=>transformVNodeArgs);
parcelHelpers.export(exports, "useAttrs", ()=>useAttrs);
parcelHelpers.export(exports, "useModel", ()=>useModel);
parcelHelpers.export(exports, "useSSRContext", ()=>useSSRContext);
parcelHelpers.export(exports, "useSlots", ()=>useSlots);
parcelHelpers.export(exports, "useTransitionState", ()=>useTransitionState);
parcelHelpers.export(exports, "version", ()=>version);
parcelHelpers.export(exports, "warn", ()=>warn);
parcelHelpers.export(exports, "watch", ()=>watch);
parcelHelpers.export(exports, "watchEffect", ()=>watchEffect);
parcelHelpers.export(exports, "watchPostEffect", ()=>watchPostEffect);
parcelHelpers.export(exports, "watchSyncEffect", ()=>watchSyncEffect);
parcelHelpers.export(exports, "withAsyncContext", ()=>withAsyncContext);
parcelHelpers.export(exports, "withCtx", ()=>withCtx);
parcelHelpers.export(exports, "withDefaults", ()=>withDefaults);
parcelHelpers.export(exports, "withDirectives", ()=>withDirectives);
parcelHelpers.export(exports, "withMemo", ()=>withMemo);
parcelHelpers.export(exports, "withScopeId", ()=>withScopeId);
var _reactivity = require("@vue/reactivity");
var _shared = require("@vue/shared");
const stack = [];
function pushWarningContext(vnode) {
    stack.push(vnode);
}
function popWarningContext() {
    stack.pop();
}
function warn(msg, ...args) {
    (0, _reactivity.pauseTracking)();
    const instance = stack.length ? stack[stack.length - 1].component : null;
    const appWarnHandler = instance && instance.appContext.config.warnHandler;
    const trace = getComponentTrace();
    if (appWarnHandler) callWithErrorHandling(appWarnHandler, instance, 11, [
        msg + args.join(""),
        instance && instance.proxy,
        trace.map(({ vnode })=>`at <${formatComponentName(instance, vnode.type)}>`).join("\n"),
        trace
    ]);
    else {
        const warnArgs = [
            `[Vue warn]: ${msg}`,
            ...args
        ];
        if (trace.length && // avoid spamming console during tests
        true) warnArgs.push(`
`, ...formatTrace(trace));
        console.warn(...warnArgs);
    }
    (0, _reactivity.resetTracking)();
}
function getComponentTrace() {
    let currentVNode = stack[stack.length - 1];
    if (!currentVNode) return [];
    const normalizedStack = [];
    while(currentVNode){
        const last = normalizedStack[0];
        if (last && last.vnode === currentVNode) last.recurseCount++;
        else normalizedStack.push({
            vnode: currentVNode,
            recurseCount: 0
        });
        const parentInstance = currentVNode.component && currentVNode.component.parent;
        currentVNode = parentInstance && parentInstance.vnode;
    }
    return normalizedStack;
}
function formatTrace(trace) {
    const logs = [];
    trace.forEach((entry, i)=>{
        logs.push(...i === 0 ? [] : [
            `
`
        ], ...formatTraceEntry(entry));
    });
    return logs;
}
function formatTraceEntry({ vnode, recurseCount }) {
    const postfix = recurseCount > 0 ? `... (${recurseCount} recursive calls)` : ``;
    const isRoot = vnode.component ? vnode.component.parent == null : false;
    const open = ` at <${formatComponentName(vnode.component, vnode.type, isRoot)}`;
    const close = `>` + postfix;
    return vnode.props ? [
        open,
        ...formatProps(vnode.props),
        close
    ] : [
        open + close
    ];
}
function formatProps(props) {
    const res = [];
    const keys = Object.keys(props);
    keys.slice(0, 3).forEach((key)=>{
        res.push(...formatProp(key, props[key]));
    });
    if (keys.length > 3) res.push(` ...`);
    return res;
}
function formatProp(key, value1, raw) {
    if ((0, _shared.isString)(value1)) {
        value1 = JSON.stringify(value1);
        return raw ? value1 : [
            `${key}=${value1}`
        ];
    } else if (typeof value1 === "number" || typeof value1 === "boolean" || value1 == null) return raw ? value1 : [
        `${key}=${value1}`
    ];
    else if ((0, _reactivity.isRef)(value1)) {
        value1 = formatProp(key, (0, _reactivity.toRaw)(value1.value), true);
        return raw ? value1 : [
            `${key}=Ref<`,
            value1,
            `>`
        ];
    } else if ((0, _shared.isFunction)(value1)) return [
        `${key}=fn${value1.name ? `<${value1.name}>` : ``}`
    ];
    else {
        value1 = (0, _reactivity.toRaw)(value1);
        return raw ? value1 : [
            `${key}=`,
            value1
        ];
    }
}
function assertNumber(val, type) {
    if (val === void 0) return;
    else if (typeof val !== "number") warn(`${type} is not a valid number - got ${JSON.stringify(val)}.`);
    else if (isNaN(val)) warn(`${type} is NaN - the duration expression might be incorrect.`);
}
const ErrorTypeStrings = {
    ["sp"]: "serverPrefetch hook",
    ["bc"]: "beforeCreate hook",
    ["c"]: "created hook",
    ["bm"]: "beforeMount hook",
    ["m"]: "mounted hook",
    ["bu"]: "beforeUpdate hook",
    ["u"]: "updated",
    ["bum"]: "beforeUnmount hook",
    ["um"]: "unmounted hook",
    ["a"]: "activated hook",
    ["da"]: "deactivated hook",
    ["ec"]: "errorCaptured hook",
    ["rtc"]: "renderTracked hook",
    ["rtg"]: "renderTriggered hook",
    [0]: "setup function",
    [1]: "render function",
    [2]: "watcher getter",
    [3]: "watcher callback",
    [4]: "watcher cleanup function",
    [5]: "native event handler",
    [6]: "component event handler",
    [7]: "vnode hook",
    [8]: "directive hook",
    [9]: "transition hook",
    [10]: "app errorHandler",
    [11]: "app warnHandler",
    [12]: "ref function",
    [13]: "async component loader",
    [14]: "scheduler flush. This is likely a Vue internals bug. Please open an issue at https://new-issue.vuejs.org/?repo=vuejs/core"
};
function callWithErrorHandling(fn, instance, type, args) {
    let res;
    try {
        res = args ? fn(...args) : fn();
    } catch (err) {
        handleError(err, instance, type);
    }
    return res;
}
function callWithAsyncErrorHandling(fn, instance, type, args) {
    if ((0, _shared.isFunction)(fn)) {
        const res = callWithErrorHandling(fn, instance, type, args);
        if (res && (0, _shared.isPromise)(res)) res.catch((err)=>{
            handleError(err, instance, type);
        });
        return res;
    }
    const values = [];
    for(let i = 0; i < fn.length; i++)values.push(callWithAsyncErrorHandling(fn[i], instance, type, args));
    return values;
}
function handleError(err, instance, type, throwInDev = true) {
    const contextVNode = instance ? instance.vnode : null;
    if (instance) {
        let cur = instance.parent;
        const exposedInstance = instance.proxy;
        const errorInfo = (0, ErrorTypeStrings[type]);
        while(cur){
            const errorCapturedHooks = cur.ec;
            if (errorCapturedHooks) for(let i = 0; i < errorCapturedHooks.length; i++){
                if (errorCapturedHooks[i](err, exposedInstance, errorInfo) === false) return;
            }
            cur = cur.parent;
        }
        const appErrorHandler = instance.appContext.config.errorHandler;
        if (appErrorHandler) {
            callWithErrorHandling(appErrorHandler, null, 10, [
                err,
                exposedInstance,
                errorInfo
            ]);
            return;
        }
    }
    logError(err, type, contextVNode, throwInDev);
}
function logError(err, type, contextVNode, throwInDev = true) {
    {
        const info = ErrorTypeStrings[type];
        if (contextVNode) pushWarningContext(contextVNode);
        warn(`Unhandled error${info ? ` during execution of ${info}` : ``}`);
        if (contextVNode) popWarningContext();
        if (throwInDev) throw err;
        else console.error(err);
    }
}
let isFlushing = false;
let isFlushPending = false;
const queue = [];
let flushIndex = 0;
const pendingPostFlushCbs = [];
let activePostFlushCbs = null;
let postFlushIndex = 0;
const resolvedPromise = /* @__PURE__ */ Promise.resolve();
let currentFlushPromise = null;
const RECURSION_LIMIT = 100;
function nextTick(fn) {
    const p = currentFlushPromise || resolvedPromise;
    return fn ? p.then(this ? fn.bind(this) : fn) : p;
}
function findInsertionIndex(id) {
    let start = flushIndex + 1;
    let end = queue.length;
    while(start < end){
        const middle = start + end >>> 1;
        const middleJob = queue[middle];
        const middleJobId = getId(middleJob);
        if (middleJobId < id || middleJobId === id && middleJob.pre) start = middle + 1;
        else end = middle;
    }
    return start;
}
function queueJob(job) {
    if (!queue.length || !queue.includes(job, isFlushing && job.allowRecurse ? flushIndex + 1 : flushIndex)) {
        if (job.id == null) queue.push(job);
        else queue.splice(findInsertionIndex(job.id), 0, job);
        queueFlush();
    }
}
function queueFlush() {
    if (!isFlushing && !isFlushPending) {
        isFlushPending = true;
        currentFlushPromise = resolvedPromise.then(flushJobs);
    }
}
function invalidateJob(job) {
    const i = queue.indexOf(job);
    if (i > flushIndex) queue.splice(i, 1);
}
function queuePostFlushCb(cb) {
    if (!(0, _shared.isArray)(cb)) {
        if (!activePostFlushCbs || !activePostFlushCbs.includes(cb, cb.allowRecurse ? postFlushIndex + 1 : postFlushIndex)) pendingPostFlushCbs.push(cb);
    } else pendingPostFlushCbs.push(...cb);
    queueFlush();
}
function flushPreFlushCbs(instance, seen, i = isFlushing ? flushIndex + 1 : 0) {
    seen = seen || /* @__PURE__ */ new Map();
    for(; i < queue.length; i++){
        const cb = queue[i];
        if (cb && cb.pre) {
            if (instance && cb.id !== instance.uid) continue;
            if (checkRecursiveUpdates(seen, cb)) continue;
            queue.splice(i, 1);
            i--;
            cb();
        }
    }
}
function flushPostFlushCbs(seen) {
    if (pendingPostFlushCbs.length) {
        const deduped = [
            ...new Set(pendingPostFlushCbs)
        ];
        pendingPostFlushCbs.length = 0;
        if (activePostFlushCbs) {
            activePostFlushCbs.push(...deduped);
            return;
        }
        activePostFlushCbs = deduped;
        seen = seen || /* @__PURE__ */ new Map();
        activePostFlushCbs.sort((a, b)=>getId(a) - getId(b));
        for(postFlushIndex = 0; postFlushIndex < activePostFlushCbs.length; postFlushIndex++){
            if (checkRecursiveUpdates(seen, activePostFlushCbs[postFlushIndex])) continue;
            activePostFlushCbs[postFlushIndex]();
        }
        activePostFlushCbs = null;
        postFlushIndex = 0;
    }
}
const getId = (job)=>job.id == null ? Infinity : job.id;
const comparator = (a, b)=>{
    const diff = getId(a) - getId(b);
    if (diff === 0) {
        if (a.pre && !b.pre) return -1;
        if (b.pre && !a.pre) return 1;
    }
    return diff;
};
function flushJobs(seen) {
    isFlushPending = false;
    isFlushing = true;
    seen = seen || /* @__PURE__ */ new Map();
    queue.sort(comparator);
    const check = (job)=>checkRecursiveUpdates(seen, job);
    try {
        for(flushIndex = 0; flushIndex < queue.length; flushIndex++){
            const job = queue[flushIndex];
            if (job && job.active !== false) {
                if (check(job)) continue;
                callWithErrorHandling(job, null, 14);
            }
        }
    } finally{
        flushIndex = 0;
        queue.length = 0;
        flushPostFlushCbs(seen);
        isFlushing = false;
        currentFlushPromise = null;
        if (queue.length || pendingPostFlushCbs.length) flushJobs(seen);
    }
}
function checkRecursiveUpdates(seen, fn) {
    if (!seen.has(fn)) seen.set(fn, 1);
    else {
        const count = seen.get(fn);
        if (count > RECURSION_LIMIT) {
            const instance = fn.ownerInstance;
            const componentName = instance && getComponentName(instance.type);
            warn(`Maximum recursive updates exceeded${componentName ? ` in component <${componentName}>` : ``}. This means you have a reactive effect that is mutating its own dependencies and thus recursively triggering itself. Possible sources include component template, render function, updated hook or watcher source function.`);
            return true;
        } else seen.set(fn, count + 1);
    }
}
let isHmrUpdating = false;
const hmrDirtyComponents = /* @__PURE__ */ new Set();
(0, _shared.getGlobalThis)().__VUE_HMR_RUNTIME__ = {
    createRecord: tryWrap(createRecord),
    rerender: tryWrap(rerender),
    reload: tryWrap(reload)
};
const map = /* @__PURE__ */ new Map();
function registerHMR(instance) {
    const id = instance.type.__hmrId;
    let record = map.get(id);
    if (!record) {
        createRecord(id, instance.type);
        record = map.get(id);
    }
    record.instances.add(instance);
}
function unregisterHMR(instance) {
    map.get(instance.type.__hmrId).instances.delete(instance);
}
function createRecord(id, initialDef) {
    if (map.has(id)) return false;
    map.set(id, {
        initialDef: normalizeClassComponent(initialDef),
        instances: /* @__PURE__ */ new Set()
    });
    return true;
}
function normalizeClassComponent(component) {
    return isClassComponent(component) ? component.__vccOpts : component;
}
function rerender(id, newRender) {
    const record = map.get(id);
    if (!record) return;
    record.initialDef.render = newRender;
    [
        ...record.instances
    ].forEach((instance)=>{
        if (newRender) {
            instance.render = newRender;
            normalizeClassComponent(instance.type).render = newRender;
        }
        instance.renderCache = [];
        isHmrUpdating = true;
        instance.update();
        isHmrUpdating = false;
    });
}
function reload(id, newComp) {
    const record = map.get(id);
    if (!record) return;
    newComp = normalizeClassComponent(newComp);
    updateComponentDef(record.initialDef, newComp);
    const instances = [
        ...record.instances
    ];
    for (const instance of instances){
        const oldComp = normalizeClassComponent(instance.type);
        if (!hmrDirtyComponents.has(oldComp)) {
            if (oldComp !== record.initialDef) updateComponentDef(oldComp, newComp);
            hmrDirtyComponents.add(oldComp);
        }
        instance.appContext.propsCache.delete(instance.type);
        instance.appContext.emitsCache.delete(instance.type);
        instance.appContext.optionsCache.delete(instance.type);
        if (instance.ceReload) {
            hmrDirtyComponents.add(oldComp);
            instance.ceReload(newComp.styles);
            hmrDirtyComponents.delete(oldComp);
        } else if (instance.parent) queueJob(instance.parent.update);
        else if (instance.appContext.reload) instance.appContext.reload();
        else if (typeof window !== "undefined") window.location.reload();
        else console.warn("[HMR] Root or manually mounted instance modified. Full reload required.");
    }
    queuePostFlushCb(()=>{
        for (const instance of instances)hmrDirtyComponents.delete(normalizeClassComponent(instance.type));
    });
}
function updateComponentDef(oldComp, newComp) {
    (0, _shared.extend)(oldComp, newComp);
    for(const key in oldComp)if (key !== "__file" && !(key in newComp)) delete oldComp[key];
}
function tryWrap(fn) {
    return (id, arg)=>{
        try {
            return fn(id, arg);
        } catch (e) {
            console.error(e);
            console.warn(`[HMR] Something went wrong during Vue component hot-reload. Full reload required.`);
        }
    };
}
let devtools;
let buffer = [];
let devtoolsNotInstalled = false;
function emit$1(event, ...args) {
    if (devtools) devtools.emit(event, ...args);
    else if (!devtoolsNotInstalled) buffer.push({
        event,
        args
    });
}
function setDevtoolsHook(hook, target) {
    var _a, _b;
    devtools = hook;
    if (devtools) {
        devtools.enabled = true;
        buffer.forEach(({ event, args })=>devtools.emit(event, ...args));
        buffer = [];
    } else if (// handle late devtools injection - only do this if we are in an actual
    // browser environment to avoid the timer handle stalling test runner exit
    // (#4815)
    typeof window !== "undefined" && // some envs mock window but not fully
    window.HTMLElement && // also exclude jsdom
    !((_b = (_a = window.navigator) == null ? void 0 : _a.userAgent) == null ? void 0 : _b.includes("jsdom"))) {
        const replay = target.__VUE_DEVTOOLS_HOOK_REPLAY__ = target.__VUE_DEVTOOLS_HOOK_REPLAY__ || [];
        replay.push((newHook)=>{
            setDevtoolsHook(newHook, target);
        });
        setTimeout(()=>{
            if (!devtools) {
                target.__VUE_DEVTOOLS_HOOK_REPLAY__ = null;
                devtoolsNotInstalled = true;
                buffer = [];
            }
        }, 3e3);
    } else {
        devtoolsNotInstalled = true;
        buffer = [];
    }
}
function devtoolsInitApp(app, version) {
    emit$1("app:init" /* APP_INIT */ , app, version, {
        Fragment,
        Text,
        Comment,
        Static
    });
}
function devtoolsUnmountApp(app) {
    emit$1("app:unmount" /* APP_UNMOUNT */ , app);
}
const devtoolsComponentAdded = /* @__PURE__ */ createDevtoolsComponentHook("component:added" /* COMPONENT_ADDED */ );
const devtoolsComponentUpdated = /* @__PURE__ */ createDevtoolsComponentHook("component:updated" /* COMPONENT_UPDATED */ );
const _devtoolsComponentRemoved = /* @__PURE__ */ createDevtoolsComponentHook("component:removed" /* COMPONENT_REMOVED */ );
const devtoolsComponentRemoved = (component)=>{
    if (devtools && typeof devtools.cleanupBuffer === "function" && // remove the component if it wasn't buffered
    !devtools.cleanupBuffer(component)) _devtoolsComponentRemoved(component);
};
function createDevtoolsComponentHook(hook) {
    return (component)=>{
        emit$1(hook, component.appContext.app, component.uid, component.parent ? component.parent.uid : void 0, component);
    };
}
const devtoolsPerfStart = /* @__PURE__ */ createDevtoolsPerformanceHook("perf:start" /* PERFORMANCE_START */ );
const devtoolsPerfEnd = /* @__PURE__ */ createDevtoolsPerformanceHook("perf:end" /* PERFORMANCE_END */ );
function createDevtoolsPerformanceHook(hook) {
    return (component, type, time)=>{
        emit$1(hook, component.appContext.app, component.uid, component, type, time);
    };
}
function devtoolsComponentEmit(component, event, params) {
    emit$1("component:emit" /* COMPONENT_EMIT */ , component.appContext.app, component, event, params);
}
function emit(instance, event, ...rawArgs) {
    if (instance.isUnmounted) return;
    const props = instance.vnode.props || (0, _shared.EMPTY_OBJ);
    {
        const { emitsOptions, propsOptions: [propsOptions] } = instance;
        if (emitsOptions) {
            if (!(event in emitsOptions) && true) {
                if (!propsOptions || !((0, _shared.toHandlerKey)(event) in propsOptions)) warn(`Component emitted event "${event}" but it is neither declared in the emits option nor as an "${(0, _shared.toHandlerKey)(event)}" prop.`);
            } else {
                const validator = emitsOptions[event];
                if ((0, _shared.isFunction)(validator)) {
                    const isValid = validator(...rawArgs);
                    if (!isValid) warn(`Invalid event arguments: event validation failed for event "${event}".`);
                }
            }
        }
    }
    let args = rawArgs;
    const isModelListener = event.startsWith("update:");
    const modelArg = isModelListener && event.slice(7);
    if (modelArg && modelArg in props) {
        const modifiersKey = `${modelArg === "modelValue" ? "model" : modelArg}Modifiers`;
        const { number, trim } = props[modifiersKey] || (0, _shared.EMPTY_OBJ);
        if (trim) args = rawArgs.map((a)=>(0, _shared.isString)(a) ? a.trim() : a);
        if (number) args = rawArgs.map((0, _shared.looseToNumber));
    }
    devtoolsComponentEmit(instance, event, args);
    {
        const lowerCaseEvent = event.toLowerCase();
        if (lowerCaseEvent !== event && props[(0, _shared.toHandlerKey)(lowerCaseEvent)]) warn(`Event "${lowerCaseEvent}" is emitted in component ${formatComponentName(instance, instance.type)} but the handler is registered for "${event}". Note that HTML attributes are case-insensitive and you cannot use v-on to listen to camelCase events when using in-DOM templates. You should probably use "${(0, _shared.hyphenate)(event)}" instead of "${event}".`);
    }
    let handlerName;
    let handler = props[handlerName = (0, _shared.toHandlerKey)(event)] || // also try camelCase event handler (#2249)
    props[handlerName = (0, _shared.toHandlerKey)((0, _shared.camelize)(event))];
    if (!handler && isModelListener) handler = props[handlerName = (0, _shared.toHandlerKey)((0, _shared.hyphenate)(event))];
    if (handler) callWithAsyncErrorHandling(handler, instance, 6, args);
    const onceHandler = props[handlerName + `Once`];
    if (onceHandler) {
        if (!instance.emitted) instance.emitted = {};
        else if (instance.emitted[handlerName]) return;
        instance.emitted[handlerName] = true;
        callWithAsyncErrorHandling(onceHandler, instance, 6, args);
    }
}
function normalizeEmitsOptions(comp, appContext, asMixin = false) {
    const cache = appContext.emitsCache;
    const cached = cache.get(comp);
    if (cached !== void 0) return cached;
    const raw = comp.emits;
    let normalized = {};
    let hasExtends = false;
    if (__VUE_OPTIONS_API__ && !(0, _shared.isFunction)(comp)) {
        const extendEmits = (raw2)=>{
            const normalizedFromExtend = normalizeEmitsOptions(raw2, appContext, true);
            if (normalizedFromExtend) {
                hasExtends = true;
                (0, _shared.extend)(normalized, normalizedFromExtend);
            }
        };
        if (!asMixin && appContext.mixins.length) appContext.mixins.forEach(extendEmits);
        if (comp.extends) extendEmits(comp.extends);
        if (comp.mixins) comp.mixins.forEach(extendEmits);
    }
    if (!raw && !hasExtends) {
        if ((0, _shared.isObject)(comp)) cache.set(comp, null);
        return null;
    }
    if ((0, _shared.isArray)(raw)) raw.forEach((key)=>normalized[key] = null);
    else (0, _shared.extend)(normalized, raw);
    if ((0, _shared.isObject)(comp)) cache.set(comp, normalized);
    return normalized;
}
function isEmitListener(options, key) {
    if (!options || !(0, _shared.isOn)(key)) return false;
    key = key.slice(2).replace(/Once$/, "");
    return (0, _shared.hasOwn)(options, key[0].toLowerCase() + key.slice(1)) || (0, _shared.hasOwn)(options, (0, _shared.hyphenate)(key)) || (0, _shared.hasOwn)(options, key);
}
let currentRenderingInstance = null;
let currentScopeId = null;
function setCurrentRenderingInstance(instance) {
    const prev = currentRenderingInstance;
    currentRenderingInstance = instance;
    currentScopeId = instance && instance.type.__scopeId || null;
    return prev;
}
function pushScopeId(id) {
    currentScopeId = id;
}
function popScopeId() {
    currentScopeId = null;
}
const withScopeId = (_id)=>withCtx;
function withCtx(fn, ctx = currentRenderingInstance, isNonScopedSlot) {
    if (!ctx) return fn;
    if (fn._n) return fn;
    const renderFnWithContext = (...args)=>{
        if (renderFnWithContext._d) setBlockTracking(-1);
        const prevInstance = setCurrentRenderingInstance(ctx);
        let res;
        try {
            res = fn(...args);
        } finally{
            setCurrentRenderingInstance(prevInstance);
            if (renderFnWithContext._d) setBlockTracking(1);
        }
        devtoolsComponentUpdated(ctx);
        return res;
    };
    renderFnWithContext._n = true;
    renderFnWithContext._c = true;
    renderFnWithContext._d = true;
    return renderFnWithContext;
}
let accessedAttrs = false;
function markAttrsAccessed() {
    accessedAttrs = true;
}
function renderComponentRoot(instance) {
    const { type: Component, vnode, proxy, withProxy, props, propsOptions: [propsOptions], slots, attrs, emit, render, renderCache, data, setupState, ctx, inheritAttrs } = instance;
    let result;
    let fallthroughAttrs;
    const prev = setCurrentRenderingInstance(instance);
    accessedAttrs = false;
    try {
        if (vnode.shapeFlag & 4) {
            const proxyToUse = withProxy || proxy;
            const thisProxy = (0, setupState.__isScriptSetup) ? new Proxy(proxyToUse, {
                get (target, key, receiver) {
                    warn(`Property '${String(key)}' was accessed via 'this'. Avoid using 'this' in templates.`);
                    return Reflect.get(target, key, receiver);
                }
            }) : proxyToUse;
            result = normalizeVNode(render.call(thisProxy, proxyToUse, renderCache, props, setupState, data, ctx));
            fallthroughAttrs = attrs;
        } else {
            const render2 = Component;
            if (attrs === props) markAttrsAccessed();
            result = normalizeVNode(render2.length > 1 ? render2(props, {
                get attrs () {
                    markAttrsAccessed();
                    return attrs;
                },
                slots,
                emit
            }) : render2(props, null));
            fallthroughAttrs = Component.props ? attrs : getFunctionalFallthrough(attrs);
        }
    } catch (err) {
        blockStack.length = 0;
        handleError(err, instance, 1);
        result = createVNode(Comment);
    }
    let root = result;
    let setRoot = void 0;
    if (result.patchFlag > 0 && result.patchFlag & 2048) [root, setRoot] = getChildRoot(result);
    if (fallthroughAttrs && inheritAttrs !== false) {
        const keys = Object.keys(fallthroughAttrs);
        const { shapeFlag } = root;
        if (keys.length) {
            if (shapeFlag & 7) {
                if (propsOptions && keys.some((0, _shared.isModelListener))) fallthroughAttrs = filterModelListeners(fallthroughAttrs, propsOptions);
                root = cloneVNode(root, fallthroughAttrs);
            } else if (!accessedAttrs && root.type !== Comment) {
                const allAttrs = Object.keys(attrs);
                const eventAttrs = [];
                const extraAttrs = [];
                for(let i = 0, l = allAttrs.length; i < l; i++){
                    const key = allAttrs[i];
                    if ((0, _shared.isOn)(key)) {
                        if (!(0, _shared.isModelListener)(key)) eventAttrs.push(key[2].toLowerCase() + key.slice(3));
                    } else extraAttrs.push(key);
                }
                if (extraAttrs.length) warn(`Extraneous non-props attributes (${extraAttrs.join(", ")}) were passed to component but could not be automatically inherited because component renders fragment or text root nodes.`);
                if (eventAttrs.length) warn(`Extraneous non-emits event listeners (${eventAttrs.join(", ")}) were passed to component but could not be automatically inherited because component renders fragment or text root nodes. If the listener is intended to be a component custom event listener only, declare it using the "emits" option.`);
            }
        }
    }
    if (vnode.dirs) {
        if (!isElementRoot(root)) warn(`Runtime directive used on component with non-element root node. The directives will not function as intended.`);
        root = cloneVNode(root);
        root.dirs = root.dirs ? root.dirs.concat(vnode.dirs) : vnode.dirs;
    }
    if (vnode.transition) {
        if (!isElementRoot(root)) warn(`Component inside <Transition> renders non-element root node that cannot be animated.`);
        root.transition = vnode.transition;
    }
    if (setRoot) setRoot(root);
    else result = root;
    setCurrentRenderingInstance(prev);
    return result;
}
const getChildRoot = (vnode)=>{
    const rawChildren = vnode.children;
    const dynamicChildren = vnode.dynamicChildren;
    const childRoot = filterSingleRoot(rawChildren);
    if (!childRoot) return [
        vnode,
        void 0
    ];
    const index = rawChildren.indexOf(childRoot);
    const dynamicIndex = dynamicChildren ? dynamicChildren.indexOf(childRoot) : -1;
    const setRoot = (updatedRoot)=>{
        rawChildren[index] = updatedRoot;
        if (dynamicChildren) {
            if (dynamicIndex > -1) dynamicChildren[dynamicIndex] = updatedRoot;
            else if (updatedRoot.patchFlag > 0) vnode.dynamicChildren = [
                ...dynamicChildren,
                updatedRoot
            ];
        }
    };
    return [
        normalizeVNode(childRoot),
        setRoot
    ];
};
function filterSingleRoot(children) {
    let singleRoot;
    for(let i = 0; i < children.length; i++){
        const child = children[i];
        if (isVNode(child)) {
            if (child.type !== Comment || child.children === "v-if") {
                if (singleRoot) return;
                else singleRoot = child;
            }
        } else return;
    }
    return singleRoot;
}
const getFunctionalFallthrough = (attrs)=>{
    let res;
    for(const key in attrs)if (key === "class" || key === "style" || (0, _shared.isOn)(key)) (res || (res = {}))[key] = attrs[key];
    return res;
};
const filterModelListeners = (attrs, props)=>{
    const res = {};
    for(const key in attrs)if (!(0, _shared.isModelListener)(key) || !(key.slice(9) in props)) res[key] = attrs[key];
    return res;
};
const isElementRoot = (vnode)=>{
    return vnode.shapeFlag & 7 || vnode.type === Comment;
};
function shouldUpdateComponent(prevVNode, nextVNode, optimized) {
    const { props: prevProps, children: prevChildren, component } = prevVNode;
    const { props: nextProps, children: nextChildren, patchFlag } = nextVNode;
    const emits = component.emitsOptions;
    if ((prevChildren || nextChildren) && isHmrUpdating) return true;
    if (nextVNode.dirs || nextVNode.transition) return true;
    if (optimized && patchFlag >= 0) {
        if (patchFlag & 1024) return true;
        if (patchFlag & 16) {
            if (!prevProps) return !!nextProps;
            return hasPropsChanged(prevProps, nextProps, emits);
        } else if (patchFlag & 8) {
            const dynamicProps = nextVNode.dynamicProps;
            for(let i = 0; i < dynamicProps.length; i++){
                const key = dynamicProps[i];
                if (nextProps[key] !== prevProps[key] && !isEmitListener(emits, key)) return true;
            }
        }
    } else {
        if (prevChildren || nextChildren) {
            if (!nextChildren || !nextChildren.$stable) return true;
        }
        if (prevProps === nextProps) return false;
        if (!prevProps) return !!nextProps;
        if (!nextProps) return true;
        return hasPropsChanged(prevProps, nextProps, emits);
    }
    return false;
}
function hasPropsChanged(prevProps, nextProps, emitsOptions) {
    const nextKeys = Object.keys(nextProps);
    if (nextKeys.length !== Object.keys(prevProps).length) return true;
    for(let i = 0; i < nextKeys.length; i++){
        const key = nextKeys[i];
        if (nextProps[key] !== prevProps[key] && !isEmitListener(emitsOptions, key)) return true;
    }
    return false;
}
function updateHOCHostEl({ vnode, parent }, el) {
    while(parent && parent.subTree === vnode){
        (vnode = parent.vnode).el = el;
        parent = parent.parent;
    }
}
const COMPONENTS = "components";
const DIRECTIVES = "directives";
function resolveComponent(name, maybeSelfReference) {
    return resolveAsset(COMPONENTS, name, true, maybeSelfReference) || name;
}
const NULL_DYNAMIC_COMPONENT = Symbol.for("v-ndc");
function resolveDynamicComponent(component) {
    if ((0, _shared.isString)(component)) return resolveAsset(COMPONENTS, component, false) || component;
    else return component || NULL_DYNAMIC_COMPONENT;
}
function resolveDirective(name) {
    return resolveAsset(DIRECTIVES, name);
}
function resolveAsset(type, name, warnMissing = true, maybeSelfReference = false) {
    const instance = currentRenderingInstance || currentInstance;
    if (instance) {
        const Component = instance.type;
        if (type === COMPONENTS) {
            const selfName = getComponentName(Component, false);
            if (selfName && (selfName === name || selfName === (0, _shared.camelize)(name) || selfName === (0, _shared.capitalize)((0, _shared.camelize)(name)))) return Component;
        }
        const res = // local registration
        // check instance[type] first which is resolved for options API
        resolve(instance[type] || Component[type], name) || // global registration
        resolve(instance.appContext[type], name);
        if (!res && maybeSelfReference) return Component;
        if (warnMissing && !res) {
            const extra = type === COMPONENTS ? `
If this is a native custom element, make sure to exclude it from component resolution via compilerOptions.isCustomElement.` : ``;
            warn(`Failed to resolve ${type.slice(0, -1)}: ${name}${extra}`);
        }
        return res;
    } else warn(`resolve${(0, _shared.capitalize)(type.slice(0, -1))} can only be used in render() or setup().`);
}
function resolve(registry, name) {
    return registry && (registry[name] || registry[(0, _shared.camelize)(name)] || registry[(0, _shared.capitalize)((0, _shared.camelize)(name))]);
}
const isSuspense = (type)=>type.__isSuspense;
const SuspenseImpl = {
    name: "Suspense",
    // In order to make Suspense tree-shakable, we need to avoid importing it
    // directly in the renderer. The renderer checks for the __isSuspense flag
    // on a vnode's type and calls the `process` method, passing in renderer
    // internals.
    __isSuspense: true,
    process (n1, n2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized, rendererInternals) {
        if (n1 == null) mountSuspense(n2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized, rendererInternals);
        else patchSuspense(n1, n2, container, anchor, parentComponent, isSVG, slotScopeIds, optimized, rendererInternals);
    },
    hydrate: hydrateSuspense,
    create: createSuspenseBoundary,
    normalize: normalizeSuspenseChildren
};
const Suspense = SuspenseImpl;
function triggerEvent(vnode, name) {
    const eventListener = vnode.props && vnode.props[name];
    if ((0, _shared.isFunction)(eventListener)) eventListener();
}
function mountSuspense(vnode, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized, rendererInternals) {
    const { p: patch, o: { createElement } } = rendererInternals;
    const hiddenContainer = createElement("div");
    const suspense = vnode.suspense = createSuspenseBoundary(vnode, parentSuspense, parentComponent, container, hiddenContainer, anchor, isSVG, slotScopeIds, optimized, rendererInternals);
    patch(null, suspense.pendingBranch = vnode.ssContent, hiddenContainer, null, parentComponent, suspense, isSVG, slotScopeIds);
    if (suspense.deps > 0) {
        triggerEvent(vnode, "onPending");
        triggerEvent(vnode, "onFallback");
        patch(null, vnode.ssFallback, container, anchor, parentComponent, null, // fallback tree will not have suspense context
        isSVG, slotScopeIds);
        setActiveBranch(suspense, vnode.ssFallback);
    } else suspense.resolve(false, true);
}
function patchSuspense(n1, n2, container, anchor, parentComponent, isSVG, slotScopeIds, optimized, { p: patch, um: unmount, o: { createElement } }) {
    const suspense = n2.suspense = n1.suspense;
    suspense.vnode = n2;
    n2.el = n1.el;
    const newBranch = n2.ssContent;
    const newFallback = n2.ssFallback;
    const { activeBranch, pendingBranch, isInFallback, isHydrating } = suspense;
    if (pendingBranch) {
        suspense.pendingBranch = newBranch;
        if (isSameVNodeType(newBranch, pendingBranch)) {
            patch(pendingBranch, newBranch, suspense.hiddenContainer, null, parentComponent, suspense, isSVG, slotScopeIds, optimized);
            if (suspense.deps <= 0) suspense.resolve();
            else if (isInFallback) {
                patch(activeBranch, newFallback, container, anchor, parentComponent, null, // fallback tree will not have suspense context
                isSVG, slotScopeIds, optimized);
                setActiveBranch(suspense, newFallback);
            }
        } else {
            suspense.pendingId++;
            if (isHydrating) {
                suspense.isHydrating = false;
                suspense.activeBranch = pendingBranch;
            } else unmount(pendingBranch, parentComponent, suspense);
            suspense.deps = 0;
            suspense.effects.length = 0;
            suspense.hiddenContainer = createElement("div");
            if (isInFallback) {
                patch(null, newBranch, suspense.hiddenContainer, null, parentComponent, suspense, isSVG, slotScopeIds, optimized);
                if (suspense.deps <= 0) suspense.resolve();
                else {
                    patch(activeBranch, newFallback, container, anchor, parentComponent, null, // fallback tree will not have suspense context
                    isSVG, slotScopeIds, optimized);
                    setActiveBranch(suspense, newFallback);
                }
            } else if (activeBranch && isSameVNodeType(newBranch, activeBranch)) {
                patch(activeBranch, newBranch, container, anchor, parentComponent, suspense, isSVG, slotScopeIds, optimized);
                suspense.resolve(true);
            } else {
                patch(null, newBranch, suspense.hiddenContainer, null, parentComponent, suspense, isSVG, slotScopeIds, optimized);
                if (suspense.deps <= 0) suspense.resolve();
            }
        }
    } else if (activeBranch && isSameVNodeType(newBranch, activeBranch)) {
        patch(activeBranch, newBranch, container, anchor, parentComponent, suspense, isSVG, slotScopeIds, optimized);
        setActiveBranch(suspense, newBranch);
    } else {
        triggerEvent(n2, "onPending");
        suspense.pendingBranch = newBranch;
        suspense.pendingId++;
        patch(null, newBranch, suspense.hiddenContainer, null, parentComponent, suspense, isSVG, slotScopeIds, optimized);
        if (suspense.deps <= 0) suspense.resolve();
        else {
            const { timeout, pendingId } = suspense;
            if (timeout > 0) setTimeout(()=>{
                if (suspense.pendingId === pendingId) suspense.fallback(newFallback);
            }, timeout);
            else if (timeout === 0) suspense.fallback(newFallback);
        }
    }
}
let hasWarned = false;
function createSuspenseBoundary(vnode, parentSuspense, parentComponent, container, hiddenContainer, anchor, isSVG, slotScopeIds, optimized, rendererInternals, isHydrating = false) {
    if (!hasWarned) {
        hasWarned = true;
        console[console.info ? "info" : "log"](`<Suspense> is an experimental feature and its API will likely change.`);
    }
    const { p: patch, m: move, um: unmount, n: next, o: { parentNode, remove } } = rendererInternals;
    let parentSuspenseId;
    const isSuspensible = isVNodeSuspensible(vnode);
    if (isSuspensible) {
        if (parentSuspense == null ? void 0 : parentSuspense.pendingBranch) {
            parentSuspenseId = parentSuspense.pendingId;
            parentSuspense.deps++;
        }
    }
    const timeout = vnode.props ? (0, _shared.toNumber)(vnode.props.timeout) : void 0;
    assertNumber(timeout, `Suspense timeout`);
    const suspense = {
        vnode,
        parent: parentSuspense,
        parentComponent,
        isSVG,
        container,
        hiddenContainer,
        anchor,
        deps: 0,
        pendingId: 0,
        timeout: typeof timeout === "number" ? timeout : -1,
        activeBranch: null,
        pendingBranch: null,
        isInFallback: !isHydrating,
        isHydrating,
        isUnmounted: false,
        effects: [],
        resolve (resume = false, sync = false) {
            if (!resume && !suspense.pendingBranch) throw new Error(`suspense.resolve() is called without a pending branch.`);
            if (suspense.isUnmounted) throw new Error(`suspense.resolve() is called on an already unmounted suspense boundary.`);
            const { vnode: vnode2, activeBranch, pendingBranch, pendingId, effects, parentComponent: parentComponent2, container: container2 } = suspense;
            let delayEnter = false;
            if (suspense.isHydrating) suspense.isHydrating = false;
            else if (!resume) {
                delayEnter = activeBranch && pendingBranch.transition && pendingBranch.transition.mode === "out-in";
                if (delayEnter) activeBranch.transition.afterLeave = ()=>{
                    if (pendingId === suspense.pendingId) {
                        move(pendingBranch, container2, next(activeBranch), 0);
                        queuePostFlushCb(effects);
                    }
                };
                let { anchor: anchor2 } = suspense;
                if (activeBranch) {
                    anchor2 = next(activeBranch);
                    unmount(activeBranch, parentComponent2, suspense, true);
                }
                if (!delayEnter) move(pendingBranch, container2, anchor2, 0);
            }
            setActiveBranch(suspense, pendingBranch);
            suspense.pendingBranch = null;
            suspense.isInFallback = false;
            let parent = suspense.parent;
            let hasUnresolvedAncestor = false;
            while(parent){
                if (parent.pendingBranch) {
                    parent.effects.push(...effects);
                    hasUnresolvedAncestor = true;
                    break;
                }
                parent = parent.parent;
            }
            if (!hasUnresolvedAncestor && !delayEnter) queuePostFlushCb(effects);
            suspense.effects = [];
            if (isSuspensible) {
                if (parentSuspense && parentSuspense.pendingBranch && parentSuspenseId === parentSuspense.pendingId) {
                    parentSuspense.deps--;
                    if (parentSuspense.deps === 0 && !sync) parentSuspense.resolve();
                }
            }
            triggerEvent(vnode2, "onResolve");
        },
        fallback (fallbackVNode) {
            if (!suspense.pendingBranch) return;
            const { vnode: vnode2, activeBranch, parentComponent: parentComponent2, container: container2, isSVG: isSVG2 } = suspense;
            triggerEvent(vnode2, "onFallback");
            const anchor2 = next(activeBranch);
            const mountFallback = ()=>{
                if (!suspense.isInFallback) return;
                patch(null, fallbackVNode, container2, anchor2, parentComponent2, null, // fallback tree will not have suspense context
                isSVG2, slotScopeIds, optimized);
                setActiveBranch(suspense, fallbackVNode);
            };
            const delayEnter = fallbackVNode.transition && fallbackVNode.transition.mode === "out-in";
            if (delayEnter) activeBranch.transition.afterLeave = mountFallback;
            suspense.isInFallback = true;
            unmount(activeBranch, parentComponent2, null, // no suspense so unmount hooks fire now
            true);
            if (!delayEnter) mountFallback();
        },
        move (container2, anchor2, type) {
            suspense.activeBranch && move(suspense.activeBranch, container2, anchor2, type);
            suspense.container = container2;
        },
        next () {
            return suspense.activeBranch && next(suspense.activeBranch);
        },
        registerDep (instance, setupRenderEffect) {
            const isInPendingSuspense = !!suspense.pendingBranch;
            if (isInPendingSuspense) suspense.deps++;
            const hydratedEl = instance.vnode.el;
            instance.asyncDep.catch((err)=>{
                handleError(err, instance, 0);
            }).then((asyncSetupResult)=>{
                if (instance.isUnmounted || suspense.isUnmounted || suspense.pendingId !== instance.suspenseId) return;
                instance.asyncResolved = true;
                const { vnode: vnode2 } = instance;
                pushWarningContext(vnode2);
                handleSetupResult(instance, asyncSetupResult, false);
                if (hydratedEl) vnode2.el = hydratedEl;
                const placeholder = !hydratedEl && instance.subTree.el;
                setupRenderEffect(instance, vnode2, // component may have been moved before resolve.
                // if this is not a hydration, instance.subTree will be the comment
                // placeholder.
                parentNode(hydratedEl || instance.subTree.el), // anchor will not be used if this is hydration, so only need to
                // consider the comment placeholder case.
                hydratedEl ? null : next(instance.subTree), suspense, isSVG, optimized);
                if (placeholder) remove(placeholder);
                updateHOCHostEl(instance, vnode2.el);
                popWarningContext();
                if (isInPendingSuspense && --suspense.deps === 0) suspense.resolve();
            });
        },
        unmount (parentSuspense2, doRemove) {
            suspense.isUnmounted = true;
            if (suspense.activeBranch) unmount(suspense.activeBranch, parentComponent, parentSuspense2, doRemove);
            if (suspense.pendingBranch) unmount(suspense.pendingBranch, parentComponent, parentSuspense2, doRemove);
        }
    };
    return suspense;
}
function hydrateSuspense(node, vnode, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized, rendererInternals, hydrateNode) {
    const suspense = vnode.suspense = createSuspenseBoundary(vnode, parentSuspense, parentComponent, node.parentNode, document.createElement("div"), null, isSVG, slotScopeIds, optimized, rendererInternals, true);
    const result = hydrateNode(node, suspense.pendingBranch = vnode.ssContent, parentComponent, suspense, slotScopeIds, optimized);
    if (suspense.deps === 0) suspense.resolve(false, true);
    return result;
}
function normalizeSuspenseChildren(vnode) {
    const { shapeFlag, children } = vnode;
    const isSlotChildren = shapeFlag & 32;
    vnode.ssContent = normalizeSuspenseSlot(isSlotChildren ? children.default : children);
    vnode.ssFallback = isSlotChildren ? normalizeSuspenseSlot(children.fallback) : createVNode(Comment);
}
function normalizeSuspenseSlot(s) {
    let block;
    if ((0, _shared.isFunction)(s)) {
        const trackBlock = isBlockTreeEnabled && s._c;
        if (trackBlock) {
            s._d = false;
            openBlock();
        }
        s = s();
        if (trackBlock) {
            s._d = true;
            block = currentBlock;
            closeBlock();
        }
    }
    if ((0, _shared.isArray)(s)) {
        const singleChild = filterSingleRoot(s);
        if (!singleChild && s.filter((child)=>child !== NULL_DYNAMIC_COMPONENT).length > 0) warn(`<Suspense> slots expect a single root node.`);
        s = singleChild;
    }
    s = normalizeVNode(s);
    if (block && !s.dynamicChildren) s.dynamicChildren = block.filter((c)=>c !== s);
    return s;
}
function queueEffectWithSuspense(fn, suspense) {
    if (suspense && suspense.pendingBranch) {
        if ((0, _shared.isArray)(fn)) suspense.effects.push(...fn);
        else suspense.effects.push(fn);
    } else queuePostFlushCb(fn);
}
function setActiveBranch(suspense, branch) {
    suspense.activeBranch = branch;
    const { vnode, parentComponent } = suspense;
    const el = vnode.el = branch.el;
    if (parentComponent && parentComponent.subTree === vnode) {
        parentComponent.vnode.el = el;
        updateHOCHostEl(parentComponent, el);
    }
}
function isVNodeSuspensible(vnode) {
    var _a;
    return ((_a = vnode.props) == null ? void 0 : _a.suspensible) != null && vnode.props.suspensible !== false;
}
function watchEffect(effect, options) {
    return doWatch(effect, null, options);
}
function watchPostEffect(effect, options) {
    return doWatch(effect, null, (0, _shared.extend)({}, options, {
        flush: "post"
    }));
}
function watchSyncEffect(effect, options) {
    return doWatch(effect, null, (0, _shared.extend)({}, options, {
        flush: "sync"
    }));
}
const INITIAL_WATCHER_VALUE = {};
function watch(source, cb, options) {
    if (!(0, _shared.isFunction)(cb)) warn(`\`watch(fn, options?)\` signature has been moved to a separate API. Use \`watchEffect(fn, options?)\` instead. \`watch\` now only supports \`watch(source, cb, options?) signature.`);
    return doWatch(source, cb, options);
}
function doWatch(source, cb, { immediate, deep, flush, onTrack, onTrigger } = (0, _shared.EMPTY_OBJ)) {
    var _a;
    if (!cb) {
        if (immediate !== void 0) warn(`watch() "immediate" option is only respected when using the watch(source, callback, options?) signature.`);
        if (deep !== void 0) warn(`watch() "deep" option is only respected when using the watch(source, callback, options?) signature.`);
    }
    const warnInvalidSource = (s)=>{
        warn(`Invalid watch source: `, s, `A watch source can only be a getter/effect function, a ref, a reactive object, or an array of these types.`);
    };
    const instance = (0, _reactivity.getCurrentScope)() === ((_a = currentInstance) == null ? void 0 : _a.scope) ? currentInstance : null;
    let getter;
    let forceTrigger = false;
    let isMultiSource = false;
    if ((0, _reactivity.isRef)(source)) {
        getter = ()=>source.value;
        forceTrigger = (0, _reactivity.isShallow)(source);
    } else if ((0, _reactivity.isReactive)(source)) {
        getter = ()=>source;
        deep = true;
    } else if ((0, _shared.isArray)(source)) {
        isMultiSource = true;
        forceTrigger = source.some((s)=>(0, _reactivity.isReactive)(s) || (0, _reactivity.isShallow)(s));
        getter = ()=>source.map((s)=>{
                if ((0, _reactivity.isRef)(s)) return s.value;
                else if ((0, _reactivity.isReactive)(s)) return traverse(s);
                else if ((0, _shared.isFunction)(s)) return callWithErrorHandling(s, instance, 2);
                else warnInvalidSource(s);
            });
    } else if ((0, _shared.isFunction)(source)) {
        if (cb) getter = ()=>callWithErrorHandling(source, instance, 2);
        else getter = ()=>{
            if (instance && instance.isUnmounted) return;
            if (cleanup) cleanup();
            return callWithAsyncErrorHandling(source, instance, 3, [
                onCleanup
            ]);
        };
    } else {
        getter = (0, _shared.NOOP);
        warnInvalidSource(source);
    }
    if (cb && deep) {
        const baseGetter = getter;
        getter = ()=>traverse(baseGetter());
    }
    let cleanup;
    let onCleanup = (fn)=>{
        cleanup = effect.onStop = ()=>{
            callWithErrorHandling(fn, instance, 4);
            cleanup = effect.onStop = void 0;
        };
    };
    let ssrCleanup;
    if (isInSSRComponentSetup) {
        onCleanup = (0, _shared.NOOP);
        if (!cb) getter();
        else if (immediate) callWithAsyncErrorHandling(cb, instance, 3, [
            getter(),
            isMultiSource ? [] : void 0,
            onCleanup
        ]);
        if (flush === "sync") {
            const ctx = useSSRContext();
            ssrCleanup = ctx.__watcherHandles || (ctx.__watcherHandles = []);
        } else return 0, _shared.NOOP;
    }
    let oldValue = isMultiSource ? new Array(source.length).fill(INITIAL_WATCHER_VALUE) : INITIAL_WATCHER_VALUE;
    const job = ()=>{
        if (!effect.active) return;
        if (cb) {
            const newValue = effect.run();
            if (deep || forceTrigger || (isMultiSource ? newValue.some((v1, i)=>(0, _shared.hasChanged)(v1, oldValue[i])) : (0, _shared.hasChanged)(newValue, oldValue)) || false) {
                if (cleanup) cleanup();
                callWithAsyncErrorHandling(cb, instance, 3, [
                    newValue,
                    // pass undefined as the old value when it's changed for the first time
                    oldValue === INITIAL_WATCHER_VALUE ? void 0 : isMultiSource && oldValue[0] === INITIAL_WATCHER_VALUE ? [] : oldValue,
                    onCleanup
                ]);
                oldValue = newValue;
            }
        } else effect.run();
    };
    job.allowRecurse = !!cb;
    let scheduler;
    if (flush === "sync") scheduler = job;
    else if (flush === "post") scheduler = ()=>queuePostRenderEffect(job, instance && instance.suspense);
    else {
        job.pre = true;
        if (instance) job.id = instance.uid;
        scheduler = ()=>queueJob(job);
    }
    const effect = new (0, _reactivity.ReactiveEffect)(getter, scheduler);
    effect.onTrack = onTrack;
    effect.onTrigger = onTrigger;
    if (cb) {
        if (immediate) job();
        else oldValue = effect.run();
    } else if (flush === "post") queuePostRenderEffect(effect.run.bind(effect), instance && instance.suspense);
    else effect.run();
    const unwatch = ()=>{
        effect.stop();
        if (instance && instance.scope) (0, _shared.remove)(instance.scope.effects, effect);
    };
    if (ssrCleanup) ssrCleanup.push(unwatch);
    return unwatch;
}
function instanceWatch(source, value1, options) {
    const publicThis = this.proxy;
    const getter = (0, _shared.isString)(source) ? source.includes(".") ? createPathGetter(publicThis, source) : ()=>publicThis[source] : source.bind(publicThis, publicThis);
    let cb;
    if ((0, _shared.isFunction)(value1)) cb = value1;
    else {
        cb = value1.handler;
        options = value1;
    }
    const cur = currentInstance;
    setCurrentInstance(this);
    const res = doWatch(getter, cb.bind(publicThis), options);
    if (cur) setCurrentInstance(cur);
    else unsetCurrentInstance();
    return res;
}
function createPathGetter(ctx, path) {
    const segments = path.split(".");
    return ()=>{
        let cur = ctx;
        for(let i = 0; i < segments.length && cur; i++)cur = cur[segments[i]];
        return cur;
    };
}
function traverse(value1, seen) {
    if (!(0, _shared.isObject)(value1) || value1["__v_skip"]) return value1;
    seen = seen || /* @__PURE__ */ new Set();
    if (seen.has(value1)) return value1;
    seen.add(value1);
    if ((0, _reactivity.isRef)(value1)) traverse(value1.value, seen);
    else if ((0, _shared.isArray)(value1)) for(let i = 0; i < value1.length; i++)traverse(value1[i], seen);
    else if ((0, _shared.isSet)(value1) || (0, _shared.isMap)(value1)) value1.forEach((v1)=>{
        traverse(v1, seen);
    });
    else if ((0, _shared.isPlainObject)(value1)) for(const key in value1)traverse(value1[key], seen);
    return value1;
}
function validateDirectiveName(name) {
    if ((0, _shared.isBuiltInDirective)(name)) warn("Do not use built-in directive ids as custom directive id: " + name);
}
function withDirectives(vnode, directives) {
    const internalInstance = currentRenderingInstance;
    if (internalInstance === null) {
        warn(`withDirectives can only be used inside render functions.`);
        return vnode;
    }
    const instance = getExposeProxy(internalInstance) || internalInstance.proxy;
    const bindings = vnode.dirs || (vnode.dirs = []);
    for(let i = 0; i < directives.length; i++){
        let [dir, value1, arg, modifiers = (0, _shared.EMPTY_OBJ)] = directives[i];
        if (dir) {
            if ((0, _shared.isFunction)(dir)) dir = {
                mounted: dir,
                updated: dir
            };
            if (dir.deep) traverse(value1);
            bindings.push({
                dir,
                instance,
                value: value1,
                oldValue: void 0,
                arg,
                modifiers
            });
        }
    }
    return vnode;
}
function invokeDirectiveHook(vnode, prevVNode, instance, name) {
    const bindings = vnode.dirs;
    const oldBindings = prevVNode && prevVNode.dirs;
    for(let i = 0; i < bindings.length; i++){
        const binding = bindings[i];
        if (oldBindings) binding.oldValue = oldBindings[i].value;
        let hook = binding.dir[name];
        if (hook) {
            (0, _reactivity.pauseTracking)();
            callWithAsyncErrorHandling(hook, instance, 8, [
                vnode.el,
                binding,
                vnode,
                prevVNode
            ]);
            (0, _reactivity.resetTracking)();
        }
    }
}
const leaveCbKey = Symbol("_leaveCb");
const enterCbKey = Symbol("_enterCb");
function useTransitionState() {
    const state = {
        isMounted: false,
        isLeaving: false,
        isUnmounting: false,
        leavingVNodes: /* @__PURE__ */ new Map()
    };
    onMounted(()=>{
        state.isMounted = true;
    });
    onBeforeUnmount(()=>{
        state.isUnmounting = true;
    });
    return state;
}
const TransitionHookValidator = [
    Function,
    Array
];
const BaseTransitionPropsValidators = {
    mode: String,
    appear: Boolean,
    persisted: Boolean,
    // enter
    onBeforeEnter: TransitionHookValidator,
    onEnter: TransitionHookValidator,
    onAfterEnter: TransitionHookValidator,
    onEnterCancelled: TransitionHookValidator,
    // leave
    onBeforeLeave: TransitionHookValidator,
    onLeave: TransitionHookValidator,
    onAfterLeave: TransitionHookValidator,
    onLeaveCancelled: TransitionHookValidator,
    // appear
    onBeforeAppear: TransitionHookValidator,
    onAppear: TransitionHookValidator,
    onAfterAppear: TransitionHookValidator,
    onAppearCancelled: TransitionHookValidator
};
const BaseTransitionImpl = {
    name: `BaseTransition`,
    props: BaseTransitionPropsValidators,
    setup (props, { slots }) {
        const instance = getCurrentInstance();
        const state = useTransitionState();
        let prevTransitionKey;
        return ()=>{
            const children = slots.default && getTransitionRawChildren(slots.default(), true);
            if (!children || !children.length) return;
            let child = children[0];
            if (children.length > 1) {
                let hasFound = false;
                for (const c of children)if (c.type !== Comment) {
                    if (hasFound) {
                        warn("<transition> can only be used on a single element or component. Use <transition-group> for lists.");
                        break;
                    }
                    child = c;
                    hasFound = true;
                }
            }
            const rawProps = (0, _reactivity.toRaw)(props);
            const { mode } = rawProps;
            if (mode && mode !== "in-out" && mode !== "out-in" && mode !== "default") warn(`invalid <transition> mode: ${mode}`);
            if (state.isLeaving) return emptyPlaceholder(child);
            const innerChild = getKeepAliveChild(child);
            if (!innerChild) return emptyPlaceholder(child);
            const enterHooks = resolveTransitionHooks(innerChild, rawProps, state, instance);
            setTransitionHooks(innerChild, enterHooks);
            const oldChild = instance.subTree;
            const oldInnerChild = oldChild && getKeepAliveChild(oldChild);
            let transitionKeyChanged = false;
            const { getTransitionKey } = innerChild.type;
            if (getTransitionKey) {
                const key = getTransitionKey();
                if (prevTransitionKey === void 0) prevTransitionKey = key;
                else if (key !== prevTransitionKey) {
                    prevTransitionKey = key;
                    transitionKeyChanged = true;
                }
            }
            if (oldInnerChild && oldInnerChild.type !== Comment && (!isSameVNodeType(innerChild, oldInnerChild) || transitionKeyChanged)) {
                const leavingHooks = resolveTransitionHooks(oldInnerChild, rawProps, state, instance);
                setTransitionHooks(oldInnerChild, leavingHooks);
                if (mode === "out-in") {
                    state.isLeaving = true;
                    leavingHooks.afterLeave = ()=>{
                        state.isLeaving = false;
                        if (instance.update.active !== false) instance.update();
                    };
                    return emptyPlaceholder(child);
                } else if (mode === "in-out" && innerChild.type !== Comment) leavingHooks.delayLeave = (el, earlyRemove, delayedLeave)=>{
                    const leavingVNodesCache = getLeavingNodesForType(state, oldInnerChild);
                    leavingVNodesCache[String(oldInnerChild.key)] = oldInnerChild;
                    el[leaveCbKey] = ()=>{
                        earlyRemove();
                        el[leaveCbKey] = void 0;
                        delete enterHooks.delayedLeave;
                    };
                    enterHooks.delayedLeave = delayedLeave;
                };
            }
            return child;
        };
    }
};
const BaseTransition = BaseTransitionImpl;
function getLeavingNodesForType(state, vnode) {
    const { leavingVNodes } = state;
    let leavingVNodesCache = leavingVNodes.get(vnode.type);
    if (!leavingVNodesCache) {
        leavingVNodesCache = /* @__PURE__ */ Object.create(null);
        leavingVNodes.set(vnode.type, leavingVNodesCache);
    }
    return leavingVNodesCache;
}
function resolveTransitionHooks(vnode, props, state, instance) {
    const { appear, mode, persisted = false, onBeforeEnter, onEnter, onAfterEnter, onEnterCancelled, onBeforeLeave, onLeave, onAfterLeave, onLeaveCancelled, onBeforeAppear, onAppear, onAfterAppear, onAppearCancelled } = props;
    const key = String(vnode.key);
    const leavingVNodesCache = getLeavingNodesForType(state, vnode);
    const callHook = (hook, args)=>{
        hook && callWithAsyncErrorHandling(hook, instance, 9, args);
    };
    const callAsyncHook = (hook, args)=>{
        const done = args[1];
        callHook(hook, args);
        if ((0, _shared.isArray)(hook)) {
            if (hook.every((hook2)=>hook2.length <= 1)) done();
        } else if (hook.length <= 1) done();
    };
    const hooks = {
        mode,
        persisted,
        beforeEnter (el) {
            let hook = onBeforeEnter;
            if (!state.isMounted) {
                if (appear) hook = onBeforeAppear || onBeforeEnter;
                else return;
            }
            if (el[leaveCbKey]) el[leaveCbKey](true);
            const leavingVNode = leavingVNodesCache[key];
            if (leavingVNode && isSameVNodeType(vnode, leavingVNode) && leavingVNode.el[leaveCbKey]) leavingVNode.el[leaveCbKey]();
            callHook(hook, [
                el
            ]);
        },
        enter (el) {
            let hook = onEnter;
            let afterHook = onAfterEnter;
            let cancelHook = onEnterCancelled;
            if (!state.isMounted) {
                if (appear) {
                    hook = onAppear || onEnter;
                    afterHook = onAfterAppear || onAfterEnter;
                    cancelHook = onAppearCancelled || onEnterCancelled;
                } else return;
            }
            let called = false;
            const done = el[enterCbKey] = (cancelled)=>{
                if (called) return;
                called = true;
                if (cancelled) callHook(cancelHook, [
                    el
                ]);
                else callHook(afterHook, [
                    el
                ]);
                if (hooks.delayedLeave) hooks.delayedLeave();
                el[enterCbKey] = void 0;
            };
            if (hook) callAsyncHook(hook, [
                el,
                done
            ]);
            else done();
        },
        leave (el, remove) {
            const key2 = String(vnode.key);
            if (el[enterCbKey]) el[enterCbKey](true);
            if (state.isUnmounting) return remove();
            callHook(onBeforeLeave, [
                el
            ]);
            let called = false;
            const done = el[leaveCbKey] = (cancelled)=>{
                if (called) return;
                called = true;
                remove();
                if (cancelled) callHook(onLeaveCancelled, [
                    el
                ]);
                else callHook(onAfterLeave, [
                    el
                ]);
                el[leaveCbKey] = void 0;
                if (leavingVNodesCache[key2] === vnode) delete leavingVNodesCache[key2];
            };
            leavingVNodesCache[key2] = vnode;
            if (onLeave) callAsyncHook(onLeave, [
                el,
                done
            ]);
            else done();
        },
        clone (vnode2) {
            return resolveTransitionHooks(vnode2, props, state, instance);
        }
    };
    return hooks;
}
function emptyPlaceholder(vnode) {
    if (isKeepAlive(vnode)) {
        vnode = cloneVNode(vnode);
        vnode.children = null;
        return vnode;
    }
}
function getKeepAliveChild(vnode) {
    return isKeepAlive(vnode) ? // #7121 ensure get the child component subtree in case
    // it's been replaced during HMR
    (0, vnode.component) ? vnode.component.subTree : vnode.children ? vnode.children[0] : void 0 : vnode;
}
function setTransitionHooks(vnode, hooks) {
    if (vnode.shapeFlag & 6 && vnode.component) setTransitionHooks(vnode.component.subTree, hooks);
    else if (vnode.shapeFlag & 128) {
        vnode.ssContent.transition = hooks.clone(vnode.ssContent);
        vnode.ssFallback.transition = hooks.clone(vnode.ssFallback);
    } else vnode.transition = hooks;
}
function getTransitionRawChildren(children, keepComment = false, parentKey) {
    let ret = [];
    let keyedFragmentCount = 0;
    for(let i = 0; i < children.length; i++){
        let child = children[i];
        const key = parentKey == null ? child.key : String(parentKey) + String(child.key != null ? child.key : i);
        if (child.type === Fragment) {
            if (child.patchFlag & 128) keyedFragmentCount++;
            ret = ret.concat(getTransitionRawChildren(child.children, keepComment, key));
        } else if (keepComment || child.type !== Comment) ret.push(key != null ? cloneVNode(child, {
            key
        }) : child);
    }
    if (keyedFragmentCount > 1) for(let i = 0; i < ret.length; i++)ret[i].patchFlag = -2;
    return ret;
}
/*! #__NO_SIDE_EFFECTS__ */ // @__NO_SIDE_EFFECTS__
function defineComponent(options, extraOptions) {
    return (0, _shared.isFunction)(options) ? // #8326: extend call and options.name access are considered side-effects
    // by Rollup, so we have to wrap it in a pure-annotated IIFE.
    /* @__PURE__ */ (()=>(0, _shared.extend)({
            name: options.name
        }, extraOptions, {
            setup: options
        }))() : options;
}
const isAsyncWrapper = (i)=>!!i.type.__asyncLoader;
/*! #__NO_SIDE_EFFECTS__ */ // @__NO_SIDE_EFFECTS__
function defineAsyncComponent(source) {
    if ((0, _shared.isFunction)(source)) source = {
        loader: source
    };
    const { loader, loadingComponent, errorComponent, delay = 200, timeout, // undefined = never times out
    suspensible = true, onError: userOnError } = source;
    let pendingRequest = null;
    let resolvedComp;
    let retries = 0;
    const retry = ()=>{
        retries++;
        pendingRequest = null;
        return load();
    };
    const load = ()=>{
        let thisRequest;
        return pendingRequest || (thisRequest = pendingRequest = loader().catch((err)=>{
            err = err instanceof Error ? err : new Error(String(err));
            if (userOnError) return new Promise((resolve, reject)=>{
                const userRetry = ()=>resolve(retry());
                const userFail = ()=>reject(err);
                userOnError(err, userRetry, userFail, retries + 1);
            });
            else throw err;
        }).then((comp)=>{
            if (thisRequest !== pendingRequest && pendingRequest) return pendingRequest;
            if (!comp) warn(`Async component loader resolved to undefined. If you are using retry(), make sure to return its return value.`);
            if (comp && (comp.__esModule || comp[Symbol.toStringTag] === "Module")) comp = comp.default;
            if (comp && !(0, _shared.isObject)(comp) && !(0, _shared.isFunction)(comp)) throw new Error(`Invalid async component load result: ${comp}`);
            resolvedComp = comp;
            return comp;
        }));
    };
    return defineComponent({
        name: "AsyncComponentWrapper",
        __asyncLoader: load,
        get __asyncResolved () {
            return resolvedComp;
        },
        setup () {
            const instance = currentInstance;
            if (resolvedComp) return ()=>createInnerComp(resolvedComp, instance);
            const onError = (err)=>{
                pendingRequest = null;
                handleError(err, instance, 13, !errorComponent);
            };
            if (suspensible && instance.suspense || isInSSRComponentSetup) return load().then((comp)=>{
                return ()=>createInnerComp(comp, instance);
            }).catch((err)=>{
                onError(err);
                return ()=>errorComponent ? createVNode(errorComponent, {
                        error: err
                    }) : null;
            });
            const loaded = (0, _reactivity.ref)(false);
            const error = (0, _reactivity.ref)();
            const delayed = (0, _reactivity.ref)(!!delay);
            if (delay) setTimeout(()=>{
                delayed.value = false;
            }, delay);
            if (timeout != null) setTimeout(()=>{
                if (!loaded.value && !error.value) {
                    const err = new Error(`Async component timed out after ${timeout}ms.`);
                    onError(err);
                    error.value = err;
                }
            }, timeout);
            load().then(()=>{
                loaded.value = true;
                if (instance.parent && isKeepAlive(instance.parent.vnode)) queueJob(instance.parent.update);
            }).catch((err)=>{
                onError(err);
                error.value = err;
            });
            return ()=>{
                if (loaded.value && resolvedComp) return createInnerComp(resolvedComp, instance);
                else if (error.value && errorComponent) return createVNode(errorComponent, {
                    error: error.value
                });
                else if (loadingComponent && !delayed.value) return createVNode(loadingComponent);
            };
        }
    });
}
function createInnerComp(comp, parent) {
    const { ref: ref2, props, children, ce } = parent.vnode;
    const vnode = createVNode(comp, props, children);
    vnode.ref = ref2;
    vnode.ce = ce;
    delete parent.vnode.ce;
    return vnode;
}
const isKeepAlive = (vnode)=>vnode.type.__isKeepAlive;
const KeepAliveImpl = {
    name: `KeepAlive`,
    // Marker for special handling inside the renderer. We are not using a ===
    // check directly on KeepAlive in the renderer, because importing it directly
    // would prevent it from being tree-shaken.
    __isKeepAlive: true,
    props: {
        include: [
            String,
            RegExp,
            Array
        ],
        exclude: [
            String,
            RegExp,
            Array
        ],
        max: [
            String,
            Number
        ]
    },
    setup (props, { slots }) {
        const instance = getCurrentInstance();
        const sharedContext = instance.ctx;
        if (!sharedContext.renderer) return ()=>{
            const children = slots.default && slots.default();
            return children && children.length === 1 ? children[0] : children;
        };
        const cache = /* @__PURE__ */ new Map();
        const keys = /* @__PURE__ */ new Set();
        let current = null;
        instance.__v_cache = cache;
        const parentSuspense = instance.suspense;
        const { renderer: { p: patch, m: move, um: _unmount, o: { createElement } } } = sharedContext;
        const storageContainer = createElement("div");
        sharedContext.activate = (vnode, container, anchor, isSVG, optimized)=>{
            const instance2 = vnode.component;
            move(vnode, container, anchor, 0, parentSuspense);
            patch(instance2.vnode, vnode, container, anchor, instance2, parentSuspense, isSVG, vnode.slotScopeIds, optimized);
            queuePostRenderEffect(()=>{
                instance2.isDeactivated = false;
                if (instance2.a) (0, _shared.invokeArrayFns)(instance2.a);
                const vnodeHook = vnode.props && vnode.props.onVnodeMounted;
                if (vnodeHook) invokeVNodeHook(vnodeHook, instance2.parent, vnode);
            }, parentSuspense);
            devtoolsComponentAdded(instance2);
        };
        sharedContext.deactivate = (vnode)=>{
            const instance2 = vnode.component;
            move(vnode, storageContainer, null, 1, parentSuspense);
            queuePostRenderEffect(()=>{
                if (instance2.da) (0, _shared.invokeArrayFns)(instance2.da);
                const vnodeHook = vnode.props && vnode.props.onVnodeUnmounted;
                if (vnodeHook) invokeVNodeHook(vnodeHook, instance2.parent, vnode);
                instance2.isDeactivated = true;
            }, parentSuspense);
            devtoolsComponentAdded(instance2);
        };
        function unmount(vnode) {
            resetShapeFlag(vnode);
            _unmount(vnode, instance, parentSuspense, true);
        }
        function pruneCache(filter) {
            cache.forEach((vnode, key)=>{
                const name = getComponentName(vnode.type);
                if (name && (!filter || !filter(name))) pruneCacheEntry(key);
            });
        }
        function pruneCacheEntry(key) {
            const cached = cache.get(key);
            if (!current || !isSameVNodeType(cached, current)) unmount(cached);
            else if (current) resetShapeFlag(current);
            cache.delete(key);
            keys.delete(key);
        }
        watch(()=>[
                props.include,
                props.exclude
            ], ([include, exclude])=>{
            include && pruneCache((name)=>matches(include, name));
            exclude && pruneCache((name)=>!matches(exclude, name));
        }, // prune post-render after `current` has been updated
        {
            flush: "post",
            deep: true
        });
        let pendingCacheKey = null;
        const cacheSubtree = ()=>{
            if (pendingCacheKey != null) cache.set(pendingCacheKey, getInnerChild(instance.subTree));
        };
        onMounted(cacheSubtree);
        onUpdated(cacheSubtree);
        onBeforeUnmount(()=>{
            cache.forEach((cached)=>{
                const { subTree, suspense } = instance;
                const vnode = getInnerChild(subTree);
                if (cached.type === vnode.type && cached.key === vnode.key) {
                    resetShapeFlag(vnode);
                    const da = vnode.component.da;
                    da && queuePostRenderEffect(da, suspense);
                    return;
                }
                unmount(cached);
            });
        });
        return ()=>{
            pendingCacheKey = null;
            if (!slots.default) return null;
            const children = slots.default();
            const rawVNode = children[0];
            if (children.length > 1) {
                warn(`KeepAlive should contain exactly one component child.`);
                current = null;
                return children;
            } else if (!isVNode(rawVNode) || !(rawVNode.shapeFlag & 4) && !(rawVNode.shapeFlag & 128)) {
                current = null;
                return rawVNode;
            }
            let vnode = getInnerChild(rawVNode);
            const comp = vnode.type;
            const name = getComponentName(isAsyncWrapper(vnode) ? vnode.type.__asyncResolved || {} : comp);
            const { include, exclude, max } = props;
            if (include && (!name || !matches(include, name)) || exclude && name && matches(exclude, name)) {
                current = vnode;
                return rawVNode;
            }
            const key = vnode.key == null ? comp : vnode.key;
            const cachedVNode = cache.get(key);
            if (vnode.el) {
                vnode = cloneVNode(vnode);
                if (rawVNode.shapeFlag & 128) rawVNode.ssContent = vnode;
            }
            pendingCacheKey = key;
            if (cachedVNode) {
                vnode.el = cachedVNode.el;
                vnode.component = cachedVNode.component;
                if (vnode.transition) setTransitionHooks(vnode, vnode.transition);
                vnode.shapeFlag |= 512;
                keys.delete(key);
                keys.add(key);
            } else {
                keys.add(key);
                if (max && keys.size > parseInt(max, 10)) pruneCacheEntry(keys.values().next().value);
            }
            vnode.shapeFlag |= 256;
            current = vnode;
            return isSuspense(rawVNode.type) ? rawVNode : vnode;
        };
    }
};
const KeepAlive = KeepAliveImpl;
function matches(pattern, name) {
    if ((0, _shared.isArray)(pattern)) return pattern.some((p)=>matches(p, name));
    else if ((0, _shared.isString)(pattern)) return pattern.split(",").includes(name);
    else if ((0, _shared.isRegExp)(pattern)) return pattern.test(name);
    return false;
}
function onActivated(hook, target) {
    registerKeepAliveHook(hook, "a", target);
}
function onDeactivated(hook, target) {
    registerKeepAliveHook(hook, "da", target);
}
function registerKeepAliveHook(hook, type, target = currentInstance) {
    const wrappedHook = hook.__wdc || (hook.__wdc = ()=>{
        let current = target;
        while(current){
            if (current.isDeactivated) return;
            current = current.parent;
        }
        return hook();
    });
    injectHook(type, wrappedHook, target);
    if (target) {
        let current = target.parent;
        while(current && current.parent){
            if (isKeepAlive(current.parent.vnode)) injectToKeepAliveRoot(wrappedHook, type, target, current);
            current = current.parent;
        }
    }
}
function injectToKeepAliveRoot(hook, type, target, keepAliveRoot) {
    const injected = injectHook(type, hook, keepAliveRoot, true);
    onUnmounted(()=>{
        (0, _shared.remove)(keepAliveRoot[type], injected);
    }, target);
}
function resetShapeFlag(vnode) {
    vnode.shapeFlag &= -257;
    vnode.shapeFlag &= -513;
}
function getInnerChild(vnode) {
    return vnode.shapeFlag & 128 ? vnode.ssContent : vnode;
}
function injectHook(type, hook, target = currentInstance, prepend = false) {
    if (target) {
        const hooks = target[type] || (target[type] = []);
        const wrappedHook = hook.__weh || (hook.__weh = (...args)=>{
            if (target.isUnmounted) return;
            (0, _reactivity.pauseTracking)();
            setCurrentInstance(target);
            const res = callWithAsyncErrorHandling(hook, target, type, args);
            unsetCurrentInstance();
            (0, _reactivity.resetTracking)();
            return res;
        });
        if (prepend) hooks.unshift(wrappedHook);
        else hooks.push(wrappedHook);
        return wrappedHook;
    } else {
        const apiName = (0, _shared.toHandlerKey)(ErrorTypeStrings[type].replace(/ hook$/, ""));
        warn(`${apiName} is called when there is no active component instance to be associated with. Lifecycle injection APIs can only be used during execution of setup().` + ` If you are using async setup(), make sure to register lifecycle hooks before the first await statement.`);
    }
}
const createHook = (lifecycle)=>(hook, target = currentInstance)=>// post-create lifecycle registrations are noops during SSR (except for serverPrefetch)
        (!isInSSRComponentSetup || lifecycle === "sp") && injectHook(lifecycle, (...args)=>hook(...args), target);
const onBeforeMount = createHook("bm");
const onMounted = createHook("m");
const onBeforeUpdate = createHook("bu");
const onUpdated = createHook("u");
const onBeforeUnmount = createHook("bum");
const onUnmounted = createHook("um");
const onServerPrefetch = createHook("sp");
const onRenderTriggered = createHook("rtg");
const onRenderTracked = createHook("rtc");
function onErrorCaptured(hook, target = currentInstance) {
    injectHook("ec", hook, target);
}
function renderList(source, renderItem, cache, index) {
    let ret;
    const cached = cache && cache[index];
    if ((0, _shared.isArray)(source) || (0, _shared.isString)(source)) {
        ret = new Array(source.length);
        for(let i = 0, l = source.length; i < l; i++)ret[i] = renderItem(source[i], i, void 0, cached && cached[i]);
    } else if (typeof source === "number") {
        if (!Number.isInteger(source)) warn(`The v-for range expect an integer value but got ${source}.`);
        ret = new Array(source);
        for(let i = 0; i < source; i++)ret[i] = renderItem(i + 1, i, void 0, cached && cached[i]);
    } else if ((0, _shared.isObject)(source)) {
        if (source[Symbol.iterator]) ret = Array.from(source, (item, i)=>renderItem(item, i, void 0, cached && cached[i]));
        else {
            const keys = Object.keys(source);
            ret = new Array(keys.length);
            for(let i = 0, l = keys.length; i < l; i++){
                const key = keys[i];
                ret[i] = renderItem(source[key], key, i, cached && cached[i]);
            }
        }
    } else ret = [];
    if (cache) cache[index] = ret;
    return ret;
}
function createSlots(slots, dynamicSlots) {
    for(let i = 0; i < dynamicSlots.length; i++){
        const slot = dynamicSlots[i];
        if ((0, _shared.isArray)(slot)) for(let j = 0; j < slot.length; j++)slots[slot[j].name] = slot[j].fn;
        else if (slot) slots[slot.name] = slot.key ? (...args)=>{
            const res = slot.fn(...args);
            if (res) res.key = slot.key;
            return res;
        } : slot.fn;
    }
    return slots;
}
function renderSlot(slots, name, props = {}, fallback, noSlotted) {
    if (currentRenderingInstance.isCE || currentRenderingInstance.parent && isAsyncWrapper(currentRenderingInstance.parent) && currentRenderingInstance.parent.isCE) {
        if (name !== "default") props.name = name;
        return createVNode("slot", props, fallback && fallback());
    }
    let slot = slots[name];
    if (slot && slot.length > 1) {
        warn(`SSR-optimized slot function detected in a non-SSR-optimized render function. You need to mark this component with $dynamic-slots in the parent template.`);
        slot = ()=>[];
    }
    if (slot && slot._c) slot._d = false;
    openBlock();
    const validSlotContent = slot && ensureValidVNode(slot(props));
    const rendered = createBlock(Fragment, {
        key: props.key || // slot content array of a dynamic conditional slot may have a branch
        // key attached in the `createSlots` helper, respect that
        validSlotContent && validSlotContent.key || `_${name}`
    }, validSlotContent || (fallback ? fallback() : []), validSlotContent && slots._ === 1 ? 64 : -2);
    if (!noSlotted && rendered.scopeId) rendered.slotScopeIds = [
        rendered.scopeId + "-s"
    ];
    if (slot && slot._c) slot._d = true;
    return rendered;
}
function ensureValidVNode(vnodes) {
    return vnodes.some((child)=>{
        if (!isVNode(child)) return true;
        if (child.type === Comment) return false;
        if (child.type === Fragment && !ensureValidVNode(child.children)) return false;
        return true;
    }) ? vnodes : null;
}
function toHandlers(obj, preserveCaseIfNecessary) {
    const ret = {};
    if (!(0, _shared.isObject)(obj)) {
        warn(`v-on with no argument expects an object value.`);
        return ret;
    }
    for(const key in obj)ret[preserveCaseIfNecessary && /[A-Z]/.test(key) ? `on:${key}` : (0, _shared.toHandlerKey)(key)] = obj[key];
    return ret;
}
const getPublicInstance = (i)=>{
    if (!i) return null;
    if (isStatefulComponent(i)) return getExposeProxy(i) || i.proxy;
    return getPublicInstance(i.parent);
};
const publicPropertiesMap = // Move PURE marker to new line to workaround compiler discarding it
// due to type annotation
/* @__PURE__ */ (0, _shared.extend)(/* @__PURE__ */ Object.create(null), {
    $: (i)=>i,
    $el: (i)=>i.vnode.el,
    $data: (i)=>i.data,
    $props: (i)=>(0, _reactivity.shallowReadonly)(i.props),
    $attrs: (i)=>(0, _reactivity.shallowReadonly)(i.attrs),
    $slots: (i)=>(0, _reactivity.shallowReadonly)(i.slots),
    $refs: (i)=>(0, _reactivity.shallowReadonly)(i.refs),
    $parent: (i)=>getPublicInstance(i.parent),
    $root: (i)=>getPublicInstance(i.root),
    $emit: (i)=>i.emit,
    $options: (i)=>__VUE_OPTIONS_API__ ? resolveMergedOptions(i) : i.type,
    $forceUpdate: (i)=>i.f || (i.f = ()=>queueJob(i.update)),
    $nextTick: (i)=>i.n || (i.n = nextTick.bind(i.proxy)),
    $watch: (i)=>__VUE_OPTIONS_API__ ? instanceWatch.bind(i) : (0, _shared.NOOP)
});
const isReservedPrefix = (key)=>key === "_" || key === "$";
const hasSetupBinding = (state, key)=>state !== (0, _shared.EMPTY_OBJ) && !state.__isScriptSetup && (0, _shared.hasOwn)(state, key);
const PublicInstanceProxyHandlers = {
    get ({ _: instance }, key) {
        const { ctx, setupState, data, props, accessCache, type, appContext } = instance;
        if (key === "__isVue") return true;
        let normalizedProps;
        if (key[0] !== "$") {
            const n = accessCache[key];
            if (n !== void 0) switch(n){
                case 1 /* SETUP */ :
                    return setupState[key];
                case 2 /* DATA */ :
                    return data[key];
                case 4 /* CONTEXT */ :
                    return ctx[key];
                case 3 /* PROPS */ :
                    return props[key];
            }
            else if (hasSetupBinding(setupState, key)) {
                accessCache[key] = 1 /* SETUP */ ;
                return setupState[key];
            } else if (data !== (0, _shared.EMPTY_OBJ) && (0, _shared.hasOwn)(data, key)) {
                accessCache[key] = 2 /* DATA */ ;
                return data[key];
            } else if (// only cache other properties when instance has declared (thus stable)
            // props
            (normalizedProps = instance.propsOptions[0]) && (0, _shared.hasOwn)(normalizedProps, key)) {
                accessCache[key] = 3 /* PROPS */ ;
                return props[key];
            } else if (ctx !== (0, _shared.EMPTY_OBJ) && (0, _shared.hasOwn)(ctx, key)) {
                accessCache[key] = 4 /* CONTEXT */ ;
                return ctx[key];
            } else if (!__VUE_OPTIONS_API__ || shouldCacheAccess) accessCache[key] = 0 /* OTHER */ ;
        }
        const publicGetter = publicPropertiesMap[key];
        let cssModule, globalProperties;
        if (publicGetter) {
            if (key === "$attrs") {
                (0, _reactivity.track)(instance, "get", key);
                markAttrsAccessed();
            } else if (key === "$slots") (0, _reactivity.track)(instance, "get", key);
            return publicGetter(instance);
        } else if (// css module (injected by vue-loader)
        (cssModule = type.__cssModules) && (cssModule = cssModule[key])) return cssModule;
        else if (ctx !== (0, _shared.EMPTY_OBJ) && (0, _shared.hasOwn)(ctx, key)) {
            accessCache[key] = 4 /* CONTEXT */ ;
            return ctx[key];
        } else if (// global properties
        globalProperties = appContext.config.globalProperties, (0, _shared.hasOwn)(globalProperties, key)) return globalProperties[key];
        else if (currentRenderingInstance && (!(0, _shared.isString)(key) || // #1091 avoid internal isRef/isVNode checks on component instance leading
        // to infinite warning loop
        key.indexOf("__v") !== 0)) {
            if (data !== (0, _shared.EMPTY_OBJ) && isReservedPrefix(key[0]) && (0, _shared.hasOwn)(data, key)) warn(`Property ${JSON.stringify(key)} must be accessed via $data because it starts with a reserved character ("$" or "_") and is not proxied on the render context.`);
            else if (instance === currentRenderingInstance) warn(`Property ${JSON.stringify(key)} was accessed during render but is not defined on instance.`);
        }
    },
    set ({ _: instance }, key, value1) {
        const { data, setupState, ctx } = instance;
        if (hasSetupBinding(setupState, key)) {
            setupState[key] = value1;
            return true;
        } else if ((0, setupState.__isScriptSetup) && (0, _shared.hasOwn)(setupState, key)) {
            warn(`Cannot mutate <script setup> binding "${key}" from Options API.`);
            return false;
        } else if (data !== (0, _shared.EMPTY_OBJ) && (0, _shared.hasOwn)(data, key)) {
            data[key] = value1;
            return true;
        } else if ((0, _shared.hasOwn)(instance.props, key)) {
            warn(`Attempting to mutate prop "${key}". Props are readonly.`);
            return false;
        }
        if (key[0] === "$" && key.slice(1) in instance) {
            warn(`Attempting to mutate public property "${key}". Properties starting with $ are reserved and readonly.`);
            return false;
        } else if (key in instance.appContext.config.globalProperties) Object.defineProperty(ctx, key, {
            enumerable: true,
            configurable: true,
            value: value1
        });
        else ctx[key] = value1;
        return true;
    },
    has ({ _: { data, setupState, accessCache, ctx, appContext, propsOptions } }, key) {
        let normalizedProps;
        return !!accessCache[key] || data !== (0, _shared.EMPTY_OBJ) && (0, _shared.hasOwn)(data, key) || hasSetupBinding(setupState, key) || (normalizedProps = propsOptions[0]) && (0, _shared.hasOwn)(normalizedProps, key) || (0, _shared.hasOwn)(ctx, key) || (0, _shared.hasOwn)(publicPropertiesMap, key) || (0, _shared.hasOwn)(appContext.config.globalProperties, key);
    },
    defineProperty (target, key, descriptor) {
        if (descriptor.get != null) target._.accessCache[key] = 0;
        else if ((0, _shared.hasOwn)(descriptor, "value")) this.set(target, key, descriptor.value, null);
        return Reflect.defineProperty(target, key, descriptor);
    }
};
PublicInstanceProxyHandlers.ownKeys = (target)=>{
    warn(`Avoid app logic that relies on enumerating keys on a component instance. The keys will be empty in production mode to avoid performance overhead.`);
    return Reflect.ownKeys(target);
};
const RuntimeCompiledPublicInstanceProxyHandlers = /* @__PURE__ */ (0, _shared.extend)({}, PublicInstanceProxyHandlers, {
    get (target, key) {
        if (key === Symbol.unscopables) return;
        return PublicInstanceProxyHandlers.get(target, key, target);
    },
    has (_, key) {
        const has = key[0] !== "_" && !(0, _shared.isGloballyAllowed)(key);
        if (!has && PublicInstanceProxyHandlers.has(_, key)) warn(`Property ${JSON.stringify(key)} should not start with _ which is a reserved prefix for Vue internals.`);
        return has;
    }
});
function createDevRenderContext(instance) {
    const target = {};
    Object.defineProperty(target, `_`, {
        configurable: true,
        enumerable: false,
        get: ()=>instance
    });
    Object.keys(publicPropertiesMap).forEach((key)=>{
        Object.defineProperty(target, key, {
            configurable: true,
            enumerable: false,
            get: ()=>publicPropertiesMap[key](instance),
            // intercepted by the proxy so no need for implementation,
            // but needed to prevent set errors
            set: (0, _shared.NOOP)
        });
    });
    return target;
}
function exposePropsOnRenderContext(instance) {
    const { ctx, propsOptions: [propsOptions] } = instance;
    if (propsOptions) Object.keys(propsOptions).forEach((key)=>{
        Object.defineProperty(ctx, key, {
            enumerable: true,
            configurable: true,
            get: ()=>instance.props[key],
            set: (0, _shared.NOOP)
        });
    });
}
function exposeSetupStateOnRenderContext(instance) {
    const { ctx, setupState } = instance;
    Object.keys((0, _reactivity.toRaw)(setupState)).forEach((key)=>{
        if (!setupState.__isScriptSetup) {
            if (isReservedPrefix(key[0])) {
                warn(`setup() return property ${JSON.stringify(key)} should not start with "$" or "_" which are reserved prefixes for Vue internals.`);
                return;
            }
            Object.defineProperty(ctx, key, {
                enumerable: true,
                configurable: true,
                get: ()=>setupState[key],
                set: (0, _shared.NOOP)
            });
        }
    });
}
const warnRuntimeUsage = (method)=>warn(`${method}() is a compiler-hint helper that is only usable inside <script setup> of a single file component. Its arguments should be compiled away and passing it at runtime has no effect.`);
function defineProps() {
    warnRuntimeUsage(`defineProps`);
    return null;
}
function defineEmits() {
    warnRuntimeUsage(`defineEmits`);
    return null;
}
function defineExpose(exposed) {
    warnRuntimeUsage(`defineExpose`);
}
function defineOptions(options) {
    warnRuntimeUsage(`defineOptions`);
}
function defineSlots() {
    warnRuntimeUsage(`defineSlots`);
    return null;
}
function defineModel() {
    warnRuntimeUsage("defineModel");
}
function withDefaults(props, defaults) {
    warnRuntimeUsage(`withDefaults`);
    return null;
}
function useSlots() {
    return getContext().slots;
}
function useAttrs() {
    return getContext().attrs;
}
function useModel(props, name, options) {
    const i = getCurrentInstance();
    if (!i) {
        warn(`useModel() called without active instance.`);
        return (0, _reactivity.ref)();
    }
    if (!i.propsOptions[0][name]) {
        warn(`useModel() called with prop "${name}" which is not declared.`);
        return (0, _reactivity.ref)();
    }
    if (options && options.local) {
        const proxy = (0, _reactivity.ref)(props[name]);
        watch(()=>props[name], (v1)=>proxy.value = v1);
        watch(proxy, (value1)=>{
            if (value1 !== props[name]) i.emit(`update:${name}`, value1);
        });
        return proxy;
    } else return {
        __v_isRef: true,
        get value () {
            return props[name];
        },
        set value (value){
            i.emit(`update:${name}`, value);
        }
    };
}
function getContext() {
    const i = getCurrentInstance();
    if (!i) warn(`useContext() called without active instance.`);
    return i.setupContext || (i.setupContext = createSetupContext(i));
}
function normalizePropsOrEmits(props) {
    return (0, _shared.isArray)(props) ? props.reduce((normalized, p)=>(normalized[p] = null, normalized), {}) : props;
}
function mergeDefaults(raw, defaults) {
    const props = normalizePropsOrEmits(raw);
    for(const key in defaults){
        if (key.startsWith("__skip")) continue;
        let opt = props[key];
        if (opt) {
            if ((0, _shared.isArray)(opt) || (0, _shared.isFunction)(opt)) opt = props[key] = {
                type: opt,
                default: defaults[key]
            };
            else opt.default = defaults[key];
        } else if (opt === null) opt = props[key] = {
            default: defaults[key]
        };
        else warn(`props default key "${key}" has no corresponding declaration.`);
        if (opt && defaults[`__skip_${key}`]) opt.skipFactory = true;
    }
    return props;
}
function mergeModels(a, b) {
    if (!a || !b) return a || b;
    if ((0, _shared.isArray)(a) && (0, _shared.isArray)(b)) return a.concat(b);
    return (0, _shared.extend)({}, normalizePropsOrEmits(a), normalizePropsOrEmits(b));
}
function createPropsRestProxy(props, excludedKeys) {
    const ret = {};
    for(const key in props)if (!excludedKeys.includes(key)) Object.defineProperty(ret, key, {
        enumerable: true,
        get: ()=>props[key]
    });
    return ret;
}
function withAsyncContext(getAwaitable) {
    const ctx = getCurrentInstance();
    if (!ctx) warn(`withAsyncContext called without active current instance. This is likely a bug.`);
    let awaitable = getAwaitable();
    unsetCurrentInstance();
    if ((0, _shared.isPromise)(awaitable)) awaitable = awaitable.catch((e)=>{
        setCurrentInstance(ctx);
        throw e;
    });
    return [
        awaitable,
        ()=>setCurrentInstance(ctx)
    ];
}
function createDuplicateChecker() {
    const cache = /* @__PURE__ */ Object.create(null);
    return (type, key)=>{
        if (cache[key]) warn(`${type} property "${key}" is already defined in ${cache[key]}.`);
        else cache[key] = type;
    };
}
let shouldCacheAccess = true;
function applyOptions(instance) {
    const options = resolveMergedOptions(instance);
    const publicThis = instance.proxy;
    const ctx = instance.ctx;
    shouldCacheAccess = false;
    if (options.beforeCreate) callHook(options.beforeCreate, instance, "bc");
    const { // state
    data: dataOptions, computed: computedOptions, methods, watch: watchOptions, provide: provideOptions, inject: injectOptions, // lifecycle
    created, beforeMount, mounted, beforeUpdate, updated, activated, deactivated, beforeDestroy, beforeUnmount, destroyed, unmounted, render, renderTracked, renderTriggered, errorCaptured, serverPrefetch, // public API
    expose, inheritAttrs, // assets
    components, directives, filters } = options;
    const checkDuplicateProperties = createDuplicateChecker();
    {
        const [propsOptions] = instance.propsOptions;
        if (propsOptions) for(const key in propsOptions)checkDuplicateProperties("Props" /* PROPS */ , key);
    }
    if (injectOptions) resolveInjections(injectOptions, ctx, checkDuplicateProperties);
    if (methods) for(const key in methods){
        const methodHandler = methods[key];
        if ((0, _shared.isFunction)(methodHandler)) {
            Object.defineProperty(ctx, key, {
                value: methodHandler.bind(publicThis),
                configurable: true,
                enumerable: true,
                writable: true
            });
            checkDuplicateProperties("Methods" /* METHODS */ , key);
        } else warn(`Method "${key}" has type "${typeof methodHandler}" in the component definition. Did you reference the function correctly?`);
    }
    if (dataOptions) {
        if (!(0, _shared.isFunction)(dataOptions)) warn(`The data option must be a function. Plain object usage is no longer supported.`);
        const data = dataOptions.call(publicThis, publicThis);
        if ((0, _shared.isPromise)(data)) warn(`data() returned a Promise - note data() cannot be async; If you intend to perform data fetching before component renders, use async setup() + <Suspense>.`);
        if (!(0, _shared.isObject)(data)) warn(`data() should return an object.`);
        else {
            instance.data = (0, _reactivity.reactive)(data);
            for(const key in data){
                checkDuplicateProperties("Data" /* DATA */ , key);
                if (!isReservedPrefix(key[0])) Object.defineProperty(ctx, key, {
                    configurable: true,
                    enumerable: true,
                    get: ()=>data[key],
                    set: (0, _shared.NOOP)
                });
            }
        }
    }
    shouldCacheAccess = true;
    if (computedOptions) for(const key in computedOptions){
        const opt = computedOptions[key];
        const get = (0, _shared.isFunction)(opt) ? opt.bind(publicThis, publicThis) : (0, _shared.isFunction)(opt.get) ? opt.get.bind(publicThis, publicThis) : (0, _shared.NOOP);
        if (get === (0, _shared.NOOP)) warn(`Computed property "${key}" has no getter.`);
        const set = !(0, _shared.isFunction)(opt) && (0, _shared.isFunction)(opt.set) ? opt.set.bind(publicThis) : ()=>{
            warn(`Write operation failed: computed property "${key}" is readonly.`);
        };
        const c = computed({
            get,
            set
        });
        Object.defineProperty(ctx, key, {
            enumerable: true,
            configurable: true,
            get: ()=>c.value,
            set: (v1)=>c.value = v1
        });
        checkDuplicateProperties("Computed" /* COMPUTED */ , key);
    }
    if (watchOptions) for(const key in watchOptions)createWatcher(watchOptions[key], ctx, publicThis, key);
    if (provideOptions) {
        const provides = (0, _shared.isFunction)(provideOptions) ? provideOptions.call(publicThis) : provideOptions;
        Reflect.ownKeys(provides).forEach((key)=>{
            provide(key, provides[key]);
        });
    }
    if (created) callHook(created, instance, "c");
    function registerLifecycleHook(register, hook) {
        if ((0, _shared.isArray)(hook)) hook.forEach((_hook)=>register(_hook.bind(publicThis)));
        else if (hook) register(hook.bind(publicThis));
    }
    registerLifecycleHook(onBeforeMount, beforeMount);
    registerLifecycleHook(onMounted, mounted);
    registerLifecycleHook(onBeforeUpdate, beforeUpdate);
    registerLifecycleHook(onUpdated, updated);
    registerLifecycleHook(onActivated, activated);
    registerLifecycleHook(onDeactivated, deactivated);
    registerLifecycleHook(onErrorCaptured, errorCaptured);
    registerLifecycleHook(onRenderTracked, renderTracked);
    registerLifecycleHook(onRenderTriggered, renderTriggered);
    registerLifecycleHook(onBeforeUnmount, beforeUnmount);
    registerLifecycleHook(onUnmounted, unmounted);
    registerLifecycleHook(onServerPrefetch, serverPrefetch);
    if ((0, _shared.isArray)(expose)) {
        if (expose.length) {
            const exposed = instance.exposed || (instance.exposed = {});
            expose.forEach((key)=>{
                Object.defineProperty(exposed, key, {
                    get: ()=>publicThis[key],
                    set: (val)=>publicThis[key] = val
                });
            });
        } else if (!instance.exposed) instance.exposed = {};
    }
    if (render && instance.render === (0, _shared.NOOP)) instance.render = render;
    if (inheritAttrs != null) instance.inheritAttrs = inheritAttrs;
    if (components) instance.components = components;
    if (directives) instance.directives = directives;
}
function resolveInjections(injectOptions, ctx, checkDuplicateProperties = (0, _shared.NOOP)) {
    if ((0, _shared.isArray)(injectOptions)) injectOptions = normalizeInject(injectOptions);
    for(const key in injectOptions){
        const opt = injectOptions[key];
        let injected;
        if ((0, _shared.isObject)(opt)) {
            if ("default" in opt) injected = inject(opt.from || key, opt.default, true);
            else injected = inject(opt.from || key);
        } else injected = inject(opt);
        if ((0, _reactivity.isRef)(injected)) Object.defineProperty(ctx, key, {
            enumerable: true,
            configurable: true,
            get: ()=>injected.value,
            set: (v1)=>injected.value = v1
        });
        else ctx[key] = injected;
        checkDuplicateProperties("Inject" /* INJECT */ , key);
    }
}
function callHook(hook, instance, type) {
    callWithAsyncErrorHandling((0, _shared.isArray)(hook) ? hook.map((h)=>h.bind(instance.proxy)) : hook.bind(instance.proxy), instance, type);
}
function createWatcher(raw, ctx, publicThis, key) {
    const getter = key.includes(".") ? createPathGetter(publicThis, key) : ()=>publicThis[key];
    if ((0, _shared.isString)(raw)) {
        const handler = ctx[raw];
        if ((0, _shared.isFunction)(handler)) watch(getter, handler);
        else warn(`Invalid watch handler specified by key "${raw}"`, handler);
    } else if ((0, _shared.isFunction)(raw)) watch(getter, raw.bind(publicThis));
    else if ((0, _shared.isObject)(raw)) {
        if ((0, _shared.isArray)(raw)) raw.forEach((r)=>createWatcher(r, ctx, publicThis, key));
        else {
            const handler = (0, _shared.isFunction)(raw.handler) ? raw.handler.bind(publicThis) : ctx[raw.handler];
            if ((0, _shared.isFunction)(handler)) watch(getter, handler, raw);
            else warn(`Invalid watch handler specified by key "${raw.handler}"`, handler);
        }
    } else warn(`Invalid watch option: "${key}"`, raw);
}
function resolveMergedOptions(instance) {
    const base = instance.type;
    const { mixins, extends: extendsOptions } = base;
    const { mixins: globalMixins, optionsCache: cache, config: { optionMergeStrategies } } = instance.appContext;
    const cached = cache.get(base);
    let resolved;
    if (cached) resolved = cached;
    else if (!globalMixins.length && !mixins && !extendsOptions) resolved = base;
    else {
        resolved = {};
        if (globalMixins.length) globalMixins.forEach((m)=>mergeOptions(resolved, m, optionMergeStrategies, true));
        mergeOptions(resolved, base, optionMergeStrategies);
    }
    if ((0, _shared.isObject)(base)) cache.set(base, resolved);
    return resolved;
}
function mergeOptions(to, from, strats, asMixin = false) {
    const { mixins, extends: extendsOptions } = from;
    if (extendsOptions) mergeOptions(to, extendsOptions, strats, true);
    if (mixins) mixins.forEach((m)=>mergeOptions(to, m, strats, true));
    for(const key in from)if (asMixin && key === "expose") warn(`"expose" option is ignored when declared in mixins or extends. It should only be declared in the base component itself.`);
    else {
        const strat = internalOptionMergeStrats[key] || strats && strats[key];
        to[key] = strat ? strat(to[key], from[key]) : from[key];
    }
    return to;
}
const internalOptionMergeStrats = {
    data: mergeDataFn,
    props: mergeEmitsOrPropsOptions,
    emits: mergeEmitsOrPropsOptions,
    // objects
    methods: mergeObjectOptions,
    computed: mergeObjectOptions,
    // lifecycle
    beforeCreate: mergeAsArray,
    created: mergeAsArray,
    beforeMount: mergeAsArray,
    mounted: mergeAsArray,
    beforeUpdate: mergeAsArray,
    updated: mergeAsArray,
    beforeDestroy: mergeAsArray,
    beforeUnmount: mergeAsArray,
    destroyed: mergeAsArray,
    unmounted: mergeAsArray,
    activated: mergeAsArray,
    deactivated: mergeAsArray,
    errorCaptured: mergeAsArray,
    serverPrefetch: mergeAsArray,
    // assets
    components: mergeObjectOptions,
    directives: mergeObjectOptions,
    // watch
    watch: mergeWatchOptions,
    // provide / inject
    provide: mergeDataFn,
    inject: mergeInject
};
function mergeDataFn(to, from) {
    if (!from) return to;
    if (!to) return from;
    return function mergedDataFn() {
        return (0, _shared.extend)((0, _shared.isFunction)(to) ? to.call(this, this) : to, (0, _shared.isFunction)(from) ? from.call(this, this) : from);
    };
}
function mergeInject(to, from) {
    return mergeObjectOptions(normalizeInject(to), normalizeInject(from));
}
function normalizeInject(raw) {
    if ((0, _shared.isArray)(raw)) {
        const res = {};
        for(let i = 0; i < raw.length; i++)res[raw[i]] = raw[i];
        return res;
    }
    return raw;
}
function mergeAsArray(to, from) {
    return to ? [
        ...new Set([].concat(to, from))
    ] : from;
}
function mergeObjectOptions(to, from) {
    return to ? (0, _shared.extend)(/* @__PURE__ */ Object.create(null), to, from) : from;
}
function mergeEmitsOrPropsOptions(to, from) {
    if (to) {
        if ((0, _shared.isArray)(to) && (0, _shared.isArray)(from)) return [
            .../* @__PURE__ */ new Set([
                ...to,
                ...from
            ])
        ];
        return (0, _shared.extend)(/* @__PURE__ */ Object.create(null), normalizePropsOrEmits(to), normalizePropsOrEmits(from != null ? from : {}));
    } else return from;
}
function mergeWatchOptions(to, from) {
    if (!to) return from;
    if (!from) return to;
    const merged = (0, _shared.extend)(/* @__PURE__ */ Object.create(null), to);
    for(const key in from)merged[key] = mergeAsArray(to[key], from[key]);
    return merged;
}
function createAppContext() {
    return {
        app: null,
        config: {
            isNativeTag: (0, _shared.NO),
            performance: false,
            globalProperties: {},
            optionMergeStrategies: {},
            errorHandler: void 0,
            warnHandler: void 0,
            compilerOptions: {}
        },
        mixins: [],
        components: {},
        directives: {},
        provides: /* @__PURE__ */ Object.create(null),
        optionsCache: /* @__PURE__ */ new WeakMap(),
        propsCache: /* @__PURE__ */ new WeakMap(),
        emitsCache: /* @__PURE__ */ new WeakMap()
    };
}
let uid$1 = 0;
function createAppAPI(render, hydrate) {
    return function createApp(rootComponent, rootProps = null) {
        if (!(0, _shared.isFunction)(rootComponent)) rootComponent = (0, _shared.extend)({}, rootComponent);
        if (rootProps != null && !(0, _shared.isObject)(rootProps)) {
            warn(`root props passed to app.mount() must be an object.`);
            rootProps = null;
        }
        const context = createAppContext();
        Object.defineProperty(context.config, "unwrapInjectedRef", {
            get () {
                return true;
            },
            set () {
                warn(`app.config.unwrapInjectedRef has been deprecated. 3.3 now always unwraps injected refs in Options API.`);
            }
        });
        const installedPlugins = /* @__PURE__ */ new WeakSet();
        let isMounted = false;
        const app = context.app = {
            _uid: uid$1++,
            _component: rootComponent,
            _props: rootProps,
            _container: null,
            _context: context,
            _instance: null,
            version,
            get config () {
                return context.config;
            },
            set config (v){
                warn(`app.config cannot be replaced. Modify individual options instead.`);
            },
            use (plugin, ...options) {
                if (installedPlugins.has(plugin)) warn(`Plugin has already been applied to target app.`);
                else if (plugin && (0, _shared.isFunction)(plugin.install)) {
                    installedPlugins.add(plugin);
                    plugin.install(app, ...options);
                } else if ((0, _shared.isFunction)(plugin)) {
                    installedPlugins.add(plugin);
                    plugin(app, ...options);
                } else warn(`A plugin must either be a function or an object with an "install" function.`);
                return app;
            },
            mixin (mixin) {
                if (__VUE_OPTIONS_API__) {
                    if (!context.mixins.includes(mixin)) context.mixins.push(mixin);
                    else warn("Mixin has already been applied to target app" + (mixin.name ? `: ${mixin.name}` : ""));
                } else warn("Mixins are only available in builds supporting Options API");
                return app;
            },
            component (name, component) {
                validateComponentName(name, context.config);
                if (!component) return context.components[name];
                if (0, context.components[name]) warn(`Component "${name}" has already been registered in target app.`);
                context.components[name] = component;
                return app;
            },
            directive (name, directive) {
                validateDirectiveName(name);
                if (!directive) return context.directives[name];
                if (0, context.directives[name]) warn(`Directive "${name}" has already been registered in target app.`);
                context.directives[name] = directive;
                return app;
            },
            mount (rootContainer, isHydrate, isSVG) {
                if (!isMounted) {
                    if (0, rootContainer.__vue_app__) warn(`There is already an app instance mounted on the host container.
 If you want to mount another app on the same host container, you need to unmount the previous app by calling \`app.unmount()\` first.`);
                    const vnode = createVNode(rootComponent, rootProps);
                    vnode.appContext = context;
                    context.reload = ()=>{
                        render(cloneVNode(vnode), rootContainer, isSVG);
                    };
                    if (isHydrate && hydrate) hydrate(vnode, rootContainer);
                    else render(vnode, rootContainer, isSVG);
                    isMounted = true;
                    app._container = rootContainer;
                    rootContainer.__vue_app__ = app;
                    app._instance = vnode.component;
                    devtoolsInitApp(app, version);
                    return getExposeProxy(vnode.component) || vnode.component.proxy;
                } else warn(`App has already been mounted.
If you want to remount the same app, move your app creation logic into a factory function and create fresh app instances for each mount - e.g. \`const createMyApp = () => createApp(App)\``);
            },
            unmount () {
                if (isMounted) {
                    render(null, app._container);
                    app._instance = null;
                    devtoolsUnmountApp(app);
                    delete app._container.__vue_app__;
                } else warn(`Cannot unmount an app that is not mounted.`);
            },
            provide (key, value1) {
                if (key in context.provides) warn(`App already provides property with key "${String(key)}". It will be overwritten with the new value.`);
                context.provides[key] = value1;
                return app;
            },
            runWithContext (fn) {
                currentApp = app;
                try {
                    return fn();
                } finally{
                    currentApp = null;
                }
            }
        };
        return app;
    };
}
let currentApp = null;
function provide(key, value1) {
    if (!currentInstance) warn(`provide() can only be used inside setup().`);
    else {
        let provides = currentInstance.provides;
        const parentProvides = currentInstance.parent && currentInstance.parent.provides;
        if (parentProvides === provides) provides = currentInstance.provides = Object.create(parentProvides);
        provides[key] = value1;
    }
}
function inject(key, defaultValue, treatDefaultAsFactory = false) {
    const instance = currentInstance || currentRenderingInstance;
    if (instance || currentApp) {
        const provides = instance ? instance.parent == null ? instance.vnode.appContext && instance.vnode.appContext.provides : instance.parent.provides : currentApp._context.provides;
        if (provides && key in provides) return provides[key];
        else if (arguments.length > 1) return treatDefaultAsFactory && (0, _shared.isFunction)(defaultValue) ? defaultValue.call(instance && instance.proxy) : defaultValue;
        else warn(`injection "${String(key)}" not found.`);
    } else warn(`inject() can only be used inside setup() or functional components.`);
}
function hasInjectionContext() {
    return !!(currentInstance || currentRenderingInstance || currentApp);
}
function initProps(instance, rawProps, isStateful, isSSR = false) {
    const props = {};
    const attrs = {};
    (0, _shared.def)(attrs, InternalObjectKey, 1);
    instance.propsDefaults = /* @__PURE__ */ Object.create(null);
    setFullProps(instance, rawProps, props, attrs);
    for(const key in instance.propsOptions[0])if (!(key in props)) props[key] = void 0;
    validateProps(rawProps || {}, props, instance);
    if (isStateful) instance.props = isSSR ? props : (0, _reactivity.shallowReactive)(props);
    else if (!instance.type.props) instance.props = attrs;
    else instance.props = props;
    instance.attrs = attrs;
}
function isInHmrContext(instance) {
    while(instance){
        if (instance.type.__hmrId) return true;
        instance = instance.parent;
    }
}
function updateProps(instance, rawProps, rawPrevProps, optimized) {
    const { props, attrs, vnode: { patchFlag } } = instance;
    const rawCurrentProps = (0, _reactivity.toRaw)(props);
    const [options] = instance.propsOptions;
    let hasAttrsChanged = false;
    if (// always force full diff in dev
    // - #1942 if hmr is enabled with sfc component
    // - vite#872 non-sfc component used by sfc component
    !isInHmrContext(instance) && (optimized || patchFlag > 0) && !(patchFlag & 16)) {
        if (patchFlag & 8) {
            const propsToUpdate = instance.vnode.dynamicProps;
            for(let i = 0; i < propsToUpdate.length; i++){
                let key = propsToUpdate[i];
                if (isEmitListener(instance.emitsOptions, key)) continue;
                const value1 = rawProps[key];
                if (options) {
                    if ((0, _shared.hasOwn)(attrs, key)) {
                        if (value1 !== attrs[key]) {
                            attrs[key] = value1;
                            hasAttrsChanged = true;
                        }
                    } else {
                        const camelizedKey = (0, _shared.camelize)(key);
                        props[camelizedKey] = resolvePropValue(options, rawCurrentProps, camelizedKey, value1, instance, false);
                    }
                } else if (value1 !== attrs[key]) {
                    attrs[key] = value1;
                    hasAttrsChanged = true;
                }
            }
        }
    } else {
        if (setFullProps(instance, rawProps, props, attrs)) hasAttrsChanged = true;
        let kebabKey;
        for(const key in rawCurrentProps)if (!rawProps || // for camelCase
        !(0, _shared.hasOwn)(rawProps, key) && // it's possible the original props was passed in as kebab-case
        // and converted to camelCase (#955)
        ((kebabKey = (0, _shared.hyphenate)(key)) === key || !(0, _shared.hasOwn)(rawProps, kebabKey))) {
            if (options) {
                if (rawPrevProps && // for camelCase
                (rawPrevProps[key] !== void 0 || // for kebab-case
                rawPrevProps[kebabKey] !== void 0)) props[key] = resolvePropValue(options, rawCurrentProps, key, void 0, instance, true);
            } else delete props[key];
        }
        if (attrs !== rawCurrentProps) {
            for(const key in attrs)if (!rawProps || !(0, _shared.hasOwn)(rawProps, key) && true) {
                delete attrs[key];
                hasAttrsChanged = true;
            }
        }
    }
    if (hasAttrsChanged) (0, _reactivity.trigger)(instance, "set", "$attrs");
    validateProps(rawProps || {}, props, instance);
}
function setFullProps(instance, rawProps, props, attrs) {
    const [options, needCastKeys] = instance.propsOptions;
    let hasAttrsChanged = false;
    let rawCastValues;
    if (rawProps) for(let key in rawProps){
        if ((0, _shared.isReservedProp)(key)) continue;
        const value1 = rawProps[key];
        let camelKey;
        if (options && (0, _shared.hasOwn)(options, camelKey = (0, _shared.camelize)(key))) {
            if (!needCastKeys || !needCastKeys.includes(camelKey)) props[camelKey] = value1;
            else (rawCastValues || (rawCastValues = {}))[camelKey] = value1;
        } else if (!isEmitListener(instance.emitsOptions, key)) {
            if (!(key in attrs) || value1 !== attrs[key]) {
                attrs[key] = value1;
                hasAttrsChanged = true;
            }
        }
    }
    if (needCastKeys) {
        const rawCurrentProps = (0, _reactivity.toRaw)(props);
        const castValues = rawCastValues || (0, _shared.EMPTY_OBJ);
        for(let i = 0; i < needCastKeys.length; i++){
            const key = needCastKeys[i];
            props[key] = resolvePropValue(options, rawCurrentProps, key, castValues[key], instance, !(0, _shared.hasOwn)(castValues, key));
        }
    }
    return hasAttrsChanged;
}
function resolvePropValue(options, props, key, value1, instance, isAbsent) {
    const opt = options[key];
    if (opt != null) {
        const hasDefault = (0, _shared.hasOwn)(opt, "default");
        if (hasDefault && value1 === void 0) {
            const defaultValue = opt.default;
            if (opt.type !== Function && !opt.skipFactory && (0, _shared.isFunction)(defaultValue)) {
                const { propsDefaults } = instance;
                if (key in propsDefaults) value1 = propsDefaults[key];
                else {
                    setCurrentInstance(instance);
                    value1 = propsDefaults[key] = defaultValue.call(null, props);
                    unsetCurrentInstance();
                }
            } else value1 = defaultValue;
        }
        if (opt[0 /* shouldCast */ ]) {
            if (isAbsent && !hasDefault) value1 = false;
            else if (opt[1 /* shouldCastTrue */ ] && (value1 === "" || value1 === (0, _shared.hyphenate)(key))) value1 = true;
        }
    }
    return value1;
}
function normalizePropsOptions(comp, appContext, asMixin = false) {
    const cache = appContext.propsCache;
    const cached = cache.get(comp);
    if (cached) return cached;
    const raw = comp.props;
    const normalized = {};
    const needCastKeys = [];
    let hasExtends = false;
    if (__VUE_OPTIONS_API__ && !(0, _shared.isFunction)(comp)) {
        const extendProps = (raw2)=>{
            hasExtends = true;
            const [props, keys] = normalizePropsOptions(raw2, appContext, true);
            (0, _shared.extend)(normalized, props);
            if (keys) needCastKeys.push(...keys);
        };
        if (!asMixin && appContext.mixins.length) appContext.mixins.forEach(extendProps);
        if (comp.extends) extendProps(comp.extends);
        if (comp.mixins) comp.mixins.forEach(extendProps);
    }
    if (!raw && !hasExtends) {
        if ((0, _shared.isObject)(comp)) cache.set(comp, (0, _shared.EMPTY_ARR));
        return 0, _shared.EMPTY_ARR;
    }
    if ((0, _shared.isArray)(raw)) for(let i = 0; i < raw.length; i++){
        if (!(0, _shared.isString)(raw[i])) warn(`props must be strings when using array syntax.`, raw[i]);
        const normalizedKey = (0, _shared.camelize)(raw[i]);
        if (validatePropName(normalizedKey)) normalized[normalizedKey] = (0, _shared.EMPTY_OBJ);
    }
    else if (raw) {
        if (!(0, _shared.isObject)(raw)) warn(`invalid props options`, raw);
        for(const key in raw){
            const normalizedKey = (0, _shared.camelize)(key);
            if (validatePropName(normalizedKey)) {
                const opt = raw[key];
                const prop = normalized[normalizedKey] = (0, _shared.isArray)(opt) || (0, _shared.isFunction)(opt) ? {
                    type: opt
                } : (0, _shared.extend)({}, opt);
                if (prop) {
                    const booleanIndex = getTypeIndex(Boolean, prop.type);
                    const stringIndex = getTypeIndex(String, prop.type);
                    prop[0 /* shouldCast */ ] = booleanIndex > -1;
                    prop[1 /* shouldCastTrue */ ] = stringIndex < 0 || booleanIndex < stringIndex;
                    if (booleanIndex > -1 || (0, _shared.hasOwn)(prop, "default")) needCastKeys.push(normalizedKey);
                }
            }
        }
    }
    const res = [
        normalized,
        needCastKeys
    ];
    if ((0, _shared.isObject)(comp)) cache.set(comp, res);
    return res;
}
function validatePropName(key) {
    if (key[0] !== "$") return true;
    else warn(`Invalid prop name: "${key}" is a reserved property.`);
    return false;
}
function getType(ctor) {
    const match = ctor && ctor.toString().match(/^\s*(function|class) (\w+)/);
    return match ? match[2] : ctor === null ? "null" : "";
}
function isSameType(a, b) {
    return getType(a) === getType(b);
}
function getTypeIndex(type, expectedTypes) {
    if ((0, _shared.isArray)(expectedTypes)) return expectedTypes.findIndex((t)=>isSameType(t, type));
    else if ((0, _shared.isFunction)(expectedTypes)) return isSameType(expectedTypes, type) ? 0 : -1;
    return -1;
}
function validateProps(rawProps, props, instance) {
    const resolvedValues = (0, _reactivity.toRaw)(props);
    const options = instance.propsOptions[0];
    for(const key in options){
        let opt = options[key];
        if (opt == null) continue;
        validateProp(key, resolvedValues[key], opt, !(0, _shared.hasOwn)(rawProps, key) && !(0, _shared.hasOwn)(rawProps, (0, _shared.hyphenate)(key)));
    }
}
function validateProp(name, value1, prop, isAbsent) {
    const { type, required, validator, skipCheck } = prop;
    if (required && isAbsent) {
        warn('Missing required prop: "' + name + '"');
        return;
    }
    if (value1 == null && !required) return;
    if (type != null && type !== true && !skipCheck) {
        let isValid = false;
        const types = (0, _shared.isArray)(type) ? type : [
            type
        ];
        const expectedTypes = [];
        for(let i = 0; i < types.length && !isValid; i++){
            const { valid, expectedType } = assertType(value1, types[i]);
            expectedTypes.push(expectedType || "");
            isValid = valid;
        }
        if (!isValid) {
            warn(getInvalidTypeMessage(name, value1, expectedTypes));
            return;
        }
    }
    if (validator && !validator(value1)) warn('Invalid prop: custom validator check failed for prop "' + name + '".');
}
const isSimpleType = /* @__PURE__ */ (0, _shared.makeMap)("String,Number,Boolean,Function,Symbol,BigInt");
function assertType(value1, type) {
    let valid;
    const expectedType = getType(type);
    if (isSimpleType(expectedType)) {
        const t = typeof value1;
        valid = t === expectedType.toLowerCase();
        if (!valid && t === "object") valid = value1 instanceof type;
    } else if (expectedType === "Object") valid = (0, _shared.isObject)(value1);
    else if (expectedType === "Array") valid = (0, _shared.isArray)(value1);
    else if (expectedType === "null") valid = value1 === null;
    else valid = value1 instanceof type;
    return {
        valid,
        expectedType
    };
}
function getInvalidTypeMessage(name, value1, expectedTypes) {
    if (expectedTypes.length === 0) return `Prop type [] for prop "${name}" won't match anything. Did you mean to use type Array instead?`;
    let message = `Invalid prop: type check failed for prop "${name}". Expected ${expectedTypes.map((0, _shared.capitalize)).join(" | ")}`;
    const expectedType = expectedTypes[0];
    const receivedType = (0, _shared.toRawType)(value1);
    const expectedValue = styleValue(value1, expectedType);
    const receivedValue = styleValue(value1, receivedType);
    if (expectedTypes.length === 1 && isExplicable(expectedType) && !isBoolean(expectedType, receivedType)) message += ` with value ${expectedValue}`;
    message += `, got ${receivedType} `;
    if (isExplicable(receivedType)) message += `with value ${receivedValue}.`;
    return message;
}
function styleValue(value1, type) {
    if (type === "String") return `"${value1}"`;
    else if (type === "Number") return `${Number(value1)}`;
    else return `${value1}`;
}
function isExplicable(type) {
    const explicitTypes = [
        "string",
        "number",
        "boolean"
    ];
    return explicitTypes.some((elem)=>type.toLowerCase() === elem);
}
function isBoolean(...args) {
    return args.some((elem)=>elem.toLowerCase() === "boolean");
}
const isInternalKey = (key)=>key[0] === "_" || key === "$stable";
const normalizeSlotValue = (value1)=>(0, _shared.isArray)(value1) ? value1.map(normalizeVNode) : [
        normalizeVNode(value1)
    ];
const normalizeSlot = (key, rawSlot, ctx)=>{
    if (rawSlot._n) return rawSlot;
    const normalized = withCtx((...args)=>{
        if (currentInstance) warn(`Slot "${key}" invoked outside of the render function: this will not track dependencies used in the slot. Invoke the slot function inside the render function instead.`);
        return normalizeSlotValue(rawSlot(...args));
    }, ctx);
    normalized._c = false;
    return normalized;
};
const normalizeObjectSlots = (rawSlots, slots, instance)=>{
    const ctx = rawSlots._ctx;
    for(const key in rawSlots){
        if (isInternalKey(key)) continue;
        const value1 = rawSlots[key];
        if ((0, _shared.isFunction)(value1)) slots[key] = normalizeSlot(key, value1, ctx);
        else if (value1 != null) {
            warn(`Non-function value encountered for slot "${key}". Prefer function slots for better performance.`);
            const normalized = normalizeSlotValue(value1);
            slots[key] = ()=>normalized;
        }
    }
};
const normalizeVNodeSlots = (instance, children)=>{
    if (!isKeepAlive(instance.vnode) && true) warn(`Non-function value encountered for default slot. Prefer function slots for better performance.`);
    const normalized = normalizeSlotValue(children);
    instance.slots.default = ()=>normalized;
};
const initSlots = (instance, children)=>{
    if (instance.vnode.shapeFlag & 32) {
        const type = children._;
        if (type) {
            instance.slots = (0, _reactivity.toRaw)(children);
            (0, _shared.def)(children, "_", type);
        } else normalizeObjectSlots(children, instance.slots = {});
    } else {
        instance.slots = {};
        if (children) normalizeVNodeSlots(instance, children);
    }
    (0, _shared.def)(instance.slots, InternalObjectKey, 1);
};
const updateSlots = (instance, children, optimized)=>{
    const { vnode, slots } = instance;
    let needDeletionCheck = true;
    let deletionComparisonTarget = (0, _shared.EMPTY_OBJ);
    if (vnode.shapeFlag & 32) {
        const type = children._;
        if (type) {
            if (isHmrUpdating) {
                (0, _shared.extend)(slots, children);
                (0, _reactivity.trigger)(instance, "set", "$slots");
            } else if (optimized && type === 1) needDeletionCheck = false;
            else {
                (0, _shared.extend)(slots, children);
                if (!optimized && type === 1) delete slots._;
            }
        } else {
            needDeletionCheck = !children.$stable;
            normalizeObjectSlots(children, slots);
        }
        deletionComparisonTarget = children;
    } else if (children) {
        normalizeVNodeSlots(instance, children);
        deletionComparisonTarget = {
            default: 1
        };
    }
    if (needDeletionCheck) {
        for(const key in slots)if (!isInternalKey(key) && deletionComparisonTarget[key] == null) delete slots[key];
    }
};
function setRef(rawRef, oldRawRef, parentSuspense, vnode, isUnmount = false) {
    if ((0, _shared.isArray)(rawRef)) {
        rawRef.forEach((r, i)=>setRef(r, oldRawRef && ((0, _shared.isArray)(oldRawRef) ? oldRawRef[i] : oldRawRef), parentSuspense, vnode, isUnmount));
        return;
    }
    if (isAsyncWrapper(vnode) && !isUnmount) return;
    const refValue = vnode.shapeFlag & 4 ? getExposeProxy(vnode.component) || vnode.component.proxy : vnode.el;
    const value1 = isUnmount ? null : refValue;
    const { i: owner, r: ref } = rawRef;
    if (!owner) {
        warn(`Missing ref owner context. ref cannot be used on hoisted vnodes. A vnode with ref must be created inside the render function.`);
        return;
    }
    const oldRef = oldRawRef && oldRawRef.r;
    const refs = owner.refs === (0, _shared.EMPTY_OBJ) ? owner.refs = {} : owner.refs;
    const setupState = owner.setupState;
    if (oldRef != null && oldRef !== ref) {
        if ((0, _shared.isString)(oldRef)) {
            refs[oldRef] = null;
            if ((0, _shared.hasOwn)(setupState, oldRef)) setupState[oldRef] = null;
        } else if ((0, _reactivity.isRef)(oldRef)) oldRef.value = null;
    }
    if ((0, _shared.isFunction)(ref)) callWithErrorHandling(ref, owner, 12, [
        value1,
        refs
    ]);
    else {
        const _isString = (0, _shared.isString)(ref);
        const _isRef = (0, _reactivity.isRef)(ref);
        if (_isString || _isRef) {
            const doSet = ()=>{
                if (rawRef.f) {
                    const existing = _isString ? (0, _shared.hasOwn)(setupState, ref) ? setupState[ref] : refs[ref] : ref.value;
                    if (isUnmount) (0, _shared.isArray)(existing) && (0, _shared.remove)(existing, refValue);
                    else {
                        if (!(0, _shared.isArray)(existing)) {
                            if (_isString) {
                                refs[ref] = [
                                    refValue
                                ];
                                if ((0, _shared.hasOwn)(setupState, ref)) setupState[ref] = refs[ref];
                            } else {
                                ref.value = [
                                    refValue
                                ];
                                if (rawRef.k) refs[rawRef.k] = ref.value;
                            }
                        } else if (!existing.includes(refValue)) existing.push(refValue);
                    }
                } else if (_isString) {
                    refs[ref] = value1;
                    if ((0, _shared.hasOwn)(setupState, ref)) setupState[ref] = value1;
                } else if (_isRef) {
                    ref.value = value1;
                    if (rawRef.k) refs[rawRef.k] = value1;
                } else warn("Invalid template ref type:", ref, `(${typeof ref})`);
            };
            if (value1) {
                doSet.id = -1;
                queuePostRenderEffect(doSet, parentSuspense);
            } else doSet();
        } else warn("Invalid template ref type:", ref, `(${typeof ref})`);
    }
}
let hasMismatch = false;
const isSVGContainer = (container)=>/svg/.test(container.namespaceURI) && container.tagName !== "foreignObject";
const isComment = (node)=>node.nodeType === 8 /* COMMENT */ ;
function createHydrationFunctions(rendererInternals) {
    const { mt: mountComponent, p: patch, o: { patchProp, createText, nextSibling, parentNode, remove, insert, createComment } } = rendererInternals;
    const hydrate = (vnode, container)=>{
        if (!container.hasChildNodes()) {
            warn(`Attempting to hydrate existing markup but container is empty. Performing full mount instead.`);
            patch(null, vnode, container);
            flushPostFlushCbs();
            container._vnode = vnode;
            return;
        }
        hasMismatch = false;
        hydrateNode(container.firstChild, vnode, null, null, null);
        flushPostFlushCbs();
        container._vnode = vnode;
        if (hasMismatch && true) console.error(`Hydration completed but contains mismatches.`);
    };
    const hydrateNode = (node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized = false)=>{
        const isFragmentStart = isComment(node) && node.data === "[";
        const onMismatch = ()=>handleMismatch(node, vnode, parentComponent, parentSuspense, slotScopeIds, isFragmentStart);
        const { type, ref, shapeFlag, patchFlag } = vnode;
        let domType = node.nodeType;
        vnode.el = node;
        if (!("__vnode" in node)) Object.defineProperty(node, "__vnode", {
            value: vnode,
            enumerable: false
        });
        if (!("__vueParentComponent" in node)) Object.defineProperty(node, "__vueParentComponent", {
            value: parentComponent,
            enumerable: false
        });
        if (patchFlag === -2) {
            optimized = false;
            vnode.dynamicChildren = null;
        }
        let nextNode = null;
        switch(type){
            case Text:
                if (domType !== 3 /* TEXT */ ) {
                    if (vnode.children === "") {
                        insert(vnode.el = createText(""), parentNode(node), node);
                        nextNode = node;
                    } else nextNode = onMismatch();
                } else {
                    if (node.data !== vnode.children) {
                        hasMismatch = true;
                        warn(`Hydration text mismatch:
- Server rendered: ${JSON.stringify(node.data)}
- Client rendered: ${JSON.stringify(vnode.children)}`);
                        node.data = vnode.children;
                    }
                    nextNode = nextSibling(node);
                }
                break;
            case Comment:
                if (isTemplateNode(node)) {
                    nextNode = nextSibling(node);
                    replaceNode(vnode.el = node.content.firstChild, node, parentComponent);
                } else if (domType !== 8 /* COMMENT */  || isFragmentStart) nextNode = onMismatch();
                else nextNode = nextSibling(node);
                break;
            case Static:
                if (isFragmentStart) {
                    node = nextSibling(node);
                    domType = node.nodeType;
                }
                if (domType === 1 /* ELEMENT */  || domType === 3 /* TEXT */ ) {
                    nextNode = node;
                    const needToAdoptContent = !vnode.children.length;
                    for(let i = 0; i < vnode.staticCount; i++){
                        if (needToAdoptContent) vnode.children += nextNode.nodeType === 1 /* ELEMENT */  ? nextNode.outerHTML : nextNode.data;
                        if (i === vnode.staticCount - 1) vnode.anchor = nextNode;
                        nextNode = nextSibling(nextNode);
                    }
                    return isFragmentStart ? nextSibling(nextNode) : nextNode;
                } else onMismatch();
                break;
            case Fragment:
                if (!isFragmentStart) nextNode = onMismatch();
                else nextNode = hydrateFragment(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized);
                break;
            default:
                if (shapeFlag & 1) {
                    if ((domType !== 1 /* ELEMENT */  || vnode.type.toLowerCase() !== node.tagName.toLowerCase()) && !isTemplateNode(node)) nextNode = onMismatch();
                    else nextNode = hydrateElement(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized);
                } else if (shapeFlag & 6) {
                    vnode.slotScopeIds = slotScopeIds;
                    const container = parentNode(node);
                    if (isFragmentStart) nextNode = locateClosingAnchor(node);
                    else if (isComment(node) && node.data === "teleport start") nextNode = locateClosingAnchor(node, node.data, "teleport end");
                    else nextNode = nextSibling(node);
                    mountComponent(vnode, container, null, parentComponent, parentSuspense, isSVGContainer(container), optimized);
                    if (isAsyncWrapper(vnode)) {
                        let subTree;
                        if (isFragmentStart) {
                            subTree = createVNode(Fragment);
                            subTree.anchor = nextNode ? nextNode.previousSibling : container.lastChild;
                        } else subTree = node.nodeType === 3 ? createTextVNode("") : createVNode("div");
                        subTree.el = node;
                        vnode.component.subTree = subTree;
                    }
                } else if (shapeFlag & 64) {
                    if (domType !== 8 /* COMMENT */ ) nextNode = onMismatch();
                    else nextNode = vnode.type.hydrate(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized, rendererInternals, hydrateChildren);
                } else if (shapeFlag & 128) nextNode = vnode.type.hydrate(node, vnode, parentComponent, parentSuspense, isSVGContainer(parentNode(node)), slotScopeIds, optimized, rendererInternals, hydrateNode);
                else warn("Invalid HostVNode type:", type, `(${typeof type})`);
        }
        if (ref != null) setRef(ref, null, parentSuspense, vnode);
        return nextNode;
    };
    const hydrateElement = (el, vnode, parentComponent, parentSuspense, slotScopeIds, optimized)=>{
        optimized = optimized || !!vnode.dynamicChildren;
        const { type, props, patchFlag, shapeFlag, dirs, transition } = vnode;
        const forcePatch = type === "input" || type === "option";
        {
            if (dirs) invokeDirectiveHook(vnode, null, parentComponent, "created");
            let needCallTransitionHooks = false;
            if (isTemplateNode(el)) {
                needCallTransitionHooks = needTransition(parentSuspense, transition) && parentComponent && parentComponent.vnode.props && parentComponent.vnode.props.appear;
                const content = el.content.firstChild;
                if (needCallTransitionHooks) transition.beforeEnter(content);
                replaceNode(content, el, parentComponent);
                vnode.el = el = content;
            }
            if (props) {
                if (forcePatch || !optimized || patchFlag & 48) {
                    for(const key in props)if (forcePatch && (key.endsWith("value") || key === "indeterminate") || (0, _shared.isOn)(key) && !(0, _shared.isReservedProp)(key) || // force hydrate v-bind with .prop modifiers
                    key[0] === ".") patchProp(el, key, null, props[key], false, void 0, parentComponent);
                } else if (props.onClick) patchProp(el, "onClick", null, props.onClick, false, void 0, parentComponent);
            }
            let vnodeHooks;
            if (vnodeHooks = props && props.onVnodeBeforeMount) invokeVNodeHook(vnodeHooks, parentComponent, vnode);
            if (dirs) invokeDirectiveHook(vnode, null, parentComponent, "beforeMount");
            if ((vnodeHooks = props && props.onVnodeMounted) || dirs || needCallTransitionHooks) queueEffectWithSuspense(()=>{
                vnodeHooks && invokeVNodeHook(vnodeHooks, parentComponent, vnode);
                needCallTransitionHooks && transition.enter(el);
                dirs && invokeDirectiveHook(vnode, null, parentComponent, "mounted");
            }, parentSuspense);
            if (shapeFlag & 16 && // skip if element has innerHTML / textContent
            !(props && (props.innerHTML || props.textContent))) {
                let next = hydrateChildren(el.firstChild, vnode, el, parentComponent, parentSuspense, slotScopeIds, optimized);
                let hasWarned = false;
                while(next){
                    hasMismatch = true;
                    if (!hasWarned) {
                        warn(`Hydration children mismatch in <${vnode.type}>: server rendered element contains more child nodes than client vdom.`);
                        hasWarned = true;
                    }
                    const cur = next;
                    next = next.nextSibling;
                    remove(cur);
                }
            } else if (shapeFlag & 8) {
                if (el.textContent !== vnode.children) {
                    hasMismatch = true;
                    warn(`Hydration text content mismatch in <${vnode.type}>:
- Server rendered: ${el.textContent}
- Client rendered: ${vnode.children}`);
                    el.textContent = vnode.children;
                }
            }
        }
        return el.nextSibling;
    };
    const hydrateChildren = (node, parentVNode, container, parentComponent, parentSuspense, slotScopeIds, optimized)=>{
        optimized = optimized || !!parentVNode.dynamicChildren;
        const children = parentVNode.children;
        const l = children.length;
        let hasWarned = false;
        for(let i = 0; i < l; i++){
            const vnode = optimized ? children[i] : children[i] = normalizeVNode(children[i]);
            if (node) node = hydrateNode(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized);
            else if (vnode.type === Text && !vnode.children) continue;
            else {
                hasMismatch = true;
                if (!hasWarned) {
                    warn(`Hydration children mismatch in <${container.tagName.toLowerCase()}>: server rendered element contains fewer child nodes than client vdom.`);
                    hasWarned = true;
                }
                patch(null, vnode, container, null, parentComponent, parentSuspense, isSVGContainer(container), slotScopeIds);
            }
        }
        return node;
    };
    const hydrateFragment = (node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized)=>{
        const { slotScopeIds: fragmentSlotScopeIds } = vnode;
        if (fragmentSlotScopeIds) slotScopeIds = slotScopeIds ? slotScopeIds.concat(fragmentSlotScopeIds) : fragmentSlotScopeIds;
        const container = parentNode(node);
        const next = hydrateChildren(nextSibling(node), vnode, container, parentComponent, parentSuspense, slotScopeIds, optimized);
        if (next && isComment(next) && next.data === "]") return nextSibling(vnode.anchor = next);
        else {
            hasMismatch = true;
            insert(vnode.anchor = createComment(`]`), container, next);
            return next;
        }
    };
    const handleMismatch = (node, vnode, parentComponent, parentSuspense, slotScopeIds, isFragment)=>{
        hasMismatch = true;
        warn(`Hydration node mismatch:
- Client vnode:`, vnode.type, `
- Server rendered DOM:`, node, node.nodeType === 3 /* TEXT */  ? `(text)` : isComment(node) && node.data === "[" ? `(start of fragment)` : ``);
        vnode.el = null;
        if (isFragment) {
            const end = locateClosingAnchor(node);
            while(true){
                const next2 = nextSibling(node);
                if (next2 && next2 !== end) remove(next2);
                else break;
            }
        }
        const next = nextSibling(node);
        const container = parentNode(node);
        remove(node);
        patch(null, vnode, container, next, parentComponent, parentSuspense, isSVGContainer(container), slotScopeIds);
        return next;
    };
    const locateClosingAnchor = (node, open = "[", close = "]")=>{
        let match = 0;
        while(node){
            node = nextSibling(node);
            if (node && isComment(node)) {
                if (node.data === open) match++;
                if (node.data === close) {
                    if (match === 0) return nextSibling(node);
                    else match--;
                }
            }
        }
        return node;
    };
    const replaceNode = (newNode, oldNode, parentComponent)=>{
        const parentNode2 = oldNode.parentNode;
        if (parentNode2) parentNode2.replaceChild(newNode, oldNode);
        let parent = parentComponent;
        while(parent){
            if (parent.vnode.el === oldNode) parent.vnode.el = parent.subTree.el = newNode;
            parent = parent.parent;
        }
    };
    const isTemplateNode = (node)=>{
        return node.nodeType === 1 /* ELEMENT */  && node.tagName.toLowerCase() === "template";
    };
    return [
        hydrate,
        hydrateNode
    ];
}
let supported;
let perf;
function startMeasure(instance, type) {
    if (instance.appContext.config.performance && isSupported()) perf.mark(`vue-${type}-${instance.uid}`);
    devtoolsPerfStart(instance, type, isSupported() ? perf.now() : Date.now());
}
function endMeasure(instance, type) {
    if (instance.appContext.config.performance && isSupported()) {
        const startTag = `vue-${type}-${instance.uid}`;
        const endTag = startTag + `:end`;
        perf.mark(endTag);
        perf.measure(`<${formatComponentName(instance, instance.type)}> ${type}`, startTag, endTag);
        perf.clearMarks(startTag);
        perf.clearMarks(endTag);
    }
    devtoolsPerfEnd(instance, type, isSupported() ? perf.now() : Date.now());
}
function isSupported() {
    if (supported !== void 0) return supported;
    if (typeof window !== "undefined" && window.performance) {
        supported = true;
        perf = window.performance;
    } else supported = false;
    return supported;
}
function initFeatureFlags() {
    const needWarn = [];
    if (typeof __VUE_OPTIONS_API__ !== "boolean") {
        needWarn.push(`__VUE_OPTIONS_API__`);
        (0, _shared.getGlobalThis)().__VUE_OPTIONS_API__ = true;
    }
    if (typeof __VUE_PROD_DEVTOOLS__ !== "boolean") {
        needWarn.push(`__VUE_PROD_DEVTOOLS__`);
        (0, _shared.getGlobalThis)().__VUE_PROD_DEVTOOLS__ = false;
    }
    if (0, needWarn.length) {
        const multi = needWarn.length > 1;
        console.warn(`Feature flag${multi ? `s` : ``} ${needWarn.join(", ")} ${multi ? `are` : `is`} not explicitly defined. You are running the esm-bundler build of Vue, which expects these compile-time feature flags to be globally injected via the bundler config in order to get better tree-shaking in the production bundle.

For more details, see https://link.vuejs.org/feature-flags.`);
    }
}
const queuePostRenderEffect = queueEffectWithSuspense;
function createRenderer(options) {
    return baseCreateRenderer(options);
}
function createHydrationRenderer(options) {
    return baseCreateRenderer(options, createHydrationFunctions);
}
function baseCreateRenderer(options, createHydrationFns) {
    initFeatureFlags();
    const target = (0, _shared.getGlobalThis)();
    target.__VUE__ = true;
    setDevtoolsHook(target.__VUE_DEVTOOLS_GLOBAL_HOOK__, target);
    const { insert: hostInsert, remove: hostRemove, patchProp: hostPatchProp, createElement: hostCreateElement, createText: hostCreateText, createComment: hostCreateComment, setText: hostSetText, setElementText: hostSetElementText, parentNode: hostParentNode, nextSibling: hostNextSibling, setScopeId: hostSetScopeId = (0, _shared.NOOP), insertStaticContent: hostInsertStaticContent } = options;
    const patch = (n1, n2, container, anchor = null, parentComponent = null, parentSuspense = null, isSVG = false, slotScopeIds = null, optimized = isHmrUpdating ? false : !!n2.dynamicChildren)=>{
        if (n1 === n2) return;
        if (n1 && !isSameVNodeType(n1, n2)) {
            anchor = getNextHostNode(n1);
            unmount(n1, parentComponent, parentSuspense, true);
            n1 = null;
        }
        if (n2.patchFlag === -2) {
            optimized = false;
            n2.dynamicChildren = null;
        }
        const { type, ref, shapeFlag } = n2;
        switch(type){
            case Text:
                processText(n1, n2, container, anchor);
                break;
            case Comment:
                processCommentNode(n1, n2, container, anchor);
                break;
            case Static:
                if (n1 == null) mountStaticNode(n2, container, anchor, isSVG);
                else patchStaticNode(n1, n2, container, isSVG);
                break;
            case Fragment:
                processFragment(n1, n2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
                break;
            default:
                if (shapeFlag & 1) processElement(n1, n2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
                else if (shapeFlag & 6) processComponent(n1, n2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
                else if (shapeFlag & 64) type.process(n1, n2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized, internals);
                else if (shapeFlag & 128) type.process(n1, n2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized, internals);
                else warn("Invalid VNode type:", type, `(${typeof type})`);
        }
        if (ref != null && parentComponent) setRef(ref, n1 && n1.ref, parentSuspense, n2 || n1, !n2);
    };
    const processText = (n1, n2, container, anchor)=>{
        if (n1 == null) hostInsert(n2.el = hostCreateText(n2.children), container, anchor);
        else {
            const el = n2.el = n1.el;
            if (n2.children !== n1.children) hostSetText(el, n2.children);
        }
    };
    const processCommentNode = (n1, n2, container, anchor)=>{
        if (n1 == null) hostInsert(n2.el = hostCreateComment(n2.children || ""), container, anchor);
        else n2.el = n1.el;
    };
    const mountStaticNode = (n2, container, anchor, isSVG)=>{
        [n2.el, n2.anchor] = hostInsertStaticContent(n2.children, container, anchor, isSVG, n2.el, n2.anchor);
    };
    const patchStaticNode = (n1, n2, container, isSVG)=>{
        if (n2.children !== n1.children) {
            const anchor = hostNextSibling(n1.anchor);
            removeStaticNode(n1);
            [n2.el, n2.anchor] = hostInsertStaticContent(n2.children, container, anchor, isSVG);
        } else {
            n2.el = n1.el;
            n2.anchor = n1.anchor;
        }
    };
    const moveStaticNode = ({ el, anchor }, container, nextSibling)=>{
        let next;
        while(el && el !== anchor){
            next = hostNextSibling(el);
            hostInsert(el, container, nextSibling);
            el = next;
        }
        hostInsert(anchor, container, nextSibling);
    };
    const removeStaticNode = ({ el, anchor })=>{
        let next;
        while(el && el !== anchor){
            next = hostNextSibling(el);
            hostRemove(el);
            el = next;
        }
        hostRemove(anchor);
    };
    const processElement = (n1, n2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized)=>{
        isSVG = isSVG || n2.type === "svg";
        if (n1 == null) mountElement(n2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
        else patchElement(n1, n2, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
    };
    const mountElement = (vnode, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized)=>{
        let el;
        let vnodeHook;
        const { type, props, shapeFlag, transition, dirs } = vnode;
        el = vnode.el = hostCreateElement(vnode.type, isSVG, props && props.is, props);
        if (shapeFlag & 8) hostSetElementText(el, vnode.children);
        else if (shapeFlag & 16) mountChildren(vnode.children, el, null, parentComponent, parentSuspense, isSVG && type !== "foreignObject", slotScopeIds, optimized);
        if (dirs) invokeDirectiveHook(vnode, null, parentComponent, "created");
        setScopeId(el, vnode, vnode.scopeId, slotScopeIds, parentComponent);
        if (props) {
            for(const key in props)if (key !== "value" && !(0, _shared.isReservedProp)(key)) hostPatchProp(el, key, null, props[key], isSVG, vnode.children, parentComponent, parentSuspense, unmountChildren);
            if ("value" in props) hostPatchProp(el, "value", null, props.value);
            if (vnodeHook = props.onVnodeBeforeMount) invokeVNodeHook(vnodeHook, parentComponent, vnode);
        }
        Object.defineProperty(el, "__vnode", {
            value: vnode,
            enumerable: false
        });
        Object.defineProperty(el, "__vueParentComponent", {
            value: parentComponent,
            enumerable: false
        });
        if (dirs) invokeDirectiveHook(vnode, null, parentComponent, "beforeMount");
        const needCallTransitionHooks = needTransition(parentSuspense, transition);
        if (needCallTransitionHooks) transition.beforeEnter(el);
        hostInsert(el, container, anchor);
        if ((vnodeHook = props && props.onVnodeMounted) || needCallTransitionHooks || dirs) queuePostRenderEffect(()=>{
            vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
            needCallTransitionHooks && transition.enter(el);
            dirs && invokeDirectiveHook(vnode, null, parentComponent, "mounted");
        }, parentSuspense);
    };
    const setScopeId = (el, vnode, scopeId, slotScopeIds, parentComponent)=>{
        if (scopeId) hostSetScopeId(el, scopeId);
        if (slotScopeIds) for(let i = 0; i < slotScopeIds.length; i++)hostSetScopeId(el, slotScopeIds[i]);
        if (parentComponent) {
            let subTree = parentComponent.subTree;
            if (subTree.patchFlag > 0 && subTree.patchFlag & 2048) subTree = filterSingleRoot(subTree.children) || subTree;
            if (vnode === subTree) {
                const parentVNode = parentComponent.vnode;
                setScopeId(el, parentVNode, parentVNode.scopeId, parentVNode.slotScopeIds, parentComponent.parent);
            }
        }
    };
    const mountChildren = (children, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized, start = 0)=>{
        for(let i = start; i < children.length; i++){
            const child = children[i] = optimized ? cloneIfMounted(children[i]) : normalizeVNode(children[i]);
            patch(null, child, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
        }
    };
    const patchElement = (n1, n2, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized)=>{
        const el = n2.el = n1.el;
        let { patchFlag, dynamicChildren, dirs } = n2;
        patchFlag |= n1.patchFlag & 16;
        const oldProps = n1.props || (0, _shared.EMPTY_OBJ);
        const newProps = n2.props || (0, _shared.EMPTY_OBJ);
        let vnodeHook;
        parentComponent && toggleRecurse(parentComponent, false);
        if (vnodeHook = newProps.onVnodeBeforeUpdate) invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
        if (dirs) invokeDirectiveHook(n2, n1, parentComponent, "beforeUpdate");
        parentComponent && toggleRecurse(parentComponent, true);
        if (isHmrUpdating) {
            patchFlag = 0;
            optimized = false;
            dynamicChildren = null;
        }
        const areChildrenSVG = isSVG && n2.type !== "foreignObject";
        if (dynamicChildren) {
            patchBlockChildren(n1.dynamicChildren, dynamicChildren, el, parentComponent, parentSuspense, areChildrenSVG, slotScopeIds);
            traverseStaticChildren(n1, n2);
        } else if (!optimized) patchChildren(n1, n2, el, null, parentComponent, parentSuspense, areChildrenSVG, slotScopeIds, false);
        if (patchFlag > 0) {
            if (patchFlag & 16) patchProps(el, n2, oldProps, newProps, parentComponent, parentSuspense, isSVG);
            else {
                if (patchFlag & 2) {
                    if (oldProps.class !== newProps.class) hostPatchProp(el, "class", null, newProps.class, isSVG);
                }
                if (patchFlag & 4) hostPatchProp(el, "style", oldProps.style, newProps.style, isSVG);
                if (patchFlag & 8) {
                    const propsToUpdate = n2.dynamicProps;
                    for(let i = 0; i < propsToUpdate.length; i++){
                        const key = propsToUpdate[i];
                        const prev = oldProps[key];
                        const next = newProps[key];
                        if (next !== prev || key === "value") hostPatchProp(el, key, prev, next, isSVG, n1.children, parentComponent, parentSuspense, unmountChildren);
                    }
                }
            }
            if (patchFlag & 1) {
                if (n1.children !== n2.children) hostSetElementText(el, n2.children);
            }
        } else if (!optimized && dynamicChildren == null) patchProps(el, n2, oldProps, newProps, parentComponent, parentSuspense, isSVG);
        if ((vnodeHook = newProps.onVnodeUpdated) || dirs) queuePostRenderEffect(()=>{
            vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
            dirs && invokeDirectiveHook(n2, n1, parentComponent, "updated");
        }, parentSuspense);
    };
    const patchBlockChildren = (oldChildren, newChildren, fallbackContainer, parentComponent, parentSuspense, isSVG, slotScopeIds)=>{
        for(let i = 0; i < newChildren.length; i++){
            const oldVNode = oldChildren[i];
            const newVNode = newChildren[i];
            const container = // oldVNode may be an errored async setup() component inside Suspense
            // which will not have a mounted element
            oldVNode.el && // - In the case of a Fragment, we need to provide the actual parent
            // of the Fragment itself so it can move its children.
            (oldVNode.type === Fragment || // - In the case of different nodes, there is going to be a replacement
            // which also requires the correct parent container
            !isSameVNodeType(oldVNode, newVNode) || // - In the case of a component, it could contain anything.
            oldVNode.shapeFlag & 70) ? hostParentNode(oldVNode.el) : // In other cases, the parent container is not actually used so we
            // just pass the block element here to avoid a DOM parentNode call.
            fallbackContainer;
            patch(oldVNode, newVNode, container, null, parentComponent, parentSuspense, isSVG, slotScopeIds, true);
        }
    };
    const patchProps = (el, vnode, oldProps, newProps, parentComponent, parentSuspense, isSVG)=>{
        if (oldProps !== newProps) {
            if (oldProps !== (0, _shared.EMPTY_OBJ)) {
                for(const key in oldProps)if (!(0, _shared.isReservedProp)(key) && !(key in newProps)) hostPatchProp(el, key, oldProps[key], null, isSVG, vnode.children, parentComponent, parentSuspense, unmountChildren);
            }
            for(const key in newProps){
                if ((0, _shared.isReservedProp)(key)) continue;
                const next = newProps[key];
                const prev = oldProps[key];
                if (next !== prev && key !== "value") hostPatchProp(el, key, prev, next, isSVG, vnode.children, parentComponent, parentSuspense, unmountChildren);
            }
            if ("value" in newProps) hostPatchProp(el, "value", oldProps.value, newProps.value);
        }
    };
    const processFragment = (n1, n2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized)=>{
        const fragmentStartAnchor = n2.el = n1 ? n1.el : hostCreateText("");
        const fragmentEndAnchor = n2.anchor = n1 ? n1.anchor : hostCreateText("");
        let { patchFlag, dynamicChildren, slotScopeIds: fragmentSlotScopeIds } = n2;
        if (// #5523 dev root fragment may inherit directives
        isHmrUpdating || patchFlag & 2048) {
            patchFlag = 0;
            optimized = false;
            dynamicChildren = null;
        }
        if (fragmentSlotScopeIds) slotScopeIds = slotScopeIds ? slotScopeIds.concat(fragmentSlotScopeIds) : fragmentSlotScopeIds;
        if (n1 == null) {
            hostInsert(fragmentStartAnchor, container, anchor);
            hostInsert(fragmentEndAnchor, container, anchor);
            mountChildren(n2.children, container, fragmentEndAnchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
        } else if (patchFlag > 0 && patchFlag & 64 && dynamicChildren && // #2715 the previous fragment could've been a BAILed one as a result
        // of renderSlot() with no valid children
        n1.dynamicChildren) {
            patchBlockChildren(n1.dynamicChildren, dynamicChildren, container, parentComponent, parentSuspense, isSVG, slotScopeIds);
            traverseStaticChildren(n1, n2);
        } else patchChildren(n1, n2, container, fragmentEndAnchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
    };
    const processComponent = (n1, n2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized)=>{
        n2.slotScopeIds = slotScopeIds;
        if (n1 == null) {
            if (n2.shapeFlag & 512) parentComponent.ctx.activate(n2, container, anchor, isSVG, optimized);
            else mountComponent(n2, container, anchor, parentComponent, parentSuspense, isSVG, optimized);
        } else updateComponent(n1, n2, optimized);
    };
    const mountComponent = (initialVNode, container, anchor, parentComponent, parentSuspense, isSVG, optimized)=>{
        const instance = initialVNode.component = createComponentInstance(initialVNode, parentComponent, parentSuspense);
        if (0, instance.type.__hmrId) registerHMR(instance);
        pushWarningContext(initialVNode);
        startMeasure(instance, `mount`);
        if (isKeepAlive(initialVNode)) instance.ctx.renderer = internals;
        startMeasure(instance, `init`);
        setupComponent(instance);
        endMeasure(instance, `init`);
        if (instance.asyncDep) {
            parentSuspense && parentSuspense.registerDep(instance, setupRenderEffect);
            if (!initialVNode.el) {
                const placeholder = instance.subTree = createVNode(Comment);
                processCommentNode(null, placeholder, container, anchor);
            }
            return;
        }
        setupRenderEffect(instance, initialVNode, container, anchor, parentSuspense, isSVG, optimized);
        popWarningContext();
        endMeasure(instance, `mount`);
    };
    const updateComponent = (n1, n2, optimized)=>{
        const instance = n2.component = n1.component;
        if (shouldUpdateComponent(n1, n2, optimized)) {
            if (instance.asyncDep && !instance.asyncResolved) {
                pushWarningContext(n2);
                updateComponentPreRender(instance, n2, optimized);
                popWarningContext();
                return;
            } else {
                instance.next = n2;
                invalidateJob(instance.update);
                instance.update();
            }
        } else {
            n2.el = n1.el;
            instance.vnode = n2;
        }
    };
    const setupRenderEffect = (instance, initialVNode, container, anchor, parentSuspense, isSVG, optimized)=>{
        const componentUpdateFn = ()=>{
            if (!instance.isMounted) {
                let vnodeHook;
                const { el, props } = initialVNode;
                const { bm, m, parent } = instance;
                const isAsyncWrapperVNode = isAsyncWrapper(initialVNode);
                toggleRecurse(instance, false);
                if (bm) (0, _shared.invokeArrayFns)(bm);
                if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeBeforeMount)) invokeVNodeHook(vnodeHook, parent, initialVNode);
                toggleRecurse(instance, true);
                if (el && hydrateNode) {
                    const hydrateSubTree = ()=>{
                        startMeasure(instance, `render`);
                        instance.subTree = renderComponentRoot(instance);
                        endMeasure(instance, `render`);
                        startMeasure(instance, `hydrate`);
                        hydrateNode(el, instance.subTree, instance, parentSuspense, null);
                        endMeasure(instance, `hydrate`);
                    };
                    if (isAsyncWrapperVNode) initialVNode.type.__asyncLoader().then(// note: we are moving the render call into an async callback,
                    // which means it won't track dependencies - but it's ok because
                    // a server-rendered async wrapper is already in resolved state
                    // and it will never need to change.
                    ()=>!instance.isUnmounted && hydrateSubTree());
                    else hydrateSubTree();
                } else {
                    startMeasure(instance, `render`);
                    const subTree = instance.subTree = renderComponentRoot(instance);
                    endMeasure(instance, `render`);
                    startMeasure(instance, `patch`);
                    patch(null, subTree, container, anchor, instance, parentSuspense, isSVG);
                    endMeasure(instance, `patch`);
                    initialVNode.el = subTree.el;
                }
                if (m) queuePostRenderEffect(m, parentSuspense);
                if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeMounted)) {
                    const scopedInitialVNode = initialVNode;
                    queuePostRenderEffect(()=>invokeVNodeHook(vnodeHook, parent, scopedInitialVNode), parentSuspense);
                }
                if (initialVNode.shapeFlag & 256 || parent && isAsyncWrapper(parent.vnode) && parent.vnode.shapeFlag & 256) instance.a && queuePostRenderEffect(instance.a, parentSuspense);
                instance.isMounted = true;
                devtoolsComponentAdded(instance);
                initialVNode = container = anchor = null;
            } else {
                let { next, bu, u, parent, vnode } = instance;
                let originNext = next;
                let vnodeHook;
                pushWarningContext(next || instance.vnode);
                toggleRecurse(instance, false);
                if (next) {
                    next.el = vnode.el;
                    updateComponentPreRender(instance, next, optimized);
                } else next = vnode;
                if (bu) (0, _shared.invokeArrayFns)(bu);
                if (vnodeHook = next.props && next.props.onVnodeBeforeUpdate) invokeVNodeHook(vnodeHook, parent, next, vnode);
                toggleRecurse(instance, true);
                startMeasure(instance, `render`);
                const nextTree = renderComponentRoot(instance);
                endMeasure(instance, `render`);
                const prevTree = instance.subTree;
                instance.subTree = nextTree;
                startMeasure(instance, `patch`);
                patch(prevTree, nextTree, // parent may have changed if it's in a teleport
                hostParentNode(prevTree.el), // anchor may have changed if it's in a fragment
                getNextHostNode(prevTree), instance, parentSuspense, isSVG);
                endMeasure(instance, `patch`);
                next.el = nextTree.el;
                if (originNext === null) updateHOCHostEl(instance, nextTree.el);
                if (u) queuePostRenderEffect(u, parentSuspense);
                if (vnodeHook = next.props && next.props.onVnodeUpdated) queuePostRenderEffect(()=>invokeVNodeHook(vnodeHook, parent, next, vnode), parentSuspense);
                devtoolsComponentUpdated(instance);
                popWarningContext();
            }
        };
        const effect = instance.effect = new (0, _reactivity.ReactiveEffect)(componentUpdateFn, ()=>queueJob(update), instance.scope);
        const update = instance.update = ()=>effect.run();
        update.id = instance.uid;
        toggleRecurse(instance, true);
        effect.onTrack = instance.rtc ? (e)=>(0, _shared.invokeArrayFns)(instance.rtc, e) : void 0;
        effect.onTrigger = instance.rtg ? (e)=>(0, _shared.invokeArrayFns)(instance.rtg, e) : void 0;
        update.ownerInstance = instance;
        update();
    };
    const updateComponentPreRender = (instance, nextVNode, optimized)=>{
        nextVNode.component = instance;
        const prevProps = instance.vnode.props;
        instance.vnode = nextVNode;
        instance.next = null;
        updateProps(instance, nextVNode.props, prevProps, optimized);
        updateSlots(instance, nextVNode.children, optimized);
        (0, _reactivity.pauseTracking)();
        flushPreFlushCbs(instance);
        (0, _reactivity.resetTracking)();
    };
    const patchChildren = (n1, n2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized = false)=>{
        const c1 = n1 && n1.children;
        const prevShapeFlag = n1 ? n1.shapeFlag : 0;
        const c2 = n2.children;
        const { patchFlag, shapeFlag } = n2;
        if (patchFlag > 0) {
            if (patchFlag & 128) {
                patchKeyedChildren(c1, c2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
                return;
            } else if (patchFlag & 256) {
                patchUnkeyedChildren(c1, c2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
                return;
            }
        }
        if (shapeFlag & 8) {
            if (prevShapeFlag & 16) unmountChildren(c1, parentComponent, parentSuspense);
            if (c2 !== c1) hostSetElementText(container, c2);
        } else if (prevShapeFlag & 16) {
            if (shapeFlag & 16) patchKeyedChildren(c1, c2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
            else unmountChildren(c1, parentComponent, parentSuspense, true);
        } else {
            if (prevShapeFlag & 8) hostSetElementText(container, "");
            if (shapeFlag & 16) mountChildren(c2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
        }
    };
    const patchUnkeyedChildren = (c1, c2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized)=>{
        c1 = c1 || (0, _shared.EMPTY_ARR);
        c2 = c2 || (0, _shared.EMPTY_ARR);
        const oldLength = c1.length;
        const newLength = c2.length;
        const commonLength = Math.min(oldLength, newLength);
        let i;
        for(i = 0; i < commonLength; i++){
            const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
            patch(c1[i], nextChild, container, null, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
        }
        if (oldLength > newLength) unmountChildren(c1, parentComponent, parentSuspense, true, false, commonLength);
        else mountChildren(c2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized, commonLength);
    };
    const patchKeyedChildren = (c1, c2, container, parentAnchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized)=>{
        let i = 0;
        const l2 = c2.length;
        let e1 = c1.length - 1;
        let e2 = l2 - 1;
        while(i <= e1 && i <= e2){
            const n1 = c1[i];
            const n2 = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
            if (isSameVNodeType(n1, n2)) patch(n1, n2, container, null, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
            else break;
            i++;
        }
        while(i <= e1 && i <= e2){
            const n1 = c1[e1];
            const n2 = c2[e2] = optimized ? cloneIfMounted(c2[e2]) : normalizeVNode(c2[e2]);
            if (isSameVNodeType(n1, n2)) patch(n1, n2, container, null, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
            else break;
            e1--;
            e2--;
        }
        if (i > e1) {
            if (i <= e2) {
                const nextPos = e2 + 1;
                const anchor = nextPos < l2 ? c2[nextPos].el : parentAnchor;
                while(i <= e2){
                    patch(null, c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]), container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
                    i++;
                }
            }
        } else if (i > e2) while(i <= e1){
            unmount(c1[i], parentComponent, parentSuspense, true);
            i++;
        }
        else {
            const s1 = i;
            const s2 = i;
            const keyToNewIndexMap = /* @__PURE__ */ new Map();
            for(i = s2; i <= e2; i++){
                const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
                if (nextChild.key != null) {
                    if (keyToNewIndexMap.has(nextChild.key)) warn(`Duplicate keys found during update:`, JSON.stringify(nextChild.key), `Make sure keys are unique.`);
                    keyToNewIndexMap.set(nextChild.key, i);
                }
            }
            let j;
            let patched = 0;
            const toBePatched = e2 - s2 + 1;
            let moved = false;
            let maxNewIndexSoFar = 0;
            const newIndexToOldIndexMap = new Array(toBePatched);
            for(i = 0; i < toBePatched; i++)newIndexToOldIndexMap[i] = 0;
            for(i = s1; i <= e1; i++){
                const prevChild = c1[i];
                if (patched >= toBePatched) {
                    unmount(prevChild, parentComponent, parentSuspense, true);
                    continue;
                }
                let newIndex;
                if (prevChild.key != null) newIndex = keyToNewIndexMap.get(prevChild.key);
                else {
                    for(j = s2; j <= e2; j++)if (newIndexToOldIndexMap[j - s2] === 0 && isSameVNodeType(prevChild, c2[j])) {
                        newIndex = j;
                        break;
                    }
                }
                if (newIndex === void 0) unmount(prevChild, parentComponent, parentSuspense, true);
                else {
                    newIndexToOldIndexMap[newIndex - s2] = i + 1;
                    if (newIndex >= maxNewIndexSoFar) maxNewIndexSoFar = newIndex;
                    else moved = true;
                    patch(prevChild, c2[newIndex], container, null, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
                    patched++;
                }
            }
            const increasingNewIndexSequence = moved ? getSequence(newIndexToOldIndexMap) : (0, _shared.EMPTY_ARR);
            j = increasingNewIndexSequence.length - 1;
            for(i = toBePatched - 1; i >= 0; i--){
                const nextIndex = s2 + i;
                const nextChild = c2[nextIndex];
                const anchor = nextIndex + 1 < l2 ? c2[nextIndex + 1].el : parentAnchor;
                if (newIndexToOldIndexMap[i] === 0) patch(null, nextChild, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
                else if (moved) {
                    if (j < 0 || i !== increasingNewIndexSequence[j]) move(nextChild, container, anchor, 2);
                    else j--;
                }
            }
        }
    };
    const move = (vnode, container, anchor, moveType, parentSuspense = null)=>{
        const { el, type, transition, children, shapeFlag } = vnode;
        if (shapeFlag & 6) {
            move(vnode.component.subTree, container, anchor, moveType);
            return;
        }
        if (shapeFlag & 128) {
            vnode.suspense.move(container, anchor, moveType);
            return;
        }
        if (shapeFlag & 64) {
            type.move(vnode, container, anchor, internals);
            return;
        }
        if (type === Fragment) {
            hostInsert(el, container, anchor);
            for(let i = 0; i < children.length; i++)move(children[i], container, anchor, moveType);
            hostInsert(vnode.anchor, container, anchor);
            return;
        }
        if (type === Static) {
            moveStaticNode(vnode, container, anchor);
            return;
        }
        const needTransition2 = moveType !== 2 && shapeFlag & 1 && transition;
        if (needTransition2) {
            if (moveType === 0) {
                transition.beforeEnter(el);
                hostInsert(el, container, anchor);
                queuePostRenderEffect(()=>transition.enter(el), parentSuspense);
            } else {
                const { leave, delayLeave, afterLeave } = transition;
                const remove2 = ()=>hostInsert(el, container, anchor);
                const performLeave = ()=>{
                    leave(el, ()=>{
                        remove2();
                        afterLeave && afterLeave();
                    });
                };
                if (delayLeave) delayLeave(el, remove2, performLeave);
                else performLeave();
            }
        } else hostInsert(el, container, anchor);
    };
    const unmount = (vnode, parentComponent, parentSuspense, doRemove = false, optimized = false)=>{
        const { type, props, ref, children, dynamicChildren, shapeFlag, patchFlag, dirs } = vnode;
        if (ref != null) setRef(ref, null, parentSuspense, vnode, true);
        if (shapeFlag & 256) {
            parentComponent.ctx.deactivate(vnode);
            return;
        }
        const shouldInvokeDirs = shapeFlag & 1 && dirs;
        const shouldInvokeVnodeHook = !isAsyncWrapper(vnode);
        let vnodeHook;
        if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeBeforeUnmount)) invokeVNodeHook(vnodeHook, parentComponent, vnode);
        if (shapeFlag & 6) unmountComponent(vnode.component, parentSuspense, doRemove);
        else {
            if (shapeFlag & 128) {
                vnode.suspense.unmount(parentSuspense, doRemove);
                return;
            }
            if (shouldInvokeDirs) invokeDirectiveHook(vnode, null, parentComponent, "beforeUnmount");
            if (shapeFlag & 64) vnode.type.remove(vnode, parentComponent, parentSuspense, optimized, internals, doRemove);
            else if (dynamicChildren && // #1153: fast path should not be taken for non-stable (v-for) fragments
            (type !== Fragment || patchFlag > 0 && patchFlag & 64)) unmountChildren(dynamicChildren, parentComponent, parentSuspense, false, true);
            else if (type === Fragment && patchFlag & 384 || !optimized && shapeFlag & 16) unmountChildren(children, parentComponent, parentSuspense);
            if (doRemove) remove(vnode);
        }
        if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeUnmounted) || shouldInvokeDirs) queuePostRenderEffect(()=>{
            vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
            shouldInvokeDirs && invokeDirectiveHook(vnode, null, parentComponent, "unmounted");
        }, parentSuspense);
    };
    const remove = (vnode)=>{
        const { type, el, anchor, transition } = vnode;
        if (type === Fragment) {
            if (vnode.patchFlag > 0 && vnode.patchFlag & 2048 && transition && !transition.persisted) vnode.children.forEach((child)=>{
                if (child.type === Comment) hostRemove(child.el);
                else remove(child);
            });
            else removeFragment(el, anchor);
            return;
        }
        if (type === Static) {
            removeStaticNode(vnode);
            return;
        }
        const performRemove = ()=>{
            hostRemove(el);
            if (transition && !transition.persisted && transition.afterLeave) transition.afterLeave();
        };
        if (vnode.shapeFlag & 1 && transition && !transition.persisted) {
            const { leave, delayLeave } = transition;
            const performLeave = ()=>leave(el, performRemove);
            if (delayLeave) delayLeave(vnode.el, performRemove, performLeave);
            else performLeave();
        } else performRemove();
    };
    const removeFragment = (cur, end)=>{
        let next;
        while(cur !== end){
            next = hostNextSibling(cur);
            hostRemove(cur);
            cur = next;
        }
        hostRemove(end);
    };
    const unmountComponent = (instance, parentSuspense, doRemove)=>{
        if (0, instance.type.__hmrId) unregisterHMR(instance);
        const { bum, scope, update, subTree, um } = instance;
        if (bum) (0, _shared.invokeArrayFns)(bum);
        scope.stop();
        if (update) {
            update.active = false;
            unmount(subTree, instance, parentSuspense, doRemove);
        }
        if (um) queuePostRenderEffect(um, parentSuspense);
        queuePostRenderEffect(()=>{
            instance.isUnmounted = true;
        }, parentSuspense);
        if (parentSuspense && parentSuspense.pendingBranch && !parentSuspense.isUnmounted && instance.asyncDep && !instance.asyncResolved && instance.suspenseId === parentSuspense.pendingId) {
            parentSuspense.deps--;
            if (parentSuspense.deps === 0) parentSuspense.resolve();
        }
        devtoolsComponentRemoved(instance);
    };
    const unmountChildren = (children, parentComponent, parentSuspense, doRemove = false, optimized = false, start = 0)=>{
        for(let i = start; i < children.length; i++)unmount(children[i], parentComponent, parentSuspense, doRemove, optimized);
    };
    const getNextHostNode = (vnode)=>{
        if (vnode.shapeFlag & 6) return getNextHostNode(vnode.component.subTree);
        if (vnode.shapeFlag & 128) return vnode.suspense.next();
        return hostNextSibling(vnode.anchor || vnode.el);
    };
    const render = (vnode, container, isSVG)=>{
        if (vnode == null) {
            if (container._vnode) unmount(container._vnode, null, null, true);
        } else patch(container._vnode || null, vnode, container, null, null, null, isSVG);
        flushPreFlushCbs();
        flushPostFlushCbs();
        container._vnode = vnode;
    };
    const internals = {
        p: patch,
        um: unmount,
        m: move,
        r: remove,
        mt: mountComponent,
        mc: mountChildren,
        pc: patchChildren,
        pbc: patchBlockChildren,
        n: getNextHostNode,
        o: options
    };
    let hydrate;
    let hydrateNode;
    if (createHydrationFns) [hydrate, hydrateNode] = createHydrationFns(internals);
    return {
        render,
        hydrate,
        createApp: createAppAPI(render, hydrate)
    };
}
function toggleRecurse({ effect, update }, allowed) {
    effect.allowRecurse = update.allowRecurse = allowed;
}
function needTransition(parentSuspense, transition) {
    return (!parentSuspense || parentSuspense && !parentSuspense.pendingBranch) && transition && !transition.persisted;
}
function traverseStaticChildren(n1, n2, shallow = false) {
    const ch1 = n1.children;
    const ch2 = n2.children;
    if ((0, _shared.isArray)(ch1) && (0, _shared.isArray)(ch2)) for(let i = 0; i < ch1.length; i++){
        const c1 = ch1[i];
        let c2 = ch2[i];
        if (c2.shapeFlag & 1 && !c2.dynamicChildren) {
            if (c2.patchFlag <= 0 || c2.patchFlag === 32) {
                c2 = ch2[i] = cloneIfMounted(ch2[i]);
                c2.el = c1.el;
            }
            if (!shallow) traverseStaticChildren(c1, c2);
        }
        if (c2.type === Text) c2.el = c1.el;
        if (c2.type === Comment && !c2.el) c2.el = c1.el;
    }
}
function getSequence(arr) {
    const p = arr.slice();
    const result = [
        0
    ];
    let i, j, u, v1, c;
    const len = arr.length;
    for(i = 0; i < len; i++){
        const arrI = arr[i];
        if (arrI !== 0) {
            j = result[result.length - 1];
            if (arr[j] < arrI) {
                p[i] = j;
                result.push(i);
                continue;
            }
            u = 0;
            v1 = result.length - 1;
            while(u < v1){
                c = u + v1 >> 1;
                if (arr[result[c]] < arrI) u = c + 1;
                else v1 = c;
            }
            if (arrI < arr[result[u]]) {
                if (u > 0) p[i] = result[u - 1];
                result[u] = i;
            }
        }
    }
    u = result.length;
    v1 = result[u - 1];
    while(u-- > 0){
        result[u] = v1;
        v1 = p[v1];
    }
    return result;
}
const isTeleport = (type)=>type.__isTeleport;
const isTeleportDisabled = (props)=>props && (props.disabled || props.disabled === "");
const isTargetSVG = (target)=>typeof SVGElement !== "undefined" && target instanceof SVGElement;
const resolveTarget = (props, select)=>{
    const targetSelector = props && props.to;
    if ((0, _shared.isString)(targetSelector)) {
        if (!select) {
            warn(`Current renderer does not support string target for Teleports. (missing querySelector renderer option)`);
            return null;
        } else {
            const target = select(targetSelector);
            if (!target) warn(`Failed to locate Teleport target with selector "${targetSelector}". Note the target element must exist before the component is mounted - i.e. the target cannot be rendered by the component itself, and ideally should be outside of the entire Vue component tree.`);
            return target;
        }
    } else {
        if (!targetSelector && !isTeleportDisabled(props)) warn(`Invalid Teleport target: ${targetSelector}`);
        return targetSelector;
    }
};
const TeleportImpl = {
    name: "Teleport",
    __isTeleport: true,
    process (n1, n2, container, anchor, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized, internals) {
        const { mc: mountChildren, pc: patchChildren, pbc: patchBlockChildren, o: { insert, querySelector, createText, createComment } } = internals;
        const disabled = isTeleportDisabled(n2.props);
        let { shapeFlag, children, dynamicChildren } = n2;
        if (isHmrUpdating) {
            optimized = false;
            dynamicChildren = null;
        }
        if (n1 == null) {
            const placeholder = n2.el = createComment("teleport start");
            const mainAnchor = n2.anchor = createComment("teleport end");
            insert(placeholder, container, anchor);
            insert(mainAnchor, container, anchor);
            const target = n2.target = resolveTarget(n2.props, querySelector);
            const targetAnchor = n2.targetAnchor = createText("");
            if (target) {
                insert(targetAnchor, target);
                isSVG = isSVG || isTargetSVG(target);
            } else if (!disabled) warn("Invalid Teleport target on mount:", target, `(${typeof target})`);
            const mount = (container2, anchor2)=>{
                if (shapeFlag & 16) mountChildren(children, container2, anchor2, parentComponent, parentSuspense, isSVG, slotScopeIds, optimized);
            };
            if (disabled) mount(container, mainAnchor);
            else if (target) mount(target, targetAnchor);
        } else {
            n2.el = n1.el;
            const mainAnchor = n2.anchor = n1.anchor;
            const target = n2.target = n1.target;
            const targetAnchor = n2.targetAnchor = n1.targetAnchor;
            const wasDisabled = isTeleportDisabled(n1.props);
            const currentContainer = wasDisabled ? container : target;
            const currentAnchor = wasDisabled ? mainAnchor : targetAnchor;
            isSVG = isSVG || isTargetSVG(target);
            if (dynamicChildren) {
                patchBlockChildren(n1.dynamicChildren, dynamicChildren, currentContainer, parentComponent, parentSuspense, isSVG, slotScopeIds);
                traverseStaticChildren(n1, n2, true);
            } else if (!optimized) patchChildren(n1, n2, currentContainer, currentAnchor, parentComponent, parentSuspense, isSVG, slotScopeIds, false);
            if (disabled) {
                if (!wasDisabled) moveTeleport(n2, container, mainAnchor, internals, 1);
                else if (n2.props && n1.props && n2.props.to !== n1.props.to) n2.props.to = n1.props.to;
            } else {
                if ((n2.props && n2.props.to) !== (n1.props && n1.props.to)) {
                    const nextTarget = n2.target = resolveTarget(n2.props, querySelector);
                    if (nextTarget) moveTeleport(n2, nextTarget, null, internals, 0);
                    else warn("Invalid Teleport target on update:", target, `(${typeof target})`);
                } else if (wasDisabled) moveTeleport(n2, target, targetAnchor, internals, 1);
            }
        }
        updateCssVars(n2);
    },
    remove (vnode, parentComponent, parentSuspense, optimized, { um: unmount, o: { remove: hostRemove } }, doRemove) {
        const { shapeFlag, children, anchor, targetAnchor, target, props } = vnode;
        if (target) hostRemove(targetAnchor);
        doRemove && hostRemove(anchor);
        if (shapeFlag & 16) {
            const shouldRemove = doRemove || !isTeleportDisabled(props);
            for(let i = 0; i < children.length; i++){
                const child = children[i];
                unmount(child, parentComponent, parentSuspense, shouldRemove, !!child.dynamicChildren);
            }
        }
    },
    move: moveTeleport,
    hydrate: hydrateTeleport
};
function moveTeleport(vnode, container, parentAnchor, { o: { insert }, m: move }, moveType = 2) {
    if (moveType === 0) insert(vnode.targetAnchor, container, parentAnchor);
    const { el, anchor, shapeFlag, children, props } = vnode;
    const isReorder = moveType === 2;
    if (isReorder) insert(el, container, parentAnchor);
    if (!isReorder || isTeleportDisabled(props)) {
        if (shapeFlag & 16) for(let i = 0; i < children.length; i++)move(children[i], container, parentAnchor, 2);
    }
    if (isReorder) insert(anchor, container, parentAnchor);
}
function hydrateTeleport(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized, { o: { nextSibling, parentNode, querySelector } }, hydrateChildren) {
    const target = vnode.target = resolveTarget(vnode.props, querySelector);
    if (target) {
        const targetNode = target._lpa || target.firstChild;
        if (vnode.shapeFlag & 16) {
            if (isTeleportDisabled(vnode.props)) {
                vnode.anchor = hydrateChildren(nextSibling(node), vnode, parentNode(node), parentComponent, parentSuspense, slotScopeIds, optimized);
                vnode.targetAnchor = targetNode;
            } else {
                vnode.anchor = nextSibling(node);
                let targetAnchor = targetNode;
                while(targetAnchor){
                    targetAnchor = nextSibling(targetAnchor);
                    if (targetAnchor && targetAnchor.nodeType === 8 && targetAnchor.data === "teleport anchor") {
                        vnode.targetAnchor = targetAnchor;
                        target._lpa = vnode.targetAnchor && nextSibling(vnode.targetAnchor);
                        break;
                    }
                }
                hydrateChildren(targetNode, vnode, target, parentComponent, parentSuspense, slotScopeIds, optimized);
            }
        }
        updateCssVars(vnode);
    }
    return vnode.anchor && nextSibling(vnode.anchor);
}
const Teleport = TeleportImpl;
function updateCssVars(vnode) {
    const ctx = vnode.ctx;
    if (ctx && ctx.ut) {
        let node = vnode.children[0].el;
        while(node && node !== vnode.targetAnchor){
            if (node.nodeType === 1) node.setAttribute("data-v-owner", ctx.uid);
            node = node.nextSibling;
        }
        ctx.ut();
    }
}
const Fragment = Symbol.for("v-fgt");
const Text = Symbol.for("v-txt");
const Comment = Symbol.for("v-cmt");
const Static = Symbol.for("v-stc");
const blockStack = [];
let currentBlock = null;
function openBlock(disableTracking = false) {
    blockStack.push(currentBlock = disableTracking ? null : []);
}
function closeBlock() {
    blockStack.pop();
    currentBlock = blockStack[blockStack.length - 1] || null;
}
let isBlockTreeEnabled = 1;
function setBlockTracking(value1) {
    isBlockTreeEnabled += value1;
}
function setupBlock(vnode) {
    vnode.dynamicChildren = isBlockTreeEnabled > 0 ? currentBlock || (0, _shared.EMPTY_ARR) : null;
    closeBlock();
    if (isBlockTreeEnabled > 0 && currentBlock) currentBlock.push(vnode);
    return vnode;
}
function createElementBlock(type, props, children, patchFlag, dynamicProps, shapeFlag) {
    return setupBlock(createBaseVNode(type, props, children, patchFlag, dynamicProps, shapeFlag, true));
}
function createBlock(type, props, children, patchFlag, dynamicProps) {
    return setupBlock(createVNode(type, props, children, patchFlag, dynamicProps, true));
}
function isVNode(value1) {
    return value1 ? value1.__v_isVNode === true : false;
}
function isSameVNodeType(n1, n2) {
    if (n2.shapeFlag & 6 && hmrDirtyComponents.has(n2.type)) {
        n1.shapeFlag &= -257;
        n2.shapeFlag &= -513;
        return false;
    }
    return n1.type === n2.type && n1.key === n2.key;
}
let vnodeArgsTransformer;
function transformVNodeArgs(transformer) {
    vnodeArgsTransformer = transformer;
}
const createVNodeWithArgsTransform = (...args)=>{
    return _createVNode(...vnodeArgsTransformer ? vnodeArgsTransformer(args, currentRenderingInstance) : args);
};
const InternalObjectKey = `__vInternal`;
const normalizeKey = ({ key })=>key != null ? key : null;
const normalizeRef = ({ ref, ref_key, ref_for })=>{
    if (typeof ref === "number") ref = "" + ref;
    return ref != null ? (0, _shared.isString)(ref) || (0, _reactivity.isRef)(ref) || (0, _shared.isFunction)(ref) ? {
        i: currentRenderingInstance,
        r: ref,
        k: ref_key,
        f: !!ref_for
    } : ref : null;
};
function createBaseVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, shapeFlag = type === Fragment ? 0 : 1, isBlockNode = false, needFullChildrenNormalization = false) {
    const vnode = {
        __v_isVNode: true,
        __v_skip: true,
        type,
        props,
        key: props && normalizeKey(props),
        ref: props && normalizeRef(props),
        scopeId: currentScopeId,
        slotScopeIds: null,
        children,
        component: null,
        suspense: null,
        ssContent: null,
        ssFallback: null,
        dirs: null,
        transition: null,
        el: null,
        anchor: null,
        target: null,
        targetAnchor: null,
        staticCount: 0,
        shapeFlag,
        patchFlag,
        dynamicProps,
        dynamicChildren: null,
        appContext: null,
        ctx: currentRenderingInstance
    };
    if (needFullChildrenNormalization) {
        normalizeChildren(vnode, children);
        if (shapeFlag & 128) type.normalize(vnode);
    } else if (children) vnode.shapeFlag |= (0, _shared.isString)(children) ? 8 : 16;
    if (vnode.key !== vnode.key) warn(`VNode created with invalid key (NaN). VNode type:`, vnode.type);
    if (isBlockTreeEnabled > 0 && // avoid a block node from tracking itself
    !isBlockNode && // has current parent block
    currentBlock && // presence of a patch flag indicates this node needs patching on updates.
    // component nodes also should always be patched, because even if the
    // component doesn't need to update, it needs to persist the instance on to
    // the next vnode so that it can be properly unmounted later.
    (vnode.patchFlag > 0 || shapeFlag & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
    // vnode should not be considered dynamic due to handler caching.
    vnode.patchFlag !== 32) currentBlock.push(vnode);
    return vnode;
}
const createVNode = createVNodeWithArgsTransform;
function _createVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, isBlockNode = false) {
    if (!type || type === NULL_DYNAMIC_COMPONENT) {
        if (!type) warn(`Invalid vnode type when creating vnode: ${type}.`);
        type = Comment;
    }
    if (isVNode(type)) {
        const cloned = cloneVNode(type, props, true);
        if (children) normalizeChildren(cloned, children);
        if (isBlockTreeEnabled > 0 && !isBlockNode && currentBlock) {
            if (cloned.shapeFlag & 6) currentBlock[currentBlock.indexOf(type)] = cloned;
            else currentBlock.push(cloned);
        }
        cloned.patchFlag |= -2;
        return cloned;
    }
    if (isClassComponent(type)) type = type.__vccOpts;
    if (props) {
        props = guardReactiveProps(props);
        let { class: klass, style } = props;
        if (klass && !(0, _shared.isString)(klass)) props.class = (0, _shared.normalizeClass)(klass);
        if ((0, _shared.isObject)(style)) {
            if ((0, _reactivity.isProxy)(style) && !(0, _shared.isArray)(style)) style = (0, _shared.extend)({}, style);
            props.style = (0, _shared.normalizeStyle)(style);
        }
    }
    const shapeFlag = (0, _shared.isString)(type) ? 1 : isSuspense(type) ? 128 : isTeleport(type) ? 64 : (0, _shared.isObject)(type) ? 4 : (0, _shared.isFunction)(type) ? 2 : 0;
    if (shapeFlag & 4 && (0, _reactivity.isProxy)(type)) {
        type = (0, _reactivity.toRaw)(type);
        warn(`Vue received a Component that was made a reactive object. This can lead to unnecessary performance overhead and should be avoided by marking the component with \`markRaw\` or using \`shallowRef\` instead of \`ref\`.`, `
Component that was made reactive: `, type);
    }
    return createBaseVNode(type, props, children, patchFlag, dynamicProps, shapeFlag, isBlockNode, true);
}
function guardReactiveProps(props) {
    if (!props) return null;
    return (0, _reactivity.isProxy)(props) || InternalObjectKey in props ? (0, _shared.extend)({}, props) : props;
}
function cloneVNode(vnode, extraProps, mergeRef = false) {
    const { props, ref, patchFlag, children } = vnode;
    const mergedProps = extraProps ? mergeProps(props || {}, extraProps) : props;
    const cloned = {
        __v_isVNode: true,
        __v_skip: true,
        type: vnode.type,
        props: mergedProps,
        key: mergedProps && normalizeKey(mergedProps),
        ref: extraProps && extraProps.ref ? // #2078 in the case of <component :is="vnode" ref="extra"/>
        // if the vnode itself already has a ref, cloneVNode will need to merge
        // the refs so the single vnode can be set on multiple refs
        mergeRef && ref ? (0, _shared.isArray)(ref) ? ref.concat(normalizeRef(extraProps)) : [
            ref,
            normalizeRef(extraProps)
        ] : normalizeRef(extraProps) : ref,
        scopeId: vnode.scopeId,
        slotScopeIds: vnode.slotScopeIds,
        children: patchFlag === -1 && (0, _shared.isArray)(children) ? children.map(deepCloneVNode) : children,
        target: vnode.target,
        targetAnchor: vnode.targetAnchor,
        staticCount: vnode.staticCount,
        shapeFlag: vnode.shapeFlag,
        // if the vnode is cloned with extra props, we can no longer assume its
        // existing patch flag to be reliable and need to add the FULL_PROPS flag.
        // note: preserve flag for fragments since they use the flag for children
        // fast paths only.
        patchFlag: extraProps && vnode.type !== Fragment ? patchFlag === -1 ? 16 : patchFlag | 16 : patchFlag,
        dynamicProps: vnode.dynamicProps,
        dynamicChildren: vnode.dynamicChildren,
        appContext: vnode.appContext,
        dirs: vnode.dirs,
        transition: vnode.transition,
        // These should technically only be non-null on mounted VNodes. However,
        // they *should* be copied for kept-alive vnodes. So we just always copy
        // them since them being non-null during a mount doesn't affect the logic as
        // they will simply be overwritten.
        component: vnode.component,
        suspense: vnode.suspense,
        ssContent: vnode.ssContent && cloneVNode(vnode.ssContent),
        ssFallback: vnode.ssFallback && cloneVNode(vnode.ssFallback),
        el: vnode.el,
        anchor: vnode.anchor,
        ctx: vnode.ctx,
        ce: vnode.ce
    };
    return cloned;
}
function deepCloneVNode(vnode) {
    const cloned = cloneVNode(vnode);
    if ((0, _shared.isArray)(vnode.children)) cloned.children = vnode.children.map(deepCloneVNode);
    return cloned;
}
function createTextVNode(text = " ", flag = 0) {
    return createVNode(Text, null, text, flag);
}
function createStaticVNode(content, numberOfNodes) {
    const vnode = createVNode(Static, null, content);
    vnode.staticCount = numberOfNodes;
    return vnode;
}
function createCommentVNode(text = "", asBlock = false) {
    return asBlock ? (openBlock(), createBlock(Comment, null, text)) : createVNode(Comment, null, text);
}
function normalizeVNode(child) {
    if (child == null || typeof child === "boolean") return createVNode(Comment);
    else if ((0, _shared.isArray)(child)) return createVNode(Fragment, null, // #3666, avoid reference pollution when reusing vnode
    child.slice());
    else if (typeof child === "object") return cloneIfMounted(child);
    else return createVNode(Text, null, String(child));
}
function cloneIfMounted(child) {
    return child.el === null && child.patchFlag !== -1 || child.memo ? child : cloneVNode(child);
}
function normalizeChildren(vnode, children) {
    let type = 0;
    const { shapeFlag } = vnode;
    if (children == null) children = null;
    else if ((0, _shared.isArray)(children)) type = 16;
    else if (typeof children === "object") {
        if (shapeFlag & 65) {
            const slot = children.default;
            if (slot) {
                slot._c && (slot._d = false);
                normalizeChildren(vnode, slot());
                slot._c && (slot._d = true);
            }
            return;
        } else {
            type = 32;
            const slotFlag = children._;
            if (!slotFlag && !(InternalObjectKey in children)) children._ctx = currentRenderingInstance;
            else if (slotFlag === 3 && currentRenderingInstance) {
                if (currentRenderingInstance.slots._ === 1) children._ = 1;
                else {
                    children._ = 2;
                    vnode.patchFlag |= 1024;
                }
            }
        }
    } else if ((0, _shared.isFunction)(children)) {
        children = {
            default: children,
            _ctx: currentRenderingInstance
        };
        type = 32;
    } else {
        children = String(children);
        if (shapeFlag & 64) {
            type = 16;
            children = [
                createTextVNode(children)
            ];
        } else type = 8;
    }
    vnode.children = children;
    vnode.shapeFlag |= type;
}
function mergeProps(...args) {
    const ret = {};
    for(let i = 0; i < args.length; i++){
        const toMerge = args[i];
        for(const key in toMerge){
            if (key === "class") {
                if (ret.class !== toMerge.class) ret.class = (0, _shared.normalizeClass)([
                    ret.class,
                    toMerge.class
                ]);
            } else if (key === "style") ret.style = (0, _shared.normalizeStyle)([
                ret.style,
                toMerge.style
            ]);
            else if ((0, _shared.isOn)(key)) {
                const existing = ret[key];
                const incoming = toMerge[key];
                if (incoming && existing !== incoming && !((0, _shared.isArray)(existing) && existing.includes(incoming))) ret[key] = existing ? [].concat(existing, incoming) : incoming;
            } else if (key !== "") ret[key] = toMerge[key];
        }
    }
    return ret;
}
function invokeVNodeHook(hook, instance, vnode, prevVNode = null) {
    callWithAsyncErrorHandling(hook, instance, 7, [
        vnode,
        prevVNode
    ]);
}
const emptyAppContext = createAppContext();
let uid = 0;
function createComponentInstance(vnode, parent, suspense) {
    const type = vnode.type;
    const appContext = (parent ? parent.appContext : vnode.appContext) || emptyAppContext;
    const instance = {
        uid: uid++,
        vnode,
        type,
        parent,
        appContext,
        root: null,
        // to be immediately set
        next: null,
        subTree: null,
        // will be set synchronously right after creation
        effect: null,
        update: null,
        // will be set synchronously right after creation
        scope: new (0, _reactivity.EffectScope)(true),
        render: null,
        proxy: null,
        exposed: null,
        exposeProxy: null,
        withProxy: null,
        provides: parent ? parent.provides : Object.create(appContext.provides),
        accessCache: null,
        renderCache: [],
        // local resolved assets
        components: null,
        directives: null,
        // resolved props and emits options
        propsOptions: normalizePropsOptions(type, appContext),
        emitsOptions: normalizeEmitsOptions(type, appContext),
        // emit
        emit: null,
        // to be set immediately
        emitted: null,
        // props default value
        propsDefaults: (0, _shared.EMPTY_OBJ),
        // inheritAttrs
        inheritAttrs: type.inheritAttrs,
        // state
        ctx: (0, _shared.EMPTY_OBJ),
        data: (0, _shared.EMPTY_OBJ),
        props: (0, _shared.EMPTY_OBJ),
        attrs: (0, _shared.EMPTY_OBJ),
        slots: (0, _shared.EMPTY_OBJ),
        refs: (0, _shared.EMPTY_OBJ),
        setupState: (0, _shared.EMPTY_OBJ),
        setupContext: null,
        attrsProxy: null,
        slotsProxy: null,
        // suspense related
        suspense,
        suspenseId: suspense ? suspense.pendingId : 0,
        asyncDep: null,
        asyncResolved: false,
        // lifecycle hooks
        // not using enums here because it results in computed properties
        isMounted: false,
        isUnmounted: false,
        isDeactivated: false,
        bc: null,
        c: null,
        bm: null,
        m: null,
        bu: null,
        u: null,
        um: null,
        bum: null,
        da: null,
        a: null,
        rtg: null,
        rtc: null,
        ec: null,
        sp: null
    };
    instance.ctx = createDevRenderContext(instance);
    instance.root = parent ? parent.root : instance;
    instance.emit = emit.bind(null, instance);
    if (vnode.ce) vnode.ce(instance);
    return instance;
}
let currentInstance = null;
const getCurrentInstance = ()=>currentInstance || currentRenderingInstance;
let internalSetCurrentInstance;
let globalCurrentInstanceSetters;
let settersKey = "__VUE_INSTANCE_SETTERS__";
if (!(globalCurrentInstanceSetters = (0, _shared.getGlobalThis)()[settersKey])) globalCurrentInstanceSetters = (0, _shared.getGlobalThis)()[settersKey] = [];
globalCurrentInstanceSetters.push((i)=>currentInstance = i);
internalSetCurrentInstance = (instance)=>{
    if (globalCurrentInstanceSetters.length > 1) globalCurrentInstanceSetters.forEach((s)=>s(instance));
    else globalCurrentInstanceSetters[0](instance);
};
const setCurrentInstance = (instance)=>{
    internalSetCurrentInstance(instance);
    instance.scope.on();
};
const unsetCurrentInstance = ()=>{
    currentInstance && currentInstance.scope.off();
    internalSetCurrentInstance(null);
};
const isBuiltInTag = /* @__PURE__ */ (0, _shared.makeMap)("slot,component");
function validateComponentName(name, config) {
    const appIsNativeTag = config.isNativeTag || (0, _shared.NO);
    if (isBuiltInTag(name) || appIsNativeTag(name)) warn("Do not use built-in or reserved HTML elements as component id: " + name);
}
function isStatefulComponent(instance) {
    return instance.vnode.shapeFlag & 4;
}
let isInSSRComponentSetup = false;
function setupComponent(instance, isSSR = false) {
    isInSSRComponentSetup = isSSR;
    const { props, children } = instance.vnode;
    const isStateful = isStatefulComponent(instance);
    initProps(instance, props, isStateful, isSSR);
    initSlots(instance, children);
    const setupResult = isStateful ? setupStatefulComponent(instance, isSSR) : void 0;
    isInSSRComponentSetup = false;
    return setupResult;
}
function setupStatefulComponent(instance, isSSR) {
    var _a;
    const Component = instance.type;
    if (Component.name) validateComponentName(Component.name, instance.appContext.config);
    if (Component.components) {
        const names = Object.keys(Component.components);
        for(let i = 0; i < names.length; i++)validateComponentName(names[i], instance.appContext.config);
    }
    if (Component.directives) {
        const names = Object.keys(Component.directives);
        for(let i = 0; i < names.length; i++)validateDirectiveName(names[i]);
    }
    if (Component.compilerOptions && isRuntimeOnly()) warn(`"compilerOptions" is only supported when using a build of Vue that includes the runtime compiler. Since you are using a runtime-only build, the options should be passed via your build tool config instead.`);
    instance.accessCache = /* @__PURE__ */ Object.create(null);
    instance.proxy = (0, _reactivity.markRaw)(new Proxy(instance.ctx, PublicInstanceProxyHandlers));
    exposePropsOnRenderContext(instance);
    const { setup } = Component;
    if (setup) {
        const setupContext = instance.setupContext = setup.length > 1 ? createSetupContext(instance) : null;
        setCurrentInstance(instance);
        (0, _reactivity.pauseTracking)();
        const setupResult = callWithErrorHandling(setup, instance, 0, [
            (0, _reactivity.shallowReadonly)(instance.props),
            setupContext
        ]);
        (0, _reactivity.resetTracking)();
        unsetCurrentInstance();
        if ((0, _shared.isPromise)(setupResult)) {
            setupResult.then(unsetCurrentInstance, unsetCurrentInstance);
            if (isSSR) return setupResult.then((resolvedResult)=>{
                handleSetupResult(instance, resolvedResult, isSSR);
            }).catch((e)=>{
                handleError(e, instance, 0);
            });
            else {
                instance.asyncDep = setupResult;
                if (!instance.suspense) {
                    const name = (_a = Component.name) != null ? _a : "Anonymous";
                    warn(`Component <${name}>: setup function returned a promise, but no <Suspense> boundary was found in the parent component tree. A component with async setup() must be nested in a <Suspense> in order to be rendered.`);
                }
            }
        } else handleSetupResult(instance, setupResult, isSSR);
    } else finishComponentSetup(instance, isSSR);
}
function handleSetupResult(instance, setupResult, isSSR) {
    if ((0, _shared.isFunction)(setupResult)) {
        if (instance.type.__ssrInlineRender) instance.ssrRender = setupResult;
        else instance.render = setupResult;
    } else if ((0, _shared.isObject)(setupResult)) {
        if (isVNode(setupResult)) warn(`setup() should not return VNodes directly - return a render function instead.`);
        instance.devtoolsRawSetupState = setupResult;
        instance.setupState = (0, _reactivity.proxyRefs)(setupResult);
        exposeSetupStateOnRenderContext(instance);
    } else if (setupResult !== void 0) warn(`setup() should return an object. Received: ${setupResult === null ? "null" : typeof setupResult}`);
    finishComponentSetup(instance, isSSR);
}
let compile;
let installWithProxy;
function registerRuntimeCompiler(_compile) {
    compile = _compile;
    installWithProxy = (i)=>{
        if (i.render._rc) i.withProxy = new Proxy(i.ctx, RuntimeCompiledPublicInstanceProxyHandlers);
    };
}
const isRuntimeOnly = ()=>!compile;
function finishComponentSetup(instance, isSSR, skipOptions) {
    const Component = instance.type;
    if (!instance.render) {
        if (!isSSR && compile && !Component.render) {
            const template = Component.template || resolveMergedOptions(instance).template;
            if (template) {
                startMeasure(instance, `compile`);
                const { isCustomElement, compilerOptions } = instance.appContext.config;
                const { delimiters, compilerOptions: componentCompilerOptions } = Component;
                const finalCompilerOptions = (0, _shared.extend)((0, _shared.extend)({
                    isCustomElement,
                    delimiters
                }, compilerOptions), componentCompilerOptions);
                Component.render = compile(template, finalCompilerOptions);
                endMeasure(instance, `compile`);
            }
        }
        instance.render = Component.render || (0, _shared.NOOP);
        if (installWithProxy) installWithProxy(instance);
    }
    if (__VUE_OPTIONS_API__ && true) {
        setCurrentInstance(instance);
        (0, _reactivity.pauseTracking)();
        try {
            applyOptions(instance);
        } finally{
            (0, _reactivity.resetTracking)();
            unsetCurrentInstance();
        }
    }
    if (!Component.render && instance.render === (0, _shared.NOOP) && !isSSR) {
        if (!compile && Component.template) warn(`Component provided template option but runtime compilation is not supported in this build of Vue.` + ` Configure your bundler to alias "vue" to "vue/dist/vue.esm-bundler.js".`);
        else warn(`Component is missing template or render function.`);
    }
}
function getAttrsProxy(instance) {
    return instance.attrsProxy || (instance.attrsProxy = new Proxy(instance.attrs, {
        get (target, key) {
            markAttrsAccessed();
            (0, _reactivity.track)(instance, "get", "$attrs");
            return target[key];
        },
        set () {
            warn(`setupContext.attrs is readonly.`);
            return false;
        },
        deleteProperty () {
            warn(`setupContext.attrs is readonly.`);
            return false;
        }
    }));
}
function getSlotsProxy(instance) {
    return instance.slotsProxy || (instance.slotsProxy = new Proxy(instance.slots, {
        get (target, key) {
            (0, _reactivity.track)(instance, "get", "$slots");
            return target[key];
        }
    }));
}
function createSetupContext(instance) {
    const expose = (exposed)=>{
        if (instance.exposed) warn(`expose() should be called only once per setup().`);
        if (exposed != null) {
            let exposedType = typeof exposed;
            if (exposedType === "object") {
                if ((0, _shared.isArray)(exposed)) exposedType = "array";
                else if ((0, _reactivity.isRef)(exposed)) exposedType = "ref";
            }
            if (exposedType !== "object") warn(`expose() should be passed a plain object, received ${exposedType}.`);
        }
        instance.exposed = exposed || {};
    };
    return Object.freeze({
        get attrs () {
            return getAttrsProxy(instance);
        },
        get slots () {
            return getSlotsProxy(instance);
        },
        get emit () {
            return (event, ...args)=>instance.emit(event, ...args);
        },
        expose
    });
}
function getExposeProxy(instance) {
    if (instance.exposed) return instance.exposeProxy || (instance.exposeProxy = new Proxy((0, _reactivity.proxyRefs)((0, _reactivity.markRaw)(instance.exposed)), {
        get (target, key) {
            if (key in target) return target[key];
            else if (key in publicPropertiesMap) return publicPropertiesMap[key](instance);
        },
        has (target, key) {
            return key in target || key in publicPropertiesMap;
        }
    }));
}
const classifyRE = /(?:^|[-_])(\w)/g;
const classify = (str)=>str.replace(classifyRE, (c)=>c.toUpperCase()).replace(/[-_]/g, "");
function getComponentName(Component, includeInferred = true) {
    return (0, _shared.isFunction)(Component) ? Component.displayName || Component.name : Component.name || includeInferred && Component.__name;
}
function formatComponentName(instance, Component, isRoot = false) {
    let name = getComponentName(Component);
    if (!name && Component.__file) {
        const match = Component.__file.match(/([^/\\]+)\.\w+$/);
        if (match) name = match[1];
    }
    if (!name && instance && instance.parent) {
        const inferFromRegistry = (registry)=>{
            for(const key in registry){
                if (registry[key] === Component) return key;
            }
        };
        name = inferFromRegistry(instance.components || instance.parent.type.components) || inferFromRegistry(instance.appContext.components);
    }
    return name ? classify(name) : isRoot ? `App` : `Anonymous`;
}
function isClassComponent(value1) {
    return (0, _shared.isFunction)(value1) && "__vccOpts" in value1;
}
const computed = (getterOrOptions, debugOptions)=>{
    return (0, _reactivity.computed)(getterOrOptions, debugOptions, isInSSRComponentSetup);
};
function h(type, propsOrChildren, children) {
    const l = arguments.length;
    if (l === 2) {
        if ((0, _shared.isObject)(propsOrChildren) && !(0, _shared.isArray)(propsOrChildren)) {
            if (isVNode(propsOrChildren)) return createVNode(type, null, [
                propsOrChildren
            ]);
            return createVNode(type, propsOrChildren);
        } else return createVNode(type, null, propsOrChildren);
    } else {
        if (l > 3) children = Array.prototype.slice.call(arguments, 2);
        else if (l === 3 && isVNode(children)) children = [
            children
        ];
        return createVNode(type, propsOrChildren, children);
    }
}
const ssrContextKey = Symbol.for("v-scx");
const useSSRContext = ()=>{
    {
        const ctx = inject(ssrContextKey);
        if (!ctx) warn(`Server rendering context not provided. Make sure to only call useSSRContext() conditionally in the server build.`);
        return ctx;
    }
};
function isShallow(value1) {
    return !!(value1 && value1["__v_isShallow"]);
}
function initCustomFormatter() {
    if (typeof window === "undefined") return;
    const vueStyle = {
        style: "color:#3ba776"
    };
    const numberStyle = {
        style: "color:#1677ff"
    };
    const stringStyle = {
        style: "color:#f5222d"
    };
    const keywordStyle = {
        style: "color:#eb2f96"
    };
    const formatter = {
        header (obj) {
            if (!(0, _shared.isObject)(obj)) return null;
            if (obj.__isVue) return [
                "div",
                vueStyle,
                `VueInstance`
            ];
            else if ((0, _reactivity.isRef)(obj)) return [
                "div",
                {},
                [
                    "span",
                    vueStyle,
                    genRefFlag(obj)
                ],
                "<",
                formatValue(obj.value),
                `>`
            ];
            else if ((0, _reactivity.isReactive)(obj)) return [
                "div",
                {},
                [
                    "span",
                    vueStyle,
                    isShallow(obj) ? "ShallowReactive" : "Reactive"
                ],
                "<",
                formatValue(obj),
                `>${(0, _reactivity.isReadonly)(obj) ? ` (readonly)` : ``}`
            ];
            else if ((0, _reactivity.isReadonly)(obj)) return [
                "div",
                {},
                [
                    "span",
                    vueStyle,
                    isShallow(obj) ? "ShallowReadonly" : "Readonly"
                ],
                "<",
                formatValue(obj),
                ">"
            ];
            return null;
        },
        hasBody (obj) {
            return obj && obj.__isVue;
        },
        body (obj) {
            if (obj && obj.__isVue) return [
                "div",
                {},
                ...formatInstance(obj.$)
            ];
        }
    };
    function formatInstance(instance) {
        const blocks = [];
        if (instance.type.props && instance.props) blocks.push(createInstanceBlock("props", (0, _reactivity.toRaw)(instance.props)));
        if (instance.setupState !== (0, _shared.EMPTY_OBJ)) blocks.push(createInstanceBlock("setup", instance.setupState));
        if (instance.data !== (0, _shared.EMPTY_OBJ)) blocks.push(createInstanceBlock("data", (0, _reactivity.toRaw)(instance.data)));
        const computed = extractKeys(instance, "computed");
        if (computed) blocks.push(createInstanceBlock("computed", computed));
        const injected = extractKeys(instance, "inject");
        if (injected) blocks.push(createInstanceBlock("injected", injected));
        blocks.push([
            "div",
            {},
            [
                "span",
                {
                    style: keywordStyle.style + ";opacity:0.66"
                },
                "$ (internal): "
            ],
            [
                "object",
                {
                    object: instance
                }
            ]
        ]);
        return blocks;
    }
    function createInstanceBlock(type, target) {
        target = (0, _shared.extend)({}, target);
        if (!Object.keys(target).length) return [
            "span",
            {}
        ];
        return [
            "div",
            {
                style: "line-height:1.25em;margin-bottom:0.6em"
            },
            [
                "div",
                {
                    style: "color:#476582"
                },
                type
            ],
            [
                "div",
                {
                    style: "padding-left:1.25em"
                },
                ...Object.keys(target).map((key)=>{
                    return [
                        "div",
                        {},
                        [
                            "span",
                            keywordStyle,
                            key + ": "
                        ],
                        formatValue(target[key], false)
                    ];
                })
            ]
        ];
    }
    function formatValue(v1, asRaw = true) {
        if (typeof v1 === "number") return [
            "span",
            numberStyle,
            v1
        ];
        else if (typeof v1 === "string") return [
            "span",
            stringStyle,
            JSON.stringify(v1)
        ];
        else if (typeof v1 === "boolean") return [
            "span",
            keywordStyle,
            v1
        ];
        else if ((0, _shared.isObject)(v1)) return [
            "object",
            {
                object: asRaw ? (0, _reactivity.toRaw)(v1) : v1
            }
        ];
        else return [
            "span",
            stringStyle,
            String(v1)
        ];
    }
    function extractKeys(instance, type) {
        const Comp = instance.type;
        if ((0, _shared.isFunction)(Comp)) return;
        const extracted = {};
        for(const key in instance.ctx)if (isKeyOfType(Comp, key, type)) extracted[key] = instance.ctx[key];
        return extracted;
    }
    function isKeyOfType(Comp, key, type) {
        const opts = Comp[type];
        if ((0, _shared.isArray)(opts) && opts.includes(key) || (0, _shared.isObject)(opts) && key in opts) return true;
        if (Comp.extends && isKeyOfType(Comp.extends, key, type)) return true;
        if (Comp.mixins && Comp.mixins.some((m)=>isKeyOfType(m, key, type))) return true;
    }
    function genRefFlag(v1) {
        if (isShallow(v1)) return `ShallowRef`;
        if (v1.effect) return `ComputedRef`;
        return `Ref`;
    }
    if (window.devtoolsFormatters) window.devtoolsFormatters.push(formatter);
    else window.devtoolsFormatters = [
        formatter
    ];
}
function withMemo(memo, render, cache, index) {
    const cached = cache[index];
    if (cached && isMemoSame(cached, memo)) return cached;
    const ret = render();
    ret.memo = memo.slice();
    return cache[index] = ret;
}
function isMemoSame(cached, memo) {
    const prev = cached.memo;
    if (prev.length != memo.length) return false;
    for(let i = 0; i < prev.length; i++){
        if ((0, _shared.hasChanged)(prev[i], memo[i])) return false;
    }
    if (isBlockTreeEnabled > 0 && currentBlock) currentBlock.push(cached);
    return true;
}
const version = "3.3.13";
const _ssrUtils = {
    createComponentInstance,
    setupComponent,
    renderComponentRoot,
    setCurrentRenderingInstance,
    isVNode: isVNode,
    normalizeVNode
};
const ssrUtils = _ssrUtils;
const resolveFilter = null;
const compatUtils = null;

},{"@vue/reactivity":"d7UXQ","@vue/shared":"3SM3y","@parcel/transformer-js/src/esmodule-helpers.js":"gkKU3"}],"d7UXQ":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "EffectScope", ()=>EffectScope);
parcelHelpers.export(exports, "ITERATE_KEY", ()=>ITERATE_KEY);
parcelHelpers.export(exports, "ReactiveEffect", ()=>ReactiveEffect);
parcelHelpers.export(exports, "computed", ()=>computed);
parcelHelpers.export(exports, "customRef", ()=>customRef);
parcelHelpers.export(exports, "deferredComputed", ()=>deferredComputed);
parcelHelpers.export(exports, "effect", ()=>effect);
parcelHelpers.export(exports, "effectScope", ()=>effectScope);
parcelHelpers.export(exports, "enableTracking", ()=>enableTracking);
parcelHelpers.export(exports, "getCurrentScope", ()=>getCurrentScope);
parcelHelpers.export(exports, "isProxy", ()=>isProxy);
parcelHelpers.export(exports, "isReactive", ()=>isReactive);
parcelHelpers.export(exports, "isReadonly", ()=>isReadonly);
parcelHelpers.export(exports, "isRef", ()=>isRef);
parcelHelpers.export(exports, "isShallow", ()=>isShallow);
parcelHelpers.export(exports, "markRaw", ()=>markRaw);
parcelHelpers.export(exports, "onScopeDispose", ()=>onScopeDispose);
parcelHelpers.export(exports, "pauseTracking", ()=>pauseTracking);
parcelHelpers.export(exports, "proxyRefs", ()=>proxyRefs);
parcelHelpers.export(exports, "reactive", ()=>reactive);
parcelHelpers.export(exports, "readonly", ()=>readonly);
parcelHelpers.export(exports, "ref", ()=>ref);
parcelHelpers.export(exports, "resetTracking", ()=>resetTracking);
parcelHelpers.export(exports, "shallowReactive", ()=>shallowReactive);
parcelHelpers.export(exports, "shallowReadonly", ()=>shallowReadonly);
parcelHelpers.export(exports, "shallowRef", ()=>shallowRef);
parcelHelpers.export(exports, "stop", ()=>stop);
parcelHelpers.export(exports, "toRaw", ()=>toRaw);
parcelHelpers.export(exports, "toRef", ()=>toRef);
parcelHelpers.export(exports, "toRefs", ()=>toRefs);
parcelHelpers.export(exports, "toValue", ()=>toValue);
parcelHelpers.export(exports, "track", ()=>track);
parcelHelpers.export(exports, "trigger", ()=>trigger);
parcelHelpers.export(exports, "triggerRef", ()=>triggerRef);
parcelHelpers.export(exports, "unref", ()=>unref);
var _shared = require("@vue/shared");
function warn(msg, ...args) {
    console.warn(`[Vue warn] ${msg}`, ...args);
}
let activeEffectScope;
class EffectScope {
    constructor(detached = false){
        this.detached = detached;
        /**
     * @internal
     */ this._active = true;
        /**
     * @internal
     */ this.effects = [];
        /**
     * @internal
     */ this.cleanups = [];
        this.parent = activeEffectScope;
        if (!detached && activeEffectScope) this.index = (activeEffectScope.scopes || (activeEffectScope.scopes = [])).push(this) - 1;
    }
    get active() {
        return this._active;
    }
    run(fn) {
        if (this._active) {
            const currentEffectScope = activeEffectScope;
            try {
                activeEffectScope = this;
                return fn();
            } finally{
                activeEffectScope = currentEffectScope;
            }
        } else warn(`cannot run an inactive effect scope.`);
    }
    /**
   * This should only be called on non-detached scopes
   * @internal
   */ on() {
        activeEffectScope = this;
    }
    /**
   * This should only be called on non-detached scopes
   * @internal
   */ off() {
        activeEffectScope = this.parent;
    }
    stop(fromParent) {
        if (this._active) {
            let i, l;
            for(i = 0, l = this.effects.length; i < l; i++)this.effects[i].stop();
            for(i = 0, l = this.cleanups.length; i < l; i++)this.cleanups[i]();
            if (this.scopes) for(i = 0, l = this.scopes.length; i < l; i++)this.scopes[i].stop(true);
            if (!this.detached && this.parent && !fromParent) {
                const last = this.parent.scopes.pop();
                if (last && last !== this) {
                    this.parent.scopes[this.index] = last;
                    last.index = this.index;
                }
            }
            this.parent = void 0;
            this._active = false;
        }
    }
}
function effectScope(detached) {
    return new EffectScope(detached);
}
function recordEffectScope(effect, scope = activeEffectScope) {
    if (scope && scope.active) scope.effects.push(effect);
}
function getCurrentScope() {
    return activeEffectScope;
}
function onScopeDispose(fn) {
    if (activeEffectScope) activeEffectScope.cleanups.push(fn);
    else warn(`onScopeDispose() is called when there is no active effect scope to be associated with.`);
}
const createDep = (effects)=>{
    const dep = new Set(effects);
    dep.w = 0;
    dep.n = 0;
    return dep;
};
const wasTracked = (dep)=>(dep.w & trackOpBit) > 0;
const newTracked = (dep)=>(dep.n & trackOpBit) > 0;
const initDepMarkers = ({ deps })=>{
    if (deps.length) for(let i = 0; i < deps.length; i++)deps[i].w |= trackOpBit;
};
const finalizeDepMarkers = (effect)=>{
    const { deps } = effect;
    if (deps.length) {
        let ptr = 0;
        for(let i = 0; i < deps.length; i++){
            const dep = deps[i];
            if (wasTracked(dep) && !newTracked(dep)) dep.delete(effect);
            else deps[ptr++] = dep;
            dep.w &= ~trackOpBit;
            dep.n &= ~trackOpBit;
        }
        deps.length = ptr;
    }
};
const targetMap = /* @__PURE__ */ new WeakMap();
let effectTrackDepth = 0;
let trackOpBit = 1;
const maxMarkerBits = 30;
let activeEffect;
const ITERATE_KEY = Symbol("iterate");
const MAP_KEY_ITERATE_KEY = Symbol("Map key iterate");
class ReactiveEffect {
    constructor(fn, scheduler = null, scope){
        this.fn = fn;
        this.scheduler = scheduler;
        this.active = true;
        this.deps = [];
        this.parent = void 0;
        recordEffectScope(this, scope);
    }
    run() {
        if (!this.active) return this.fn();
        let parent = activeEffect;
        let lastShouldTrack = shouldTrack;
        while(parent){
            if (parent === this) return;
            parent = parent.parent;
        }
        try {
            this.parent = activeEffect;
            activeEffect = this;
            shouldTrack = true;
            trackOpBit = 1 << ++effectTrackDepth;
            if (effectTrackDepth <= maxMarkerBits) initDepMarkers(this);
            else cleanupEffect(this);
            return this.fn();
        } finally{
            if (effectTrackDepth <= maxMarkerBits) finalizeDepMarkers(this);
            trackOpBit = 1 << --effectTrackDepth;
            activeEffect = this.parent;
            shouldTrack = lastShouldTrack;
            this.parent = void 0;
            if (this.deferStop) this.stop();
        }
    }
    stop() {
        if (activeEffect === this) this.deferStop = true;
        else if (this.active) {
            cleanupEffect(this);
            if (this.onStop) this.onStop();
            this.active = false;
        }
    }
}
function cleanupEffect(effect2) {
    const { deps } = effect2;
    if (deps.length) {
        for(let i = 0; i < deps.length; i++)deps[i].delete(effect2);
        deps.length = 0;
    }
}
function effect(fn, options) {
    if (fn.effect instanceof ReactiveEffect) fn = fn.effect.fn;
    const _effect = new ReactiveEffect(fn);
    if (options) {
        (0, _shared.extend)(_effect, options);
        if (options.scope) recordEffectScope(_effect, options.scope);
    }
    if (!options || !options.lazy) _effect.run();
    const runner = _effect.run.bind(_effect);
    runner.effect = _effect;
    return runner;
}
function stop(runner) {
    runner.effect.stop();
}
let shouldTrack = true;
const trackStack = [];
function pauseTracking() {
    trackStack.push(shouldTrack);
    shouldTrack = false;
}
function enableTracking() {
    trackStack.push(shouldTrack);
    shouldTrack = true;
}
function resetTracking() {
    const last = trackStack.pop();
    shouldTrack = last === void 0 ? true : last;
}
function track(target, type, key) {
    if (shouldTrack && activeEffect) {
        let depsMap = targetMap.get(target);
        if (!depsMap) targetMap.set(target, depsMap = /* @__PURE__ */ new Map());
        let dep = depsMap.get(key);
        if (!dep) depsMap.set(key, dep = createDep());
        const eventInfo = {
            effect: activeEffect,
            target,
            type,
            key
        };
        trackEffects(dep, eventInfo);
    }
}
function trackEffects(dep, debuggerEventExtraInfo) {
    let shouldTrack2 = false;
    if (effectTrackDepth <= maxMarkerBits) {
        if (!newTracked(dep)) {
            dep.n |= trackOpBit;
            shouldTrack2 = !wasTracked(dep);
        }
    } else shouldTrack2 = !dep.has(activeEffect);
    if (shouldTrack2) {
        dep.add(activeEffect);
        activeEffect.deps.push(dep);
        if (0, activeEffect.onTrack) activeEffect.onTrack((0, _shared.extend)({
            effect: activeEffect
        }, debuggerEventExtraInfo));
    }
}
function trigger(target, type, key, newValue, oldValue, oldTarget) {
    const depsMap = targetMap.get(target);
    if (!depsMap) return;
    let deps = [];
    if (type === "clear") deps = [
        ...depsMap.values()
    ];
    else if (key === "length" && (0, _shared.isArray)(target)) {
        const newLength = Number(newValue);
        depsMap.forEach((dep, key2)=>{
            if (key2 === "length" || !(0, _shared.isSymbol)(key2) && key2 >= newLength) deps.push(dep);
        });
    } else {
        if (key !== void 0) deps.push(depsMap.get(key));
        switch(type){
            case "add":
                if (!(0, _shared.isArray)(target)) {
                    deps.push(depsMap.get(ITERATE_KEY));
                    if ((0, _shared.isMap)(target)) deps.push(depsMap.get(MAP_KEY_ITERATE_KEY));
                } else if ((0, _shared.isIntegerKey)(key)) deps.push(depsMap.get("length"));
                break;
            case "delete":
                if (!(0, _shared.isArray)(target)) {
                    deps.push(depsMap.get(ITERATE_KEY));
                    if ((0, _shared.isMap)(target)) deps.push(depsMap.get(MAP_KEY_ITERATE_KEY));
                }
                break;
            case "set":
                if ((0, _shared.isMap)(target)) deps.push(depsMap.get(ITERATE_KEY));
                break;
        }
    }
    const eventInfo = {
        target,
        type,
        key,
        newValue,
        oldValue,
        oldTarget
    };
    if (deps.length === 1) {
        if (deps[0]) triggerEffects(deps[0], eventInfo);
    } else {
        const effects = [];
        for (const dep of deps)if (dep) effects.push(...dep);
        triggerEffects(createDep(effects), eventInfo);
    }
}
function triggerEffects(dep, debuggerEventExtraInfo) {
    const effects = (0, _shared.isArray)(dep) ? dep : [
        ...dep
    ];
    for (const effect2 of effects)if (effect2.computed) triggerEffect(effect2, debuggerEventExtraInfo);
    for (const effect2 of effects)if (!effect2.computed) triggerEffect(effect2, debuggerEventExtraInfo);
}
function triggerEffect(effect2, debuggerEventExtraInfo) {
    if (effect2 !== activeEffect || effect2.allowRecurse) {
        if (0, effect2.onTrigger) effect2.onTrigger((0, _shared.extend)({
            effect: effect2
        }, debuggerEventExtraInfo));
        if (effect2.scheduler) effect2.scheduler();
        else effect2.run();
    }
}
function getDepFromReactive(object, key) {
    var _a;
    return (_a = targetMap.get(object)) == null ? void 0 : _a.get(key);
}
const isNonTrackableKeys = /* @__PURE__ */ (0, _shared.makeMap)(`__proto__,__v_isRef,__isVue`);
const builtInSymbols = new Set(/* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((key)=>key !== "arguments" && key !== "caller").map((key)=>Symbol[key]).filter((0, _shared.isSymbol)));
const arrayInstrumentations = /* @__PURE__ */ createArrayInstrumentations();
function createArrayInstrumentations() {
    const instrumentations = {};
    [
        "includes",
        "indexOf",
        "lastIndexOf"
    ].forEach((key)=>{
        instrumentations[key] = function(...args) {
            const arr = toRaw(this);
            for(let i = 0, l = this.length; i < l; i++)track(arr, "get", i + "");
            const res = arr[key](...args);
            if (res === -1 || res === false) return arr[key](...args.map(toRaw));
            else return res;
        };
    });
    [
        "push",
        "pop",
        "shift",
        "unshift",
        "splice"
    ].forEach((key)=>{
        instrumentations[key] = function(...args) {
            pauseTracking();
            const res = toRaw(this)[key].apply(this, args);
            resetTracking();
            return res;
        };
    });
    return instrumentations;
}
function hasOwnProperty(key) {
    const obj = toRaw(this);
    track(obj, "has", key);
    return obj.hasOwnProperty(key);
}
class BaseReactiveHandler {
    constructor(_isReadonly = false, _shallow = false){
        this._isReadonly = _isReadonly;
        this._shallow = _shallow;
    }
    get(target, key, receiver) {
        const isReadonly2 = this._isReadonly, shallow = this._shallow;
        if (key === "__v_isReactive") return !isReadonly2;
        else if (key === "__v_isReadonly") return isReadonly2;
        else if (key === "__v_isShallow") return shallow;
        else if (key === "__v_raw") {
            if (receiver === (isReadonly2 ? shallow ? shallowReadonlyMap : readonlyMap : shallow ? shallowReactiveMap : reactiveMap).get(target) || // receiver is not the reactive proxy, but has the same prototype
            // this means the reciever is a user proxy of the reactive proxy
            Object.getPrototypeOf(target) === Object.getPrototypeOf(receiver)) return target;
            return;
        }
        const targetIsArray = (0, _shared.isArray)(target);
        if (!isReadonly2) {
            if (targetIsArray && (0, _shared.hasOwn)(arrayInstrumentations, key)) return Reflect.get(arrayInstrumentations, key, receiver);
            if (key === "hasOwnProperty") return hasOwnProperty;
        }
        const res = Reflect.get(target, key, receiver);
        if ((0, _shared.isSymbol)(key) ? builtInSymbols.has(key) : isNonTrackableKeys(key)) return res;
        if (!isReadonly2) track(target, "get", key);
        if (shallow) return res;
        if (isRef(res)) return targetIsArray && (0, _shared.isIntegerKey)(key) ? res : res.value;
        if ((0, _shared.isObject)(res)) return isReadonly2 ? readonly(res) : reactive(res);
        return res;
    }
}
class MutableReactiveHandler extends BaseReactiveHandler {
    constructor(shallow = false){
        super(false, shallow);
    }
    set(target, key, value, receiver) {
        let oldValue = target[key];
        if (!this._shallow) {
            const isOldValueReadonly = isReadonly(oldValue);
            if (!isShallow(value) && !isReadonly(value)) {
                oldValue = toRaw(oldValue);
                value = toRaw(value);
            }
            if (!(0, _shared.isArray)(target) && isRef(oldValue) && !isRef(value)) {
                if (isOldValueReadonly) return false;
                else {
                    oldValue.value = value;
                    return true;
                }
            }
        }
        const hadKey = (0, _shared.isArray)(target) && (0, _shared.isIntegerKey)(key) ? Number(key) < target.length : (0, _shared.hasOwn)(target, key);
        const result = Reflect.set(target, key, value, receiver);
        if (target === toRaw(receiver)) {
            if (!hadKey) trigger(target, "add", key, value);
            else if ((0, _shared.hasChanged)(value, oldValue)) trigger(target, "set", key, value, oldValue);
        }
        return result;
    }
    deleteProperty(target, key) {
        const hadKey = (0, _shared.hasOwn)(target, key);
        const oldValue = target[key];
        const result = Reflect.deleteProperty(target, key);
        if (result && hadKey) trigger(target, "delete", key, void 0, oldValue);
        return result;
    }
    has(target, key) {
        const result = Reflect.has(target, key);
        if (!(0, _shared.isSymbol)(key) || !builtInSymbols.has(key)) track(target, "has", key);
        return result;
    }
    ownKeys(target) {
        track(target, "iterate", (0, _shared.isArray)(target) ? "length" : ITERATE_KEY);
        return Reflect.ownKeys(target);
    }
}
class ReadonlyReactiveHandler extends BaseReactiveHandler {
    constructor(shallow = false){
        super(true, shallow);
    }
    set(target, key) {
        warn(`Set operation on key "${String(key)}" failed: target is readonly.`, target);
        return true;
    }
    deleteProperty(target, key) {
        warn(`Delete operation on key "${String(key)}" failed: target is readonly.`, target);
        return true;
    }
}
const mutableHandlers = /* @__PURE__ */ new MutableReactiveHandler();
const readonlyHandlers = /* @__PURE__ */ new ReadonlyReactiveHandler();
const shallowReactiveHandlers = /* @__PURE__ */ new MutableReactiveHandler(true);
const shallowReadonlyHandlers = /* @__PURE__ */ new ReadonlyReactiveHandler(true);
const toShallow = (value)=>value;
const getProto = (v)=>Reflect.getPrototypeOf(v);
function get(target, key, isReadonly = false, isShallow = false) {
    target = target["__v_raw"];
    const rawTarget = toRaw(target);
    const rawKey = toRaw(key);
    if (!isReadonly) {
        if ((0, _shared.hasChanged)(key, rawKey)) track(rawTarget, "get", key);
        track(rawTarget, "get", rawKey);
    }
    const { has: has2 } = getProto(rawTarget);
    const wrap = isShallow ? toShallow : isReadonly ? toReadonly : toReactive;
    if (has2.call(rawTarget, key)) return wrap(target.get(key));
    else if (has2.call(rawTarget, rawKey)) return wrap(target.get(rawKey));
    else if (target !== rawTarget) target.get(key);
}
function has(key, isReadonly = false) {
    const target = this["__v_raw"];
    const rawTarget = toRaw(target);
    const rawKey = toRaw(key);
    if (!isReadonly) {
        if ((0, _shared.hasChanged)(key, rawKey)) track(rawTarget, "has", key);
        track(rawTarget, "has", rawKey);
    }
    return key === rawKey ? target.has(key) : target.has(key) || target.has(rawKey);
}
function size(target, isReadonly = false) {
    target = target["__v_raw"];
    !isReadonly && track(toRaw(target), "iterate", ITERATE_KEY);
    return Reflect.get(target, "size", target);
}
function add(value) {
    value = toRaw(value);
    const target = toRaw(this);
    const proto = getProto(target);
    const hadKey = proto.has.call(target, value);
    if (!hadKey) {
        target.add(value);
        trigger(target, "add", value, value);
    }
    return this;
}
function set(key, value) {
    value = toRaw(value);
    const target = toRaw(this);
    const { has: has2, get: get2 } = getProto(target);
    let hadKey = has2.call(target, key);
    if (!hadKey) {
        key = toRaw(key);
        hadKey = has2.call(target, key);
    } else checkIdentityKeys(target, has2, key);
    const oldValue = get2.call(target, key);
    target.set(key, value);
    if (!hadKey) trigger(target, "add", key, value);
    else if ((0, _shared.hasChanged)(value, oldValue)) trigger(target, "set", key, value, oldValue);
    return this;
}
function deleteEntry(key) {
    const target = toRaw(this);
    const { has: has2, get: get2 } = getProto(target);
    let hadKey = has2.call(target, key);
    if (!hadKey) {
        key = toRaw(key);
        hadKey = has2.call(target, key);
    } else checkIdentityKeys(target, has2, key);
    const oldValue = get2 ? get2.call(target, key) : void 0;
    const result = target.delete(key);
    if (hadKey) trigger(target, "delete", key, void 0, oldValue);
    return result;
}
function clear() {
    const target = toRaw(this);
    const hadItems = target.size !== 0;
    const oldTarget = (0, _shared.isMap)(target) ? new Map(target) : new Set(target);
    const result = target.clear();
    if (hadItems) trigger(target, "clear", void 0, void 0, oldTarget);
    return result;
}
function createForEach(isReadonly, isShallow) {
    return function forEach(callback, thisArg) {
        const observed = this;
        const target = observed["__v_raw"];
        const rawTarget = toRaw(target);
        const wrap = isShallow ? toShallow : isReadonly ? toReadonly : toReactive;
        !isReadonly && track(rawTarget, "iterate", ITERATE_KEY);
        return target.forEach((value, key)=>{
            return callback.call(thisArg, wrap(value), wrap(key), observed);
        });
    };
}
function createIterableMethod(method, isReadonly, isShallow) {
    return function(...args) {
        const target = this["__v_raw"];
        const rawTarget = toRaw(target);
        const targetIsMap = (0, _shared.isMap)(rawTarget);
        const isPair = method === "entries" || method === Symbol.iterator && targetIsMap;
        const isKeyOnly = method === "keys" && targetIsMap;
        const innerIterator = target[method](...args);
        const wrap = isShallow ? toShallow : isReadonly ? toReadonly : toReactive;
        !isReadonly && track(rawTarget, "iterate", isKeyOnly ? MAP_KEY_ITERATE_KEY : ITERATE_KEY);
        return {
            // iterator protocol
            next () {
                const { value, done } = innerIterator.next();
                return done ? {
                    value,
                    done
                } : {
                    value: isPair ? [
                        wrap(value[0]),
                        wrap(value[1])
                    ] : wrap(value),
                    done
                };
            },
            // iterable protocol
            [Symbol.iterator] () {
                return this;
            }
        };
    };
}
function createReadonlyMethod(type) {
    return function(...args) {
        {
            const key = args[0] ? `on key "${args[0]}" ` : ``;
            console.warn(`${(0, _shared.capitalize)(type)} operation ${key}failed: target is readonly.`, toRaw(this));
        }
        return type === "delete" ? false : type === "clear" ? void 0 : this;
    };
}
function createInstrumentations() {
    const mutableInstrumentations2 = {
        get (key) {
            return get(this, key);
        },
        get size () {
            return size(this);
        },
        has,
        add,
        set,
        delete: deleteEntry,
        clear,
        forEach: createForEach(false, false)
    };
    const shallowInstrumentations2 = {
        get (key) {
            return get(this, key, false, true);
        },
        get size () {
            return size(this);
        },
        has,
        add,
        set,
        delete: deleteEntry,
        clear,
        forEach: createForEach(false, true)
    };
    const readonlyInstrumentations2 = {
        get (key) {
            return get(this, key, true);
        },
        get size () {
            return size(this, true);
        },
        has (key) {
            return has.call(this, key, true);
        },
        add: createReadonlyMethod("add"),
        set: createReadonlyMethod("set"),
        delete: createReadonlyMethod("delete"),
        clear: createReadonlyMethod("clear"),
        forEach: createForEach(true, false)
    };
    const shallowReadonlyInstrumentations2 = {
        get (key) {
            return get(this, key, true, true);
        },
        get size () {
            return size(this, true);
        },
        has (key) {
            return has.call(this, key, true);
        },
        add: createReadonlyMethod("add"),
        set: createReadonlyMethod("set"),
        delete: createReadonlyMethod("delete"),
        clear: createReadonlyMethod("clear"),
        forEach: createForEach(true, true)
    };
    const iteratorMethods = [
        "keys",
        "values",
        "entries",
        Symbol.iterator
    ];
    iteratorMethods.forEach((method)=>{
        mutableInstrumentations2[method] = createIterableMethod(method, false, false);
        readonlyInstrumentations2[method] = createIterableMethod(method, true, false);
        shallowInstrumentations2[method] = createIterableMethod(method, false, true);
        shallowReadonlyInstrumentations2[method] = createIterableMethod(method, true, true);
    });
    return [
        mutableInstrumentations2,
        readonlyInstrumentations2,
        shallowInstrumentations2,
        shallowReadonlyInstrumentations2
    ];
}
const [mutableInstrumentations, readonlyInstrumentations, shallowInstrumentations, shallowReadonlyInstrumentations] = /* @__PURE__ */ createInstrumentations();
function createInstrumentationGetter(isReadonly, shallow) {
    const instrumentations = shallow ? isReadonly ? shallowReadonlyInstrumentations : shallowInstrumentations : isReadonly ? readonlyInstrumentations : mutableInstrumentations;
    return (target, key, receiver)=>{
        if (key === "__v_isReactive") return !isReadonly;
        else if (key === "__v_isReadonly") return isReadonly;
        else if (key === "__v_raw") return target;
        return Reflect.get((0, _shared.hasOwn)(instrumentations, key) && key in target ? instrumentations : target, key, receiver);
    };
}
const mutableCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(false, false)
};
const shallowCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(false, true)
};
const readonlyCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(true, false)
};
const shallowReadonlyCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(true, true)
};
function checkIdentityKeys(target, has2, key) {
    const rawKey = toRaw(key);
    if (rawKey !== key && has2.call(target, rawKey)) {
        const type = (0, _shared.toRawType)(target);
        console.warn(`Reactive ${type} contains both the raw and reactive versions of the same object${type === `Map` ? ` as keys` : ``}, which can lead to inconsistencies. Avoid differentiating between the raw and reactive versions of an object and only use the reactive version if possible.`);
    }
}
const reactiveMap = /* @__PURE__ */ new WeakMap();
const shallowReactiveMap = /* @__PURE__ */ new WeakMap();
const readonlyMap = /* @__PURE__ */ new WeakMap();
const shallowReadonlyMap = /* @__PURE__ */ new WeakMap();
function targetTypeMap(rawType) {
    switch(rawType){
        case "Object":
        case "Array":
            return 1 /* COMMON */ ;
        case "Map":
        case "Set":
        case "WeakMap":
        case "WeakSet":
            return 2 /* COLLECTION */ ;
        default:
            return 0 /* INVALID */ ;
    }
}
function getTargetType(value) {
    return value["__v_skip"] || !Object.isExtensible(value) ? 0 /* INVALID */  : targetTypeMap((0, _shared.toRawType)(value));
}
function reactive(target) {
    if (isReadonly(target)) return target;
    return createReactiveObject(target, false, mutableHandlers, mutableCollectionHandlers, reactiveMap);
}
function shallowReactive(target) {
    return createReactiveObject(target, false, shallowReactiveHandlers, shallowCollectionHandlers, shallowReactiveMap);
}
function readonly(target) {
    return createReactiveObject(target, true, readonlyHandlers, readonlyCollectionHandlers, readonlyMap);
}
function shallowReadonly(target) {
    return createReactiveObject(target, true, shallowReadonlyHandlers, shallowReadonlyCollectionHandlers, shallowReadonlyMap);
}
function createReactiveObject(target, isReadonly2, baseHandlers, collectionHandlers, proxyMap) {
    if (!(0, _shared.isObject)(target)) {
        console.warn(`value cannot be made reactive: ${String(target)}`);
        return target;
    }
    if (target["__v_raw"] && !(isReadonly2 && target["__v_isReactive"])) return target;
    const existingProxy = proxyMap.get(target);
    if (existingProxy) return existingProxy;
    const targetType = getTargetType(target);
    if (targetType === 0 /* INVALID */ ) return target;
    const proxy = new Proxy(target, targetType === 2 /* COLLECTION */  ? collectionHandlers : baseHandlers);
    proxyMap.set(target, proxy);
    return proxy;
}
function isReactive(value) {
    if (isReadonly(value)) return isReactive(value["__v_raw"]);
    return !!(value && value["__v_isReactive"]);
}
function isReadonly(value) {
    return !!(value && value["__v_isReadonly"]);
}
function isShallow(value) {
    return !!(value && value["__v_isShallow"]);
}
function isProxy(value) {
    return isReactive(value) || isReadonly(value);
}
function toRaw(observed) {
    const raw = observed && observed["__v_raw"];
    return raw ? toRaw(raw) : observed;
}
function markRaw(value) {
    (0, _shared.def)(value, "__v_skip", true);
    return value;
}
const toReactive = (value)=>(0, _shared.isObject)(value) ? reactive(value) : value;
const toReadonly = (value)=>(0, _shared.isObject)(value) ? readonly(value) : value;
function trackRefValue(ref2) {
    if (shouldTrack && activeEffect) {
        ref2 = toRaw(ref2);
        trackEffects(ref2.dep || (ref2.dep = createDep()), {
            target: ref2,
            type: "get",
            key: "value"
        });
    }
}
function triggerRefValue(ref2, newVal) {
    ref2 = toRaw(ref2);
    const dep = ref2.dep;
    if (dep) triggerEffects(dep, {
        target: ref2,
        type: "set",
        key: "value",
        newValue: newVal
    });
}
function isRef(r) {
    return !!(r && r.__v_isRef === true);
}
function ref(value) {
    return createRef(value, false);
}
function shallowRef(value) {
    return createRef(value, true);
}
function createRef(rawValue, shallow) {
    if (isRef(rawValue)) return rawValue;
    return new RefImpl(rawValue, shallow);
}
class RefImpl {
    constructor(value, __v_isShallow){
        this.__v_isShallow = __v_isShallow;
        this.dep = void 0;
        this.__v_isRef = true;
        this._rawValue = __v_isShallow ? value : toRaw(value);
        this._value = __v_isShallow ? value : toReactive(value);
    }
    get value() {
        trackRefValue(this);
        return this._value;
    }
    set value(newVal) {
        const useDirectValue = this.__v_isShallow || isShallow(newVal) || isReadonly(newVal);
        newVal = useDirectValue ? newVal : toRaw(newVal);
        if ((0, _shared.hasChanged)(newVal, this._rawValue)) {
            this._rawValue = newVal;
            this._value = useDirectValue ? newVal : toReactive(newVal);
            triggerRefValue(this, newVal);
        }
    }
}
function triggerRef(ref2) {
    triggerRefValue(ref2, (0, ref2.value));
}
function unref(ref2) {
    return isRef(ref2) ? ref2.value : ref2;
}
function toValue(source) {
    return (0, _shared.isFunction)(source) ? source() : unref(source);
}
const shallowUnwrapHandlers = {
    get: (target, key, receiver)=>unref(Reflect.get(target, key, receiver)),
    set: (target, key, value, receiver)=>{
        const oldValue = target[key];
        if (isRef(oldValue) && !isRef(value)) {
            oldValue.value = value;
            return true;
        } else return Reflect.set(target, key, value, receiver);
    }
};
function proxyRefs(objectWithRefs) {
    return isReactive(objectWithRefs) ? objectWithRefs : new Proxy(objectWithRefs, shallowUnwrapHandlers);
}
class CustomRefImpl {
    constructor(factory){
        this.dep = void 0;
        this.__v_isRef = true;
        const { get, set } = factory(()=>trackRefValue(this), ()=>triggerRefValue(this));
        this._get = get;
        this._set = set;
    }
    get value() {
        return this._get();
    }
    set value(newVal) {
        this._set(newVal);
    }
}
function customRef(factory) {
    return new CustomRefImpl(factory);
}
function toRefs(object) {
    if (!isProxy(object)) console.warn(`toRefs() expects a reactive object but received a plain one.`);
    const ret = (0, _shared.isArray)(object) ? new Array(object.length) : {};
    for(const key in object)ret[key] = propertyToRef(object, key);
    return ret;
}
class ObjectRefImpl {
    constructor(_object, _key, _defaultValue){
        this._object = _object;
        this._key = _key;
        this._defaultValue = _defaultValue;
        this.__v_isRef = true;
    }
    get value() {
        const val = this._object[this._key];
        return val === void 0 ? this._defaultValue : val;
    }
    set value(newVal) {
        this._object[this._key] = newVal;
    }
    get dep() {
        return getDepFromReactive(toRaw(this._object), this._key);
    }
}
class GetterRefImpl {
    constructor(_getter){
        this._getter = _getter;
        this.__v_isRef = true;
        this.__v_isReadonly = true;
    }
    get value() {
        return this._getter();
    }
}
function toRef(source, key, defaultValue) {
    if (isRef(source)) return source;
    else if ((0, _shared.isFunction)(source)) return new GetterRefImpl(source);
    else if ((0, _shared.isObject)(source) && arguments.length > 1) return propertyToRef(source, key, defaultValue);
    else return ref(source);
}
function propertyToRef(source, key, defaultValue) {
    const val = source[key];
    return isRef(val) ? val : new ObjectRefImpl(source, key, defaultValue);
}
class ComputedRefImpl {
    constructor(getter, _setter, isReadonly, isSSR){
        this._setter = _setter;
        this.dep = void 0;
        this.__v_isRef = true;
        this["__v_isReadonly"] = false;
        this._dirty = true;
        this.effect = new ReactiveEffect(getter, ()=>{
            if (!this._dirty) {
                this._dirty = true;
                triggerRefValue(this);
            }
        });
        this.effect.computed = this;
        this.effect.active = this._cacheable = !isSSR;
        this["__v_isReadonly"] = isReadonly;
    }
    get value() {
        const self = toRaw(this);
        trackRefValue(self);
        if (self._dirty || !self._cacheable) {
            self._dirty = false;
            self._value = self.effect.run();
        }
        return self._value;
    }
    set value(newValue) {
        this._setter(newValue);
    }
}
function computed(getterOrOptions, debugOptions, isSSR = false) {
    let getter;
    let setter;
    const onlyGetter = (0, _shared.isFunction)(getterOrOptions);
    if (onlyGetter) {
        getter = getterOrOptions;
        setter = ()=>{
            console.warn("Write operation failed: computed value is readonly");
        };
    } else {
        getter = getterOrOptions.get;
        setter = getterOrOptions.set;
    }
    const cRef = new ComputedRefImpl(getter, setter, onlyGetter || !setter, isSSR);
    if (debugOptions && !isSSR) {
        cRef.effect.onTrack = debugOptions.onTrack;
        cRef.effect.onTrigger = debugOptions.onTrigger;
    }
    return cRef;
}
const tick = /* @__PURE__ */ Promise.resolve();
const queue = [];
let queued = false;
const scheduler = (fn)=>{
    queue.push(fn);
    if (!queued) {
        queued = true;
        tick.then(flush);
    }
};
const flush = ()=>{
    for(let i = 0; i < queue.length; i++)queue[i]();
    queue.length = 0;
    queued = false;
};
class DeferredComputedRefImpl {
    constructor(getter){
        this.dep = void 0;
        this._dirty = true;
        this.__v_isRef = true;
        this["__v_isReadonly"] = true;
        let compareTarget;
        let hasCompareTarget = false;
        let scheduled = false;
        this.effect = new ReactiveEffect(getter, (computedTrigger)=>{
            if (this.dep) {
                if (computedTrigger) {
                    compareTarget = this._value;
                    hasCompareTarget = true;
                } else if (!scheduled) {
                    const valueToCompare = hasCompareTarget ? compareTarget : this._value;
                    scheduled = true;
                    hasCompareTarget = false;
                    scheduler(()=>{
                        if (this.effect.active && this._get() !== valueToCompare) triggerRefValue(this);
                        scheduled = false;
                    });
                }
                for (const e of this.dep)if (e.computed instanceof DeferredComputedRefImpl) e.scheduler(true);
            }
            this._dirty = true;
        });
        this.effect.computed = this;
    }
    _get() {
        if (this._dirty) {
            this._dirty = false;
            return this._value = this.effect.run();
        }
        return this._value;
    }
    get value() {
        trackRefValue(this);
        return toRaw(this)._get();
    }
}
function deferredComputed(getter) {
    return new DeferredComputedRefImpl(getter);
}

},{"@vue/shared":"3SM3y","@parcel/transformer-js/src/esmodule-helpers.js":"gkKU3"}],"3SM3y":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "EMPTY_ARR", ()=>EMPTY_ARR);
parcelHelpers.export(exports, "EMPTY_OBJ", ()=>EMPTY_OBJ);
parcelHelpers.export(exports, "NO", ()=>NO);
parcelHelpers.export(exports, "NOOP", ()=>NOOP);
parcelHelpers.export(exports, "PatchFlagNames", ()=>PatchFlagNames);
parcelHelpers.export(exports, "camelize", ()=>camelize);
parcelHelpers.export(exports, "capitalize", ()=>capitalize);
parcelHelpers.export(exports, "def", ()=>def);
parcelHelpers.export(exports, "escapeHtml", ()=>escapeHtml);
parcelHelpers.export(exports, "escapeHtmlComment", ()=>escapeHtmlComment);
parcelHelpers.export(exports, "extend", ()=>extend);
parcelHelpers.export(exports, "genPropsAccessExp", ()=>genPropsAccessExp);
parcelHelpers.export(exports, "generateCodeFrame", ()=>generateCodeFrame);
parcelHelpers.export(exports, "getGlobalThis", ()=>getGlobalThis);
parcelHelpers.export(exports, "hasChanged", ()=>hasChanged);
parcelHelpers.export(exports, "hasOwn", ()=>hasOwn);
parcelHelpers.export(exports, "hyphenate", ()=>hyphenate);
parcelHelpers.export(exports, "includeBooleanAttr", ()=>includeBooleanAttr);
parcelHelpers.export(exports, "invokeArrayFns", ()=>invokeArrayFns);
parcelHelpers.export(exports, "isArray", ()=>isArray);
parcelHelpers.export(exports, "isBooleanAttr", ()=>isBooleanAttr);
parcelHelpers.export(exports, "isBuiltInDirective", ()=>isBuiltInDirective);
parcelHelpers.export(exports, "isDate", ()=>isDate);
parcelHelpers.export(exports, "isFunction", ()=>isFunction);
parcelHelpers.export(exports, "isGloballyAllowed", ()=>isGloballyAllowed);
parcelHelpers.export(exports, "isGloballyWhitelisted", ()=>isGloballyWhitelisted);
parcelHelpers.export(exports, "isHTMLTag", ()=>isHTMLTag);
parcelHelpers.export(exports, "isIntegerKey", ()=>isIntegerKey);
parcelHelpers.export(exports, "isKnownHtmlAttr", ()=>isKnownHtmlAttr);
parcelHelpers.export(exports, "isKnownSvgAttr", ()=>isKnownSvgAttr);
parcelHelpers.export(exports, "isMap", ()=>isMap);
parcelHelpers.export(exports, "isModelListener", ()=>isModelListener);
parcelHelpers.export(exports, "isObject", ()=>isObject);
parcelHelpers.export(exports, "isOn", ()=>isOn);
parcelHelpers.export(exports, "isPlainObject", ()=>isPlainObject);
parcelHelpers.export(exports, "isPromise", ()=>isPromise);
parcelHelpers.export(exports, "isRegExp", ()=>isRegExp);
parcelHelpers.export(exports, "isReservedProp", ()=>isReservedProp);
parcelHelpers.export(exports, "isSSRSafeAttrName", ()=>isSSRSafeAttrName);
parcelHelpers.export(exports, "isSVGTag", ()=>isSVGTag);
parcelHelpers.export(exports, "isSet", ()=>isSet);
parcelHelpers.export(exports, "isSpecialBooleanAttr", ()=>isSpecialBooleanAttr);
parcelHelpers.export(exports, "isString", ()=>isString);
parcelHelpers.export(exports, "isSymbol", ()=>isSymbol);
parcelHelpers.export(exports, "isVoidTag", ()=>isVoidTag);
parcelHelpers.export(exports, "looseEqual", ()=>looseEqual);
parcelHelpers.export(exports, "looseIndexOf", ()=>looseIndexOf);
parcelHelpers.export(exports, "looseToNumber", ()=>looseToNumber);
parcelHelpers.export(exports, "makeMap", ()=>makeMap);
parcelHelpers.export(exports, "normalizeClass", ()=>normalizeClass);
parcelHelpers.export(exports, "normalizeProps", ()=>normalizeProps);
parcelHelpers.export(exports, "normalizeStyle", ()=>normalizeStyle);
parcelHelpers.export(exports, "objectToString", ()=>objectToString);
parcelHelpers.export(exports, "parseStringStyle", ()=>parseStringStyle);
parcelHelpers.export(exports, "propsToAttrMap", ()=>propsToAttrMap);
parcelHelpers.export(exports, "remove", ()=>remove);
parcelHelpers.export(exports, "slotFlagsText", ()=>slotFlagsText);
parcelHelpers.export(exports, "stringifyStyle", ()=>stringifyStyle);
parcelHelpers.export(exports, "toDisplayString", ()=>toDisplayString);
parcelHelpers.export(exports, "toHandlerKey", ()=>toHandlerKey);
parcelHelpers.export(exports, "toNumber", ()=>toNumber);
parcelHelpers.export(exports, "toRawType", ()=>toRawType);
parcelHelpers.export(exports, "toTypeString", ()=>toTypeString);
var global = arguments[3];
function makeMap(str, expectsLowerCase) {
    const map = /* @__PURE__ */ Object.create(null);
    const list = str.split(",");
    for(let i = 0; i < list.length; i++)map[list[i]] = true;
    return expectsLowerCase ? (val)=>!!map[val.toLowerCase()] : (val)=>!!map[val];
}
const EMPTY_OBJ = Object.freeze({});
const EMPTY_ARR = Object.freeze([]);
const NOOP = ()=>{};
const NO = ()=>false;
const isOn = (key)=>key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && // uppercase letter
    (key.charCodeAt(2) > 122 || key.charCodeAt(2) < 97);
const isModelListener = (key)=>key.startsWith("onUpdate:");
const extend = Object.assign;
const remove = (arr, el)=>{
    const i = arr.indexOf(el);
    if (i > -1) arr.splice(i, 1);
};
const hasOwnProperty = Object.prototype.hasOwnProperty;
const hasOwn = (val, key)=>hasOwnProperty.call(val, key);
const isArray = Array.isArray;
const isMap = (val)=>toTypeString(val) === "[object Map]";
const isSet = (val)=>toTypeString(val) === "[object Set]";
const isDate = (val)=>toTypeString(val) === "[object Date]";
const isRegExp = (val)=>toTypeString(val) === "[object RegExp]";
const isFunction = (val)=>typeof val === "function";
const isString = (val)=>typeof val === "string";
const isSymbol = (val)=>typeof val === "symbol";
const isObject = (val)=>val !== null && typeof val === "object";
const isPromise = (val)=>{
    return (isObject(val) || isFunction(val)) && isFunction(val.then) && isFunction(val.catch);
};
const objectToString = Object.prototype.toString;
const toTypeString = (value)=>objectToString.call(value);
const toRawType = (value)=>{
    return toTypeString(value).slice(8, -1);
};
const isPlainObject = (val)=>toTypeString(val) === "[object Object]";
const isIntegerKey = (key)=>isString(key) && key !== "NaN" && key[0] !== "-" && "" + parseInt(key, 10) === key;
const isReservedProp = /* @__PURE__ */ makeMap(// the leading comma is intentional so empty string "" is also included
",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted");
const isBuiltInDirective = /* @__PURE__ */ makeMap("bind,cloak,else-if,else,for,html,if,model,on,once,pre,show,slot,text,memo");
const cacheStringFunction = (fn)=>{
    const cache = /* @__PURE__ */ Object.create(null);
    return (str)=>{
        const hit = cache[str];
        return hit || (cache[str] = fn(str));
    };
};
const camelizeRE = /-(\w)/g;
const camelize = cacheStringFunction((str)=>{
    return str.replace(camelizeRE, (_, c)=>c ? c.toUpperCase() : "");
});
const hyphenateRE = /\B([A-Z])/g;
const hyphenate = cacheStringFunction((str)=>str.replace(hyphenateRE, "-$1").toLowerCase());
const capitalize = cacheStringFunction((str)=>{
    return str.charAt(0).toUpperCase() + str.slice(1);
});
const toHandlerKey = cacheStringFunction((str)=>{
    const s = str ? `on${capitalize(str)}` : ``;
    return s;
});
const hasChanged = (value, oldValue)=>!Object.is(value, oldValue);
const invokeArrayFns = (fns, arg)=>{
    for(let i = 0; i < fns.length; i++)fns[i](arg);
};
const def = (obj, key, value)=>{
    Object.defineProperty(obj, key, {
        configurable: true,
        enumerable: false,
        value
    });
};
const looseToNumber = (val)=>{
    const n = parseFloat(val);
    return isNaN(n) ? val : n;
};
const toNumber = (val)=>{
    const n = isString(val) ? Number(val) : NaN;
    return isNaN(n) ? val : n;
};
let _globalThis;
const getGlobalThis = ()=>{
    return _globalThis || (_globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
};
const identRE = /^[_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*$/;
function genPropsAccessExp(name) {
    return identRE.test(name) ? `__props.${name}` : `__props[${JSON.stringify(name)}]`;
}
const PatchFlagNames = {
    [1]: `TEXT`,
    [2]: `CLASS`,
    [4]: `STYLE`,
    [8]: `PROPS`,
    [16]: `FULL_PROPS`,
    [32]: `NEED_HYDRATION`,
    [64]: `STABLE_FRAGMENT`,
    [128]: `KEYED_FRAGMENT`,
    [256]: `UNKEYED_FRAGMENT`,
    [512]: `NEED_PATCH`,
    [1024]: `DYNAMIC_SLOTS`,
    [2048]: `DEV_ROOT_FRAGMENT`,
    [-1]: `HOISTED`,
    [-2]: `BAIL`
};
const slotFlagsText = {
    [1]: "STABLE",
    [2]: "DYNAMIC",
    [3]: "FORWARDED"
};
const GLOBALS_ALLOWED = "Infinity,undefined,NaN,isFinite,isNaN,parseFloat,parseInt,decodeURI,decodeURIComponent,encodeURI,encodeURIComponent,Math,Number,Date,Array,Object,Boolean,String,RegExp,Map,Set,JSON,Intl,BigInt,console";
const isGloballyAllowed = /* @__PURE__ */ makeMap(GLOBALS_ALLOWED);
const isGloballyWhitelisted = isGloballyAllowed;
const range = 2;
function generateCodeFrame(source, start = 0, end = source.length) {
    let lines = source.split(/(\r?\n)/);
    const newlineSequences = lines.filter((_, idx)=>idx % 2 === 1);
    lines = lines.filter((_, idx)=>idx % 2 === 0);
    let count = 0;
    const res = [];
    for(let i = 0; i < lines.length; i++){
        count += lines[i].length + (newlineSequences[i] && newlineSequences[i].length || 0);
        if (count >= start) {
            for(let j = i - range; j <= i + range || end > count; j++){
                if (j < 0 || j >= lines.length) continue;
                const line = j + 1;
                res.push(`${line}${" ".repeat(Math.max(3 - String(line).length, 0))}|  ${lines[j]}`);
                const lineLength = lines[j].length;
                const newLineSeqLength = newlineSequences[j] && newlineSequences[j].length || 0;
                if (j === i) {
                    const pad = start - (count - (lineLength + newLineSeqLength));
                    const length = Math.max(1, end > count ? lineLength - pad : end - start);
                    res.push(`   |  ` + " ".repeat(pad) + "^".repeat(length));
                } else if (j > i) {
                    if (end > count) {
                        const length = Math.max(Math.min(end - count, lineLength), 1);
                        res.push(`   |  ` + "^".repeat(length));
                    }
                    count += lineLength + newLineSeqLength;
                }
            }
            break;
        }
    }
    return res.join("\n");
}
function normalizeStyle(value) {
    if (isArray(value)) {
        const res = {};
        for(let i = 0; i < value.length; i++){
            const item = value[i];
            const normalized = isString(item) ? parseStringStyle(item) : normalizeStyle(item);
            if (normalized) for(const key in normalized)res[key] = normalized[key];
        }
        return res;
    } else if (isString(value) || isObject(value)) return value;
}
const listDelimiterRE = /;(?![^(]*\))/g;
const propertyDelimiterRE = /:([^]+)/;
const styleCommentRE = /\/\*[^]*?\*\//g;
function parseStringStyle(cssText) {
    const ret = {};
    cssText.replace(styleCommentRE, "").split(listDelimiterRE).forEach((item)=>{
        if (item) {
            const tmp = item.split(propertyDelimiterRE);
            tmp.length > 1 && (ret[tmp[0].trim()] = tmp[1].trim());
        }
    });
    return ret;
}
function stringifyStyle(styles) {
    let ret = "";
    if (!styles || isString(styles)) return ret;
    for(const key in styles){
        const value = styles[key];
        const normalizedKey = key.startsWith(`--`) ? key : hyphenate(key);
        if (isString(value) || typeof value === "number") ret += `${normalizedKey}:${value};`;
    }
    return ret;
}
function normalizeClass(value) {
    let res = "";
    if (isString(value)) res = value;
    else if (isArray(value)) for(let i = 0; i < value.length; i++){
        const normalized = normalizeClass(value[i]);
        if (normalized) res += normalized + " ";
    }
    else if (isObject(value)) {
        for(const name in value)if (value[name]) res += name + " ";
    }
    return res.trim();
}
function normalizeProps(props) {
    if (!props) return null;
    let { class: klass, style } = props;
    if (klass && !isString(klass)) props.class = normalizeClass(klass);
    if (style) props.style = normalizeStyle(style);
    return props;
}
const HTML_TAGS = "html,body,base,head,link,meta,style,title,address,article,aside,footer,header,hgroup,h1,h2,h3,h4,h5,h6,nav,section,div,dd,dl,dt,figcaption,figure,picture,hr,img,li,main,ol,p,pre,ul,a,b,abbr,bdi,bdo,br,cite,code,data,dfn,em,i,kbd,mark,q,rp,rt,ruby,s,samp,small,span,strong,sub,sup,time,u,var,wbr,area,audio,map,track,video,embed,object,param,source,canvas,script,noscript,del,ins,caption,col,colgroup,table,thead,tbody,td,th,tr,button,datalist,fieldset,form,input,label,legend,meter,optgroup,option,output,progress,select,textarea,details,dialog,menu,summary,template,blockquote,iframe,tfoot";
const SVG_TAGS = "svg,animate,animateMotion,animateTransform,circle,clipPath,color-profile,defs,desc,discard,ellipse,feBlend,feColorMatrix,feComponentTransfer,feComposite,feConvolveMatrix,feDiffuseLighting,feDisplacementMap,feDistantLight,feDropShadow,feFlood,feFuncA,feFuncB,feFuncG,feFuncR,feGaussianBlur,feImage,feMerge,feMergeNode,feMorphology,feOffset,fePointLight,feSpecularLighting,feSpotLight,feTile,feTurbulence,filter,foreignObject,g,hatch,hatchpath,image,line,linearGradient,marker,mask,mesh,meshgradient,meshpatch,meshrow,metadata,mpath,path,pattern,polygon,polyline,radialGradient,rect,set,solidcolor,stop,switch,symbol,text,textPath,title,tspan,unknown,use,view";
const VOID_TAGS = "area,base,br,col,embed,hr,img,input,link,meta,param,source,track,wbr";
const isHTMLTag = /* @__PURE__ */ makeMap(HTML_TAGS);
const isSVGTag = /* @__PURE__ */ makeMap(SVG_TAGS);
const isVoidTag = /* @__PURE__ */ makeMap(VOID_TAGS);
const specialBooleanAttrs = `itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly`;
const isSpecialBooleanAttr = /* @__PURE__ */ makeMap(specialBooleanAttrs);
const isBooleanAttr = /* @__PURE__ */ makeMap(specialBooleanAttrs + `,async,autofocus,autoplay,controls,default,defer,disabled,hidden,inert,loop,open,required,reversed,scoped,seamless,checked,muted,multiple,selected`);
function includeBooleanAttr(value) {
    return !!value || value === "";
}
const unsafeAttrCharRE = /[>/="'\u0009\u000a\u000c\u0020]/;
const attrValidationCache = {};
function isSSRSafeAttrName(name) {
    if (attrValidationCache.hasOwnProperty(name)) return attrValidationCache[name];
    const isUnsafe = unsafeAttrCharRE.test(name);
    if (isUnsafe) console.error(`unsafe attribute name: ${name}`);
    return attrValidationCache[name] = !isUnsafe;
}
const propsToAttrMap = {
    acceptCharset: "accept-charset",
    className: "class",
    htmlFor: "for",
    httpEquiv: "http-equiv"
};
const isKnownHtmlAttr = /* @__PURE__ */ makeMap(`accept,accept-charset,accesskey,action,align,allow,alt,async,autocapitalize,autocomplete,autofocus,autoplay,background,bgcolor,border,buffered,capture,challenge,charset,checked,cite,class,code,codebase,color,cols,colspan,content,contenteditable,contextmenu,controls,coords,crossorigin,csp,data,datetime,decoding,default,defer,dir,dirname,disabled,download,draggable,dropzone,enctype,enterkeyhint,for,form,formaction,formenctype,formmethod,formnovalidate,formtarget,headers,height,hidden,high,href,hreflang,http-equiv,icon,id,importance,inert,integrity,ismap,itemprop,keytype,kind,label,lang,language,loading,list,loop,low,manifest,max,maxlength,minlength,media,min,multiple,muted,name,novalidate,open,optimum,pattern,ping,placeholder,poster,preload,radiogroup,readonly,referrerpolicy,rel,required,reversed,rows,rowspan,sandbox,scope,scoped,selected,shape,size,sizes,slot,span,spellcheck,src,srcdoc,srclang,srcset,start,step,style,summary,tabindex,target,title,translate,type,usemap,value,width,wrap`);
const isKnownSvgAttr = /* @__PURE__ */ makeMap(`xmlns,accent-height,accumulate,additive,alignment-baseline,alphabetic,amplitude,arabic-form,ascent,attributeName,attributeType,azimuth,baseFrequency,baseline-shift,baseProfile,bbox,begin,bias,by,calcMode,cap-height,class,clip,clipPathUnits,clip-path,clip-rule,color,color-interpolation,color-interpolation-filters,color-profile,color-rendering,contentScriptType,contentStyleType,crossorigin,cursor,cx,cy,d,decelerate,descent,diffuseConstant,direction,display,divisor,dominant-baseline,dur,dx,dy,edgeMode,elevation,enable-background,end,exponent,fill,fill-opacity,fill-rule,filter,filterRes,filterUnits,flood-color,flood-opacity,font-family,font-size,font-size-adjust,font-stretch,font-style,font-variant,font-weight,format,from,fr,fx,fy,g1,g2,glyph-name,glyph-orientation-horizontal,glyph-orientation-vertical,glyphRef,gradientTransform,gradientUnits,hanging,height,href,hreflang,horiz-adv-x,horiz-origin-x,id,ideographic,image-rendering,in,in2,intercept,k,k1,k2,k3,k4,kernelMatrix,kernelUnitLength,kerning,keyPoints,keySplines,keyTimes,lang,lengthAdjust,letter-spacing,lighting-color,limitingConeAngle,local,marker-end,marker-mid,marker-start,markerHeight,markerUnits,markerWidth,mask,maskContentUnits,maskUnits,mathematical,max,media,method,min,mode,name,numOctaves,offset,opacity,operator,order,orient,orientation,origin,overflow,overline-position,overline-thickness,panose-1,paint-order,path,pathLength,patternContentUnits,patternTransform,patternUnits,ping,pointer-events,points,pointsAtX,pointsAtY,pointsAtZ,preserveAlpha,preserveAspectRatio,primitiveUnits,r,radius,referrerPolicy,refX,refY,rel,rendering-intent,repeatCount,repeatDur,requiredExtensions,requiredFeatures,restart,result,rotate,rx,ry,scale,seed,shape-rendering,slope,spacing,specularConstant,specularExponent,speed,spreadMethod,startOffset,stdDeviation,stemh,stemv,stitchTiles,stop-color,stop-opacity,strikethrough-position,strikethrough-thickness,string,stroke,stroke-dasharray,stroke-dashoffset,stroke-linecap,stroke-linejoin,stroke-miterlimit,stroke-opacity,stroke-width,style,surfaceScale,systemLanguage,tabindex,tableValues,target,targetX,targetY,text-anchor,text-decoration,text-rendering,textLength,to,transform,transform-origin,type,u1,u2,underline-position,underline-thickness,unicode,unicode-bidi,unicode-range,units-per-em,v-alphabetic,v-hanging,v-ideographic,v-mathematical,values,vector-effect,version,vert-adv-y,vert-origin-x,vert-origin-y,viewBox,viewTarget,visibility,width,widths,word-spacing,writing-mode,x,x-height,x1,x2,xChannelSelector,xlink:actuate,xlink:arcrole,xlink:href,xlink:role,xlink:show,xlink:title,xlink:type,xmlns:xlink,xml:base,xml:lang,xml:space,y,y1,y2,yChannelSelector,z,zoomAndPan`);
const escapeRE = /["'&<>]/;
function escapeHtml(string) {
    const str = "" + string;
    const match = escapeRE.exec(str);
    if (!match) return str;
    let html = "";
    let escaped;
    let index;
    let lastIndex = 0;
    for(index = match.index; index < str.length; index++){
        switch(str.charCodeAt(index)){
            case 34:
                escaped = "&quot;";
                break;
            case 38:
                escaped = "&amp;";
                break;
            case 39:
                escaped = "&#39;";
                break;
            case 60:
                escaped = "&lt;";
                break;
            case 62:
                escaped = "&gt;";
                break;
            default:
                continue;
        }
        if (lastIndex !== index) html += str.slice(lastIndex, index);
        lastIndex = index + 1;
        html += escaped;
    }
    return lastIndex !== index ? html + str.slice(lastIndex, index) : html;
}
const commentStripRE = /^-?>|<!--|-->|--!>|<!-$/g;
function escapeHtmlComment(src) {
    return src.replace(commentStripRE, "");
}
function looseCompareArrays(a, b) {
    if (a.length !== b.length) return false;
    let equal = true;
    for(let i = 0; equal && i < a.length; i++)equal = looseEqual(a[i], b[i]);
    return equal;
}
function looseEqual(a, b) {
    if (a === b) return true;
    let aValidType = isDate(a);
    let bValidType = isDate(b);
    if (aValidType || bValidType) return aValidType && bValidType ? a.getTime() === b.getTime() : false;
    aValidType = isSymbol(a);
    bValidType = isSymbol(b);
    if (aValidType || bValidType) return a === b;
    aValidType = isArray(a);
    bValidType = isArray(b);
    if (aValidType || bValidType) return aValidType && bValidType ? looseCompareArrays(a, b) : false;
    aValidType = isObject(a);
    bValidType = isObject(b);
    if (aValidType || bValidType) {
        if (!aValidType || !bValidType) return false;
        const aKeysCount = Object.keys(a).length;
        const bKeysCount = Object.keys(b).length;
        if (aKeysCount !== bKeysCount) return false;
        for(const key in a){
            const aHasKey = a.hasOwnProperty(key);
            const bHasKey = b.hasOwnProperty(key);
            if (aHasKey && !bHasKey || !aHasKey && bHasKey || !looseEqual(a[key], b[key])) return false;
        }
    }
    return String(a) === String(b);
}
function looseIndexOf(arr, val) {
    return arr.findIndex((item)=>looseEqual(item, val));
}
const toDisplayString = (val)=>{
    return isString(val) ? val : val == null ? "" : isArray(val) || isObject(val) && (val.toString === objectToString || !isFunction(val.toString)) ? JSON.stringify(val, replacer, 2) : String(val);
};
const replacer = (_key, val)=>{
    if (val && val.__v_isRef) return replacer(_key, val.value);
    else if (isMap(val)) return {
        [`Map(${val.size})`]: [
            ...val.entries()
        ].reduce((entries, [key, val2], i)=>{
            entries[stringifySymbol(key, i) + " =>"] = val2;
            return entries;
        }, {})
    };
    else if (isSet(val)) return {
        [`Set(${val.size})`]: [
            ...val.values()
        ].map((v)=>stringifySymbol(v))
    };
    else if (isSymbol(val)) return stringifySymbol(val);
    else if (isObject(val) && !isArray(val) && !isPlainObject(val)) return String(val);
    return val;
};
const stringifySymbol = (v, i = "")=>{
    var _a;
    return isSymbol(v) ? `Symbol(${(_a = v.description) != null ? _a : i})` : v;
};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"gkKU3"}],"gkKU3":[function(require,module,exports) {
exports.interopDefault = function(a) {
    return a && a.__esModule ? a : {
        default: a
    };
};
exports.defineInteropFlag = function(a) {
    Object.defineProperty(a, "__esModule", {
        value: true
    });
};
exports.exportAll = function(source, dest) {
    Object.keys(source).forEach(function(key) {
        if (key === "default" || key === "__esModule" || Object.prototype.hasOwnProperty.call(dest, key)) return;
        Object.defineProperty(dest, key, {
            enumerable: true,
            get: function() {
                return source[key];
            }
        });
    });
    return dest;
};
exports.export = function(dest, destName, get) {
    Object.defineProperty(dest, destName, {
        enumerable: true,
        get: get
    });
};

},{}],"aohMd":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "defaultSettings", ()=>defaultSettings);
parcelHelpers.export(exports, "Settings", ()=>Settings);
var _log = require("../utilities/Log");
var _events = require("events");
var _eventsDefault = parcelHelpers.interopDefault(_events);
const defaultSettings = {
    showToolbarOverlay: true,
    debug: false
};
class Settings extends (0, _eventsDefault.default) {
    constructor(settings){
        super();
        this._settings = {
            ...defaultSettings
        };
        this.eventListenerTarget = document.getElementById("slc-injected-script");
        if (settings) Object.assign(this._settings, settings);
        this.eventListenerTarget?.addEventListener("getSettings-response", (e)=>{
            const details = e.detail;
            (0, _log.Log).info('Receiving response for "Loading stored settings"', details);
            // if there are stored settings, store them inside the class
            // otherwise save the default settings
            if (details?.settings) {
                this._settings = details.settings;
                this.emit("settingsLoaded", this._settings);
            } else this.saveStoredSettings();
        });
        this.eventListenerTarget?.addEventListener("settingsChanged", (e)=>this.onSettingsChanged(e));
        this.loadStoredSettings();
    }
    onSettingsChanged(e) {
        const details = e.detail;
        (0, _log.Log).info("Settings has changed", details);
        if (details?.settings) {
            this._settings = details.settings;
            this.emit("settingsChanged", this._settings);
        }
    }
    loadStoredSettings() {
        (0, _log.Log).info("Loading stored settings");
        this.eventListenerTarget?.dispatchEvent(new CustomEvent("getSettings"));
    }
    saveStoredSettings() {
        (0, _log.Log).info("Saving stored settings");
        this.eventListenerTarget?.dispatchEvent(new CustomEvent("setSettings", {
            detail: {
                settings: this._settings
            }
        }));
    }
    get settings() {
        return this._settings;
    }
}

},{"../utilities/Log":"8wG4i","events":"1VQLm","@parcel/transformer-js/src/esmodule-helpers.js":"gkKU3"}],"8wG4i":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "Log", ()=>Log);
var LogType;
(function(LogType) {
    LogType["INFO"] = "info";
    LogType["WARN"] = "warn";
    LogType["ERROR"] = "error";
})(LogType || (LogType = {}));
class Log {
    // private static settingsInstance: Settings
    static execLog(type, ...message) {
        const prefix = "SLC -";
        /* if (chrome.storage) {
      console.log('storage available')
    } else {
      this.settingsInstance = new Settings()
    }
    
    console.log(this.settingsInstance.settings)*/ console[type](prefix, ...message);
    }
    static info(...message) {
        this.execLog("info", ...message);
    }
    static warn(...message) {
        this.execLog("warn", ...message);
    }
    static error(...message) {
        this.execLog("error", ...message);
    }
}

},{"@parcel/transformer-js/src/esmodule-helpers.js":"gkKU3"}],"1VQLm":[function(require,module,exports) {
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
"use strict";
var R = typeof Reflect === "object" ? Reflect : null;
var ReflectApply = R && typeof R.apply === "function" ? R.apply : function ReflectApply(target, receiver, args) {
    return Function.prototype.apply.call(target, receiver, args);
};
var ReflectOwnKeys;
if (R && typeof R.ownKeys === "function") ReflectOwnKeys = R.ownKeys;
else if (Object.getOwnPropertySymbols) ReflectOwnKeys = function ReflectOwnKeys(target) {
    return Object.getOwnPropertyNames(target).concat(Object.getOwnPropertySymbols(target));
};
else ReflectOwnKeys = function ReflectOwnKeys(target) {
    return Object.getOwnPropertyNames(target);
};
function ProcessEmitWarning(warning) {
    if (console && console.warn) console.warn(warning);
}
var NumberIsNaN = Number.isNaN || function NumberIsNaN(value) {
    return value !== value;
};
function EventEmitter() {
    EventEmitter.init.call(this);
}
module.exports = EventEmitter;
module.exports.once = once;
// Backwards-compat with node 0.10.x
EventEmitter.EventEmitter = EventEmitter;
EventEmitter.prototype._events = undefined;
EventEmitter.prototype._eventsCount = 0;
EventEmitter.prototype._maxListeners = undefined;
// By default EventEmitters will print a warning if more than 10 listeners are
// added to it. This is a useful default which helps finding memory leaks.
var defaultMaxListeners = 10;
function checkListener(listener) {
    if (typeof listener !== "function") throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof listener);
}
Object.defineProperty(EventEmitter, "defaultMaxListeners", {
    enumerable: true,
    get: function() {
        return defaultMaxListeners;
    },
    set: function(arg) {
        if (typeof arg !== "number" || arg < 0 || NumberIsNaN(arg)) throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + arg + ".");
        defaultMaxListeners = arg;
    }
});
EventEmitter.init = function() {
    if (this._events === undefined || this._events === Object.getPrototypeOf(this)._events) {
        this._events = Object.create(null);
        this._eventsCount = 0;
    }
    this._maxListeners = this._maxListeners || undefined;
};
// Obviously not all Emitters should be limited to 10. This function allows
// that to be increased. Set to zero for unlimited.
EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
    if (typeof n !== "number" || n < 0 || NumberIsNaN(n)) throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + n + ".");
    this._maxListeners = n;
    return this;
};
function _getMaxListeners(that) {
    if (that._maxListeners === undefined) return EventEmitter.defaultMaxListeners;
    return that._maxListeners;
}
EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
    return _getMaxListeners(this);
};
EventEmitter.prototype.emit = function emit(type) {
    var args = [];
    for(var i = 1; i < arguments.length; i++)args.push(arguments[i]);
    var doError = type === "error";
    var events = this._events;
    if (events !== undefined) doError = doError && events.error === undefined;
    else if (!doError) return false;
    // If there is no 'error' event listener then throw.
    if (doError) {
        var er;
        if (args.length > 0) er = args[0];
        if (er instanceof Error) // Note: The comments on the `throw` lines are intentional, they show
        // up in Node's output if this results in an unhandled exception.
        throw er; // Unhandled 'error' event
        // At least give some kind of context to the user
        var err = new Error("Unhandled error." + (er ? " (" + er.message + ")" : ""));
        err.context = er;
        throw err; // Unhandled 'error' event
    }
    var handler = events[type];
    if (handler === undefined) return false;
    if (typeof handler === "function") ReflectApply(handler, this, args);
    else {
        var len = handler.length;
        var listeners = arrayClone(handler, len);
        for(var i = 0; i < len; ++i)ReflectApply(listeners[i], this, args);
    }
    return true;
};
function _addListener(target, type, listener, prepend) {
    var m;
    var events;
    var existing;
    checkListener(listener);
    events = target._events;
    if (events === undefined) {
        events = target._events = Object.create(null);
        target._eventsCount = 0;
    } else {
        // To avoid recursion in the case that type === "newListener"! Before
        // adding it to the listeners, first emit "newListener".
        if (events.newListener !== undefined) {
            target.emit("newListener", type, listener.listener ? listener.listener : listener);
            // Re-assign `events` because a newListener handler could have caused the
            // this._events to be assigned to a new object
            events = target._events;
        }
        existing = events[type];
    }
    if (existing === undefined) {
        // Optimize the case of one listener. Don't need the extra array object.
        existing = events[type] = listener;
        ++target._eventsCount;
    } else {
        if (typeof existing === "function") // Adding the second element, need to change to array.
        existing = events[type] = prepend ? [
            listener,
            existing
        ] : [
            existing,
            listener
        ];
        else if (prepend) existing.unshift(listener);
        else existing.push(listener);
        // Check for listener leak
        m = _getMaxListeners(target);
        if (m > 0 && existing.length > m && !existing.warned) {
            existing.warned = true;
            // No error code for this since it is a Warning
            // eslint-disable-next-line no-restricted-syntax
            var w = new Error("Possible EventEmitter memory leak detected. " + existing.length + " " + String(type) + " listeners " + "added. Use emitter.setMaxListeners() to " + "increase limit");
            w.name = "MaxListenersExceededWarning";
            w.emitter = target;
            w.type = type;
            w.count = existing.length;
            ProcessEmitWarning(w);
        }
    }
    return target;
}
EventEmitter.prototype.addListener = function addListener(type, listener) {
    return _addListener(this, type, listener, false);
};
EventEmitter.prototype.on = EventEmitter.prototype.addListener;
EventEmitter.prototype.prependListener = function prependListener(type, listener) {
    return _addListener(this, type, listener, true);
};
function onceWrapper() {
    if (!this.fired) {
        this.target.removeListener(this.type, this.wrapFn);
        this.fired = true;
        if (arguments.length === 0) return this.listener.call(this.target);
        return this.listener.apply(this.target, arguments);
    }
}
function _onceWrap(target, type, listener) {
    var state = {
        fired: false,
        wrapFn: undefined,
        target: target,
        type: type,
        listener: listener
    };
    var wrapped = onceWrapper.bind(state);
    wrapped.listener = listener;
    state.wrapFn = wrapped;
    return wrapped;
}
EventEmitter.prototype.once = function once(type, listener) {
    checkListener(listener);
    this.on(type, _onceWrap(this, type, listener));
    return this;
};
EventEmitter.prototype.prependOnceListener = function prependOnceListener(type, listener) {
    checkListener(listener);
    this.prependListener(type, _onceWrap(this, type, listener));
    return this;
};
// Emits a 'removeListener' event if and only if the listener was removed.
EventEmitter.prototype.removeListener = function removeListener(type, listener) {
    var list, events, position, i, originalListener;
    checkListener(listener);
    events = this._events;
    if (events === undefined) return this;
    list = events[type];
    if (list === undefined) return this;
    if (list === listener || list.listener === listener) {
        if (--this._eventsCount === 0) this._events = Object.create(null);
        else {
            delete events[type];
            if (events.removeListener) this.emit("removeListener", type, list.listener || listener);
        }
    } else if (typeof list !== "function") {
        position = -1;
        for(i = list.length - 1; i >= 0; i--)if (list[i] === listener || list[i].listener === listener) {
            originalListener = list[i].listener;
            position = i;
            break;
        }
        if (position < 0) return this;
        if (position === 0) list.shift();
        else spliceOne(list, position);
        if (list.length === 1) events[type] = list[0];
        if (events.removeListener !== undefined) this.emit("removeListener", type, originalListener || listener);
    }
    return this;
};
EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
EventEmitter.prototype.removeAllListeners = function removeAllListeners(type) {
    var listeners, events, i;
    events = this._events;
    if (events === undefined) return this;
    // not listening for removeListener, no need to emit
    if (events.removeListener === undefined) {
        if (arguments.length === 0) {
            this._events = Object.create(null);
            this._eventsCount = 0;
        } else if (events[type] !== undefined) {
            if (--this._eventsCount === 0) this._events = Object.create(null);
            else delete events[type];
        }
        return this;
    }
    // emit removeListener for all listeners on all events
    if (arguments.length === 0) {
        var keys = Object.keys(events);
        var key;
        for(i = 0; i < keys.length; ++i){
            key = keys[i];
            if (key === "removeListener") continue;
            this.removeAllListeners(key);
        }
        this.removeAllListeners("removeListener");
        this._events = Object.create(null);
        this._eventsCount = 0;
        return this;
    }
    listeners = events[type];
    if (typeof listeners === "function") this.removeListener(type, listeners);
    else if (listeners !== undefined) // LIFO order
    for(i = listeners.length - 1; i >= 0; i--)this.removeListener(type, listeners[i]);
    return this;
};
function _listeners(target, type, unwrap) {
    var events = target._events;
    if (events === undefined) return [];
    var evlistener = events[type];
    if (evlistener === undefined) return [];
    if (typeof evlistener === "function") return unwrap ? [
        evlistener.listener || evlistener
    ] : [
        evlistener
    ];
    return unwrap ? unwrapListeners(evlistener) : arrayClone(evlistener, evlistener.length);
}
EventEmitter.prototype.listeners = function listeners(type) {
    return _listeners(this, type, true);
};
EventEmitter.prototype.rawListeners = function rawListeners(type) {
    return _listeners(this, type, false);
};
EventEmitter.listenerCount = function(emitter, type) {
    if (typeof emitter.listenerCount === "function") return emitter.listenerCount(type);
    else return listenerCount.call(emitter, type);
};
EventEmitter.prototype.listenerCount = listenerCount;
function listenerCount(type) {
    var events = this._events;
    if (events !== undefined) {
        var evlistener = events[type];
        if (typeof evlistener === "function") return 1;
        else if (evlistener !== undefined) return evlistener.length;
    }
    return 0;
}
EventEmitter.prototype.eventNames = function eventNames() {
    return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
};
function arrayClone(arr, n) {
    var copy = new Array(n);
    for(var i = 0; i < n; ++i)copy[i] = arr[i];
    return copy;
}
function spliceOne(list, index) {
    for(; index + 1 < list.length; index++)list[index] = list[index + 1];
    list.pop();
}
function unwrapListeners(arr) {
    var ret = new Array(arr.length);
    for(var i = 0; i < ret.length; ++i)ret[i] = arr[i].listener || arr[i];
    return ret;
}
function once(emitter, name) {
    return new Promise(function(resolve, reject) {
        function errorListener(err) {
            emitter.removeListener(name, resolver);
            reject(err);
        }
        function resolver() {
            if (typeof emitter.removeListener === "function") emitter.removeListener("error", errorListener);
            resolve([].slice.call(arguments));
        }
        eventTargetAgnosticAddListener(emitter, name, resolver, {
            once: true
        });
        if (name !== "error") addErrorHandlerIfEventEmitter(emitter, errorListener, {
            once: true
        });
    });
}
function addErrorHandlerIfEventEmitter(emitter, handler, flags) {
    if (typeof emitter.on === "function") eventTargetAgnosticAddListener(emitter, "error", handler, flags);
}
function eventTargetAgnosticAddListener(emitter, name, listener, flags) {
    if (typeof emitter.on === "function") {
        if (flags.once) emitter.once(name, listener);
        else emitter.on(name, listener);
    } else if (typeof emitter.addEventListener === "function") // EventTarget does not have `error` event semantics like Node
    // EventEmitters, we do not listen for `error` events here.
    emitter.addEventListener(name, function wrapListener(arg) {
        // IE does not have builtin `{ once: true }` support so we
        // have to do it manually.
        if (flags.once) emitter.removeEventListener(name, wrapListener);
        listener(arg);
    });
    else throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof emitter);
}

},{}],"l5ThS":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "render", ()=>render);
var _vue = require("vue");
const _hoisted_1 = {
    class: "toolbar-content"
};
const _hoisted_2 = {
    class: "icon icon-static"
};
const _hoisted_3 = {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 256 512",
    style: {
        "fill": "currentColor"
    }
};
const _hoisted_4 = /*#__PURE__*/ (0, _vue.createElementVNode)("path", {
    d: "M192 448c-8.188 0-16.38-3.125-22.62-9.375l-160-160c-12.5-12.5-12.5-32.75 0-45.25l160-160c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25L77.25 256l137.4 137.4c12.5 12.5 12.5 32.75 0 45.25C208.4 444.9 200.2 448 192 448z"
}, null, -1 /* HOISTED */ );
const _hoisted_5 = [
    _hoisted_4
];
const _hoisted_6 = /*#__PURE__*/ (0, _vue.createElementVNode)("i", {
    class: "icon"
}, [
    /*#__PURE__*/ (0, _vue.createElementVNode)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 512 512",
        fill: "currentColor"
    }, [
        /*#__PURE__*/ (0, _vue.createElementVNode)("path", {
            d: "M448 192H64C28.65 192 0 220.7 0 256v96c0 17.67 14.33 32 32 32h32v96c0 17.67 14.33 32 32 32h320c17.67 0 32-14.33 32-32v-96h32c17.67 0 32-14.33 32-32V256C512 220.7 483.3 192 448 192zM384 448H128v-96h256V448zM432 296c-13.25 0-24-10.75-24-24c0-13.27 10.75-24 24-24s24 10.73 24 24C456 285.3 445.3 296 432 296zM128 64h229.5L384 90.51V160h64V77.25c0-8.484-3.375-16.62-9.375-22.62l-45.25-45.25C387.4 3.375 379.2 0 370.8 0H96C78.34 0 64 14.33 64 32v128h64V64z"
        })
    ])
], -1 /* HOISTED */ );
const _hoisted_7 = /*#__PURE__*/ (0, _vue.createElementVNode)("span", {
    class: "title"
}, "Print", -1 /* HOISTED */ );
const _hoisted_8 = [
    _hoisted_6,
    _hoisted_7
];
const _hoisted_9 = /*#__PURE__*/ (0, _vue.createElementVNode)("i", {
    class: "icon"
}, [
    /*#__PURE__*/ (0, _vue.createElementVNode)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 512 512",
        fill: "currentColor"
    }, [
        /*#__PURE__*/ (0, _vue.createElementVNode)("path", {
            d: "M0 219.2v212.5c0 14.25 11.62 26.25 26.5 27C75.32 461.2 180.2 471.3 240 511.9V245.2C181.4 205.5 79.99 194.8 29.84 192C13.59 191.1 0 203.6 0 219.2zM482.2 192c-50.09 2.848-151.3 13.47-209.1 53.09C272.1 245.2 272 245.3 272 245.5v266.5c60.04-40.39 164.7-50.76 213.5-53.28C500.4 457.9 512 445.9 512 431.7V219.2C512 203.6 498.4 191.1 482.2 192zM352 96c0-53-43-96-96-96S160 43 160 96s43 96 96 96S352 149 352 96z"
        })
    ])
], -1 /* HOISTED */ );
const _hoisted_10 = /*#__PURE__*/ (0, _vue.createElementVNode)("span", {
    class: "title"
}, "Speaker View", -1 /* HOISTED */ );
const _hoisted_11 = [
    _hoisted_9,
    _hoisted_10
];
function render(_ctx, _cache, $props, $setup, $data, $options) {
    return _ctx.settings && _ctx.settings.showToolbarOverlay ? ((0, _vue.openBlock)(), (0, _vue.createElementBlock)("div", {
        key: 0,
        class: (0, _vue.normalizeClass)([
            "toolbar",
            {
                "active": _ctx.active
            }
        ]),
        ref: "toolbar",
        onMouseover: _cache[2] || (_cache[2] = ($event)=>_ctx.active = true),
        onMouseout: _cache[3] || (_cache[3] = ($event)=>_ctx.active = false)
    }, [
        (0, _vue.createElementVNode)("div", _hoisted_1, [
            (0, _vue.createElementVNode)("div", _hoisted_2, [
                ((0, _vue.openBlock)(), (0, _vue.createElementBlock)("svg", _hoisted_3, [
                    ..._hoisted_5
                ]))
            ]),
            (0, _vue.createElementVNode)("button", {
                onClick: _cache[0] || (_cache[0] = (...args)=>_ctx.onPrintClick && _ctx.onPrintClick(...args)),
                class: "btn"
            }, [
                ..._hoisted_8
            ]),
            (0, _vue.createElementVNode)("button", {
                onClick: _cache[1] || (_cache[1] = (...args)=>_ctx.onSpeakerViewClick && _ctx.onSpeakerViewClick(...args)),
                class: "btn"
            }, [
                ..._hoisted_11
            ])
        ])
    ], 34 /* CLASS, NEED_HYDRATION */ )) : (0, _vue.createCommentVNode)("v-if", true);
}
if (module.hot) module.hot.accept(()=>{
    __VUE_HMR_RUNTIME__.rerender("3cca5d-hmr", render);
});

},{"vue":"gzxs9","@parcel/transformer-js/src/esmodule-helpers.js":"gkKU3"}],"jABBs":[function() {},{}],"dywpD":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
_c = NOOP;
exports.default = (script)=>{};
var _c;
$RefreshReg$(_c, "NOOP");

},{"@parcel/transformer-js/src/esmodule-helpers.js":"gkKU3"}],"bbfjI":[function(require,module,exports) {
!function(t, e) {
    module.exports = e();
}(this, function() {
    "use strict";
    function t() {
        return {
            baseUrl: null,
            breaks: !1,
            extensions: null,
            gfm: !0,
            headerIds: !0,
            headerPrefix: "",
            highlight: null,
            langPrefix: "language-",
            mangle: !0,
            pedantic: !1,
            renderer: null,
            sanitize: !1,
            sanitizer: null,
            silent: !1,
            smartLists: !1,
            smartypants: !1,
            tokenizer: null,
            walkTokens: null,
            xhtml: !1
        };
    }
    let e = {
        baseUrl: null,
        breaks: !1,
        extensions: null,
        gfm: !0,
        headerIds: !0,
        headerPrefix: "",
        highlight: null,
        langPrefix: "language-",
        mangle: !0,
        pedantic: !1,
        renderer: null,
        sanitize: !1,
        sanitizer: null,
        silent: !1,
        smartLists: !1,
        smartypants: !1,
        tokenizer: null,
        walkTokens: null,
        xhtml: !1
    };
    const n = /[&<>"']/, i = /[&<>"']/g, s = /[<>"']|&(?!#?\w+;)/, r = /[<>"']|&(?!#?\w+;)/g, a = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    }, l = (t)=>a[t];
    function o(t, e) {
        if (e) {
            if (n.test(t)) return t.replace(i, l);
        } else if (s.test(t)) return t.replace(r, l);
        return t;
    }
    const c = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/gi;
    function p(t) {
        return t.replace(c, (t, e)=>"colon" === (e = e.toLowerCase()) ? ":" : "#" === e.charAt(0) ? "x" === e.charAt(1) ? String.fromCharCode(parseInt(e.substring(2), 16)) : String.fromCharCode(+e.substring(1)) : "");
    }
    const u = /(^|[^\[])\^/g;
    function d(t, e) {
        t = t.source || t, e = e || "";
        const n = {
            replace: (e, i)=>(i = (i = i.source || i).replace(u, "$1"), t = t.replace(e, i), n),
            getRegex: ()=>new RegExp(t, e)
        };
        return n;
    }
    const h = /[^\w:]/g, g = /^$|^[a-z][a-z0-9+.-]*:|^[?#]/i;
    function m(t, e, n) {
        if (t) {
            let t;
            try {
                t = decodeURIComponent(p(n)).replace(h, "").toLowerCase();
            } catch (t) {
                return null;
            }
            if (0 === t.indexOf("javascript:") || 0 === t.indexOf("vbscript:") || 0 === t.indexOf("data:")) return null;
        }
        e && !g.test(n) && (n = function(t, e) {
            f[" " + t] || (k.test(t) ? f[" " + t] = t + "/" : f[" " + t] = S(t, "/", !0));
            const n = -1 === (t = f[" " + t]).indexOf(":");
            return "//" === e.substring(0, 2) ? n ? e : t.replace(x, "$1") + e : "/" === e.charAt(0) ? n ? e : t.replace(b, "$1") + e : t + e;
        }(e, n));
        try {
            n = encodeURI(n).replace(/%25/g, "%");
        } catch (t) {
            return null;
        }
        return n;
    }
    const f = {}, k = /^[^:]+:\/*[^/]*$/, x = /^([^:]+:)[\s\S]*$/, b = /^([^:]+:\/*[^/]*)[\s\S]*$/;
    const w = {
        exec: function() {}
    };
    function y(t) {
        let e, n, i = 1;
        for(; i < arguments.length; i++)for(n in e = arguments[i], e)Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        return t;
    }
    function v(t, e) {
        const n = t.replace(/\|/g, (t, e, n)=>{
            let i = !1, s = e;
            for(; --s >= 0 && "\\" === n[s];)i = !i;
            return i ? "|" : " |";
        }).split(/ \|/);
        let i = 0;
        if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), n.length > e) n.splice(e);
        else for(; n.length < e;)n.push("");
        for(; i < n.length; i++)n[i] = n[i].trim().replace(/\\\|/g, "|");
        return n;
    }
    function S(t, e, n) {
        const i = t.length;
        if (0 === i) return "";
        let s = 0;
        for(; s < i;){
            const r = t.charAt(i - s - 1);
            if (r !== e || n) {
                if (r === e || !n) break;
                s++;
            } else s++;
        }
        return t.substr(0, i - s);
    }
    function T(t) {
        t && t.sanitize && !t.silent && console.warn("marked(): sanitize and sanitizer parameters are deprecated since version 0.7.0, should not be used and will be removed in the future. Read more here: https://marked.js.org/#/USING_ADVANCED.md#options");
    }
    function _(t, e) {
        if (e < 1) return "";
        let n = "";
        for(; e > 1;)1 & e && (n += t), e >>= 1, t += t;
        return n + t;
    }
    function z(t, e, n, i) {
        const s = e.href, r = e.title ? o(e.title) : null, a = t[1].replace(/\\([\[\]])/g, "$1");
        if ("!" !== t[0].charAt(0)) {
            i.state.inLink = !0;
            const t = {
                type: "link",
                raw: n,
                href: s,
                title: r,
                text: a,
                tokens: i.inlineTokens(a, [])
            };
            return i.state.inLink = !1, t;
        }
        return {
            type: "image",
            raw: n,
            href: s,
            title: r,
            text: o(a)
        };
    }
    class E {
        constructor(t){
            this.options = t || e;
        }
        space(t) {
            const e = this.rules.block.newline.exec(t);
            if (e && e[0].length > 0) return {
                type: "space",
                raw: e[0]
            };
        }
        code(t) {
            const e = this.rules.block.code.exec(t);
            if (e) {
                const t = e[0].replace(/^ {1,4}/gm, "");
                return {
                    type: "code",
                    raw: e[0],
                    codeBlockStyle: "indented",
                    text: this.options.pedantic ? t : S(t, "\n")
                };
            }
        }
        fences(t) {
            const e = this.rules.block.fences.exec(t);
            if (e) {
                const t = e[0], n = function(t, e) {
                    const n = t.match(/^(\s+)(?:```)/);
                    if (null === n) return e;
                    const i = n[1];
                    return e.split("\n").map((t)=>{
                        const e = t.match(/^\s+/);
                        if (null === e) return t;
                        const [n] = e;
                        return n.length >= i.length ? t.slice(i.length) : t;
                    }).join("\n");
                }(t, e[3] || "");
                return {
                    type: "code",
                    raw: t,
                    lang: e[2] ? e[2].trim() : e[2],
                    text: n
                };
            }
        }
        heading(t) {
            const e = this.rules.block.heading.exec(t);
            if (e) {
                let t = e[2].trim();
                if (/#$/.test(t)) {
                    const e = S(t, "#");
                    this.options.pedantic ? t = e.trim() : e && !/ $/.test(e) || (t = e.trim());
                }
                const n = {
                    type: "heading",
                    raw: e[0],
                    depth: e[1].length,
                    text: t,
                    tokens: []
                };
                return this.lexer.inline(n.text, n.tokens), n;
            }
        }
        hr(t) {
            const e = this.rules.block.hr.exec(t);
            if (e) return {
                type: "hr",
                raw: e[0]
            };
        }
        blockquote(t) {
            const e = this.rules.block.blockquote.exec(t);
            if (e) {
                const t = e[0].replace(/^ *> ?/gm, "");
                return {
                    type: "blockquote",
                    raw: e[0],
                    tokens: this.lexer.blockTokens(t, []),
                    text: t
                };
            }
        }
        list(t) {
            let e = this.rules.block.list.exec(t);
            if (e) {
                let n, i, s, r, a, l, o, c, p, u, d, h, g = e[1].trim();
                const m = g.length > 1, f = {
                    type: "list",
                    raw: "",
                    ordered: m,
                    start: m ? +g.slice(0, -1) : "",
                    loose: !1,
                    items: []
                };
                g = m ? `\\d{1,9}\\${g.slice(-1)}` : `\\${g}`, this.options.pedantic && (g = m ? g : "[*+-]");
                const k = new RegExp(`^( {0,3}${g})((?: [^\\n]*)?(?:\\n|$))`);
                for(; t && (h = !1, e = k.exec(t)) && !this.rules.block.hr.test(t);){
                    if (n = e[0], t = t.substring(n.length), c = e[2].split("\n", 1)[0], p = t.split("\n", 1)[0], this.options.pedantic ? (r = 2, d = c.trimLeft()) : (r = e[2].search(/[^ ]/), r = r > 4 ? 1 : r, d = c.slice(r), r += e[1].length), l = !1, !c && /^ *$/.test(p) && (n += p + "\n", t = t.substring(p.length + 1), h = !0), !h) {
                        const e = new RegExp(`^ {0,${Math.min(3, r - 1)}}(?:[*+-]|\\d{1,9}[.)])`);
                        for(; t && (u = t.split("\n", 1)[0], c = u, this.options.pedantic && (c = c.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), !e.test(c));){
                            if (c.search(/[^ ]/) >= r || !c.trim()) d += "\n" + c.slice(r);
                            else {
                                if (l) break;
                                d += "\n" + c;
                            }
                            l || c.trim() || (l = !0), n += u + "\n", t = t.substring(u.length + 1);
                        }
                    }
                    f.loose || (o ? f.loose = !0 : /\n *\n *$/.test(n) && (o = !0)), this.options.gfm && (i = /^\[[ xX]\] /.exec(d), i && (s = "[ ] " !== i[0], d = d.replace(/^\[[ xX]\] +/, ""))), f.items.push({
                        type: "list_item",
                        raw: n,
                        task: !!i,
                        checked: s,
                        loose: !1,
                        text: d
                    }), f.raw += n;
                }
                f.items[f.items.length - 1].raw = n.trimRight(), f.items[f.items.length - 1].text = d.trimRight(), f.raw = f.raw.trimRight();
                const x = f.items.length;
                for(a = 0; a < x; a++){
                    this.lexer.state.top = !1, f.items[a].tokens = this.lexer.blockTokens(f.items[a].text, []);
                    const t = f.items[a].tokens.filter((t)=>"space" === t.type), e = t.every((t)=>{
                        const e = t.raw.split("");
                        let n = 0;
                        for (const t of e)if ("\n" === t && (n += 1), n > 1) return !0;
                        return !1;
                    });
                    !f.loose && t.length && e && (f.loose = !0, f.items[a].loose = !0);
                }
                return f;
            }
        }
        html(t) {
            const e = this.rules.block.html.exec(t);
            if (e) {
                const t = {
                    type: "html",
                    raw: e[0],
                    pre: !this.options.sanitizer && ("pre" === e[1] || "script" === e[1] || "style" === e[1]),
                    text: e[0]
                };
                return this.options.sanitize && (t.type = "paragraph", t.text = this.options.sanitizer ? this.options.sanitizer(e[0]) : o(e[0]), t.tokens = [], this.lexer.inline(t.text, t.tokens)), t;
            }
        }
        def(t) {
            const e = this.rules.block.def.exec(t);
            if (e) {
                e[3] && (e[3] = e[3].substring(1, e[3].length - 1));
                return {
                    type: "def",
                    tag: e[1].toLowerCase().replace(/\s+/g, " "),
                    raw: e[0],
                    href: e[2],
                    title: e[3]
                };
            }
        }
        table(t) {
            const e = this.rules.block.table.exec(t);
            if (e) {
                const t = {
                    type: "table",
                    header: v(e[1]).map((t)=>({
                            text: t
                        })),
                    align: e[2].replace(/^ *|\| *$/g, "").split(/ *\| */),
                    rows: e[3] && e[3].trim() ? e[3].replace(/\n[ \t]*$/, "").split("\n") : []
                };
                if (t.header.length === t.align.length) {
                    t.raw = e[0];
                    let n, i, s, r, a = t.align.length;
                    for(n = 0; n < a; n++)/^ *-+: *$/.test(t.align[n]) ? t.align[n] = "right" : /^ *:-+: *$/.test(t.align[n]) ? t.align[n] = "center" : /^ *:-+ *$/.test(t.align[n]) ? t.align[n] = "left" : t.align[n] = null;
                    for(a = t.rows.length, n = 0; n < a; n++)t.rows[n] = v(t.rows[n], t.header.length).map((t)=>({
                            text: t
                        }));
                    for(a = t.header.length, i = 0; i < a; i++)t.header[i].tokens = [], this.lexer.inlineTokens(t.header[i].text, t.header[i].tokens);
                    for(a = t.rows.length, i = 0; i < a; i++)for(r = t.rows[i], s = 0; s < r.length; s++)r[s].tokens = [], this.lexer.inlineTokens(r[s].text, r[s].tokens);
                    return t;
                }
            }
        }
        lheading(t) {
            const e = this.rules.block.lheading.exec(t);
            if (e) {
                const t = {
                    type: "heading",
                    raw: e[0],
                    depth: "=" === e[2].charAt(0) ? 1 : 2,
                    text: e[1],
                    tokens: []
                };
                return this.lexer.inline(t.text, t.tokens), t;
            }
        }
        paragraph(t) {
            const e = this.rules.block.paragraph.exec(t);
            if (e) {
                const t = {
                    type: "paragraph",
                    raw: e[0],
                    text: "\n" === e[1].charAt(e[1].length - 1) ? e[1].slice(0, -1) : e[1],
                    tokens: []
                };
                return this.lexer.inline(t.text, t.tokens), t;
            }
        }
        text(t) {
            const e = this.rules.block.text.exec(t);
            if (e) {
                const t = {
                    type: "text",
                    raw: e[0],
                    text: e[0],
                    tokens: []
                };
                return this.lexer.inline(t.text, t.tokens), t;
            }
        }
        escape(t) {
            const e = this.rules.inline.escape.exec(t);
            if (e) return {
                type: "escape",
                raw: e[0],
                text: o(e[1])
            };
        }
        tag(t) {
            const e = this.rules.inline.tag.exec(t);
            if (e) return !this.lexer.state.inLink && /^<a /i.test(e[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(e[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(e[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(e[0]) && (this.lexer.state.inRawBlock = !1), {
                type: this.options.sanitize ? "text" : "html",
                raw: e[0],
                inLink: this.lexer.state.inLink,
                inRawBlock: this.lexer.state.inRawBlock,
                text: this.options.sanitize ? this.options.sanitizer ? this.options.sanitizer(e[0]) : o(e[0]) : e[0]
            };
        }
        link(t) {
            const e = this.rules.inline.link.exec(t);
            if (e) {
                const t = e[2].trim();
                if (!this.options.pedantic && /^</.test(t)) {
                    if (!/>$/.test(t)) return;
                    const e = S(t.slice(0, -1), "\\");
                    if ((t.length - e.length) % 2 == 0) return;
                } else {
                    const t = function(t, e) {
                        if (-1 === t.indexOf(e[1])) return -1;
                        const n = t.length;
                        let i = 0, s = 0;
                        for(; s < n; s++)if ("\\" === t[s]) s++;
                        else if (t[s] === e[0]) i++;
                        else if (t[s] === e[1] && (i--, i < 0)) return s;
                        return -1;
                    }(e[2], "()");
                    if (t > -1) {
                        const n = (0 === e[0].indexOf("!") ? 5 : 4) + e[1].length + t;
                        e[2] = e[2].substring(0, t), e[0] = e[0].substring(0, n).trim(), e[3] = "";
                    }
                }
                let n = e[2], i = "";
                if (this.options.pedantic) {
                    const t = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(n);
                    t && (n = t[1], i = t[3]);
                } else i = e[3] ? e[3].slice(1, -1) : "";
                return n = n.trim(), /^</.test(n) && (n = this.options.pedantic && !/>$/.test(t) ? n.slice(1) : n.slice(1, -1)), z(e, {
                    href: n ? n.replace(this.rules.inline._escapes, "$1") : n,
                    title: i ? i.replace(this.rules.inline._escapes, "$1") : i
                }, e[0], this.lexer);
            }
        }
        reflink(t, e) {
            let n;
            if ((n = this.rules.inline.reflink.exec(t)) || (n = this.rules.inline.nolink.exec(t))) {
                let t = (n[2] || n[1]).replace(/\s+/g, " ");
                if (t = e[t.toLowerCase()], !t || !t.href) {
                    const t = n[0].charAt(0);
                    return {
                        type: "text",
                        raw: t,
                        text: t
                    };
                }
                return z(n, t, n[0], this.lexer);
            }
        }
        emStrong(t, e, n = "") {
            let i = this.rules.inline.emStrong.lDelim.exec(t);
            if (!i) return;
            if (i[3] && n.match(/[\p{L}\p{N}]/u)) return;
            const s = i[1] || i[2] || "";
            if (!s || s && ("" === n || this.rules.inline.punctuation.exec(n))) {
                const n = i[0].length - 1;
                let s, r, a = n, l = 0;
                const o = "*" === i[0][0] ? this.rules.inline.emStrong.rDelimAst : this.rules.inline.emStrong.rDelimUnd;
                for(o.lastIndex = 0, e = e.slice(-1 * t.length + n); null != (i = o.exec(e));){
                    if (s = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !s) continue;
                    if (r = s.length, i[3] || i[4]) {
                        a += r;
                        continue;
                    }
                    if ((i[5] || i[6]) && n % 3 && !((n + r) % 3)) {
                        l += r;
                        continue;
                    }
                    if (a -= r, a > 0) continue;
                    if (r = Math.min(r, r + a + l), Math.min(n, r) % 2) {
                        const e = t.slice(1, n + i.index + r);
                        return {
                            type: "em",
                            raw: t.slice(0, n + i.index + r + 1),
                            text: e,
                            tokens: this.lexer.inlineTokens(e, [])
                        };
                    }
                    const e = t.slice(2, n + i.index + r - 1);
                    return {
                        type: "strong",
                        raw: t.slice(0, n + i.index + r + 1),
                        text: e,
                        tokens: this.lexer.inlineTokens(e, [])
                    };
                }
            }
        }
        codespan(t) {
            const e = this.rules.inline.code.exec(t);
            if (e) {
                let t = e[2].replace(/\n/g, " ");
                const n = /[^ ]/.test(t), i = /^ /.test(t) && / $/.test(t);
                return n && i && (t = t.substring(1, t.length - 1)), t = o(t, !0), {
                    type: "codespan",
                    raw: e[0],
                    text: t
                };
            }
        }
        br(t) {
            const e = this.rules.inline.br.exec(t);
            if (e) return {
                type: "br",
                raw: e[0]
            };
        }
        del(t) {
            const e = this.rules.inline.del.exec(t);
            if (e) return {
                type: "del",
                raw: e[0],
                text: e[2],
                tokens: this.lexer.inlineTokens(e[2], [])
            };
        }
        autolink(t, e) {
            const n = this.rules.inline.autolink.exec(t);
            if (n) {
                let t, i;
                return "@" === n[2] ? (t = o(this.options.mangle ? e(n[1]) : n[1]), i = "mailto:" + t) : (t = o(n[1]), i = t), {
                    type: "link",
                    raw: n[0],
                    text: t,
                    href: i,
                    tokens: [
                        {
                            type: "text",
                            raw: t,
                            text: t
                        }
                    ]
                };
            }
        }
        url(t, e) {
            let n;
            if (n = this.rules.inline.url.exec(t)) {
                let t, i;
                if ("@" === n[2]) t = o(this.options.mangle ? e(n[0]) : n[0]), i = "mailto:" + t;
                else {
                    let e;
                    do e = n[0], n[0] = this.rules.inline._backpedal.exec(n[0])[0];
                    while (e !== n[0]);
                    t = o(n[0]), i = "www." === n[1] ? "http://" + t : t;
                }
                return {
                    type: "link",
                    raw: n[0],
                    text: t,
                    href: i,
                    tokens: [
                        {
                            type: "text",
                            raw: t,
                            text: t
                        }
                    ]
                };
            }
        }
        inlineText(t, e) {
            const n = this.rules.inline.text.exec(t);
            if (n) {
                let t;
                return t = this.lexer.state.inRawBlock ? this.options.sanitize ? this.options.sanitizer ? this.options.sanitizer(n[0]) : o(n[0]) : n[0] : o(this.options.smartypants ? e(n[0]) : n[0]), {
                    type: "text",
                    raw: n[0],
                    text: t
                };
            }
        }
    }
    const A = {
        newline: /^(?: *(?:\n|$))+/,
        code: /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/,
        fences: /^ {0,3}(`{3,}(?=[^`\n]*\n)|~{3,})([^\n]*)\n(?:|([\s\S]*?)\n)(?: {0,3}\1[~`]* *(?=\n|$)|$)/,
        hr: /^ {0,3}((?:- *){3,}|(?:_ *){3,}|(?:\* *){3,})(?:\n+|$)/,
        heading: /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/,
        blockquote: /^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/,
        list: /^( {0,3}bull)( [^\n]+?)?(?:\n|$)/,
        html: "^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))",
        def: /^ {0,3}\[(label)\]: *(?:\n *)?<?([^\s>]+)>?(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/,
        table: w,
        lheading: /^([^\n]+)\n {0,3}(=+|-+) *(?:\n+|$)/,
        _paragraph: /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/,
        text: /^[^\n]+/,
        _label: /(?!\s*\])(?:\\.|[^\[\]\\])+/,
        _title: /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/
    };
    A.def = d(A.def).replace("label", A._label).replace("title", A._title).getRegex(), A.bullet = /(?:[*+-]|\d{1,9}[.)])/, A.listItemStart = d(/^( *)(bull) */).replace("bull", A.bullet).getRegex(), A.list = d(A.list).replace(/bull/g, A.bullet).replace("hr", "\\n+(?=\\1?(?:(?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$))").replace("def", "\\n+(?=" + A.def.source + ")").getRegex(), A._tag = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|section|source|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", A._comment = /<!--(?!-?>)[\s\S]*?(?:-->|$)/, A.html = d(A.html, "i").replace("comment", A._comment).replace("tag", A._tag).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), A.paragraph = d(A._paragraph).replace("hr", A.hr).replace("heading", " {0,3}#{1,6} ").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", A._tag).getRegex(), A.blockquote = d(A.blockquote).replace("paragraph", A.paragraph).getRegex(), A.normal = y({}, A), A.gfm = y({}, A.normal, {
        table: "^ *([^\\n ].*\\|.*)\\n {0,3}(?:\\| *)?(:?-+:? *(?:\\| *:?-+:? *)*)(?:\\| *)?(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)"
    }), A.gfm.table = d(A.gfm.table).replace("hr", A.hr).replace("heading", " {0,3}#{1,6} ").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", A._tag).getRegex(), A.gfm.paragraph = d(A._paragraph).replace("hr", A.hr).replace("heading", " {0,3}#{1,6} ").replace("|lheading", "").replace("table", A.gfm.table).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", A._tag).getRegex(), A.pedantic = y({}, A.normal, {
        html: d("^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:\"[^\"]*\"|'[^']*'|\\s[^'\"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))").replace("comment", A._comment).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
        def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
        heading: /^(#{1,6})(.*)(?:\n+|$)/,
        fences: w,
        paragraph: d(A.normal._paragraph).replace("hr", A.hr).replace("heading", " *#{1,6} *[^\n]").replace("lheading", A.lheading).replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").getRegex()
    });
    const $ = {
        escape: /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/,
        autolink: /^<(scheme:[^\s\x00-\x1f<>]*|email)>/,
        url: w,
        tag: "^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>",
        link: /^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/,
        reflink: /^!?\[(label)\]\[(ref)\]/,
        nolink: /^!?\[(ref)\](?:\[\])?/,
        reflinkSearch: "reflink|nolink(?!\\()",
        emStrong: {
            lDelim: /^(?:\*+(?:([punct_])|[^\s*]))|^_+(?:([punct*])|([^\s_]))/,
            rDelimAst: /^[^_*]*?\_\_[^_*]*?\*[^_*]*?(?=\_\_)|[punct_](\*+)(?=[\s]|$)|[^punct*_\s](\*+)(?=[punct_\s]|$)|[punct_\s](\*+)(?=[^punct*_\s])|[\s](\*+)(?=[punct_])|[punct_](\*+)(?=[punct_])|[^punct*_\s](\*+)(?=[^punct*_\s])/,
            rDelimUnd: /^[^_*]*?\*\*[^_*]*?\_[^_*]*?(?=\*\*)|[punct*](\_+)(?=[\s]|$)|[^punct*_\s](\_+)(?=[punct*\s]|$)|[punct*\s](\_+)(?=[^punct*_\s])|[\s](\_+)(?=[punct*])|[punct*](\_+)(?=[punct*])/
        },
        code: /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/,
        br: /^( {2,}|\\)\n(?!\s*$)/,
        del: w,
        text: /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/,
        punctuation: /^([\spunctuation])/
    };
    function L(t) {
        return t.replace(/---/g, "\u2014").replace(/--/g, "\u2013").replace(/(^|[-\u2014/(\[{"\s])'/g, "$1\u2018").replace(/'/g, "\u2019").replace(/(^|[-\u2014/(\[{\u2018\s])"/g, "$1\u201C").replace(/"/g, "\u201D").replace(/\.{3}/g, "\u2026");
    }
    function R(t) {
        let e, n, i = "";
        const s = t.length;
        for(e = 0; e < s; e++)n = t.charCodeAt(e), Math.random() > .5 && (n = "x" + n.toString(16)), i += "&#" + n + ";";
        return i;
    }
    $._punctuation = "!\"#$%&'()+\\-.,/:;<=>?@\\[\\]`^{|}~", $.punctuation = d($.punctuation).replace(/punctuation/g, $._punctuation).getRegex(), $.blockSkip = /\[[^\]]*?\]\([^\)]*?\)|`[^`]*?`|<[^>]*?>/g, $.escapedEmSt = /\\\*|\\_/g, $._comment = d(A._comment).replace("(?:-->|$)", "-->").getRegex(), $.emStrong.lDelim = d($.emStrong.lDelim).replace(/punct/g, $._punctuation).getRegex(), $.emStrong.rDelimAst = d($.emStrong.rDelimAst, "g").replace(/punct/g, $._punctuation).getRegex(), $.emStrong.rDelimUnd = d($.emStrong.rDelimUnd, "g").replace(/punct/g, $._punctuation).getRegex(), $._escapes = /\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/g, $._scheme = /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/, $._email = /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/, $.autolink = d($.autolink).replace("scheme", $._scheme).replace("email", $._email).getRegex(), $._attribute = /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/, $.tag = d($.tag).replace("comment", $._comment).replace("attribute", $._attribute).getRegex(), $._label = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, $._href = /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/, $._title = /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/, $.link = d($.link).replace("label", $._label).replace("href", $._href).replace("title", $._title).getRegex(), $.reflink = d($.reflink).replace("label", $._label).replace("ref", A._label).getRegex(), $.nolink = d($.nolink).replace("ref", A._label).getRegex(), $.reflinkSearch = d($.reflinkSearch, "g").replace("reflink", $.reflink).replace("nolink", $.nolink).getRegex(), $.normal = y({}, $), $.pedantic = y({}, $.normal, {
        strong: {
            start: /^__|\*\*/,
            middle: /^__(?=\S)([\s\S]*?\S)__(?!_)|^\*\*(?=\S)([\s\S]*?\S)\*\*(?!\*)/,
            endAst: /\*\*(?!\*)/g,
            endUnd: /__(?!_)/g
        },
        em: {
            start: /^_|\*/,
            middle: /^()\*(?=\S)([\s\S]*?\S)\*(?!\*)|^_(?=\S)([\s\S]*?\S)_(?!_)/,
            endAst: /\*(?!\*)/g,
            endUnd: /_(?!_)/g
        },
        link: d(/^!?\[(label)\]\((.*?)\)/).replace("label", $._label).getRegex(),
        reflink: d(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", $._label).getRegex()
    }), $.gfm = y({}, $.normal, {
        escape: d($.escape).replace("])", "~|])").getRegex(),
        _extended_email: /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/,
        url: /^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/,
        _backpedal: /(?:[^?!.,:;*_~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_~)]+(?!$))+/,
        del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
        text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
    }), $.gfm.url = d($.gfm.url, "i").replace("email", $.gfm._extended_email).getRegex(), $.breaks = y({}, $.gfm, {
        br: d($.br).replace("{2,}", "*").getRegex(),
        text: d($.gfm.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
    });
    class I {
        constructor(t){
            this.tokens = [], this.tokens.links = Object.create(null), this.options = t || e, this.options.tokenizer = this.options.tokenizer || new E, this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
                inLink: !1,
                inRawBlock: !1,
                top: !0
            };
            const n = {
                block: A.normal,
                inline: $.normal
            };
            this.options.pedantic ? (n.block = A.pedantic, n.inline = $.pedantic) : this.options.gfm && (n.block = A.gfm, this.options.breaks ? n.inline = $.breaks : n.inline = $.gfm), this.tokenizer.rules = n;
        }
        static get rules() {
            return {
                block: A,
                inline: $
            };
        }
        static lex(t, e) {
            return new I(e).lex(t);
        }
        static lexInline(t, e) {
            return new I(e).inlineTokens(t);
        }
        lex(t) {
            let e;
            for(t = t.replace(/\r\n|\r/g, "\n").replace(/\t/g, "    "), this.blockTokens(t, this.tokens); e = this.inlineQueue.shift();)this.inlineTokens(e.src, e.tokens);
            return this.tokens;
        }
        blockTokens(t, e = []) {
            let n, i, s, r;
            for(this.options.pedantic && (t = t.replace(/^ +$/gm, "")); t;)if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((i)=>!!(n = i.call({
                    lexer: this
                }, t, e)) && (t = t.substring(n.raw.length), e.push(n), !0)))) {
                if (n = this.tokenizer.space(t)) t = t.substring(n.raw.length), 1 === n.raw.length && e.length > 0 ? e[e.length - 1].raw += "\n" : e.push(n);
                else if (n = this.tokenizer.code(t)) t = t.substring(n.raw.length), i = e[e.length - 1], !i || "paragraph" !== i.type && "text" !== i.type ? e.push(n) : (i.raw += "\n" + n.raw, i.text += "\n" + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = i.text);
                else if (n = this.tokenizer.fences(t)) t = t.substring(n.raw.length), e.push(n);
                else if (n = this.tokenizer.heading(t)) t = t.substring(n.raw.length), e.push(n);
                else if (n = this.tokenizer.hr(t)) t = t.substring(n.raw.length), e.push(n);
                else if (n = this.tokenizer.blockquote(t)) t = t.substring(n.raw.length), e.push(n);
                else if (n = this.tokenizer.list(t)) t = t.substring(n.raw.length), e.push(n);
                else if (n = this.tokenizer.html(t)) t = t.substring(n.raw.length), e.push(n);
                else if (n = this.tokenizer.def(t)) t = t.substring(n.raw.length), i = e[e.length - 1], !i || "paragraph" !== i.type && "text" !== i.type ? this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
                    href: n.href,
                    title: n.title
                }) : (i.raw += "\n" + n.raw, i.text += "\n" + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = i.text);
                else if (n = this.tokenizer.table(t)) t = t.substring(n.raw.length), e.push(n);
                else if (n = this.tokenizer.lheading(t)) t = t.substring(n.raw.length), e.push(n);
                else {
                    if (s = t, this.options.extensions && this.options.extensions.startBlock) {
                        let e = 1 / 0;
                        const n = t.slice(1);
                        let i;
                        this.options.extensions.startBlock.forEach(function(t) {
                            i = t.call({
                                lexer: this
                            }, n), "number" == typeof i && i >= 0 && (e = Math.min(e, i));
                        }), e < 1 / 0 && e >= 0 && (s = t.substring(0, e + 1));
                    }
                    if (this.state.top && (n = this.tokenizer.paragraph(s))) i = e[e.length - 1], r && "paragraph" === i.type ? (i.raw += "\n" + n.raw, i.text += "\n" + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : e.push(n), r = s.length !== t.length, t = t.substring(n.raw.length);
                    else if (n = this.tokenizer.text(t)) t = t.substring(n.raw.length), i = e[e.length - 1], i && "text" === i.type ? (i.raw += "\n" + n.raw, i.text += "\n" + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : e.push(n);
                    else if (t) {
                        const e = "Infinite loop on byte: " + t.charCodeAt(0);
                        if (this.options.silent) {
                            console.error(e);
                            break;
                        }
                        throw new Error(e);
                    }
                }
            }
            return this.state.top = !0, e;
        }
        inline(t, e) {
            this.inlineQueue.push({
                src: t,
                tokens: e
            });
        }
        inlineTokens(t, e = []) {
            let n, i, s, r, a, l, o = t;
            if (this.tokens.links) {
                const t = Object.keys(this.tokens.links);
                if (t.length > 0) for(; null != (r = this.tokenizer.rules.inline.reflinkSearch.exec(o));)t.includes(r[0].slice(r[0].lastIndexOf("[") + 1, -1)) && (o = o.slice(0, r.index) + "[" + _("a", r[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
            }
            for(; null != (r = this.tokenizer.rules.inline.blockSkip.exec(o));)o = o.slice(0, r.index) + "[" + _("a", r[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
            for(; null != (r = this.tokenizer.rules.inline.escapedEmSt.exec(o));)o = o.slice(0, r.index) + "++" + o.slice(this.tokenizer.rules.inline.escapedEmSt.lastIndex);
            for(; t;)if (a || (l = ""), a = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((i)=>!!(n = i.call({
                    lexer: this
                }, t, e)) && (t = t.substring(n.raw.length), e.push(n), !0)))) {
                if (n = this.tokenizer.escape(t)) t = t.substring(n.raw.length), e.push(n);
                else if (n = this.tokenizer.tag(t)) t = t.substring(n.raw.length), i = e[e.length - 1], i && "text" === n.type && "text" === i.type ? (i.raw += n.raw, i.text += n.text) : e.push(n);
                else if (n = this.tokenizer.link(t)) t = t.substring(n.raw.length), e.push(n);
                else if (n = this.tokenizer.reflink(t, this.tokens.links)) t = t.substring(n.raw.length), i = e[e.length - 1], i && "text" === n.type && "text" === i.type ? (i.raw += n.raw, i.text += n.text) : e.push(n);
                else if (n = this.tokenizer.emStrong(t, o, l)) t = t.substring(n.raw.length), e.push(n);
                else if (n = this.tokenizer.codespan(t)) t = t.substring(n.raw.length), e.push(n);
                else if (n = this.tokenizer.br(t)) t = t.substring(n.raw.length), e.push(n);
                else if (n = this.tokenizer.del(t)) t = t.substring(n.raw.length), e.push(n);
                else if (n = this.tokenizer.autolink(t, R)) t = t.substring(n.raw.length), e.push(n);
                else if (this.state.inLink || !(n = this.tokenizer.url(t, R))) {
                    if (s = t, this.options.extensions && this.options.extensions.startInline) {
                        let e = 1 / 0;
                        const n = t.slice(1);
                        let i;
                        this.options.extensions.startInline.forEach(function(t) {
                            i = t.call({
                                lexer: this
                            }, n), "number" == typeof i && i >= 0 && (e = Math.min(e, i));
                        }), e < 1 / 0 && e >= 0 && (s = t.substring(0, e + 1));
                    }
                    if (n = this.tokenizer.inlineText(s, L)) t = t.substring(n.raw.length), "_" !== n.raw.slice(-1) && (l = n.raw.slice(-1)), a = !0, i = e[e.length - 1], i && "text" === i.type ? (i.raw += n.raw, i.text += n.text) : e.push(n);
                    else if (t) {
                        const e = "Infinite loop on byte: " + t.charCodeAt(0);
                        if (this.options.silent) {
                            console.error(e);
                            break;
                        }
                        throw new Error(e);
                    }
                } else t = t.substring(n.raw.length), e.push(n);
            }
            return e;
        }
    }
    class C {
        constructor(t){
            this.options = t || e;
        }
        code(t, e, n) {
            const i = (e || "").match(/\S*/)[0];
            if (this.options.highlight) {
                const e = this.options.highlight(t, i);
                null != e && e !== t && (n = !0, t = e);
            }
            return t = t.replace(/\n$/, "") + "\n", i ? '<pre><code class="' + this.options.langPrefix + o(i, !0) + '">' + (n ? t : o(t, !0)) + "</code></pre>\n" : "<pre><code>" + (n ? t : o(t, !0)) + "</code></pre>\n";
        }
        blockquote(t) {
            return "<blockquote>\n" + t + "</blockquote>\n";
        }
        html(t) {
            return t;
        }
        heading(t, e, n, i) {
            return this.options.headerIds ? "<h" + e + ' id="' + this.options.headerPrefix + i.slug(n) + '">' + t + "</h" + e + ">\n" : "<h" + e + ">" + t + "</h" + e + ">\n";
        }
        hr() {
            return this.options.xhtml ? "<hr/>\n" : "<hr>\n";
        }
        list(t, e, n) {
            const i = e ? "ol" : "ul";
            return "<" + i + (e && 1 !== n ? ' start="' + n + '"' : "") + ">\n" + t + "</" + i + ">\n";
        }
        listitem(t) {
            return "<li>" + t + "</li>\n";
        }
        checkbox(t) {
            return "<input " + (t ? 'checked="" ' : "") + 'disabled="" type="checkbox"' + (this.options.xhtml ? " /" : "") + "> ";
        }
        paragraph(t) {
            return "<p>" + t + "</p>\n";
        }
        table(t, e) {
            return e && (e = "<tbody>" + e + "</tbody>"), "<table>\n<thead>\n" + t + "</thead>\n" + e + "</table>\n";
        }
        tablerow(t) {
            return "<tr>\n" + t + "</tr>\n";
        }
        tablecell(t, e) {
            const n = e.header ? "th" : "td";
            return (e.align ? "<" + n + ' align="' + e.align + '">' : "<" + n + ">") + t + "</" + n + ">\n";
        }
        strong(t) {
            return "<strong>" + t + "</strong>";
        }
        em(t) {
            return "<em>" + t + "</em>";
        }
        codespan(t) {
            return "<code>" + t + "</code>";
        }
        br() {
            return this.options.xhtml ? "<br/>" : "<br>";
        }
        del(t) {
            return "<del>" + t + "</del>";
        }
        link(t, e, n) {
            if (null === (t = m(this.options.sanitize, this.options.baseUrl, t))) return n;
            let i = '<a href="' + o(t) + '"';
            return e && (i += ' title="' + e + '"'), i += ">" + n + "</a>", i;
        }
        image(t, e, n) {
            if (null === (t = m(this.options.sanitize, this.options.baseUrl, t))) return n;
            let i = '<img src="' + t + '" alt="' + n + '"';
            return e && (i += ' title="' + e + '"'), i += this.options.xhtml ? "/>" : ">", i;
        }
        text(t) {
            return t;
        }
    }
    class M {
        strong(t) {
            return t;
        }
        em(t) {
            return t;
        }
        codespan(t) {
            return t;
        }
        del(t) {
            return t;
        }
        html(t) {
            return t;
        }
        text(t) {
            return t;
        }
        link(t, e, n) {
            return "" + n;
        }
        image(t, e, n) {
            return "" + n;
        }
        br() {
            return "";
        }
    }
    class q {
        constructor(){
            this.seen = {};
        }
        serialize(t) {
            return t.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, "").replace(/[\u2000-\u206F\u2E00-\u2E7F\\'!"#$%&()*+,./:;<=>?@[\]^`{|}~]/g, "").replace(/\s/g, "-");
        }
        getNextSafeSlug(t, e) {
            let n = t, i = 0;
            if (this.seen.hasOwnProperty(n)) {
                i = this.seen[t];
                do i++, n = t + "-" + i;
                while (this.seen.hasOwnProperty(n));
            }
            return e || (this.seen[t] = i, this.seen[n] = 0), n;
        }
        slug(t, e = {}) {
            const n = this.serialize(t);
            return this.getNextSafeSlug(n, e.dryrun);
        }
    }
    class O {
        constructor(t){
            this.options = t || e, this.options.renderer = this.options.renderer || new C, this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new M, this.slugger = new q;
        }
        static parse(t, e) {
            return new O(e).parse(t);
        }
        static parseInline(t, e) {
            return new O(e).parseInline(t);
        }
        parse(t, e = !0) {
            let n, i, s, r, a, l, o, c, u, d, h, g, m, f, k, x, b, w, y, v = "";
            const S = t.length;
            for(n = 0; n < S; n++)if (d = t[n], this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[d.type] && (y = this.options.extensions.renderers[d.type].call({
                parser: this
            }, d), !1 !== y || ![
                "space",
                "hr",
                "heading",
                "code",
                "table",
                "blockquote",
                "list",
                "html",
                "paragraph",
                "text"
            ].includes(d.type))) v += y || "";
            else switch(d.type){
                case "space":
                    continue;
                case "hr":
                    v += this.renderer.hr();
                    continue;
                case "heading":
                    v += this.renderer.heading(this.parseInline(d.tokens), d.depth, p(this.parseInline(d.tokens, this.textRenderer)), this.slugger);
                    continue;
                case "code":
                    v += this.renderer.code(d.text, d.lang, d.escaped);
                    continue;
                case "table":
                    for(c = "", o = "", r = d.header.length, i = 0; i < r; i++)o += this.renderer.tablecell(this.parseInline(d.header[i].tokens), {
                        header: !0,
                        align: d.align[i]
                    });
                    for(c += this.renderer.tablerow(o), u = "", r = d.rows.length, i = 0; i < r; i++){
                        for(l = d.rows[i], o = "", a = l.length, s = 0; s < a; s++)o += this.renderer.tablecell(this.parseInline(l[s].tokens), {
                            header: !1,
                            align: d.align[s]
                        });
                        u += this.renderer.tablerow(o);
                    }
                    v += this.renderer.table(c, u);
                    continue;
                case "blockquote":
                    u = this.parse(d.tokens), v += this.renderer.blockquote(u);
                    continue;
                case "list":
                    for(h = d.ordered, g = d.start, m = d.loose, r = d.items.length, u = "", i = 0; i < r; i++)k = d.items[i], x = k.checked, b = k.task, f = "", k.task && (w = this.renderer.checkbox(x), m ? k.tokens.length > 0 && "paragraph" === k.tokens[0].type ? (k.tokens[0].text = w + " " + k.tokens[0].text, k.tokens[0].tokens && k.tokens[0].tokens.length > 0 && "text" === k.tokens[0].tokens[0].type && (k.tokens[0].tokens[0].text = w + " " + k.tokens[0].tokens[0].text)) : k.tokens.unshift({
                        type: "text",
                        text: w
                    }) : f += w), f += this.parse(k.tokens, m), u += this.renderer.listitem(f, b, x);
                    v += this.renderer.list(u, h, g);
                    continue;
                case "html":
                    v += this.renderer.html(d.text);
                    continue;
                case "paragraph":
                    v += this.renderer.paragraph(this.parseInline(d.tokens));
                    continue;
                case "text":
                    for(u = d.tokens ? this.parseInline(d.tokens) : d.text; n + 1 < S && "text" === t[n + 1].type;)d = t[++n], u += "\n" + (d.tokens ? this.parseInline(d.tokens) : d.text);
                    v += e ? this.renderer.paragraph(u) : u;
                    continue;
                default:
                    {
                        const t = 'Token with "' + d.type + '" type was not found.';
                        if (this.options.silent) return void console.error(t);
                        throw new Error(t);
                    }
            }
            return v;
        }
        parseInline(t, e) {
            e = e || this.renderer;
            let n, i, s, r = "";
            const a = t.length;
            for(n = 0; n < a; n++)if (i = t[n], this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type] && (s = this.options.extensions.renderers[i.type].call({
                parser: this
            }, i), !1 !== s || ![
                "escape",
                "html",
                "link",
                "image",
                "strong",
                "em",
                "codespan",
                "br",
                "del",
                "text"
            ].includes(i.type))) r += s || "";
            else switch(i.type){
                case "escape":
                    r += e.text(i.text);
                    break;
                case "html":
                    r += e.html(i.text);
                    break;
                case "link":
                    r += e.link(i.href, i.title, this.parseInline(i.tokens, e));
                    break;
                case "image":
                    r += e.image(i.href, i.title, i.text);
                    break;
                case "strong":
                    r += e.strong(this.parseInline(i.tokens, e));
                    break;
                case "em":
                    r += e.em(this.parseInline(i.tokens, e));
                    break;
                case "codespan":
                    r += e.codespan(i.text);
                    break;
                case "br":
                    r += e.br();
                    break;
                case "del":
                    r += e.del(this.parseInline(i.tokens, e));
                    break;
                case "text":
                    r += e.text(i.text);
                    break;
                default:
                    {
                        const t = 'Token with "' + i.type + '" type was not found.';
                        if (this.options.silent) return void console.error(t);
                        throw new Error(t);
                    }
            }
            return r;
        }
    }
    function N(t, e, n) {
        if (null == t) throw new Error("marked(): input parameter is undefined or null");
        if ("string" != typeof t) throw new Error("marked(): input parameter is of type " + Object.prototype.toString.call(t) + ", string expected");
        if ("function" == typeof e && (n = e, e = null), T(e = y({}, N.defaults, e || {})), n) {
            const i = e.highlight;
            let s;
            try {
                s = I.lex(t, e);
            } catch (t) {
                return n(t);
            }
            const r = function(t) {
                let r;
                if (!t) try {
                    e.walkTokens && N.walkTokens(s, e.walkTokens), r = O.parse(s, e);
                } catch (e) {
                    t = e;
                }
                return e.highlight = i, t ? n(t) : n(null, r);
            };
            if (!i || i.length < 3) return r();
            if (delete e.highlight, !s.length) return r();
            let a = 0;
            return N.walkTokens(s, function(t) {
                "code" === t.type && (a++, setTimeout(()=>{
                    i(t.text, t.lang, function(e, n) {
                        if (e) return r(e);
                        null != n && n !== t.text && (t.text = n, t.escaped = !0), a--, 0 === a && r();
                    });
                }, 0));
            }), void (0 === a && r());
        }
        try {
            const n = I.lex(t, e);
            return e.walkTokens && N.walkTokens(n, e.walkTokens), O.parse(n, e);
        } catch (t) {
            if (t.message += "\nPlease report this to https://github.com/markedjs/marked.", e.silent) return "<p>An error occurred:</p><pre>" + o(t.message + "", !0) + "</pre>";
            throw t;
        }
    }
    N.options = N.setOptions = function(t) {
        var n;
        return y(N.defaults, t), n = N.defaults, e = n, N;
    }, N.getDefaults = t, N.defaults = e, N.use = function(...t) {
        const e = y({}, ...t), n = N.defaults.extensions || {
            renderers: {},
            childTokens: {}
        };
        let i;
        t.forEach((t)=>{
            if (t.extensions && (i = !0, t.extensions.forEach((t)=>{
                if (!t.name) throw new Error("extension name required");
                if (t.renderer) {
                    const e = n.renderers ? n.renderers[t.name] : null;
                    n.renderers[t.name] = e ? function(...n) {
                        let i = t.renderer.apply(this, n);
                        return !1 === i && (i = e.apply(this, n)), i;
                    } : t.renderer;
                }
                if (t.tokenizer) {
                    if (!t.level || "block" !== t.level && "inline" !== t.level) throw new Error("extension level must be 'block' or 'inline'");
                    n[t.level] ? n[t.level].unshift(t.tokenizer) : n[t.level] = [
                        t.tokenizer
                    ], t.start && ("block" === t.level ? n.startBlock ? n.startBlock.push(t.start) : n.startBlock = [
                        t.start
                    ] : "inline" === t.level && (n.startInline ? n.startInline.push(t.start) : n.startInline = [
                        t.start
                    ]));
                }
                t.childTokens && (n.childTokens[t.name] = t.childTokens);
            })), t.renderer) {
                const n = N.defaults.renderer || new C;
                for(const e in t.renderer){
                    const i = n[e];
                    n[e] = (...s)=>{
                        let r = t.renderer[e].apply(n, s);
                        return !1 === r && (r = i.apply(n, s)), r;
                    };
                }
                e.renderer = n;
            }
            if (t.tokenizer) {
                const n = N.defaults.tokenizer || new E;
                for(const e in t.tokenizer){
                    const i = n[e];
                    n[e] = (...s)=>{
                        let r = t.tokenizer[e].apply(n, s);
                        return !1 === r && (r = i.apply(n, s)), r;
                    };
                }
                e.tokenizer = n;
            }
            if (t.walkTokens) {
                const n = N.defaults.walkTokens;
                e.walkTokens = function(e) {
                    t.walkTokens.call(this, e), n && n.call(this, e);
                };
            }
            i && (e.extensions = n), N.setOptions(e);
        });
    }, N.walkTokens = function(t, e) {
        for (const n of t)switch(e.call(N, n), n.type){
            case "table":
                for (const t of n.header)N.walkTokens(t.tokens, e);
                for (const t of n.rows)for (const n of t)N.walkTokens(n.tokens, e);
                break;
            case "list":
                N.walkTokens(n.items, e);
                break;
            default:
                N.defaults.extensions && N.defaults.extensions.childTokens && N.defaults.extensions.childTokens[n.type] ? N.defaults.extensions.childTokens[n.type].forEach(function(t) {
                    N.walkTokens(n[t], e);
                }) : n.tokens && N.walkTokens(n.tokens, e);
        }
    }, N.parseInline = function(t, e) {
        if (null == t) throw new Error("marked.parseInline(): input parameter is undefined or null");
        if ("string" != typeof t) throw new Error("marked.parseInline(): input parameter is of type " + Object.prototype.toString.call(t) + ", string expected");
        T(e = y({}, N.defaults, e || {}));
        try {
            const n = I.lexInline(t, e);
            return e.walkTokens && N.walkTokens(n, e.walkTokens), O.parseInline(n, e);
        } catch (t) {
            if (t.message += "\nPlease report this to https://github.com/markedjs/marked.", e.silent) return "<p>An error occurred:</p><pre>" + o(t.message + "", !0) + "</pre>";
            throw t;
        }
    }, N.Parser = O, N.parser = O.parse, N.Renderer = C, N.TextRenderer = M, N.Lexer = I, N.lexer = I.lex, N.Tokenizer = E, N.Slugger = q, N.parse = N;
    return ()=>{
        let t, e, n = null;
        function i() {
            if (n && !n.closed) n.focus();
            else {
                if (n = window.open("about:blank", "reveal.js - Notes", "width=1100,height=700"), n.marked = N, n.document.write("<!--\n	NOTE: You need to build the notes plugin after making changes to this file.\n-->\n<html lang=\"en\">\n	<head>\n		<meta charset=\"utf-8\">\n\n		<title>reveal.js - Speaker View</title>\n\n		<style>\n			body {\n				font-family: Helvetica;\n				font-size: 18px;\n			}\n\n			#current-slide,\n			#upcoming-slide,\n			#speaker-controls {\n				padding: 6px;\n				box-sizing: border-box;\n				-moz-box-sizing: border-box;\n			}\n\n			#current-slide iframe,\n			#upcoming-slide iframe {\n				width: 100%;\n				height: 100%;\n				border: 1px solid #ddd;\n			}\n\n			#current-slide .label,\n			#upcoming-slide .label {\n				position: absolute;\n				top: 10px;\n				left: 10px;\n				z-index: 2;\n			}\n\n			#connection-status {\n				position: absolute;\n				top: 0;\n				left: 0;\n				width: 100%;\n				height: 100%;\n				z-index: 20;\n				padding: 30% 20% 20% 20%;\n				font-size: 18px;\n				color: #222;\n				background: #fff;\n				text-align: center;\n				box-sizing: border-box;\n				line-height: 1.4;\n			}\n\n			.overlay-element {\n				height: 34px;\n				line-height: 34px;\n				padding: 0 10px;\n				text-shadow: none;\n				background: rgba( 220, 220, 220, 0.8 );\n				color: #222;\n				font-size: 14px;\n			}\n\n			.overlay-element.interactive:hover {\n				background: rgba( 220, 220, 220, 1 );\n			}\n\n			#current-slide {\n				position: absolute;\n				width: 60%;\n				height: 100%;\n				top: 0;\n				left: 0;\n				padding-right: 0;\n			}\n\n			#upcoming-slide {\n				position: absolute;\n				width: 40%;\n				height: 40%;\n				right: 0;\n				top: 0;\n			}\n\n			/* Speaker controls */\n			#speaker-controls {\n				position: absolute;\n				top: 40%;\n				right: 0;\n				width: 40%;\n				height: 60%;\n				overflow: auto;\n				font-size: 18px;\n			}\n\n				.speaker-controls-time.hidden,\n				.speaker-controls-notes.hidden {\n					display: none;\n				}\n\n				.speaker-controls-time .label,\n				.speaker-controls-pace .label,\n				.speaker-controls-notes .label {\n					text-transform: uppercase;\n					font-weight: normal;\n					font-size: 0.66em;\n					color: #666;\n					margin: 0;\n				}\n\n				.speaker-controls-time, .speaker-controls-pace {\n					border-bottom: 1px solid rgba( 200, 200, 200, 0.5 );\n					margin-bottom: 10px;\n					padding: 10px 16px;\n					padding-bottom: 20px;\n					cursor: pointer;\n				}\n\n				.speaker-controls-time .reset-button {\n					opacity: 0;\n					float: right;\n					color: #666;\n					text-decoration: none;\n				}\n				.speaker-controls-time:hover .reset-button {\n					opacity: 1;\n				}\n\n				.speaker-controls-time .timer,\n				.speaker-controls-time .clock {\n					width: 50%;\n				}\n\n				.speaker-controls-time .timer,\n				.speaker-controls-time .clock,\n				.speaker-controls-time .pacing .hours-value,\n				.speaker-controls-time .pacing .minutes-value,\n				.speaker-controls-time .pacing .seconds-value {\n					font-size: 1.9em;\n				}\n\n				.speaker-controls-time .timer {\n					float: left;\n				}\n\n				.speaker-controls-time .clock {\n					float: right;\n					text-align: right;\n				}\n\n				.speaker-controls-time span.mute {\n					opacity: 0.3;\n				}\n\n				.speaker-controls-time .pacing-title {\n					margin-top: 5px;\n				}\n\n				.speaker-controls-time .pacing.ahead {\n					color: blue;\n				}\n\n				.speaker-controls-time .pacing.on-track {\n					color: green;\n				}\n\n				.speaker-controls-time .pacing.behind {\n					color: red;\n				}\n\n				.speaker-controls-notes {\n					padding: 10px 16px;\n				}\n\n				.speaker-controls-notes .value {\n					margin-top: 5px;\n					line-height: 1.4;\n					font-size: 1.2em;\n				}\n\n			/* Layout selector\xa0*/\n			#speaker-layout {\n				position: absolute;\n				top: 10px;\n				right: 10px;\n				color: #222;\n				z-index: 10;\n			}\n				#speaker-layout select {\n					position: absolute;\n					width: 100%;\n					height: 100%;\n					top: 0;\n					left: 0;\n					border: 0;\n					box-shadow: 0;\n					cursor: pointer;\n					opacity: 0;\n\n					font-size: 1em;\n					background-color: transparent;\n\n					-moz-appearance: none;\n					-webkit-appearance: none;\n					-webkit-tap-highlight-color: rgba(0, 0, 0, 0);\n				}\n\n				#speaker-layout select:focus {\n					outline: none;\n					box-shadow: none;\n				}\n\n			.clear {\n				clear: both;\n			}\n\n			/* Speaker layout: Wide */\n			body[data-speaker-layout=\"wide\"] #current-slide,\n			body[data-speaker-layout=\"wide\"] #upcoming-slide {\n				width: 50%;\n				height: 45%;\n				padding: 6px;\n			}\n\n			body[data-speaker-layout=\"wide\"] #current-slide {\n				top: 0;\n				left: 0;\n			}\n\n			body[data-speaker-layout=\"wide\"] #upcoming-slide {\n				top: 0;\n				left: 50%;\n			}\n\n			body[data-speaker-layout=\"wide\"] #speaker-controls {\n				top: 45%;\n				left: 0;\n				width: 100%;\n				height: 50%;\n				font-size: 1.25em;\n			}\n\n			/* Speaker layout: Tall */\n			body[data-speaker-layout=\"tall\"] #current-slide,\n			body[data-speaker-layout=\"tall\"] #upcoming-slide {\n				width: 45%;\n				height: 50%;\n				padding: 6px;\n			}\n\n			body[data-speaker-layout=\"tall\"] #current-slide {\n				top: 0;\n				left: 0;\n			}\n\n			body[data-speaker-layout=\"tall\"] #upcoming-slide {\n				top: 50%;\n				left: 0;\n			}\n\n			body[data-speaker-layout=\"tall\"] #speaker-controls {\n				padding-top: 40px;\n				top: 0;\n				left: 45%;\n				width: 55%;\n				height: 100%;\n				font-size: 1.25em;\n			}\n\n			/* Speaker layout: Notes only */\n			body[data-speaker-layout=\"notes-only\"] #current-slide,\n			body[data-speaker-layout=\"notes-only\"] #upcoming-slide {\n				display: none;\n			}\n\n			body[data-speaker-layout=\"notes-only\"] #speaker-controls {\n				padding-top: 40px;\n				top: 0;\n				left: 0;\n				width: 100%;\n				height: 100%;\n				font-size: 1.25em;\n			}\n\n			@media screen and (max-width: 1080px) {\n				body[data-speaker-layout=\"default\"] #speaker-controls {\n					font-size: 16px;\n				}\n			}\n\n			@media screen and (max-width: 900px) {\n				body[data-speaker-layout=\"default\"] #speaker-controls {\n					font-size: 14px;\n				}\n			}\n\n			@media screen and (max-width: 800px) {\n				body[data-speaker-layout=\"default\"] #speaker-controls {\n					font-size: 12px;\n				}\n			}\n\n		</style>\n	</head>\n\n	<body>\n\n		<div id=\"connection-status\">Loading speaker view...</div>\n\n		<div id=\"current-slide\"></div>\n		<div id=\"upcoming-slide\"><span class=\"overlay-element label\">Upcoming</span></div>\n		<div id=\"speaker-controls\">\n			<div class=\"speaker-controls-time\">\n				<h4 class=\"label\">Time <span class=\"reset-button\">Click to Reset</span></h4>\n				<div class=\"clock\">\n					<span class=\"clock-value\">0:00 AM</span>\n				</div>\n				<div class=\"timer\">\n					<span class=\"hours-value\">00</span><span class=\"minutes-value\">:00</span><span class=\"seconds-value\">:00</span>\n				</div>\n				<div class=\"clear\"></div>\n\n				<h4 class=\"label pacing-title\" style=\"display: none\">Pacing \u2013 Time to finish current slide</h4>\n				<div class=\"pacing\" style=\"display: none\">\n					<span class=\"hours-value\">00</span><span class=\"minutes-value\">:00</span><span class=\"seconds-value\">:00</span>\n				</div>\n			</div>\n\n			<div class=\"speaker-controls-notes hidden\">\n				<h4 class=\"label\">Notes</h4>\n				<div class=\"value\"></div>\n			</div>\n		</div>\n		<div id=\"speaker-layout\" class=\"overlay-element interactive\">\n			<span class=\"speaker-layout-label\"></span>\n			<select class=\"speaker-layout-dropdown\"></select>\n		</div>\n\n		<script>\n\n			(function() {\n\n				var notes,\n					notesValue,\n					currentState,\n					currentSlide,\n					upcomingSlide,\n					layoutLabel,\n					layoutDropdown,\n					pendingCalls = {},\n					lastRevealApiCallId = 0,\n					connected = false\n\n				var connectionStatus = document.querySelector( '#connection-status' );\n\n				var SPEAKER_LAYOUTS = {\n					'default': 'Default',\n					'wide': 'Wide',\n					'tall': 'Tall',\n					'notes-only': 'Notes only'\n				};\n\n				setupLayout();\n\n				let openerOrigin;\n\n				try {\n					openerOrigin = window.opener.location.origin;\n				}\n				catch ( error ) { console.warn( error ) }\n\n				// In order to prevent XSS, the speaker view will only run if its\n				// opener has the same origin as itself\n				if( window.location.origin !== openerOrigin ) {\n					connectionStatus.innerHTML = 'Cross origin error.<br>The speaker window can only be opened from the same origin.';\n					return;\n				}\n\n				var connectionTimeout = setTimeout( function() {\n					connectionStatus.innerHTML = 'Error connecting to main window.<br>Please try closing and reopening the speaker view.';\n				}, 5000 );\n\n				window.addEventListener( 'message', function( event ) {\n\n					clearTimeout( connectionTimeout );\n					connectionStatus.style.display = 'none';\n\n					var data = JSON.parse( event.data );\n\n					// The overview mode is only useful to the reveal.js instance\n					// where navigation occurs so we don't sync it\n					if( data.state ) delete data.state.overview;\n\n					// Messages sent by the notes plugin inside of the main window\n					if( data && data.namespace === 'reveal-notes' ) {\n						if( data.type === 'connect' ) {\n							handleConnectMessage( data );\n						}\n						else if( data.type === 'state' ) {\n							handleStateMessage( data );\n						}\n						else if( data.type === 'return' ) {\n							pendingCalls[data.callId](data.result);\n							delete pendingCalls[data.callId];\n						}\n					}\n					// Messages sent by the reveal.js inside of the current slide preview\n					else if( data && data.namespace === 'reveal' ) {\n						if( /ready/.test( data.eventName ) ) {\n							// Send a message back to notify that the handshake is complete\n							window.opener.postMessage( JSON.stringify({ namespace: 'reveal-notes', type: 'connected'} ), '*' );\n						}\n						else if( /slidechanged|fragmentshown|fragmenthidden|paused|resumed/.test( data.eventName ) && currentState !== JSON.stringify( data.state ) ) {\n\n							dispatchStateToMainWindow( data.state );\n\n						}\n					}\n\n				} );\n\n				/**\n				 * Updates the presentation in the main window to match the state\n				 * of the presentation in the notes window.\n				 */\n				const dispatchStateToMainWindow = debounce(( state ) => {\n					window.opener.postMessage( JSON.stringify({ method: 'setState', args: [ state ]} ), '*' );\n				}, 500);\n\n				/**\n				 * Asynchronously calls the Reveal.js API of the main frame.\n				 */\n				function callRevealApi( methodName, methodArguments, callback ) {\n\n					var callId = ++lastRevealApiCallId;\n					pendingCalls[callId] = callback;\n					window.opener.postMessage( JSON.stringify( {\n						namespace: 'reveal-notes',\n						type: 'call',\n						callId: callId,\n						methodName: methodName,\n						arguments: methodArguments\n					} ), '*' );\n\n				}\n\n				/**\n				 * Called when the main window is trying to establish a\n				 * connection.\n				 */\n				function handleConnectMessage( data ) {\n\n					if( connected === false ) {\n						connected = true;\n\n						setupIframes( data );\n						setupKeyboard();\n						setupNotes();\n						setupTimer();\n						setupHeartbeat();\n					}\n\n				}\n\n				/**\n				 * Called when the main window sends an updated state.\n				 */\n				function handleStateMessage( data ) {\n\n					// Store the most recently set state to avoid circular loops\n					// applying the same state\n					currentState = JSON.stringify( data.state );\n\n					// No need for updating the notes in case of fragment changes\n					if ( data.notes ) {\n						notes.classList.remove( 'hidden' );\n						notesValue.style.whiteSpace = data.whitespace;\n						if( data.markdown ) {\n							notesValue.innerHTML = marked( data.notes );\n						}\n						else {\n							notesValue.innerHTML = data.notes;\n						}\n					}\n					else {\n						notes.classList.add( 'hidden' );\n					}\n\n					// Update the note slides\n					currentSlide.contentWindow.postMessage( JSON.stringify({ method: 'setState', args: [ data.state ] }), '*' );\n					upcomingSlide.contentWindow.postMessage( JSON.stringify({ method: 'setState', args: [ data.state ] }), '*' );\n					upcomingSlide.contentWindow.postMessage( JSON.stringify({ method: 'next' }), '*' );\n\n				}\n\n				// Limit to max one state update per X ms\n				handleStateMessage = debounce( handleStateMessage, 200 );\n\n				/**\n				 * Forward keyboard events to the current slide window.\n				 * This enables keyboard events to work even if focus\n				 * isn't set on the current slide iframe.\n				 *\n				 * Block F5 default handling, it reloads and disconnects\n				 * the speaker notes window.\n				 */\n				function setupKeyboard() {\n\n					document.addEventListener( 'keydown', function( event ) {\n						if( event.keyCode === 116 || ( event.metaKey && event.keyCode === 82 ) ) {\n							event.preventDefault();\n							return false;\n						}\n						currentSlide.contentWindow.postMessage( JSON.stringify({ method: 'triggerKey', args: [ event.keyCode ] }), '*' );\n					} );\n\n				}\n\n				/**\n				 * Creates the preview iframes.\n				 */\n				function setupIframes( data ) {\n\n					var params = [\n						'receiver',\n						'progress=false',\n						'history=false',\n						'transition=none',\n						'autoSlide=0',\n						'backgroundTransition=none'\n					].join( '&' );\n\n					var urlSeparator = /\\?/.test(data.url) ? '&' : '?';\n					var hash = '#/' + data.state.indexh + '/' + data.state.indexv;\n					var currentURL = data.url + urlSeparator + params + '&postMessageEvents=true' + hash;\n					var upcomingURL = data.url + urlSeparator + params + '&controls=false' + hash;\n\n					currentSlide = document.createElement( 'iframe' );\n					currentSlide.setAttribute( 'width', 1280 );\n					currentSlide.setAttribute( 'height', 1024 );\n					currentSlide.setAttribute( 'src', currentURL );\n					document.querySelector( '#current-slide' ).appendChild( currentSlide );\n\n					upcomingSlide = document.createElement( 'iframe' );\n					upcomingSlide.setAttribute( 'width', 640 );\n					upcomingSlide.setAttribute( 'height', 512 );\n					upcomingSlide.setAttribute( 'src', upcomingURL );\n					document.querySelector( '#upcoming-slide' ).appendChild( upcomingSlide );\n\n				}\n\n				/**\n				 * Setup the notes UI.\n				 */\n				function setupNotes() {\n\n					notes = document.querySelector( '.speaker-controls-notes' );\n					notesValue = document.querySelector( '.speaker-controls-notes .value' );\n\n				}\n\n				/**\n				 * We send out a heartbeat at all times to ensure we can\n				 * reconnect with the main presentation window after reloads.\n				 */\n				function setupHeartbeat() {\n\n					setInterval( () => {\n						window.opener.postMessage( JSON.stringify({ namespace: 'reveal-notes', type: 'heartbeat'} ), '*' );\n					}, 1000 );\n\n				}\n\n				function getTimings( callback ) {\n\n					callRevealApi( 'getSlidesAttributes', [], function ( slideAttributes ) {\n						callRevealApi( 'getConfig', [], function ( config ) {\n							var totalTime = config.totalTime;\n							var minTimePerSlide = config.minimumTimePerSlide || 0;\n							var defaultTiming = config.defaultTiming;\n							if ((defaultTiming == null) && (totalTime == null)) {\n								callback(null);\n								return;\n							}\n							// Setting totalTime overrides defaultTiming\n							if (totalTime) {\n								defaultTiming = 0;\n							}\n							var timings = [];\n							for ( var i in slideAttributes ) {\n								var slide = slideAttributes[ i ];\n								var timing = defaultTiming;\n								if( slide.hasOwnProperty( 'data-timing' )) {\n									var t = slide[ 'data-timing' ];\n									timing = parseInt(t);\n									if( isNaN(timing) ) {\n										console.warn(\"Could not parse timing '\" + t + \"' of slide \" + i + \"; using default of \" + defaultTiming);\n										timing = defaultTiming;\n									}\n								}\n								timings.push(timing);\n							}\n							if ( totalTime ) {\n								// After we've allocated time to individual slides, we summarize it and\n								// subtract it from the total time\n								var remainingTime = totalTime - timings.reduce( function(a, b) { return a + b; }, 0 );\n								// The remaining time is divided by the number of slides that have 0 seconds\n								// allocated at the moment, giving the average time-per-slide on the remaining slides\n								var remainingSlides = (timings.filter( function(x) { return x == 0 }) ).length\n								var timePerSlide = Math.round( remainingTime / remainingSlides, 0 )\n								// And now we replace every zero-value timing with that average\n								timings = timings.map( function(x) { return (x==0 ? timePerSlide : x) } );\n							}\n							var slidesUnderMinimum = timings.filter( function(x) { return (x < minTimePerSlide) } ).length\n							if ( slidesUnderMinimum ) {\n								message = \"The pacing time for \" + slidesUnderMinimum + \" slide(s) is under the configured minimum of \" + minTimePerSlide + \" seconds. Check the data-timing attribute on individual slides, or consider increasing the totalTime or minimumTimePerSlide configuration options (or removing some slides).\";\n								alert(message);\n							}\n							callback( timings );\n						} );\n					} );\n\n				}\n\n				/**\n				 * Return the number of seconds allocated for presenting\n				 * all slides up to and including this one.\n				 */\n				function getTimeAllocated( timings, callback ) {\n\n					callRevealApi( 'getSlidePastCount', [], function ( currentSlide ) {\n						var allocated = 0;\n						for (var i in timings.slice(0, currentSlide + 1)) {\n							allocated += timings[i];\n						}\n						callback( allocated );\n					} );\n\n				}\n\n				/**\n				 * Create the timer and clock and start updating them\n				 * at an interval.\n				 */\n				function setupTimer() {\n\n					var start = new Date(),\n					timeEl = document.querySelector( '.speaker-controls-time' ),\n					clockEl = timeEl.querySelector( '.clock-value' ),\n					hoursEl = timeEl.querySelector( '.hours-value' ),\n					minutesEl = timeEl.querySelector( '.minutes-value' ),\n					secondsEl = timeEl.querySelector( '.seconds-value' ),\n					pacingTitleEl = timeEl.querySelector( '.pacing-title' ),\n					pacingEl = timeEl.querySelector( '.pacing' ),\n					pacingHoursEl = pacingEl.querySelector( '.hours-value' ),\n					pacingMinutesEl = pacingEl.querySelector( '.minutes-value' ),\n					pacingSecondsEl = pacingEl.querySelector( '.seconds-value' );\n\n					var timings = null;\n					getTimings( function ( _timings ) {\n\n						timings = _timings;\n						if (_timings !== null) {\n							pacingTitleEl.style.removeProperty('display');\n							pacingEl.style.removeProperty('display');\n						}\n\n						// Update once directly\n						_updateTimer();\n\n						// Then update every second\n						setInterval( _updateTimer, 1000 );\n\n					} );\n\n\n					function _resetTimer() {\n\n						if (timings == null) {\n							start = new Date();\n							_updateTimer();\n						}\n						else {\n							// Reset timer to beginning of current slide\n							getTimeAllocated( timings, function ( slideEndTimingSeconds ) {\n								var slideEndTiming = slideEndTimingSeconds * 1000;\n								callRevealApi( 'getSlidePastCount', [], function ( currentSlide ) {\n									var currentSlideTiming = timings[currentSlide] * 1000;\n									var previousSlidesTiming = slideEndTiming - currentSlideTiming;\n									var now = new Date();\n									start = new Date(now.getTime() - previousSlidesTiming);\n									_updateTimer();\n								} );\n							} );\n						}\n\n					}\n\n					timeEl.addEventListener( 'click', function() {\n						_resetTimer();\n						return false;\n					} );\n\n					function _displayTime( hrEl, minEl, secEl, time) {\n\n						var sign = Math.sign(time) == -1 ? \"-\" : \"\";\n						time = Math.abs(Math.round(time / 1000));\n						var seconds = time % 60;\n						var minutes = Math.floor( time / 60 ) % 60 ;\n						var hours = Math.floor( time / ( 60 * 60 )) ;\n						hrEl.innerHTML = sign + zeroPadInteger( hours );\n						if (hours == 0) {\n							hrEl.classList.add( 'mute' );\n						}\n						else {\n							hrEl.classList.remove( 'mute' );\n						}\n						minEl.innerHTML = ':' + zeroPadInteger( minutes );\n						if (hours == 0 && minutes == 0) {\n							minEl.classList.add( 'mute' );\n						}\n						else {\n							minEl.classList.remove( 'mute' );\n						}\n						secEl.innerHTML = ':' + zeroPadInteger( seconds );\n					}\n\n					function _updateTimer() {\n\n						var diff, hours, minutes, seconds,\n						now = new Date();\n\n						diff = now.getTime() - start.getTime();\n\n						clockEl.innerHTML = now.toLocaleTimeString( 'en-US', { hour12: true, hour: '2-digit', minute:'2-digit' } );\n						_displayTime( hoursEl, minutesEl, secondsEl, diff );\n						if (timings !== null) {\n							_updatePacing(diff);\n						}\n\n					}\n\n					function _updatePacing(diff) {\n\n						getTimeAllocated( timings, function ( slideEndTimingSeconds ) {\n							var slideEndTiming = slideEndTimingSeconds * 1000;\n\n							callRevealApi( 'getSlidePastCount', [], function ( currentSlide ) {\n								var currentSlideTiming = timings[currentSlide] * 1000;\n								var timeLeftCurrentSlide = slideEndTiming - diff;\n								if (timeLeftCurrentSlide < 0) {\n									pacingEl.className = 'pacing behind';\n								}\n								else if (timeLeftCurrentSlide < currentSlideTiming) {\n									pacingEl.className = 'pacing on-track';\n								}\n								else {\n									pacingEl.className = 'pacing ahead';\n								}\n								_displayTime( pacingHoursEl, pacingMinutesEl, pacingSecondsEl, timeLeftCurrentSlide );\n							} );\n						} );\n					}\n\n				}\n\n				/**\n				 * Sets up the speaker view layout and layout selector.\n				 */\n				function setupLayout() {\n\n					layoutDropdown = document.querySelector( '.speaker-layout-dropdown' );\n					layoutLabel = document.querySelector( '.speaker-layout-label' );\n\n					// Render the list of available layouts\n					for( var id in SPEAKER_LAYOUTS ) {\n						var option = document.createElement( 'option' );\n						option.setAttribute( 'value', id );\n						option.textContent = SPEAKER_LAYOUTS[ id ];\n						layoutDropdown.appendChild( option );\n					}\n\n					// Monitor the dropdown for changes\n					layoutDropdown.addEventListener( 'change', function( event ) {\n\n						setLayout( layoutDropdown.value );\n\n					}, false );\n\n					// Restore any currently persisted layout\n					setLayout( getLayout() );\n\n				}\n\n				/**\n				 * Sets a new speaker view layout. The layout is persisted\n				 * in local storage.\n				 */\n				function setLayout( value ) {\n\n					var title = SPEAKER_LAYOUTS[ value ];\n\n					layoutLabel.innerHTML = 'Layout' + ( title ? ( ': ' + title ) : '' );\n					layoutDropdown.value = value;\n\n					document.body.setAttribute( 'data-speaker-layout', value );\n\n					// Persist locally\n					if( supportsLocalStorage() ) {\n						window.localStorage.setItem( 'reveal-speaker-layout', value );\n					}\n\n				}\n\n				/**\n				 * Returns the ID of the most recently set speaker layout\n				 * or our default layout if none has been set.\n				 */\n				function getLayout() {\n\n					if( supportsLocalStorage() ) {\n						var layout = window.localStorage.getItem( 'reveal-speaker-layout' );\n						if( layout ) {\n							return layout;\n						}\n					}\n\n					// Default to the first record in the layouts hash\n					for( var id in SPEAKER_LAYOUTS ) {\n						return id;\n					}\n\n				}\n\n				function supportsLocalStorage() {\n\n					try {\n						localStorage.setItem('test', 'test');\n						localStorage.removeItem('test');\n						return true;\n					}\n					catch( e ) {\n						return false;\n					}\n\n				}\n\n				function zeroPadInteger( num ) {\n\n					var str = '00' + parseInt( num );\n					return str.substring( str.length - 2 );\n\n				}\n\n				/**\n				 * Limits the frequency at which a function can be called.\n				 */\n				function debounce( fn, ms ) {\n\n					var lastTime = 0,\n						timeout;\n\n					return function() {\n\n						var args = arguments;\n						var context = this;\n\n						clearTimeout( timeout );\n\n						var timeSinceLastCall = Date.now() - lastTime;\n						if( timeSinceLastCall > ms ) {\n							fn.apply( context, args );\n							lastTime = Date.now();\n						}\n						else {\n							timeout = setTimeout( function() {\n								fn.apply( context, args );\n								lastTime = Date.now();\n							}, ms - timeSinceLastCall );\n						}\n\n					}\n\n				}\n\n			})();\n\n		</script>\n	</body>\n</html>"), !n) return void alert("Speaker view popup failed to open. Please make sure popups are allowed and reopen the speaker view.");
                !function() {
                    const i = e.getConfig().url, s = "string" == typeof i ? i : window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search;
                    t = setInterval(function() {
                        n.postMessage(JSON.stringify({
                            namespace: "reveal-notes",
                            type: "connect",
                            state: e.getState(),
                            url: s
                        }), "*");
                    }, 500), window.addEventListener("message", r);
                }();
            }
        }
        function s(t) {
            let i = e.getCurrentSlide(), s = i.querySelector("aside.notes"), r = i.querySelector(".current-fragment"), a = {
                namespace: "reveal-notes",
                type: "state",
                notes: "",
                markdown: !1,
                whitespace: "normal",
                state: e.getState()
            };
            if (i.hasAttribute("data-notes") && (a.notes = i.getAttribute("data-notes"), a.whitespace = "pre-wrap"), r) {
                let t = r.querySelector("aside.notes");
                t ? s = t : r.hasAttribute("data-notes") && (a.notes = r.getAttribute("data-notes"), a.whitespace = "pre-wrap", s = null);
            }
            s && (a.notes = s.innerHTML, a.markdown = "string" == typeof s.getAttribute("data-markdown")), n.postMessage(JSON.stringify(a), "*");
        }
        function r(i) {
            if (function(t) {
                try {
                    return window.location.origin === t.source.location.origin;
                } catch (t) {
                    return !1;
                }
            }(i)) {
                let s = JSON.parse(i.data);
                s && "reveal-notes" === s.namespace && "connected" === s.type ? (clearInterval(t), a()) : s && "reveal-notes" === s.namespace && "call" === s.type && function(t, i, s) {
                    let r = e[t].apply(e, i);
                    n.postMessage(JSON.stringify({
                        namespace: "reveal-notes",
                        type: "return",
                        result: r,
                        callId: s
                    }), "*");
                }(s.methodName, s.arguments, s.callId);
            }
        }
        function a() {
            e.on("slidechanged", s), e.on("fragmentshown", s), e.on("fragmenthidden", s), e.on("overviewhidden", s), e.on("overviewshown", s), e.on("paused", s), e.on("resumed", s), s();
        }
        return {
            id: "notes",
            init: function(t) {
                e = t, /receiver/i.test(window.location.search) || (null !== window.location.search.match(/(\?|\&)notes/gi) ? i() : window.addEventListener("message", (t)=>{
                    if (!n && "string" == typeof t.data) {
                        let i;
                        try {
                            i = JSON.parse(t.data);
                        } catch (t) {}
                        i && "reveal-notes" === i.namespace && "heartbeat" === i.type && (e = t.source, n && !n.closed ? n.focus() : (n = e, window.addEventListener("message", r), a()));
                    }
                    var e;
                }), e.addKeyBinding({
                    keyCode: 83,
                    key: "S",
                    description: "Speaker notes view"
                }, function() {
                    i();
                }));
            },
            open: i
        };
    };
});

},{}]},["80kME","1xC6H","4vE77"], "4vE77", "parcelRequire64a3")

//# sourceMappingURL=index.js.map
